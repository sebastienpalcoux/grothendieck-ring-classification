# Exact upper-rank verification repository

This directory contains both census sources, current ledgers, new models, theoretical premise checkers, and exact historical overrides. With Python3 and SymPy installed, run from this directory:

```sh
python3 tools/verify_upper_residual_20261002b.py
python3 -O tools/verify_upper_residual_20261002b.py
```

The outer rank-seven and rank-eight verify.py entrypoints dispatch here. Historical verification uses a temporary copy; current ledgers are never rewritten to obtain a historical pass. General exclusions and scoped obstructions remain distinct.
