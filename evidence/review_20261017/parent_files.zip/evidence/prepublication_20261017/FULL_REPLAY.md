# Full upper-rank replay, including the base certificates

The current unified verifier freshly checks the latest decisions, their
source bindings and exact preservation of earlier stages. Its `--historical`
option replays those earlier finite updates. The original full base checks
are a separate step: the current supplement wrappers delegate to historical
update scripts before reaching the old all-record loops.

The helper in this directory restores the exact pre-stage-b files in a new
isolated directory. It checks the fixed source-manifest identities for all
four reversed stages, every source file in those manifests, all changed and
unchanged records, the complete canonical parent ledgers, and the prior model
files. It does not edit the source repository or change any frozen verifier.
It refuses an existing output directory or an output inside the source tree.
Restoration alone is not mathematical verification.

## Reproduce

Use normal Python for both original full checkers: some of their critical
checks use `assert`, which `python -O` removes. The optimized current-stage
run below is an additional check, not a replacement for normal Python.
The replay environment needs Python 3.12 or later, SymPy 1.14.0, NumPy 2.3.5
and a C++17 compiler available as `g++`. The signed enumeration engines compile
temporary exact integer programs. No network is used by the replay itself.

From the classification repository root:

```bash
python3 tools/restore_data.py
GRC_AUDIT=$(mktemp -d)
python3 evidence/prepublication_20261017/restore_pre_b_snapshot.py \
  --repo . --output "$GRC_AUDIT/base"

(cd "$GRC_AUDIT/base/supplements/rank7" && python3 verify.py --workers 2) \
  > "$GRC_AUDIT/rank7-full-base.log" 2>&1
(cd "$GRC_AUDIT/base/supplements/rank8/software" && python3 verify.py) \
  > "$GRC_AUDIT/rank8-full-base.log" 2>&1

python3 tools/verify_unified_20261016.py --historical \
  > "$GRC_AUDIT/unified-history.log"
python3 -O tools/verify_unified_20261016.py --historical \
  > "$GRC_AUDIT/unified-history-optimized.log"
```

Check each command's exit status. Do not interpret a timeout or interrupted
run as a pass or an exclusion. The base checks can take substantially longer
than a consistency check. Their generated reports are written in the isolated
copy; the source repository's frozen reports remain unchanged. The restoration
receipt is saved beside that copy as `base_restoration.json`.

## Coverage

| Rank | Full pre-b input | Pre-b exclusions / models / open | Later changes checked by the unified history chain | Current recorded totals |
|---:|---:|---:|---|---:|
| 7 | 4,201 records | 4,116 / 26 / 59 | 56 exclusions and 3 constructions | 4,172 / 29 / 0 |
| 8 | 973 records | 832 / 60 / 81 | 64 exclusions and 17 constructions | 896 / 77 / 0 |

The 140 later transitions are exactly the 43 + 14 + 47 + 36 decisions in
stages b, c, theoretical and unified. Exact preservation checks connect them
to the base ledgers. The full rank-eight loop also replays 75 imported
rank-eight signed proof trees and four rank-seven subring trees, and checks
six published full-tensor transfers. Census exhaustiveness and the cited
mathematical classification theorems remain explicit input dependencies.

Rank six has a direct full checker, separately from the upper-rank chain:

```bash
(cd "$GRC_AUDIT/base/supplements/rank6" && python3 verify.py --jobs 2 \
  --out "$GRC_AUDIT/rank6-full-receipts.jsonl") \
  > "$GRC_AUDIT/rank6-full.log" 2>&1
```

The rank-six supplement is unchanged by the upper-rank stage restoration,
so this also runs in the isolated copy. That run needs SciPy and python-flint
for its fresh constructors and
checks; the prepublication environment used SciPy 1.17.0 and python-flint 0.8.0.
It covers all 25,421 ledger records, reconstructs the recorded positive
models, and checks all 25,362 accepted negative certificates. It retains
`R6_4_155` and `R6_8_1660` as unresolved.

## What a successful replay means

A pass establishes the calculations and input bindings checked by these
programs. It does not prove every categorical reduction or cited theorem,
independently enumerate the upstream census, rerun the published Normaliz
searches used by appendix transfers, or constitute human verification or Lean
formalization. Read the [dated review and errata](../../docs/PREPUBLICATION_REVIEW.md)
and [research-status notice](../../docs/RESEARCH_STATUS.md) alongside the results.
