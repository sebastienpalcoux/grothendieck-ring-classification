# Complete rank-five current replay

This package contains all inputs and exact proof code needed to replay the 40,999 pinned rank-five decisions.

**AI-generated or AI-revised research: use with caution. It has not been independently human-verified or Lean-formalized.**

From this directory, run:

```sh
python evidence/prepublication_20261017/rank5/verify_current.py --jobs 2
python -O evidence/prepublication_20261017/rank5/verify_current.py --jobs 2
```

Use Python 3.12, a C++17-capable g++, and the pinned dependencies in evidence/prepublication_20261017/rank5/requirements.txt. See that directory's README, reconstruction.json, and verification receipts for provenance and limits. The reconstructed ledger is distinct from the unavailable historical decisions_all.json.
