#!/usr/bin/env python3
"""Replay all 40,999 rank-five decisions from restored, pinned tensor inputs.

This is a fresh replay entry point. Historical verifiers and receipts retain
their original scope. The unavailable historical decisions_all.json is not
represented as a recovered file: this program writes a new complete ledger.
"""
import os
for variable in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[variable] = '1'
import argparse
import collections
import concurrent.futures
import copy
import gzip
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent
REPOSITORY = ROOT.parents[2]
sys.path.insert(0, str(ROOT / 'software'))
from exact import require
from census_common import TABLES, TABLES_SHA256, canonical, check_axioms
from rings import fingerprint
import unified
import inert_parity

HISTORICAL_LEDGER_SHA256 = '9261917451d469ece9929a1756f505924cf84adf34e79a0d2e6f68fed43f55cf'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_certificate(tensor, certificate):
    if certificate['kind'] == 'inert_parity_spherical':
        inert_parity.verify(tensor, certificate['descent'])
        unified.check_sphere(tensor, certificate['sphere'], unified.check_extended_pseudo)
    else:
        unified.verify(tensor, certificate)


def check_one(item):
    key, tensor, certificate = item
    require(fingerprint(tensor) == key, 'certificate tensor fingerprint mismatch')
    verify_certificate(tensor, certificate)
    return certificate['kind']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--jobs', type=int, default=2)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--ledger-output', type=Path)
    args = parser.parse_args()
    require(1 <= args.jobs <= 16, 'jobs must lie in 1..16')
    start = time.monotonic()
    mode = 'optimized' if sys.flags.optimize else 'normal'
    output = args.output or ROOT / f'verification/current_{mode}.json'
    ledger_output = args.ledger_output or ROOT / 'verification/current_decisions.json'
    inputs = ROOT / 'data/current'
    input_manifest = json.loads((inputs / 'SHA256.json').read_text())
    require(set(input_manifest) == {'classification_tensors.json', 'exclusions.json', 'extension19_20.jsonl'}, 'current input manifest coverage')
    for name, expected in input_manifest.items():
        require(digest(inputs / name) == expected, 'current replay input hash mismatch: ' + name)
    require(digest(TABLES) == TABLES_SHA256, 'pinned census tensor hash mismatch')
    rows = json.loads((inputs / 'classification_tensors.json').read_text())
    cache = json.loads((inputs / 'exclusions.json').read_text())
    extension = [json.loads(line) for line in (inputs / 'extension19_20.jsonl').read_text().splitlines()]
    registry = json.loads((ROOT / 'data/positive_models.json').read_text())
    historical_frontier = json.loads((ROOT / 'data/frontier.json').read_text())
    require(unified.build_model_registry() == registry, 'positive constructions changed')
    modelmap = {canonical(record['tensor']): i for i, record in enumerate(registry)}
    require(len(modelmap) == 17, 'positive model count')

    pinned, source_counts, source_extension = set(), collections.Counter(), []
    with gzip.open(TABLES, 'rt') as stream:
        for line in stream:
            tensor = json.loads(line.replace('{', '[').replace('}', ']'))
            check_axioms(tensor)
            key = canonical(tensor)
            require(key not in pinned, 'duplicate pinned tensor isomorphism class')
            pinned.add(key)
            m = max(x for matrix in tensor for row in matrix for x in row)
            require(1 <= m <= 20, 'unexpected pinned multiplicity')
            source_counts[m] += 1
            if m in (19, 20):
                source_extension.append((m, source_counts[m], tensor))
    require(len(pinned) == 40999 and len(rows) == 28493, 'pinned census size')
    require(len(source_extension) == len(extension) == 12506, 'extension size')

    seen, models_seen = set(), set()
    local_indices, verified_counts = collections.Counter(), collections.Counter()
    ledger, work, work_m = [], [], []
    tensors = {}
    for row in rows:
        tensor = row['N']
        check_axioms(tensor)
        key, can = fingerprint(tensor), canonical(tensor)
        require(can in pinned and can not in seen, 'prefix census crosswalk mismatch')
        seen.add(can)
        tensors[key] = tensor
        m = max(x for matrix in tensor for vec in matrix for x in vec)
        require(row['m'] == m <= 18, 'prefix multiplicity mismatch')
        local_indices[m] += 1
        require(row['local_index'] == local_indices[m], 'prefix local-index gap')
        dual = unified.dual(tensor)
        dtype = 'S' if dual == list(range(5)) else 'N2' if sum(dual[i] != i for i in range(5)) == 2 else 'N4'
        require(row['duality_type'] == dtype, 'prefix duality mismatch')
        model = modelmap.get(can)
        require(int(key in cache) + int(model is not None) == 1, 'prefix decision overlap or gap')
        record = {'m': m, 'j': row['j'], 'local_index': row['local_index'], 'fingerprint': key}
        if model is not None:
            match = unified.match_model(tensor, registry)
            require(match is not None, 'positive model basis isomorphism missing')
            models_seen.add(model)
            record.update(general='realized', pivotal='realized', spherical='realized', pseudo_unitary='realized', unitary='realized', criterion='unitary_model', model=match)
        else:
            cert = cache[key]
            work.append((key, tensor, cert))
            work_m.append(m)
            record.update(general='excluded', pivotal='excluded', spherical='excluded', pseudo_unitary='excluded', unitary='excluded', criterion=cert['kind'])
        ledger.append(record)
        verified_counts[m] += 1
    require(models_seen == set(range(17)), 'positive model coverage')
    require(set(cache) == {key for key, tensor, cert in work}, 'extraneous prefix certificate')
    require(len(historical_frontier) == 2, 'historical frontier size')
    for old in historical_frontier:
        key = old['fingerprint']
        require(old['N'] == tensors[key], 'historical frontier tensor changed')
        require(cache[key]['kind'] == 'inert_parity_spherical', 'historical frontier lacks inert closure')
        require(cache[key]['sphere'] == old['spherical_certificate'], 'historical spherical witness changed')

    for record, (m, index, tensor) in zip(extension, source_extension):
        key, can = fingerprint(tensor), canonical(tensor)
        require(record['m'] == m and record['repository_index'] == index, 'extension source order mismatch')
        require(record['N'] == tensor and record['fingerprint'] == key, 'extension source tensor mismatch')
        require(can not in seen, 'extension repeats an isomorphism class')
        seen.add(can)
        cert = record['certificate']
        require(cert is not None and record['criterion'] == cert['kind'], 'extension certificate missing')
        work.append((key, tensor, cert))
        work_m.append(m)
        ledger.append({'m': m, 'repository_index': index, 'fingerprint': key, 'general': 'excluded', 'pivotal': 'excluded', 'spherical': 'excluded', 'pseudo_unitary': 'excluded', 'unitary': 'excluded', 'criterion': cert['kind']})
        verified_counts[m] += 1
    require(seen == pinned and verified_counts == source_counts, 'complete census coverage mismatch')
    require(len(work) == 40982, 'general exclusion count')
    print('PASS exact pinned census coverage: 40,999 classes; 17 unitary model tensors.', flush=True)
    allocation = collections.defaultdict(collections.Counter)
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.jobs) as workers:
        for i, kind in enumerate(workers.map(check_one, work, chunksize=20)):
            allocation[work_m[i]][kind] += 1
            if (i + 1) % 2000 == 0:
                print(f'{i + 1}/{len(work)} general exclusion certificates checked.', flush=True)

    from regression_tests import run
    controls = run(rows, cache, registry)
    inert_mutations = 0
    for old in historical_frontier:
        for mutation in ('wrong_field', 'missing_residues', 'missing_spherical_characters'):
            bad = copy.deepcopy(cache[old['fingerprint']])
            if mutation == 'wrong_field':
                bad['descent']['q'] += 1
            elif mutation == 'missing_residues':
                bad['descent']['allowed_residue_characters'] = []
            else:
                bad['sphere']['characters'] = []
            rejected = False
            try:
                verify_certificate(old['N'], bad)
            except Exception:
                rejected = True
            require(rejected, 'mutated inert composite was accepted: ' + mutation)
            inert_mutations += 1
    controls['inert_parity_mutation_cases'] = inert_mutations

    status_file = REPOSITORY / 'data/classification_status.json'
    published = json.loads(status_file.read_text())
    require(published['inputs']['rank5']['sha256'] == HISTORICAL_LEDGER_SHA256, 'historical ledger reference changed')
    require(published['inputs']['rank5']['classified_through'] == 20, 'published bound changed')
    require(published['inputs']['rank5']['status_totals'] == {'realized': 17, 'excluded': 40982}, 'published status totals changed')
    published_rows = {r['multiplicity']: r for r in published['rows'] if r['rank'] == 5 and r['multiplicity'] <= 20}
    require(set(published_rows) == set(range(1, 21)), 'published multiplicity coverage')
    for m in range(1, 21):
        row = published_rows[m]
        realized = sum(r['m'] == m and r['general'] == 'realized' for r in ledger)
        require(row['rings'] == verified_counts[m], 'published census count mismatch')
        require(row['excluded_general'] == sum(allocation[m].values()), 'published exclusion count mismatch')
        require(row['realized_unitary'] + row['realized_other_or_unspecified'] == realized, 'published realization count mismatch')
        require(row['unresolved_general'] == row['unassessed'] == 0, 'published scope mismatch')
    ledger_bytes = (json.dumps(ledger, separators=(',', ':')) + '\n').encode()
    ledger_output.parent.mkdir(parents=True, exist_ok=True)
    ledger_output.write_bytes(ledger_bytes)
    sources = {str(path.relative_to(ROOT)): digest(path) for path in sorted((ROOT / 'software').iterdir()) if path.suffix in ('.py', '.cpp', '.hpp')}
    sources[Path(__file__).name] = digest(Path(__file__))
    report = {'status': 'PASS', 'mode': mode, 'python': sys.version, 'complete_general_bound': 20,
              'checked_tensors': len(ledger), 'positive_models': 17, 'general_exclusions': len(work),
              'pinned_repository_commit': 'b86eb6dc6eeeafe5fc5f6906d7b074e0322e9726',
              'pinned_tables_sha256': TABLES_SHA256, 'reconstruction_inputs_sha256': input_manifest,
              'proof_sources_sha256': sources, 'classification_status_sha256': digest(status_file),
              'historical_ledger_reference_sha256': HISTORICAL_LEDGER_SHA256,
              'historical_ledger_bytes_recovered': False,
              'fresh_ledger_sha256': hashlib.sha256(ledger_bytes).hexdigest(),
              'fresh_ledger_matches_historical_hash': hashlib.sha256(ledger_bytes).hexdigest() == HISTORICAL_LEDGER_SHA256,
              'counts': dict(sorted(verified_counts.items())),
              'criterion_allocation': {m: dict(sorted(counts.items())) for m, counts in sorted(allocation.items())},
              'regressions': controls, 'seconds': round(time.monotonic() - start, 3)}
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2), flush=True)
    print('PASS: every current rank-five decision replayed from pinned source tensors.', flush=True)


if __name__ == '__main__':
    main()
