# Rank-five full replay: multiplicity at most 20

This fresh replay package checks all **40,999** pinned rank-five tensors: **17 unitary model matches** and **40,982 general exclusions**. It supplies the data missing from the older compact supplement and dispatches the two inert-prime parity closures that its historical entry point omitted.

**Use these results and data with caution. The mathematical arguments, code, and this audit were generated or revised with AI assistance. They have not been independently verified by a human expert or formalized in Lean. A successful replay checks the encoded exact arithmetic and coverage; it does not independently certify the mathematical theorems connecting those computations to fusion categories.**

All input files are included in this package. From the extracted `rank5_current_replay/` directory, run:

```sh
python evidence/prepublication_20261017/rank5/verify_current.py --jobs 2
python -O evidence/prepublication_20261017/rank5/verify_current.py --jobs 2
```

Use Python 3.12 with the versions in `requirements.txt` and a C++17-capable `g++` compiler. The checker compiles its small exact enumeration helpers in temporary directories. The `--output` and `--ledger-output` options place fresh receipts and decisions at paths of your choosing.

The checker validates the exact pinned census-table hash, all fusion axioms, uniqueness under all 24 unit-preserving basis permutations, every tensor-to-certificate binding, the 17 explicit positive tensors, all 40,982 exclusion certificates, and the existing secondary controls. It also rejects corrupted inert-prime certificates and compares every published multiplicity-band count and status with the freshly checked decisions. Its proof conditions use explicit exceptions, including under `python -O`.

The pinned source is `fusion-ring-census` commit `b86eb6dc6eeeafe5fc5f6906d7b074e0322e9726`; the compressed rank-five table has SHA-256 `4542c0871498337ef38ce3903407933289699a5ff06c85ad0f6c2bd57da823fb`.

The older release referenced a complete archive and a `decisions_all.json` ledger with SHA-256 `9261917451d469ece9929a1756f505924cf84adf34e79a0d2e6f68fed43f55cf`. Those final archive/ledger bytes were not recovered for this audit. That digest is retained as a historical reference, not presented as a verified digest of the reconstructed ledger. This replay writes `verification/current_decisions.json`, records its actual digest, and explicitly reports whether it matches the historical digest.

The prefix inputs come from the checksummed original `Rank5_Unified_Frontier.zip`. Its two historical spherical witnesses are retained exactly and composed with the existing tensor-derived inert-prime parity criterion. The multiplicity-19/20 tensors come from `rank5_multiplicity20_verified.zip`, whose table matches the pinned hash exactly; their exclusion certificates were freshly generated using the existing proof engine and are then replayed using exact arithmetic. Discovery may use numerical linear programming to propose rational certificates. Replay checks those certificates exactly and does not call numerical linear programming.

`reconstruction.json` identifies the recovered archives, transformations, code hashes, and limits. `data/current/SHA256.json` binds every reconstructed input. Historical evidence elsewhere in the repository is unchanged. No claim is made for multiplicity 21 or above.
