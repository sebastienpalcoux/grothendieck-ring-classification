"""Independent exact audit of the C18 isotropic-orbifold model for R1848.
Does not import the proposed model's generator or use its saved model tensor.
"""
import json,itertools,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent;ROOT=P.parents[1]
R=json.load(open(ROOT/'work/verification_corpus.json'))['tensors']['R9_2_1848']
record=json.load(open(ROOT/'phase5/quadratic_noncomm/1848_model.json'))
assert record['source_tensor']==R
G=range(18);H={0,6,12};perp={x for x in G if all(x*h%18==0 for h in H)}
assert perp=={0,3,6,9,12,15} and H<=perp
assert all(h*h%36==0 for h in H)
# Independent source labels assigned by the displayed map, then derive every
# product directly from the quotient groups and Theorem12.5.
p=[0,1,4,8,3,2,5,7,6];assert p==record['model_to_census']
def invertible(a):return p[a%6]
def noninvertible(a):return p[6+a%3]
def product(i,j):
 terms={}
 def put(k,m=1):terms[k]=terms.get(k,0)+m
 if i<6 and j<6:put(invertible(i+j))
 elif i<6:put(noninvertible(i+j-6))
 elif j<6:put(noninvertible(i-6-j))
 else:
  # (g^a sigma)(g^b sigma) = g^(a-b) sigma^2.
  a,b=i-6,j-6
  # Representatives of Hperp/H inside C18/H are0,3.
  for k in [0,3]:put(invertible(a-b+k))
  for k in range(3):put(noninvertible(a-b+k),2)
 return [terms.get(k,0)for k in range(9)]
assert all(product(i,j)==R[p[i]][p[j]]for i,j in itertools.product(range(9),repeat=2))
assert all(R[i][0][j]==R[0][i][j]==int(i==j)for i,j in itertools.product(range(9),repeat=2))
dual=[next(j for j in range(9)if R[i][j][0])for i in range(9)]
assert all(R[i][j][k]==R[dual[i]][k][j]==R[k][dual[j]][i]for i,j,k in itertools.product(range(9),repeat=3))
assert all(sum(R[i][j][u]*R[u][k][l]for u in range(9))==sum(R[i][u][l]*R[j][k][u]for u in range(9))for i,j,k,l in itertools.product(range(9),repeat=4))
# Exact FP dimensions over Q(sqrt11).
def mul(x,y):return (x[0]*y[0]+11*x[1]*y[1],x[0]*y[1]+x[1]*y[0])
ds=[(1,0)if i in p[:6]else(3,1)for i in range(9)]
assert all(mul(ds[i],ds[j])==tuple(sum(R[i][j][k]*ds[k][a]for k in range(9))for a in range(2))for i,j in itertools.product(range(9),repeat=2))
# The group C18 quotient arithmetic is independent of a representative m:
# all unit pairings have the same Hperp and all allowed quadratic refinements
# restrict trivially to this odd isotropic subgroup.
for m in [m for m in range(36)if __import__('math').gcd(m,18)==1]:
 assert {x for x in G if all(m*x*h%18==0 for h in H)}==perp
 assert all(m*h*h%36==0 for h in H)
receipt={'status':'PASS','id':'R9_2_1848','model_to_census':p,'all_729_coefficients_match':True,'source_hash':hashlib.sha256(json.dumps(R,separators=(',',':')).encode()).hexdigest(),'unit':True,'associativity':True,'both_Frobenius_reciprocity_identities':True,'duality':dual,'exact_FPdim_equations':True,'isotropic_H':[0,6,12],'Hperp':sorted(perp),'a_restriction_trivial':True,'hypotheses_for_all_unit_pairings_on_C18':True,'associator_scope':'Existence supplied by cited Budinski2021 exact construction and Izumi2015 Theorem12.5; not reconstructed by this audit.'}
(P/'independent_verification.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
