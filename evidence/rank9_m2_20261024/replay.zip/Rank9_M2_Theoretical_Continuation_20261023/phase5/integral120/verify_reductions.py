#!/usr/bin/env python3
"""Exact standard-library replay for phase-five dimension-120 reductions.

Categorical theorems are stated in THEORY.md; this checks finite hypotheses.
Run without -O. No repository checkout, GAP, NumPy or SymPy is required.
"""
from pathlib import Path
from fractions import Fraction
from collections import Counter
from itertools import product
import gzip, hashlib, json
if not __debug__:
    raise SystemExit("Do not run this verifier with -O")
HERE=Path(__file__).resolve().parent
BASE=HERE.parents[1]
SOURCE=BASE/'inputs/rank9_M2_verified/FusionRingMultiplicationTables.txt.gz'
DIMS={12:[1,1,1,2,6,6,2,1,6],959:[1,1,1,2,6,6,6,2,1]}

def matmul(a,b):
    return [[sum(x*y for x,y in zip(row,col)) for col in zip(*b)] for row in a]

def rank(a):
    a=[[Fraction(x) for x in row] for row in a];r=0
    for j in range(len(a[0])):
        s=next((s for s in range(r,len(a)) if a[s][j]),None)
        if s is None:continue
        a[r],a[s]=a[s],a[r];p=a[r][j];a[r]=[v/p for v in a[r]]
        for s in range(r+1,len(a)):
            p=a[s][j]
            if p:a[s]=[x-p*y for x,y in zip(a[s],a[r])]
        r+=1
    return r

def read_targets():
    counts=Counter();out={}
    for physical,line in enumerate(gzip.open(SOURCE,'rt'),1):
        R=json.loads(line.replace('{','[').replace('}',']'))
        m=max(x for a in R for b in a for x in b);counts[m]+=1
        if m==2 and counts[m] in DIMS:out[counts[m]]=(physical,R)
    assert set(out)==set(DIMS)
    return out

def closure(R,items):
    ans=set(items)|{0}
    while True:
        new=ans|{k for i in ans for j in ans for k,v in enumerate(R[i][j]) if v}
        if new==ans:return sorted(ans)
        ans=new

def check_one(num,physical,R):
    n=len(R);d=DIMS[num];assert n==9
    dual=[next(j for j in range(n) if R[i][j][0]) for i in range(n)]
    for i,j,k in product(range(n),repeat=3):
        assert isinstance(R[i][j][k],int) and R[i][j][k]>=0
        assert R[i][j][k]==R[j][i][k]
        assert R[0][i][j]==(i==j)
        assert R[i][j][0]==(j==dual[i])
        assert R[i][j][k]==R[dual[i]][k][j]
        assert sum(R[i][j][a]*d[a] for a in range(n))==d[i]*d[j]
    for i,j,k,l in product(range(n),repeat=4):
        assert sum(R[i][j][a]*R[a][k][l] for a in range(n))==sum(R[j][k][a]*R[i][a][l] for a in range(n))
    adj=closure(R,{k for i in range(n) for k,v in enumerate(R[i][dual[i]]) if v})
    assert adj==list(range(n));assert sum(x*x for x in d)==120
    # Commutativity makes all irreducible based-algebra representations 1-dimensional.
    # Thus the eigenvalues of this Casimir multiplication matrix are formal codegrees.
    cas=[[0]*n for _ in range(n)]
    for i in range(n):
        t=matmul(R[i],R[dual[i]])
        cas=[[x+y for x,y in zip(a,b)] for a,b in zip(cas,t)]
    eigens={4:2,6:2,20:1,24:1,30:2,120:1}
    for val,multip in eigens.items():
        assert n-rank([[cas[i][j]-val*(i==j) for j in range(n)] for i in range(n)])==multip
    assert sum(eigens.values())==n
    indu=sorted(120//val for val,mult in eigens.items() for _ in range(mult))
    assert indu==[1,4,4,5,6,20,20,30,30] and sum(indu)==120
    # Every dimension-60 subobject of I(1) containing its unit includes dimension 5.
    halves=[]
    for bits in product((0,1),repeat=8):
        chosen=[indu[0]]+[v for v,b in zip(indu[1:],bits) if b]
        if sum(chosen)==60:
            assert 5 in chosen;halves.append(chosen)
    assert halves
    inv=[i for i,x in enumerate(d) if x==1]
    involutions=[g for g in inv if g and R[g][g][0]==1]
    descended=[]
    for g in involutions:
        perm=[row.index(1) for row in R[g]]
        todo=set(range(n));dd=[];orbits=[]
        while todo:
            i=min(todo);orbit=sorted({i,perm[i]});todo-=set(orbit);orbits.append(orbit)
            if len(orbit)==1:
                assert d[i]%2==0;dd.extend([d[i]//2]*2)
            else:dd.append(d[i])
        assert sum(v*v for v in dd)==60
        assert sorted(dd) in [[1,1,2,3,3,6],[1]*6+[3]*6]
        descended.append({'underlying_involution':g,'permutation':perm,'orbits':orbits,'descended_dimensions':sorted(dd)})
    return {'id':f'R9_2_{num}','physical_line':physical,'tensor_sha256':hashlib.sha256(json.dumps(R,separators=(',',':')).encode()).hexdigest(),'dimensions':d,'adjoint_closure':adj,'formal_codegrees_with_multiplicity':eigens,'induction_dimensions':indu,'dimension60_unit_containing_induction_subobjects':halves,'central_C2_possible_descents':descended,'ring_axioms_and_associativity':True}

def rank12_gradings():
    # For D of type (1^6,3^6), every 3-simple has stabilizer exactly C3.
    # Thus D_ad has at least three invertibles and at least one 3-simple.
    patterns=[]
    for u in range(2,61):
        if 60%u:continue
        component_dim=60//u
        packets=[(a,b) for a in range(7) for b in range(7) if a+9*b==component_dim]
        neutrals=[p for p in packets if p[0] in [3,6] and p[1]>=1]
        def rec(left,a,b,acc):
            if left==0:
                if a==b==0:yield acc
                return
            for x,y in packets:
                if x<=a and y<=b:yield from rec(left-1,a-x,b-y,acc+[(x,y)])
        for a,b in neutrals:
            for rest in rec(u-1,6-a,6-b,[]):patterns.append({'order':u,'component_types':[(a,b)]+rest})
    assert patterns==[{'order':2,'component_types':[(3,3),(3,3)]}]
    return patterns

def main():
    targets=read_targets()
    old=BASE/'phase4/integral/GT_verification.json'
    audit=BASE/'phase4/audit_integral_gt/audit_verdict.json'
    receipt=json.loads(old.read_text());verdict=json.loads(audit.read_text())
    assert verdict['status']=='PASS'
    needed={'R9_2_12','R9_2_959'}
    assert needed<=set(receipt['accepted_group_theoretical_exclusions'])
    assert needed<=set(verdict['group_theoretical_exclusions'])
    for name,sha in verdict['source_sha256_after_corrections'].items():
        assert hashlib.sha256((BASE/'phase4/integral'/name).read_bytes()).hexdigest()==sha
    # The rank-six descent has no nontrivial grading, already from dimensions.
    assert 6**2>60/2
    rank6_descended=[1,1,1,3,3,3]
    assert sum(x*x for x in rank6_descended)==30
    out={'kind':'dimension120_general_exclusion_finite_certificate','checks':[check_one(k,*v) for k,v in sorted(targets.items())],'type_1six_3six_possible_nontrivial_gradings':rank12_gradings(),'rank6_dimension60_largest_simple_square':36,'rank6_solvable_C2_descent_dimensions':rank6_descended,'phase4_GT_dependency':{'receipt_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'independent_audit_sha256':hashlib.sha256(audit.read_bytes()).hexdigest(),'status':'PASS; all recorded audited source hashes match'},'categorical_dependencies':'THEORY.md; exact arithmetic checks do not certify the cited categorical theorems','general_exclusion_theorem_ids':sorted(needed),'independent_phase5_audit':'pending; not substituted by this finite replay','status':'PASS finite hypotheses; proposed general exclusions are proved in THEORY.md'}
    (HERE/'reductions_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
    print('PASS: exact ring, formal-codegree, induction-parity, C2-descent and grading hypotheses')
if __name__=='__main__':main()
