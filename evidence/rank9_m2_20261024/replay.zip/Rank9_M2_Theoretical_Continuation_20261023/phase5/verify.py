"""Replay accepted phase-five premises and check the complete classification.
The categorical proofs have separate human-readable adversarial audits.
"""
from pathlib import Path
import json,hashlib,itertools,collections,subprocess,sys
P=Path(__file__).resolve().parent;B=P.parent
def need(c,m):
    if not c:raise ValueError(m)
def read(rel):return json.loads((B/rel).read_text())
def main():
    need(__debug__,'Run without -O')
    scripts=['integral120/verify_reductions.py','audit_integral120/independent_checks.py','integral168/verify_general_exclusion.py','audit_integral168/independent_replay.py','case941/verify_odd_columns.py','root/verify_941_independent.py','quadratic_noncomm/verify_1848_model.py','audit_model1848/verify_independent.py']
    if '--frontier' in sys.argv:
        scripts+=['quadratic_comm/verify_packaged_records.py','quadratic_comm/ty_module_subtask/forced_associator_check.py','orbifold_scope/verify_orbifold.py','audit_orbifold_scope/verify_independent.py','quadratic_noncomm/probe_order32_canonical_algebra.py','quadratic_noncomm/check_1975_forced_associator.py']
    replays=[]
    for rel in scripts:
        r=subprocess.run([sys.executable,str(P/rel)],cwd=B,capture_output=True,text=True,timeout=120)
        need(r.returncode==0,rel+': '+r.stdout+r.stderr)
        replays.append({'script':rel,'status':'PASS'})
    old=read('phase4/results/ledger.json');new=read('phase5/results/ledger.json');summary=read('phase5/results/summary.json')
    need(hashlib.sha256((B/'phase4/results/ledger.json').read_bytes()).hexdigest()==summary['baseline_ledger_sha256'],'baseline ledger hash')
    E={f'R9_2_{i}' for i in (12,941,959,1965)};M={'R9_2_1848'};U={f'R9_2_{i}' for i in (137,1607,1975,1976)}
    need(len(old)==len(new)==2083,'ledger length')
    corpus=read('work/verification_corpus.json')['tensors']
    for a,b in zip(old,new):
        need(a['id']==b['id'] and a['tensor_sha256']==b['tensor_sha256'],'identity changed')
        need(hashlib.sha256(json.dumps(corpus[b['id']],separators=(',',':')).encode()).hexdigest()==b['tensor_sha256'],'source tensor hash')
        if b['id'] in E:
            need(a['status']=='unresolved' and b['status']=='excluded' and len(b['exclusion_certificates'])==1,'exclusion transition')
            c=b['exclusion_certificates'][0]
            for k in ('record_file','proof','independent_audit'):need((B/c[k]).is_file(),'missing exclusion evidence '+c[k])
            need(c['scope']=='general_complex_fusion_category','scope')
        elif b['id'] in M:
            need(a['status']=='unresolved' and b['status']=='unitarily_realized' and len(b['models'])==1,'model transition')
        else:
            need(a['status']==b['status'] and a['models']==b['models'] and a['exclusion_certificates']==b['exclusion_certificates'],'unrelated decision changed')
    counts=collections.Counter(r['status'] for r in new)
    need(counts=={'excluded':2043,'unitarily_realized':36,'unresolved':4},'partition')
    unresolved=read('phase5/results/unresolved.json');need({r['id'] for r in unresolved}==U,'residual set')
    need(all(r['categorification_scopes']['braided']=='excluded' for r in unresolved),'residual braided scope')
    models=read('phase5/results/models.json');need(len(models)==36 and len({r['id'] for r in models})==36,'models unique')
    for m in models:
        R=corpus[m['id']];T=m['tensor'];p=m['basis_map_source_to_model']
        need(sorted(p)==list(range(9)) and p[0]==0,'basis map')
        need(all(R[i][j][k]==T[p[i]][p[j]][p[k]] for i,j,k in itertools.product(range(9),repeat=3)),'tensor transport '+m['id'])
        if m['id'] in M:
            for k in ('record_file','proof','independent_audit'):need((B/m[k]).is_file(),'missing model evidence')
    out={'status':'PASS','input_decisions':2083,'partition':dict(counts),'all_36_model_tensor_coefficients':36*729,'new_model_tensor_coefficients':729,'new_general_exclusions':4,'new_unitary_models':1,'remaining':sorted(U,key=lambda s:int(s.split('_')[-1])),'replays':replays,'scope':'Exact finite replays and separate categorical audits; not a proof-assistant formalization.','online_changes':False}
    (P/'verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
