"""Independent exact replay of the dimension-63 parity lemma, without imports
from the author's verifier or its enumerated candidate list.
"""
from pathlib import Path
from fractions import Fraction as F
import json, itertools, hashlib

P=Path(__file__).resolve().parent
R=json.loads((P.parents[1]/'work/verification_corpus.json').read_text())['tensors']['R9_2_941']
d=[1,7,8,7,7,7,9,9,9]
assert sum(x*x for x in d)==504
bs=[1,3,4,5]; cs=[6,7,8]
ch8=[1,-1,0,-1,-1,-1,1,1,1]
ch9=[]
for j in bs:
    ch=[0]*9;ch[0]=1;ch[2]=-1
    for k in bs:ch[k]=1-3*(k==j)
    ch9.append(ch)
for ch in [d,ch8,*ch9]:
    assert all(ch[i]*ch[j]==sum(R[i][j][k]*ch[k] for k in range(9)) for i,j in itertools.product(range(9),repeat=2))
# Directly compute FI, independently of the Casimir matrix implementation.
B=[[sum(R[t][j][q]*R[q][t][i] for t,q in itertools.product(range(9),repeat=2)) for j in range(9)] for i in range(9)]
assert all(sum(B[i][j]*d[j] for j in range(9))==504*d[i] for i in range(9))

def compositions(total,parts):
    if parts==1:
        yield (total,);return
    for v in range(total+1):
        for tail in compositions(total-v,parts-1):yield (v,*tail)

aggregates=set();pre=[];survive=[]
for t in (0,1):
    for a in range(8):
        for b in range(10):
            rest=63-t-8*a-7*b
            if rest<0 or rest%9:continue
            c=rest//9;r=(t+a)%7
            if c>=3*r and (c-3*r)%7==0:aggregates.add((t,a,b,c))
            for bv in compositions(b,4):
                if any((t+b-a-3*x)%9 for x in bv):continue
                for cv in compositions(c,3):
                    if any((x-t-a)%7 for x in cv):continue
                    s=t+a
                    trace7=3*s*s-2*s*c+5*sum(x*x for x in cv)-4*sum(cv[i]*cv[j] for i in range(3) for j in range(i))
                    norm=F(63**2,504**2)+F((t-b+c)**2,64)+sum(F((t+b-a-3*x)**2,81) for x in bv)+F(trace7,49)
                    v=[0]*9;v[0]=t;v[2]=a
                    for j,x in zip(bs,bv):v[j]=x
                    for j,x in zip(cs,cv):v[j]=x
                    pre.append(v)
                    if norm<=1:survive.append({'v':v,'norm':str(norm)})
assert len(aggregates)==7
assert {tuple(x['v']) for x in survive}=={(0,1,1,1,1,1,1,1,1),(1,0,1,0,0,0,2,2,2)}
# Low odd dimensions allow no Y-coordinate; only dimension-nine columns
# contribute a C-coordinate. This uses only dimensions and the I(1) list.
odd=[x for x in range(1,505,2) if 504%x==0]
assert odd==[1,3,7,9,21,63]
def weighted_vectors(weights,z):
    if not weights:
        if z==0:yield ()
        return
    for a in range(z//weights[0]+1):
        for tail in weighted_vectors(weights[1:],z-a*weights[0]):yield (a,*tail)
for z in [3,7,9,21]:
    for v in weighted_vectors(d[1:],z):
        assert v[1]==0
        assert all(x==0 for x in v[5:]) or (z==9 and sum(v)==1)
out={'status':'PASS','tensor_sha256':hashlib.sha256(json.dumps(R,separators=(',',':')).encode()).hexdigest(),'seven_aggregate_cases':sorted(aggregates),'congruence_vectors_before_norm':len(pre),'dimension63_survivors':survive,'odd_divisors':odd,'central_character_identity_source':'Ostrik1309.4822 Example2.9 and paragraph before Theorem2.13','scope':'Independent arithmetic replay; categorical review is in AUDIT_941.md.'}
(P/'941_independent_receipt.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
