#!/usr/bin/env python3
"""Independent finite-premise audit; does not import the author's verifier."""
import gzip
import hashlib
import itertools
import json
from pathlib import Path
import sympy as sp

HERE = Path(__file__).resolve().parent
BASE = HERE.parents[1]

def need(p, reason):
    if not p:
        raise RuntimeError(reason)

def h(obj):
    return hashlib.sha256(json.dumps(obj, separators=(",", ":")).encode()).hexdigest()

corpus = json.loads((BASE / "work/verification_corpus.json").read_text())["tensors"]
raw = {}
counter = 0
with gzip.open(BASE / "inputs/rank9_M2_verified/FusionRingMultiplicationTables.txt.gz", "rt") as f:
    for line in f:
        R = json.loads(line.replace("{", "[").replace("}", "]"))
        if max(x for row in R for v in row for x in v) == 2:
            counter += 1
            if counter in (12, 959):
                raw[counter] = R

out = {"status": "PASS", "cases": []}
for case in [12, 959]:
    R = corpus[f"R9_2_{case}"]
    need(R == raw[case], "independent corpus/raw-input binding")
    n = len(R)
    ds = [1,1,1,2,6,6,2,1,6] if case == 12 else [1,1,1,2,6,6,6,2,1]
    dual = [next(j for j in range(n) if R[i][j][0]) for i in range(n)]
    for i,j,k in itertools.product(range(n), repeat=3):
        need(R[i][j][k] == R[j][i][k], "commutativity")
        need(R[i][j][k] == R[dual[i]][k][j], "reciprocity")
        need(R[i][j][0] == int(j == dual[i]), "unit coefficient")
    for i,j in itertools.product(range(n), repeat=2):
        need(sum(R[i][j][k]*ds[k] for k in range(n)) == ds[i]*ds[j], "positive dimension character")
    for i,j,k,l in itertools.product(range(n), repeat=4):
        need(sum(R[i][j][a]*R[a][k][l] for a in range(n)) ==
             sum(R[j][k][a]*R[i][a][l] for a in range(n)), "associativity")
    adj = {k for i in range(n) for k in range(n) if R[i][dual[i]][k]}
    while True:
        extra = {k for i in adj for j in adj for k in range(n) if R[i][j][k]}
        if extra <= adj: break
        adj |= extra
    need(adj == set(range(n)), "trivial universal grading")
    # Full noncommutative FI formula, independently of the author's Casimir method.
    B = sp.Matrix([[sum(R[t][j][k]*R[k][dual[t]][i] for t in range(n) for k in range(n))
                    for j in range(n)] for i in range(n)])
    t = sp.Symbol("t")
    expected = (t-120)*(t-24)*(t-20)*(t-30)**2*(t-6)**2*(t-4)**2
    need(sp.expand(B.charpoly(t).as_expr()-expected) == 0, "formal codegree polynomial")
    induction = [1,5,6,4,4,20,20,30,30]
    parity = []
    for signs in itertools.product([-1,1], repeat=8):
        eps = [1]+list(signs)
        if sum(a*b for a,b in zip(eps,induction)) == 0:
            need(eps[1] == 1, "fermion parity must centralize five-dimensional summand")
            parity.append(eps)
    need(parity, "nonvacuous parity equations")
    inv = [i for i in range(n) if ds[i] == 1]
    involutions = [g for g in inv if g != 0 and R[g][g][0] == 1]
    need(involutions == ([1,2,7] if case == 12 else [8]), "complete involution list")
    descents = {}
    for g in involutions:
        seen=set(); target=[]; orbits=[]
        for i in range(n):
            if i in seen: continue
            j=next(k for k in range(n) if R[g][i][k])
            need(sum(R[g][i]) == 1, "invertible action")
            orb=sorted({i,j}); seen.update(orb); orbits.append(orb)
            if i==j:
                need(ds[i] % 2 == 0, "integral split dimension")
                target.extend([ds[i]//2,ds[i]//2])
            else:
                target.append(ds[i])
        target.sort()
        expected_target = [1,1,2,3,3,6] if case==12 and g in (1,2) else [1]*6+[3]*6
        need(target == expected_target, "complete descent type")
        descents[str(g)]={"orbits":orbits,"dimensions":target}
    out["cases"].append({"id":f"R9_2_{case}","tensor_sha256":h(R),
                         "formal_codegree_polynomial":str(sp.factor(expected)),
                         "induction_dimensions":induction,"fermion_sign_solutions":parity,
                         "involutions":involutions,"descents":descents,
                         "full_induction_gram":B.tolist()})

# Independent grading bookkeeping: neutral component includes a subgroup of 3
# invertibles and a three-dimensional simple; enumerate all possible component
# dimensions and check that the remaining simple counts admit a partition.
patterns=[]
for u in sp.divisors(60):
    if u==1:continue
    size=60//u
    packets=[(a,b) for a in range(7) for b in range(7) if a+9*b==size]
    for a,b in packets:
        if a not in (3,6) or b<1:continue
        remaining={(6-a,6-b)}
        for _ in range(u-1):
            remaining={(x-c,y-d) for x,y in remaining for c,d in packets if c<=x and d<=y}
        if (0,0) in remaining:
            patterns.append({"order":int(u),"neutral":[a,b],"component_dimension":size})
need(patterns==[{"order":2,"neutral":[3,3],"component_dimension":30}],"grading obstruction")
out["rank12_nontrivial_grading_patterns"]=patterns
out["phase5_author_files_sha256"]={
    name:hashlib.sha256((BASE/"phase5/integral120"/name).read_bytes()).hexdigest()
    for name in ("THEORY.md","verify_reductions.py","reductions_certificate.json","REPORT.md")}
(HERE/"independent_checks.json").write_text(json.dumps(out,indent=2,default=int)+"\n")
print("PASS: independent raw/corpus, ring, full-induction, parity, involution and grading checks")
