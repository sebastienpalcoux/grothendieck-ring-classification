from pathlib import Path
import re,subprocess
P=Path(__file__).resolve().parent;F=P.parent
sections=[('Research status','REPORT.md'),('Dimension 120: a fermion-parity criterion and descent','integral120/THEORY.md'),('Dimension 504: a central parity obstruction','case941/EXCLUSION_THEOREM.md'),('Dimension 168: a forced Lagrangian subcategory','integral168/GENERAL_EXCLUSION.md'),('A unitary orbifold model for R9_2_1848','quadratic_noncomm/REPORT.md'),('Independent audit: dimension 120','audit_integral120/REPORT.md'),('Independent audit: dimension 504','root/AUDIT_941.md'),('Independent audit: dimension 168','audit_integral168/REPORT.md'),('Independent audit: the orbifold model','audit_model1848/REPORT.md')]
text='''---
title: "Rank-nine multiplicity-two fusion rings"
subtitle: "Fifth continuation: four general exclusions and one unitary model"
date: "24 October 2026"
author: "Research prepared with AI assistance"
fontsize: 10pt
geometry: margin=24mm
mainfont: DejaVu Serif
monofont: DejaVu Sans Mono
colorlinks: true
linkcolor: blue
urlcolor: blue
---

'''
for index,(title,rel) in enumerate(sections):
    s=(F/rel).read_text();s=re.sub(r'^# [^\n]*\n','',s,count=1)
    if rel=='quadratic_noncomm/REPORT.md':s=s.split('## R9_2_1975:')[0]
    s=re.sub(r'^(#{2,6}) \d+\.\s*',r'\1 ',s,flags=re.M)
    text+=('\n\\clearpage\n' if index in (0,1,2,3,4,5) else '\n')+'\n# '+title+'\n\n'+s+'\n'
(P/'research.md').write_text(text)
baseline=F.parent/'phase4/manuscript'
for name in ('header.tex','inline_code.lua'):(P/name).write_bytes((baseline/name).read_bytes())
args=['pandoc',str(P/'research.md'),'--from=markdown+tex_math_single_backslash+autolink_bare_uris','--standalone','--toc','--number-sections','--lua-filter='+str(P/'inline_code.lua'),'--include-in-header='+str(P/'header.tex')]
stem='Rank9_M2_Continuation_Phase5_20261024'
subprocess.run(args+['-o',str(P/(stem+'.tex'))],check=True)
subprocess.run(args+['--pdf-engine=xelatex','-o',str(P/(stem+'.pdf'))],check=True)
print('Built phase-five manuscript.')
