---
title: "Rank-nine multiplicity-two fusion rings"
subtitle: "Fifth continuation: four general exclusions and one unitary model"
date: "24 October 2026"
author: "Research prepared with AI assistance"
fontsize: 10pt
geometry: margin=24mm
mainfont: DejaVu Serif
monofont: DejaVu Sans Mono
colorlinks: true
linkcolor: blue
urlcolor: blue
---


\clearpage

# Research status


Research date: 24 October 2026. This continuation investigates all nine
rank-nine, exact-multiplicity-two cases left by phase four. Five are now
settled after independent categorical review and exact arithmetic replay.

| Ring | Result | Main argument |
|---|---|---|
| R9_2_12 | Excluded over C | Fermion parity forces a Tannakian center; weak group-theoreticality and dimension-60 descents contradict the complete group-theoretical obstruction. |
| R9_2_941 | Excluded over C | Odd central-dimension restrictions force a dimension-nine simple in a center that must be simple. |
| R9_2_959 | Excluded over C | The same dimension-120 theorem as R9_2_12. |
| R9_2_1848 | Unitary model | Isotropic C3 orbifold of an existing unitary near-group category NG(C18,18). |
| R9_2_1965 | Excluded over C | Two scalar characters force a symmetric central subcategory; a dimension-84 Gram obstruction makes it Lagrangian. |

The four unresolved rings are **R9_2_137, R9_2_1607, R9_2_1975 and
R9_2_1976**. They all have dimension type
`(1^4,2,(4+3sqrt(2))^4)` and global dimension `144+96sqrt(2)`.
Their braided categorifications are already excluded, but their general
categorifiability remains open in this research.

## Classification counts

| Scope | Total | Excluded | Modelled | Unresolved |
|---|---:|---:|---:|---:|
| Rank 9, exact multiplicity 2 | 2083 | 2043 | 36 | 4 |
| Rank 9, multiplicity at most 2 | 2225 | 2145 | 76 | 4 |

The second row retains the previous 142 multiplicity-one decisions.
Relative to the accepted phase-four research baseline, seven earlier-rank
cases are unchanged and the project-wide unresolved frontier decreases
from 16 to 11. These are research-lineage counts; independent corrections
made by the other agent performing the online audit must be reconciled
before publication.

## The theoretical content

The dimension-120 argument gives a reusable criterion: in an integral
commutative category whose dimension is divisible by four, if the
multiplicity-free induction of the unit has exactly one odd nonunit
constituent, of odd prime-power dimension, then its center has a
nontrivial Tannakian subcategory. The possible fermionic exception is
handled by the S-matrix eigenvector identity for I(1), followed by parity.
The full proof conservatively assumes trivial universal grading, which
also permits an independent relative-center derivation.

The dimension-504 argument classifies only the possible odd-dimensional
central restrictions. It reduces the difficult dimension-63 case to two
congruences and seven aggregate possibilities. Two dimension identities
modulo two then force a central prime-power object. A large center
enumeration or numerical infeasibility claim is unnecessary.

The dimension-168 argument constructs a Tannakian subcategory from two
central dimension-three objects using the scalar-character S identity.
It excludes a central involution through a strictly negative two-by-two
induction-Gram minor in its forced dimension-84 quotient. The Tannaka
group is then perfect of order dividing 168, so the subcategory is
Lagrangian. The previously audited all-cocycle group-theoretical theorem
supplies the contradiction.

The R9_2_1848 model uses Izumi's published isotropic orbifold theorem and
Budinski's exact unitary NG(C18,18) existence result. The construction
supplies coherent associativity; a fresh implementation independently
matches every one of the 729 census coefficients. This does not claim a
fresh reconstruction of the source near-group associator or a universal
parameterization of arbitrary spherical categories.

## Evidence and scope

Proofs and independent audits:

| Cases | Proof | Independent audit |
|---|---|---|
| 12,959 | `integral120/THEORY.md` | `audit_integral120/REPORT.md` |
| 941 | `case941/EXCLUSION_THEOREM.md` | `root/AUDIT_941.md` |
| 1965 | `integral168/GENERAL_EXCLUSION.md` | `audit_integral168/REPORT.md` |
| 1848 | `quadratic_noncomm/REPORT.md` | `audit_model1848/REPORT.md` |

The current authority is `results/ledger.json`, generated from the
immutable phase-four snapshot by `build_results.py`. `accepted.json`
lists the five changes. `verify.py` replays the accepted finite evidence,
checks all 2083 source identities, and compares all **26244** structure
constants of the 36 model transports. These finite checks accompany
separate categorical audits; they are not formal proofs in a proof assistant.

The four residual cases receive further structural reduction and model
investigation in `quadratic_comm/` and `quadratic_noncomm/`. Necessary
Morita-ring completions are not categorical models, and a failed
construction is not a nonexistence theorem. Any scope limitations in
those reports are retained in the classification.

The independent replacement exclusion of R8_3_436 from phase four is
unchanged. Its withdrawn universal unitary-table premise remains
withdrawn; no claim made here reinstates it.

## Publication boundary

No GitHub repository or website was modified. The user paused this
agent's online work because another agent is revising after an audit.
These results are prepared as separate research evidence for a later
coordinated revision. Earlier research snapshots are preserved, including
their supersession notices and the repaired rank-eight proof.


\clearpage

# Dimension 120: a fermion-parity criterion and descent


This file records new phase-five arguments for `R9_2_12` and `R9_2_959`.
They concern arbitrary complex fusion categories, not only unitary or braided
categories. No earlier phase or online repository is changed. The finite
hypotheses are checked by `verify_reductions.py` using the original input.

## A fermion-parity criterion

**Proposition.** Let C be an integral fusion category with commutative
Grothendieck ring, trivial universal grading, and dimension N divisible by
four. Write the induction of the unit into Z(C) as a sum of distinct simple
objects. Suppose exactly one nonunit summand has odd dimension, and that its
dimension is a positive power of an odd prime. Then Z(C) contains a
nontrivial Tannakian subcategory.

**Proof.** Integrality gives a canonical positive spherical structure and
makes Z(C) an integral nondegenerate braided category. The odd-prime-power
summand of I(1) and ENO Corollary 7.2 produce a nontrivial symmetric fusion
subcategory. If that symmetric category has dimension larger than two,
Deligne's theorem gives a nontrivial Tannakian subcategory. A symmetric
category of dimension two is either Tannakian or sVec. It remains to handle
sVec, generated by a fermion chi in Z(C).

Here is a short proof of the required dimension count. By Ostrik
Proposition 2.8, for the unnormalized modular S-matrix,

    S [I(1)] = N [I(1)].

The fermion chi has twist -1, whereas every summand of A=I(1) has twist +1
(Ostrik Theorem 2.5); hence chi is absent from A. The chi entry of this
identity is zero. For each simple Z in A, monodromy with the order-two
invertible chi is a scalar epsilon_Z in {+1,-1}, and
`S_{chi,Z}=epsilon_Z FPdim(Z)`. Thus the total dimension of the
constituents of A centralizing chi equals that of the other constituents,
namely N/2. This uses no braiding on C.

For completeness the same dimension count has the following independent
relative-center derivation. Let F:Z(C)->C be the forgetful functor and
g=F(chi). Because the universal grading of C is trivial, the forgetful homomorphism on invertible
objects is injective: its kernel is the group of tensor automorphisms of
Id_C, namely the characters of the universal grading group. Thus g is a
nontrivial order-two invertible, and D=<g> has dimension two.

Use the relative-center construction from the proof of ENO Lemma 9.17.
The forgetful functor Z(C)->Z_D(C), which remembers the half-braiding only
against D, is dominant. Its right adjoint on the unit gives a connected
algebra B contained in A, of dimension N/FPdim(D)=N/2. This follows either
from that lemma's dimension calculation or from the dominant-functor
index formula and FPdim(Z_D(C))=FPdim(C) FPdim(D).

We claim that B is precisely the sum of those constituents of A that
centralize chi. Here is the explicit morphism check, so this identification
does not require a fixed-algebra theorem or a choice of associator.
For a central simple Z occurring in A, take a nonzero map f:F(Z)->1.
It is a morphism to the unit in the relative center precisely when

    (id_g tensor f) c_{Z,g} = f tensor id_g.

The naturality of chi's half-braiding gives

    (f tensor id_g) c_{g,Z} = id_g tensor f.

Consequently the relative-center condition is equivalent to

    (f tensor id_g) (c_{g,Z} c_{Z,g}) = f tensor id_g.

In Z(C), Z tensor chi is simple, so this monodromy is scalar. Since chi
has order two, its monodromy eigenvalue is +1 or -1. The displayed condition
therefore holds exactly when Z centralizes chi. This proves the claim,
including multiplicities (which are one because the based ring is
commutative).

The dimension of B is N/2, which is even. B contains the unit, and every
nonunit summand of A except the specified odd-prime-power object has even
dimension. Parity therefore forces that odd object to occur in B. It lies
in the centralizer E=<chi>' inside Z(C). By nondegeneracy of Z(C), the
Muger center of E is exactly <chi>=sVec, so E is slightly degenerate.
ENO Proposition 7.4 says that a slightly degenerate integral braided
category containing a simple object of odd-prime-power dimension has a
nontrivial Tannakian subcategory. This proves the proposition. QED.

The argument explicitly treats a possible central fermion. It does not
infer a Tannakian category merely from an unspecified symmetric category.

## Application to both dimension-120 tensors

Both input tensors have dimensions `(1^4,2^2,6^3)`, are commutative, and
have trivial universal grading. Their formal codegrees, with multiplicity,
are

    120, 24, 20, 30, 30, 6, 6, 4, 4.

Ostrik's induction theorem (Theorem 2.13 of arXiv:1309.4822) gives a
multiplicity-free decomposition of A=I(1) with simple dimensions

    1, 5, 6, 4, 4, 20, 20, 30, 30.

There is exactly one odd nonunit summand, of dimension five. The proposition
therefore forces a nontrivial Tannakian subcategory of Z(C).

Li Dai's Lemma 3.1 then implies that C is weakly group-theoretical. Its
full hypothesis is exactly: an integral category of dimension 120 whose
center contains a nontrivial Tannakian subcategory. For clarity, its
reduction is as follows. If the Tannaka group's order is a power of two,
it contains a quotient C2, and the corresponding Rep(C2) in the center
gives an extension or equivariantization of a dimension-60 category.
All dimension-60 categories are weakly group-theoretical by ENO
Theorem 9.16. If the Tannaka group's order is divisible by three or five,
the neutral component of the de-equivariantized center has dimension
`(120/|G|)^2`, with at most two prime divisors, and is solvable by ENO
Theorem 1.6. The extension/equivariantization and center characterizations
of weak group-theoreticality finish the reduction.

**New conclusion:** every hypothetical categorification of either
`R9_2_12` or `R9_2_959` is weakly group-theoretical. This conclusion applies
to arbitrary complex fusion categories and is not a model construction.

## An auxiliary dimension-30 obstruction

**Lemma.** An integral fusion category of dimension 30 has no simple
object of dimension three.

**Proof.** ENO Theorem 9.2 makes every integral fusion category of
square-free dimension 30 group-theoretical. Every group G of order 30
has a normal cyclic subgroup P of order 15. One elementary proof is:
if its Sylow-five subgroup were not normal, there would be 24 nonidentity
order-five elements. Counting forces the Sylow-three subgroup to be
normal. The inverse image of the normal Sylow-five subgroup in the
order-ten quotient is then a normal subgroup of order 15, necessarily
cyclic, making its Sylow-five subgroup normal after all. Thus Sylow five
is normal. In the order-six quotient, the Sylow-three subgroup is normal;
its inverse image is the desired cyclic subgroup of order 15.

In a group-theoretical presentation C(G,omega,H,psi), simples over HgH are
indexed by projective irreducible representations of K=H intersect gHg^{-1},
with dimension `[H:K] dim(pi)`. Every such K has square-free order, so
H^2(K,C*)=0: restriction to a Sylow subgroup is injective on the
corresponding primary part by restriction/corestriction, while every
Sylow subgroup is cyclic and has trivial complex Schur multiplier.
Thus all projective degrees coincide with ordinary character degrees.

Set Q=H intersect P. It is cyclic and, being a subgroup of the cyclic
normal subgroup P, is normal in G. We have [H:Q]<=2, and Q lies in every
intersection K. Hence [H:K]<=2. If [H:K]=2, K=Q is cyclic, so every
projective irreducible of K has dimension one. If [H:K]=1, K=H has a
cyclic normal subgroup of index at most two. Restriction of an ordinary
irreducible representation to that cyclic subgroup is a sum of characters.
Clifford theory gives irreducible dimensions at most two: an orbit of size
two induces a two-dimensional representation, while an invariant character
extends across the cyclic quotient and gives one-dimensional representations.
Thus all resulting simple dimensions are one or two.
In particular no dimension-three simple occurs. QED.

This argument allows arbitrary three-cocycles and subgroup cochains; an
untwisted character-table search alone would not suffice. The elementary
group-of-order-30 fact can equivalently be checked on the four groups of
order 30. It is also a consequence of the classification of groups of
square-free order at this particular order.

## No solvable category has dimension type (1^6,3^6)

**Theorem.** A fusion category D with six invertibles and six simple
objects of dimension three is not solvable.

**Proof.** Its dimension is 60. For each dimension-three simple X,
G[X] has order dividing both |G(D)|=6 and FPdim(X)^2=9. In the decomposition
of X tensor X*, all noninvertible summands have dimensions divisible by
three, so |G[X]| is divisible by three. Hence |G[X]|=3. The group of
six invertibles has a unique subgroup H of order three, so this same H
fixes all six noninvertible objects. It lies in D_ad. The remainder of
X tensor X* has dimension six, so D_ad is nonpointed.

Consider a nontrivial faithful grading with group order u. Each component
has dimension 60/u. The neutral component contains H and at least one
three-dimensional object. A component with a invertibles and b
three-dimensional simples has dimension a+9b. There are six invertibles
and six three-dimensional simples in all. These constraints leave only
u=2, with both components of type `(1^3,3^3)`. This elementary enumeration
is replayed exhaustively by the verifier. The neutral category would
have dimension 30 and a three-dimensional simple, contrary to Section 3.
Thus U(D)=1.

If D were solvable, the final step of a cyclic-prime extension/
equivariantization construction could not be an extension. It must be
an equivariantization by C_p. Its central Rep(C_p) embeds into D and
supplies p invertibles, so p=2 or p=3.

For p=2, its nontrivial character acts freely on the six dimension-three
objects: their stabilizers under G(D) have order three. It also acts
freely on all six invertibles. De-equivariantization has type `(1^3,3^3)`
and dimension 30, again impossible.

For p=3, its character subgroup is H and fixes all six noninvertible
objects. The six invertibles form two free orbits. De-equivariantization
has dimension 20 and is pointed: each fixed three-dimensional simple
splits into three invertibles, and each free orbit of invertibles gives
one invertible. To justify the splitting, the endomorphism algebra of
the free module of a fixed simple is a twisted group algebra of C3;
H^2(C3,C*)=0, so it has three one-dimensional simple modules. Each has
underlying object X and normalized dimension 3/3=1.

Write this pointed category as Vec_K^omega, |K|=20. The equivariantizing
C3 acts on K by group automorphisms. Its invariant invertibles each
contribute exactly three invertibles in the equivariantization, again
because H^2(C3,C*)=0. Six invertibles of D would require exactly two
fixed elements of K. But K has a unique, hence characteristic, Sylow-five
subgroup, and the C3 action is trivial there because Aut(C5)=C4.
There are at least five fixed elements, a contradiction. QED.

This theorem does not exclude categories of that dimension type in
general: the group-theoretical category C(A5,1,C3,1) supplies that type.
The conclusion is nonsolvability, which is the needed restriction.

## No solvable category has dimension type (1^2,2,3^2,6)

**Theorem.** A fusion category D of this type is not solvable.

**Proof.** A nontrivial faithful grading of a dimension-60 fusion category
has components of dimension at most 30. A simple object of dimension six
alone contributes 36 to its component, which is impossible. Hence U(D)=1.
If D were solvable, its last cyclic-prime step would be an
C2-equivariantization, since it has exactly two invertibles. Let g be the
nontrivial underlying character. It fixes the unique objects of dimensions
two and six. It exchanges the two dimension-three simples: the stabilizer
of a dimension-three simple has order dividing nine, so cannot contain an
involution. De-equivariantization therefore has three invertibles (one
from the pair of original invertibles and two from the fixed dimension-two
object) and three dimension-three simples (one from their pair, two from
the fixed dimension-six object). This is the forbidden dimension-30 type
`(1^3,3^3)` of Section 3. QED.

## Central involution descents of the two source rings

For a hypothetical central Tannakian Rep(C2), the underlying involution
must be one of the following source labels (zero-based):

| Ring | Involution | Dimension type after de-equivariantization |
|---|---:|---|
| R9_2_12 | 1 or 2 | `(1^2,2,3^2,6)` |
| R9_2_12 | 7 | `(1^6,3^6)` |
| R9_2_959 | 8 | `(1^6,3^6)` |

The verifier checks every orbit of multiplication by each involution.
A free pair of d-dimensional objects gives one d-dimensional object
below; a fixed d-dimensional object splits into two objects of dimension
d/2. This follows from the algebra 1+g and H^2(C2,C*)=0, with all
categorical premises stated. Sections 4 and 5 rule out both dimension
types whenever the descending category is required to be solvable.

## Nonsolvable weakly group-theoretical categories of dimension 120

**Lemma.** Every nonsolvable weakly group-theoretical fusion category of
dimension 120 is group-theoretical.

**Proof.** By definition it is Morita equivalent to a nilpotent category N,
built from Vec by successive faithful extensions by finite groups G_i.
The product of the orders |G_i| is 120. If every G_i is solvable, refine
each extension by a composition series into cyclic-prime extensions.
Then N, and hence the original category, is solvable, a contradiction.

Consequently one grading group is nonsolvable. A nonsolvable finite group
whose order divides 120 has a nonabelian composition factor A5: the only
possible proper nonsolvable order is 60, and its group is A5. If a grading
group has order 120, every other stage is trivial and N is pointed.
Otherwise an A5 extension uses a factor 60, leaving only a single factor
two. Up to deleting trivial stages, there are two possible orders.

First suppose Vec is extended by A5 and then by C2. The intermediate
category is P=Vec_{A5}^omega. Every invertible P-bimodule category, as a
left P-module category, has pointed dual. The classification of such
module categories (Naidu--Nikshych, Example 2.2) requires a normal abelian
subgroup H of A5. Its only possibility is H=1, so the left module is the
regular P-module, with 60 simples permuted transitively by A5. Each
component of any extension of P is such a bimodule, and has FP dimension
60. Its 60 equally dimensional simples therefore all have dimension one.
The extension N is pointed, for every omega and all coherent extension
data.

Second suppose Vec is extended by C2 and then by A5. The intermediate
category is P=Vec_{C2}^omega. Its center is pointed of rank four: its
simples are labeled by the two elements of C2 and projective irreducible
characters of C2, which are all one-dimensional since H^2(C2,C*)=0.
The group BrPic(P) is the group of braided tensor autoequivalences of
Z(P), and embeds into the permutations of its three nonunit objects.
For clarity, faithfulness follows from the classification of pointed
braided categories by metric groups: a braided tensor autoequivalence
fixing all simple objects is tensor isomorphic to the identity. Thus
BrPic(P) is a subgroup of S3 and is solvable. The homomorphism
`A5 -> BrPic(P)` of extension components is trivial, since A5 is simple
nonabelian. Every component is the regular P-bimodule and has two simple
objects. They have equal FP dimension and their squared dimensions sum
to FPdim(P)=2; both are invertible. Again N is pointed.

In all cases N is pointed, so the original category is group-theoretical.
QED. This is a dimension-120 statement with the nonsolvability hypothesis;
it does not assert that all dimension-120 categories are group-theoretical.

## General exclusion of R9_2_12 and R9_2_959

**Theorem.** Neither ring admits a complex fusion categorification.

**Proof.** Suppose C categorifies either ring. Section 2 proves that C is
weakly group-theoretical. The independently audited phase-four theorem
`phase4/integral/GROUP_THEORETICAL_OBSTRUCTIONS.md` excludes every
group-theoretical categorification, including all associators and subgroup
cochains. Section 7 consequently forces C to be solvable.

Its universal grading is trivial by the exact input tensor. The final
step of a cyclic-prime construction of C must therefore be an
equivariantization. Since C has four invertibles, the prime is two, and
the canonical central Rep(C2) has one of the underlying involutions
listed in Section 6. Its de-equivariantization D is solvable, being the
preceding category in this construction. It has one of the two dimension
types excluded for solvable categories by Sections 4 and 5. This is a
contradiction. QED.

Every reduction concerns an arbitrary hypothetical categorification.
The proof does not assume a fiber functor, braiding, unitarity, or an
uncited classification of all dimension-120 categories. It uses the
phase-four all-cocycle GT theorem only within its established scope.

## References

* Etingof--Nikshych--Ostrik, *Weakly group-theoretical and solvable fusion
  categories*, arXiv:0809.3031v2. Corollary 7.2; Proposition 7.4;
  Propositions 2.9, 2.10 and 4.4; Theorems 9.2 and 9.16; proof of
  Lemma 9.17 (relative-center algebra).
  https://arxiv.org/pdf/0809.3031
* Ostrik, *Pivotal fusion categories of rank 3*, arXiv:1309.4822,
  Theorem 2.5, Proposition 2.8, and Theorem 2.13 (valid for arbitrary
  spherical fusion categories).
  https://arxiv.org/pdf/1309.4822
* Dai, *Frobenius property for fusion categories of dimension 120*,
  Revista de la Union Matematica Argentina 68(2) (2025), 395--403,
  Lemma 3.1. DOI 10.33044/revuma.4390.
  https://inmabb.criba.edu.ar/revuma/pdf/v68n2/v68n2a03.pdf

* Naidu--Nikshych, *Lagrangian subcategories and braided tensor
  equivalences of twisted quantum doubles of finite groups*,
  arXiv:0705.0665, Example 2.2 (pointed-dual module categories).
  https://arxiv.org/pdf/0705.0665
* Etingof--Gelaki--Nikshych--Ostrik, *Tensor Categories*, Sections 8.4
  (pointed braided categories and metric groups), specifically Theorem
  8.4.12, and Section 8.27.2 (Brauer--Picard groups and centers).
  https://math.mit.edu/~etingof/egnobookfinal.pdf

The lemmas above are combinations of these primary results and explicit
arguments; no claim of literature priority is made. Final status and
any further phase-five inputs are recorded separately in REPORT.md.


\clearpage

# Dimension 504: a central parity obstruction


**Theorem.** The fusion ring `R9_2_941` admits no fusion categorification over
`C`. This conclusion uses no unitarity assumption. The ring is exactly the
rank-nine, dimension-504 ring in Alekseyev–Bruns–Dong–Palcoux,
arXiv:2507.07023v2, §1.5, Question 1.14; the previously verified tensor
isomorphism is recalled below.

## Notation and categorical input

Use source labels `X0=1`, `Y=X2`, `B1=X1`, `B2=X3`, `B3=X4`, `B4=X5`,
and `C1=X6`, `C2=X7`, `C3=X8`. Their dimensions are respectively
`1,8,7,7,7,7,9,9,9`, and total dimension is `D=504`.
Suppose a categorification C exists. Since C is integral, it has the
canonical positive spherical structure. Its center Z(C) is an integral
modular category of dimension `D^2`. Write F for forgetful functor and I
for its right adjoint. For a central simple Z write

`F(Z) = t*1 + a*Y + sum_j b_j*B_j + sum_l c_l*C_l`,

and let `z=dim(Z)`, `b=sum_j b_j`, `c=sum_l c_l`.
Thus `z=t+8a+7b+9c`.

The following standard facts will be used:

1. `z | D`, because modular square-divisibility makes `D^2/z^2` an
   integer, and `D,z` are positive integers.
2. Since K0(C) is commutative, I(1) is multiplicity-free. Its central
   simples A_chi are indexed by the nine scalar characters, with
   `dim(A_chi)=D/f_chi`. Thus `t` is zero or one. The central dimensions
   in I(1), with multiplicity, are `1,63,56,56,56,56,72,72,72`.
3. If chi is a scalar character, the central character identity gives
   `S_(A_chi,Z)=dim(A_chi)*chi(F(Z))`. By symmetry of S and the Verlinde
   character formula, `dim(A_chi)*chi(F(Z))/z` is an algebraic integer.
4. Set `G=sum_i N_i N_i^T`. The induction Gram identity gives
   `G=sum_Z v_Z v_Z^T`, where v_Z is the restriction column. Consequently
   `v_Z^T G^(-1) v_Z <=1`. Orthogonality of the real scalar characters gives

   `v_Z^T G^(-1) v_Z = sum_chi chi(F(Z))^2/f_chi^2 <=1`.       (1)

   This is an ordinary positive semidefinite matrix identity and requires
   no C*-structure on C.
5. Frobenius reciprocity and dimensions give

   `sum_Z z*[F(Z):X] = dim(I(X)) = D*dim(X)`.                 (2)

For the identity in item 3, see Deshpande, arXiv:1611.04486, Proposition
2.8 and §2.7, especially (36) and the description immediately preceding
it. For item 2 see Ostrik, arXiv:1309.4822, Theorem 2.13.

## Exact character data

The dimension character has formal codegree 504. One rational character
of codegree 8 is

`chi_8(F(Z)) = t-b+c`.

Four rational characters of codegree 9 are

`chi_9,j(F(Z)) = t+b-a-3*b_j`       (`1<=j<=4`).

The other three characters have codegree 7. Put
`alpha=2*cos(2*pi/7)`, `beta=alpha^2-2`, `gamma=1-alpha-alpha^2`.
These are the roots of `x^3+x^2-2x-1`; in a cyclic ordering the three
characters are

`chi_7(F(Z)) = t+a+c1*alpha+c2*beta+c3*gamma`,

and its two Galois conjugates. In particular
`alpha+beta+gamma=-1`, `alpha^2+beta^2+gamma^2=5`.
The appropriate cyclic ordering is verified against every source product
in the accompanying verifier; permuting the C labels has no effect on the
argument.

We use the standard integral basis
`O_(Q(alpha))=Z[alpha]`, with basis `1,alpha,alpha^2`.
For example see G. Eric Moorhouse, *Cyclotomic Fields with Applications*,
Theorem 4.8. The accompanying verifier instead tests characteristic
polynomials over Q, so its arithmetic check does not assume an integral
basis theorem.

## Only two restrictions can have central dimension 63

**Lemma.** If a central simple has dimension 63, its restriction is one
of

`U = Y+B1+B2+B3+B4+C1+C2+C3`,

`V = 1+Y+2*C1+2*C2+2*C3`.

**Proof.** Item 3 applied to the codegree-9 characters gives

`t+b-a-3*b_j == 0 (mod 9)` for every j.                       (3)

Applied to any codegree-7 character it says `(8/7)*chi_7(F(Z))`
is integral. In the integral basis above this forces

`c1 == c2 == c3 == t+a (mod 7)`.                             (4)

The dimension identity is

`t+8a+7b+9c=63`, with `t in {0,1}`.                          (5)

For completeness, here is the entire short reduction of (3)–(5).
Write `r` for the residue of `t+a` in `{0,...,6}`. Since each c_l is
nonnegative and congruent to r, the inequality `t+8a+27r<=63` leaves
only the following aggregate possibilities:

| t | a | b | c | Consequence |
|---:|---:|---:|---:|---|
| 0 | 0 | 9 | 0 | Every b_j is a multiple of 3 |
| 0 | 0 | 0 | 7 | Exactly one c_l is 7 |
| 0 | 1 | 4 | 3 | Every b_j=1 and every c_l=1: U |
| 0 | 7 | 1 | 0 | (3) requires every b_j>=1: impossible |
| 1 | 0 | 5 | 3 | (3) requires every b_j>=2: impossible |
| 1 | 1 | 0 | 6 | Every b_j=0 and every c_l=2: V |
| 1 | 6 | 2 | 0 | (3) requires every b_j>=2: impossible |

In the first row `chi_8(F(Z))=-9`, so its single contribution to
(1) is `81/64>1`. In the second row the three codegree-7 contributions
to (1) sum to `alpha^2+beta^2+gamma^2=5>1`. Both are impossible.
Only U and V remain. QED.

## Two dimension parities force prime-power central simples

The only possible odd central dimensions are the odd divisors of 504:
`1,3,7,9,21,63`.
Dimension 3 is impossible. Dimension 1 is the unit. At dimensions 7,9,21,
the restrictions are respectively a B_j, a C_l, or a sum of three B_j's;
indeed any occurrence of 1 would put the object in I(1), whose dimension
list has none of 7,9,21. At dimension 63 the preceding lemma applies.

Exactly one central simple has restriction V: it is the unique
63-dimensional summand of I(1). Let m be the number of central simples
with restriction U. Apply (2) to Y and reduce modulo 2. Even-dimensional
central objects contribute zero. Among odd-dimensional central objects,
only the unique V and the m copies of U contain Y, each with multiplicity
one. Therefore

`0 == 504*8 == 1+m (mod 2)`;

hence m is odd.

For each l let n_l be the number of central simples restricting to C_l.
Apply (2) to C_l and again reduce modulo 2. The unique V contributes
`63*2`, the U columns contribute `63*m`, and the dimension-9 columns
contribute `9*n_l`. All other contributions are even or zero. Thus

`0 == 504*9 == m+n_l (mod 2)`.

Consequently **every n_l is odd**. In particular, Z(C) contains a simple
of dimension `9=3^2`.

## Contradiction and scope

The source ring is simple and has no braided categorification. The
latter follows by the standard simple braided dichotomy: a nondegenerate
realization would require `7^2 | 504`, while a symmetric realization would
be a finite-group representation ring, which this exotic ring is not.
These ring and braided facts were established in phase4 and in the
published source identifying this ring.

Liu–Palcoux–Ren, arXiv:2102.01663v4, Theorem 5.1, states that the center
of a nonpointed simple complex fusion category is simple exactly when
the category does not admit a braiding. Hence Z(C) is simple.
But Etingof–Nikshych–Ostrik, arXiv:0809.3031, Corollary 7.2, states that
an integral nondegenerate braided category containing a nontrivial
prime-power-dimensional simple contains a nontrivial symmetric
subcategory. Such a subcategory is proper in the nondegenerate Z(C),
contradicting simplicity. This proves the theorem.

The argument applies to arbitrary complex fusion categories because
integrality supplies the positive spherical structure. It never replaces
pseudo-unitarity by unitarity. No associator or indicator classification
is assumed.

## Reproducible arithmetic and provenance

`verify_odd_columns.py` uses Python's standard library and exact rational
arithmetic only. It regenerates the character relations and G from the
original tensor, exhaustively checks all 1,612 bounded dimension-63
vectors, and recovers exactly U and V. It also verifies the complete odd
dimension list and an equivalent 15-entry Gram parity certificate, whose
right side is 937. It does not use an optimizer or the exploratory
candidate list. Output: `odd_columns_verified.json`.

The proof in §3 replaces that finite enumeration with two congruences
and the displayed seven-row argument. The enumeration is an independent
arithmetic cross-check, not the reason to believe the congruences.

The source tensor SHA256 is
`1699b4d0768bbdf652993c18237cffd6df806d0e3d9c325403fcebcea58e2c02`.
The source-to-published basis permutation is `[0,1,5,2,3,4,8,6,7]`, checked
in all 729 coefficients by phase3/audit_models/published_504_tensor.json.

Exploratory files `simple_center.py`, `full_center.py`, and
`integer_gram.py` discovered the obstruction. Their floating-point
optimization output is not used in the proof. The exact Z3 result agrees
but is likewise unnecessary for verification.

Primary sources:

- <https://arxiv.org/pdf/2507.07023v2>, §§1.5,7.5 and Question 1.14.
- <https://arxiv.org/pdf/1309.4822>, Theorem 2.13.
- <https://arxiv.org/pdf/1611.04486>, Proposition 2.8 and §2.7.
- <https://arxiv.org/pdf/2102.01663>, Theorem 5.1.
- <https://arxiv.org/pdf/0809.3031>, Corollary 7.2.
- <https://ericmoorhouse.org/handouts/cyclotomic_fields.pdf>, Theorem 4.8.

## General reusable form of the criterion

Let R be a nonpointed simple integral commutative fusion ring of even
FP-dimension D which has no braided categorification. For any hypothetical
categorification, form the possible restrictions of odd-dimensional central
simples using `z | D`, distinguished formal-codegree dimensions, and the
algebraic integrality of `(D/f_chi)*chi(v)/z`. The distinguished restrictions
with `v_0=1` occur with their prescribed integral multiplicities. The
remaining restrictions with `v_0=0` must satisfy the parity equations

`sum_(z odd) v_Z = 0` in `(Z/2)^rank`,

because `sum_Z z*v_Z = D*d` and D is even. A parity certificate forcing a
nontrivial prime-power central dimension excludes R: the center is simple,
whereas ENO's prime-power theorem supplies a proper symmetric subcategory.
This formulation does not require solving complete induction matrices.
For R9_2_941 only the four coordinates Y,C1,C2,C3 matter; the odd-column
lemma reduces the certificate to two one-line parity deductions.


\clearpage

# Dimension 168: a forced Lagrangian subcategory


**Theorem.** The based ring `R9_2_1965` is not the Grothendieck ring of a fusion category over the complex numbers.

This is a general exclusion, not merely a braided, unitary, solvable, weakly group-theoretical, or group-theoretical exclusion. The new argument forces a hypothetical categorification to be group-theoretical and then applies the independently audited phase-4 exclusion of that class. In particular, it does not assert that every integral category of dimension 168 is group-theoretical.

## Input and categorical tools

Use source labels 0 through 8. The positive dimension vector is

`(1,6,6,6,6,1,2,3,3)`,

the dual permutation is `(0,2,1,4,3,5,6,7,8)`, and the global dimension is 168. Put `g=b5` and `u=b6`. The invertible group is `{1,g}=C2`. The based adjoint subring is the entire ring, so the universal grading group is trivial. These statements, all fusion axioms, and every finite identity below are checked by `verify_general_exclusion.py` against `source_tensor.json`. The tensor's canonical compact-JSON SHA256 is

`07dac58d848bd451d8a3d9231bfd1c23c1b0117541e6de5055fa0ab90314c4f9`.

Suppose that C categorifies this ring. Since its dimension is integral, C has its canonical positive spherical structure. Write F: Z(C) → C and I for its right adjoint. For any irreducible representation E of the complexified fusion ring, there is a distinguished simple A_E in I(1) satisfying

\[
[I(1):A_E]=\dim E,\qquad \dim A_E=\frac{\dim C}{f_E},\qquad\theta_{A_E}=1.
\]

For a scalar ring character χ, the associated central simple satisfies

\[
\frac{S_{A_\chi,Z}}{\dim A_\chi}=\chi(F(Z)). \tag{1}
\]

The induction matrix is a Gram matrix:

\[
B_{ij}=[FI(b_j):b_i]=\sum_Z [F(Z):b_i][F(Z):b_j],
\qquad FI(b_j)=\sum_t b_t b_j b_t^* . \tag{2}
\]

The order of multiplication in (2) matters because the source ring is noncommutative. Removing any specified central-simple summands from this Gram decomposition leaves a positive semidefinite matrix.

Primary references for these tools are [Ostrik, arXiv:1309.4822](https://arxiv.org/abs/1309.4822), Proposition 2.4, Theorems 2.5 and 2.13, and Example 2.9 with the discussion preceding Theorem 2.13; also [Deshpande, arXiv:1611.04486](https://arxiv.org/abs/1611.04486), Proposition 2.8 and Section 2.7. None requires the fusion ring to be commutative. Pseudo-unitarity and its canonical structure are [EGNO, *Tensor Categories*](https://math.mit.edu/~etingof/egnobookfinal.pdf), Proposition 9.6.5 and Corollary 9.6.6.

## A central Tannakian lift of g is impossible

Assume there is a central Tannakian `Rep(C2)` whose nontrivial character forgets to g. The forgetful restriction to this subcategory is fully faithful. De-equivariantization by its regular algebra `1+g` gives a fusion category D of dimension 84 and a dominant free-module tensor functor Q: C → D (EGNO Theorem 8.23.3).

Tensoring with g has orbits

`{0,5}, {1,3}, {2,4}, {6}, {7,8}`.

By free-module adjunction, Q of each simple in a two-element orbit is simple, with the same dimension as the source. The fixed dimension-two simple u has `dim End(Q(u))=2`. Hence it splits into two distinct simples. Their dimensions sum to two and each is at least one, so both are invertible. Thus D has precisely three invertibles `1,a,a²`, and its remaining simples are `Y,X,Z`, of dimensions `3,6,6`, respectively. Dominance ensures that this list is exhaustive. The source images are

| Source | Q-image |
|---|---|
| b0,b5 | 1 |
| b1,b3 | X |
| b2,b4 | Z |
| b6 | a+a² |
| b7,b8 | Y |

The order-three group of invertibles fixes Y, X and Z under both left and right multiplication: it acts on a one-element set of dimension-three simples and a two-element set of dimension-six simples. Applying Q to the source products now forces all of the following:

\[
\begin{aligned}
&a^3=1,\quad aY=Ya=Y,\quad aX=Xa=X,\quad aZ=Za=Z,\\
&Y^2=1+a+a^2+2Y,\quad YX=XY=3X,\quad YZ=ZY=3Z,\\
&X^2=2X+4Z,\quad Z^2=4X+2Z,\\
&XZ=ZX=1+a+a^2+3Y+2X+2Z.
\end{aligned} \tag{3}
\]

In particular D is integral. We next give a short theoretical obstruction to (3).

### The dimension-84 induction-Gram obstruction

In basis `(1,a,a²,Y,X,Z)`, (2) gives

\[
B=\begin{pmatrix}
6&3&3&8&4&4\\
3&6&3&8&4&4\\
3&3&6&8&4&4\\
8&8&8&28&12&12\\
4&4&4&12&52&24\\
4&4&4&12&24&52
\end{pmatrix}.
\]

Since (3) is commutative, all six irreducible ring representations are scalar. Its formal codegrees are `3,3,4,28,28,84`, as verified by the characteristic polynomial of the Casimir/induction matrix:

\[
\det(fI-B)=(f-3)^2(f-4)(f-28)^2(f-84).
\]

Consequently I_D(1) has six distinct simple constituents, of dimensions `1,3,3,21,28,28`, each with multiplicity one. The dimension-one constituent is the central tensor unit. Let v range over the restriction vectors of the five other constituents. Each has `v_0=1`, and

\[
\sum v=(5,3,3,8,4,4). \tag{4}
\]

The two dimension-three constituents each have `v_a+v_{a²}=2`, with no Y, X or Z coordinates. Thus only two of the total six a/a² coordinates in (4) remain. For each dimension-28 constituent, its dimension equation modulo three says `v_a+v_{a²}≡0 (mod 3)` after subtracting its unit coordinate. The remaining budget is at most two, so both dimension-28 constituents have zero a and a² coordinates. The dimension-21 constituent therefore has `v_a+v_{a²}=2`.

Consider the three pairs of a/a² coordinates belonging to dimensions 3,3,21. Each pair sums to two and the three pairs have total `(3,3)`. Either all are `(1,1)`, or they are a permutation of `(2,0),(1,1),(0,2)`. In the latter case, subtracting their outer products from B gives value `6−8=−2` on the vector supported as `(1,−1)` in the a,a² positions. This violates positive semidefiniteness. Thus all three pairs are `(1,1)`.

Let t be the Y-coordinate of the dimension-21 constituent, and let y₁,y₂ be those of the two dimension-28 constituents. Equation (4) gives `t+y₁+y₂=8`. Remove from B the outer products of all six distinguished restriction vectors, and call the residual matrix M. Its a,Y principal entries satisfy

\[
M_{aa}=3,\quad M_{aY}=8-t,\quad
M_{YY}=28-t^2-y_1^2-y_2^2\le28-t^2-\frac{(8-t)^2}{2}.
\]

Therefore

\[
\begin{aligned}
\det M_{\{a,Y\}}
&\le84-3t^2-\frac52(8-t)^2\\
&=-\frac{(11t-40)^2}{22}-\frac{36}{11}<0.
\end{aligned}
\]

This contradicts (2). Hence (3) has no fusion categorification, and the proposed central Tannakian lift of g cannot exist.

For reference only, the full tensor (3) matches the already excluded lower-census ring `R6_4_38`, under permutation `(0,1,2,5,3,4)`. The preceding proof is independent of its existing exclusion certificate.

## Scalar codegrees force a nontrivial Tannakian subcategory

Set z=−1+√(−7) and z̄=−1−√(−7). Direct substitution in all 81 multiplication equations gives two scalar ring characters

\[
\chi_+=(1,z,\bar z,z,\bar z,1,2,3,3),\qquad
\chi_-=(1,\bar z,z,\bar z,z,1,2,3,3).
\]

Their formal codegrees are both 56. Thus there are two distinct distinguished central simples A₊,A₋ of dimension three, each occurring once in I(1), and each having twist one.

Their restrictions contain the unit once. The remaining dimension two can only be either `2g` or `u`: no additional tensor unit is allowed, because its multiplicity is exactly one. The source induction matrix has `B_{0,5}=1`. A restriction `1+2g` would contribute two to this entry and is impossible. Therefore

\[
F(A_+)=F(A_-)=1+u. \tag{5}
\]

Using (1) and (5), for every σ,τ∈{+,-} we obtain

\[
S_{A_\sigma,A_\tau}=3\chi_\sigma(1+u)=9
=\dim A_\sigma\dim A_\tau. \tag{6}
\]

We spell out why (6) gives actual centralization without any assumption of unitarity. The balancing formula, together with the trivial twists of Aσ and Aτ, says

\[
9=\sum_W N_{A_\sigma,A_\tau}^{W}\theta_W\dim W,
\qquad
9=\sum_W N_{A_\sigma,A_\tau}^{W}\dim W.
\]

All dimensions are positive, and twists are roots of unity. Equality in the triangle inequality forces θ_W=1 for every constituent W. The balancing identity for the double braiding consequently says that the double braiding is the identity. Thus A₊ and A₋ centralize one another and themselves. The fusion subcategory E that they generate is symmetric. Its twist is identically one: this follows on all tensor words from balancing and then on their summands and duals. A positive spherical symmetric fusion category with trivial twist is Tannakian. Thus

`E ≃ Rep(G)`

for a nontrivial finite group G. Here one can use EGNO's symmetric-category classification in Section 9.9; the nontrivial super case has a nontrivial canonical parity twist, which is absent here.

## The Tannakian subcategory must be Lagrangian

The kernel of `Inv Z(C) → Inv C` consists of half-braidings on the tensor unit, equivalently tensor automorphisms of the identity functor. These are the characters of the universal grading group. The source adjoint closure is all of C, so this kernel is trivial.

It follows that `Inv E` injects into `{1,g}`. If it were nontrivial, E would contain a Tannakian `Rep(C2)` whose nontrivial character forgets to g. Section 2 excluded precisely this situation. Therefore `Inv E` is trivial: G has no nontrivial one-dimensional representations and is perfect.

Let E′ be its centralizer in Z(C). The centralizer dimension theorem and de-equivariantization give a fusion category `(E′)_G` of dimension

\[
\operatorname{FPdim}((E')_G)=\frac{168^2}{|G|^2}.
\]

This rational number is an algebraic integer, so it is an integer. A rational number whose square is an integer is itself an integer; hence `|G|` divides 168.

Every group of proper-divisor order of 168 is solvable. Indeed, the orders involving at most two primes are covered by Burnside's theorem. The only proper divisors involving all three primes 2,3,7 are 42 and 84; in either order the Sylow-seven number divides 6 or 12 and is congruent to one modulo seven, so it is one. The quotient by this normal C7 has order 6 or 12 and is solvable. Since a nontrivial perfect group is not solvable, necessarily `|G|=168`.

Therefore `FPdim E=168` and `FPdim Z(C)=168²`. Since E is symmetric, the centralizer dimension formula now yields `E=E′`: it is a Lagrangian subcategory. EGNO Corollary 9.13.6 implies that C is group-theoretical.

## Contradiction with the complete group-theoretical obstruction

Phase 4 already excluded every group-theoretical categorification of `R9_2_1965`. The proof is Section 5 of `phase4/integral/GROUP_THEORETICAL_OBSTRUCTIONS.md`, with independent replay in `phase4/audit_integral_gt/AUDIT.md`.

Briefly, the all-twists projective-character reduction exhausts all 57 groups of order 168 and all 1,751 subgroup conjugacy classes. Only `(PSL(2,7),S4)`, for the two S4 conjugacy classes, survives. Restriction on third cohomology is injective: its kernel is seven-primary, whereas the Sylow-seven normalizer acts without fixed points on `H⁴(C7,Z)`. Thus every admissible associator is globally trivializable. Both classes in `H²(S4,C*)` extend from `H²(PSL(2,7),C*)` and can be removed by a global tensor autoequivalence. The resulting untwisted tensors are `R9_2_1557`, not `R9_2_1965`. Their duality types already differ (seven versus five self-dual simples).

The group-theoretical exclusion is incompatible with Section 4. This proves the theorem.

## Exact replay and scope

From the workspace root, run:

```sh
python rank9_m2_research/phase5/integral168/verify_general_exclusion.py
```

The verifier checks all fusion axioms for both tensors, the universal adjoint closure, the exact two scalar characters over Q(√−7), their formal codegrees, the source induction entry used in (5), every coefficient of the forced quotient ring map, its full induction Gram matrix and formal-codegree polynomial, and the polynomial identity giving the strictly negative minor. It also checks every coefficient of the optional lower-rank identification and records SHA256 bindings to the previously audited group-theoretical proof.

The certificate establishes finite algebraic premises; the categorical deductions are the proof above. No search cutoff, numerical optimization failure, assumption of unitarity, or assumed classification of all integral dimension-168 categories is used. No repositories or published material were changed by this research.


\clearpage

# A unitary orbifold model for R9_2_1848


**R9_2_1848 is modelled. R9_2_1975 remains unresolved.**

The new model is an application of an existing, general orbifold theorem to an
existing unitary near-group category. It does not require a new associator ansatz
or the unproved assertion that every spherical category is unitary.

## Construction and complete fusion rules

Let N be Budinski's near-group category J_18^1 of type C18+18. Its simple
objects consist of the group G=C18 and one object rho with

    rho^2 = sum_(g in C18) g + 18 rho,
    FPdim(rho) = 9 + 3 sqrt(11).

The source exists as a unitary category by the Cuntz algebra construction
described in Budinski, Theorem 3.1.1 and Table 3.1 (the four rows for n=18).
Table 3.1 displays rounded phase coordinates, but section 3.3.2 explicitly
explains the exact algebraic certification of these solutions. We use the
source's existence result as a literature dependency. This continuation does
**not** claim to independently reconstruct or replay its complete associator.

For J_18^1 the nondegenerate symmetric pairing and quadratic refinement are

    <x,y> = exp(2 pi i xy/18),
    a(x) = exp(-pi i x^2/18).

Take H={0,6,12}. Then

    H^perp = {0,3,6,9,12,15},
    H subset H^perp,  a|H=1,
    G/H = C6,  H^perp/H = C2,  G/H^perp = C3.

Apply **Izumi, Theorem 12.5**, together with the irreducible decomposition
and multiplication formulas immediately preceding it in section 12.1.
This theorem covers isotropic H; it does not require H to be Lagrangian.
The resulting unitary orbifold has six distinct invertibles indexed by G/H,
and three distinct noninvertibles indexed by G/H^perp. With g a generator
of C6 and X the distinguished component, its complete presentation is

    g^6=1,  g^3 X=X,  Xg=g^-1 X,
    X^2=1+g^3+2(X+gX+g^2X).

Here the theorem's shift g_a may be chosen to be zero because a|H=1.
Its noninvertible coefficient is |H^perp/H|=2. In particular,
FPdim(X)=3+sqrt(11), all three noninvertibles are self-dual, and the category
has rank nine and maximum fusion multiplicity two. The construction supplies
associativity at the categorical level; checking the based tensor alone would
not supply that missing premise.

The construction is a special case of the unified formula

    sigma^2 = sum_(k in H^perp/H) alpha_(k-g_a)
              + |H^perp/H| sum_(q in G/H^perp) alpha_q sigma,
    alpha_g sigma = sigma alpha_-g.

Thus the model uses a known theoretical construction and a known source
category, rather than claiming a new family of associators.

## Exact census binding

Order the model basis as

    [1,g,g^2,g^3,g^4,g^5,X,gX,g^2X].

The map into the census tensor basis is

    [0,1,4,8,3,2,5,7,6].

All **729** coefficients agree with R9_2_1848. The source tensor SHA256 is
`42681407529a88aaaf34a909975776d8d1008ee8a99b6e231263dcb1aae9ff5c`.
The self-contained record `1848_model.json` includes both tensors and the
permutation. Run

    python verify_1848_model.py

to verify the transport, the subgroup and root-of-unity exponent conditions,
associativity, duality, and the dimension identities using exact integers.
The receipt is `1848_model_verification.json`. Its scope explicitly separates
the new exact transport from the cited near-group existence theorem.

## Primary sources and scope

1. P. G. Budinski, *Exotic Fusion Categories and Their Modular Data*, master's
   thesis, University of Alberta (2021), Theorem 3.1.1, Table 3.1 (n=18),
   section 3.3.2 (exactness, printed pp.46–47).
   DOI: https://doi.org/10.7939/r3-7p7k-fg18.
   Institutional PDF:
   https://ualberta.scholaris.ca/bitstreams/3f73f320-a2a2-4184-ad81-d8708764f725/download.
2. M. Izumi, *A Cuntz algebra approach to the classification of near-group
   categories*, arXiv:1512.04288v2, section 12.1, Theorem 12.5 and the
   preceding action formulas (printed pp.107–111):
   https://arxiv.org/abs/1512.04288v2.

Source URLs and hashes are in `sources.json`. Downloaded primary papers and
extracted text are held in the local research cache; they are not included
in the verified baseline archive or the final research package. In particular,
Izumi's cached PDF and text under `sources` are URL/hash dependencies, not
bundled replay inputs. The exact tensor replays do not read these cached
papers. Later citations to the thesis in Yu's 2024 paper and
Yu–Zhang's notes support that its solutions are used as existence results,
but the proof dependency above is the primary thesis itself.

Izumi works in the unitary C* setting. That is sufficient here because the
conclusion is the existence of one unitary model. No classification theorem
for arbitrary original spherical categories is inferred.



\clearpage

# Independent audit: dimension 120


**Verdict: PASS.** The arguments in `phase5/integral120/THEORY.md` establish general non-categorifiability over C of `R9_2_12` and `R9_2_959`, using the previously audited complete group-theoretical exclusions within their established scope. No missing categorical premise or scope error was found. In particular, the proof does not replace pseudo-unitarity by unitarity.

The author verifier was replayed successfully. A separate implementation, `independent_checks.py`, reads the original compressed census and independently cross-checks it against `work/verification_corpus.json`; it does not import the author verifier. Its result is `independent_checks.json`, also PASS. The author files and previous phases were not revised by this audit.

## Fermion parity and the Tannakian reduction

The induction statement applies to arbitrary spherical fusion categories. Integrality gives the positive spherical structure, and dimensions of central objects equal those of their images under the forgetful functor. Thus the center is integral and nondegenerate, as needed for the prime-power criterion.

The following reasoning is valid and is the essential new step:

1. A dimension-five simple in the center forces a nontrivial symmetric subcategory by ENO Corollary 7.2.
2. A symmetric category of dimension greater than two contains a nontrivial Tannakian subcategory, including the super case: for `Rep(G,z)`, the even part is `Rep(G/<z>)`. Only sVec needs separate treatment.
3. With canonical positive dimensions, its fermion χ has dimension one and twist −1. Since all constituents of A=I(1) have twist +1, χ has coefficient zero in A.
4. The χ coordinate of the exact identity `S[A]=120[A]` is consequently zero. Monodromy with χ on each simple constituent is a scalar ε=±1: the tensor product with an invertible remains simple, and the scalar is multiplicative in the invertible variable, whose order is two.
5. Thus the dimensions of the ε=+1 and ε=−1 constituents each sum to 60. The unit belongs to the positive part. Every other dimension is even except the single dimension-five constituent, which must therefore also belong to that part.
6. The centralizer of sVec in the nondegenerate center has Müger center exactly sVec. It is integral and contains the dimension-five simple. ENO Proposition 7.4 therefore supplies a nontrivial Tannakian subcategory.

No positivity of a Hilbert-space inner product is used. The entire fermion argument uses categorical positivity, the induction S-eigenvector, and scalar monodromy. This direct argument is sufficient; the relative-center derivation is not needed for the conclusion. I also checked that derivation: the relative-center unit-morphism equation and naturality of the fermion's half-braiding combine to the stated scalar monodromy condition. The injectivity on invertibles follows from the trivial universal grading, so the dimension-two subcategory used there is nontrivial.

Dai Lemma 3.1 has exactly the claimed hypothesis: an integral dimension-120 category with a nontrivial Tannakian subcategory in its center is weakly group-theoretical. Its use does not presume a Tannakian subcategory in C itself or a braiding on C. The two-primary branch and the de-equivariantized-center branch are applicable as written.

Primary checks: [ENO, arXiv:0809.3031](https://arxiv.org/abs/0809.3031), Corollary 7.2 and Proposition 7.4; [Ostrik, arXiv:1309.4822](https://arxiv.org/abs/1309.4822), Theorem 2.5, Proposition 2.8 and Theorem 2.13; [Dai, 2025](https://inmabb.criba.edu.ar/revuma/pdf/v68n2/v68n2a03.pdf), Lemma 3.1.

## The dimension-30 obstruction includes all twists

The claim that an integral dimension-30 category has only simple dimensions one and two is proved, not inferred from an untwisted search. ENO Theorem 9.2 first puts it in the group-theoretical class.

I checked the group argument independently. A group of order 30 has a normal cyclic subgroup P of order 15. The stated Sylow-counting argument is valid: six Sylow-five subgroups would account for 24 nonidentity elements; ten Sylow-three subgroups would require 20 additional nonidentity elements. Thus in that case Sylow three is normal. Its quotient of order ten has normal Sylow five, giving a normal subgroup of order 15; such a subgroup is cyclic, so its characteristic Sylow five would be normal in the original group, a contradiction. Normal Sylow five and the normal Sylow-three subgroup in the quotient of order six then give P.

For any subgroup H and double-coset intersection K, the cyclic subgroup Q=H∩P is normal in the whole group (all subgroups of cyclic P are characteristic) and lies in K. Since [H:Q] is at most two, either K=H or K=Q. Every K has square-free order. Its complex Schur multiplier vanishes: restriction to each cyclic Sylow subgroup is injective on the relevant primary part by transfer, and the target is zero. Thus arbitrary associators and relative cochains cannot introduce a projective degree omitted from the ordinary degree calculation.

If K=Q, its projective irreducibles have degree one and [H:K]≤2. If K=H, the cyclic subgroup Q has index at most two, so Clifford theory gives degrees at most two. This covers every group-theoretical simple. The forbidden dimension-three object therefore cannot occur.

## Both dimension-60 nonsolvability arguments are valid

For type `(1^6,3^6)`, the stabilizer G[X] has order dividing 9 and 6; the dimension equation for XX* makes it divisible by three. It is therefore the unique order-three subgroup H of the six-element invertible group. H fixes all six three-dimensional simples, lies in the adjoint category, and XX* has a noninvertible remainder of dimension six. Hence any neutral grading component contains at least three invertibles and one three-dimensional simple.

The grading enumeration can be checked without software. If the grading group has order u>1, each component has dimension 60/u≥12, so u is 2,3,4, or 5. For u=3, a component of dimension 20 must have type `(1^2,3^2)`, impossible for the neutral component. For u=4, each dimension-15 component would need six invertibles; for u=5, each dimension-12 component would need three. Both exceed the total inventory. Only u=2 remains, with both components of type `(1^3,3^3)` and dimension 30, already impossible. Thus the universal grading is trivial.

The last step of a solvable construction is consequently an equivariantization by C2 or C3. The C2 action is free on the three-dimensional simples because their stabilizer has odd order, and the descent has forbidden type `(1^3,3^3)`. For C3, the fixed simple free-module endomorphism algebras are twisted C3 group algebras. Their cocycles are cohomologically trivial, so each three-dimensional simple splits into three invertibles. The de-equivariantization is pointed of dimension 20. A C3 action on its group K fixes its characteristic Sylow C5 pointwise, since Aut(C5) has order four. It therefore has at least five fixed elements. Each fixed invertible gives three invertibles after equivariantization, contradicting the required six. There is no omission of projective stabilizer representations in this count: H²(C3,C*)=0.

For type `(1^2,2,3^2,6)`, the square 36 of the dimension-six object excludes every nontrivial grading, since such a component has dimension at most 30. A final solvable step can only be C2-equivariantization. The involution fixes the unique dimension-two and dimension-six simples and exchanges the dimension-three pair. The free-module decomposition gives type `(1^3,3^3)` below, again impossible.

For the source rings, every potential underlying central involution is included. The independently computed lists and types are:

| Source | Involution labels | Dimension-60 type |
|---|---|---|
| R9_2_12 | 1, 2 | `(1^2,2,3^2,6)` |
| R9_2_12 | 7 | `(1^6,3^6)` |
| R9_2_959 | 8 | `(1^6,3^6)` |

The fixed/free-orbit rules follow from the free-module adjunction and the vanishing cyclic Schur multiplier. They are not merely counts guessed from dimensions.

## Nonsolvable weakly group-theoretical dimension 120 implies group-theoretical

This lemma was checked with attention to both orders of the extension tower.

Weak group-theoreticality provides a Morita-equivalent nilpotent category of the same dimension. Its faithful grading-group orders multiply to 120. If each grading group is solvable, its normal composition series refines that extension into cyclic-prime extensions; the resulting category and its Morita class are solvable. Thus a nonsolvable category requires a nonsolvable grading group.

Among proper divisors of 120, only 60 can be the order of a nonsolvable group; a nonsolvable group of order 60 is A5. A factor of order 120 leaves no other nontrivial factor and gives a pointed category immediately. A factor of order 60 leaves exactly a C2 stage. There are only two orders to examine:

- **A5 then C2.** For P=`Vec_A5^ω`, every extension component is an invertible P-bimodule category, so its underlying left module has pointed dual. Naidu–Nikshych Example 2.2 applies to arbitrary ω and forces the stabilizer to be a normal abelian subgroup of A5, hence trivial. The component has 60 simples, transitively permuted by P, with equal Frobenius–Perron dimensions. Its dimension is 60, so all simples have dimension one.
- **C2 then A5.** For either associator on `Vec_C2`, its center is pointed with four simple objects. Braided automorphisms act faithfully on those objects: in the classification by metric groups, an object-fixing braided autoequivalence is tensor-isomorphic to the identity. Hence BrPic(P) embeds in S3. Every homomorphism from A5 to it is trivial. Every extension component is therefore the regular P-bimodule and has two equal-dimensional simples, whose squared dimensions sum to two. Again they are invertible.

The extension associators and coherence data do not affect these simple-count and dimension conclusions. The nilpotent representative is pointed, proving that the original category is group-theoretical. This does not claim that all dimension-120 fusion categories are group-theoretical.

The arbitrary-associator module premise was checked directly in [Naidu–Nikshych, arXiv:0705.0665](https://arxiv.org/abs/0705.0665), Example 2.2. The Brauer–Picard identification and pointed braided category classification are in [EGNO](https://math.mit.edu/~etingof/egnobookfinal.pdf), Sections 8.27 and 8.4. Solvability's equivalent direct construction and Morita formulation are ENO Definition 1.2 and Proposition 4.4.

## Exact evidence and final implication

The independent replay verifies the full source tensors, associativity, positive dimensions, trivial universal grading, and the full induction formula `FI(X)=ΣY YXY*`. Its characteristic polynomial independently yields the claimed formal codegrees and induction dimensions. All nine fermion sign solutions with zero signed dimension sum put the dimension-five summand in the centralizing part. Every source involution and all grading possibilities were independently enumerated.

Source tensor hashes:

| Ring | Canonical compact-JSON SHA256 |
|---|---|
| R9_2_12 | `da611b1fd91686294deac7afe234e3732658da54718c4669deeffa95c3295cf8` |
| R9_2_959 | `891b9cf737debdc8a1fbd3d2281c2db06ac07778587b500ad4f343d72862a1c4` |

The author verifier additionally revalidates the existing phase-four GT audit status and its recorded source hashes. This audit accepts that independently audited all-cocycle GT theorem as an explicit dependency; it does not replace it by a new untwisted search.

The logical chain is complete: the fermion argument forces weak group-theoreticality; the existing no-GT result and Section 4 force solvability; trivial universal grading forces a final C2-equivariantization; and every resulting dimension-60 type is nonsolvable. Both general exclusions are approved.

Independent replay:

```sh
python rank9_m2_research/phase5/audit_integral120/independent_checks.py
```

Output: `PASS: independent raw/corpus, ring, full-induction, parity, involution and grading checks`.



# Independent audit: dimension 504


The root reviewer accepts the general-complex exclusion of R9_2_941.
This review checked the categorical argument separately from the finite
calculation. It does not infer a categorical premise from a successful
arithmetic test.

1. Integrality of the hypothetical category makes it pseudo-unitary, with
   positive spherical dimensions. Every central object has an integral
   dimension because its forgetful image is an object of the integral
   category. Modularity gives 504²/z² integral, hence z divides 504.
2. Ostrik, arXiv:1309.4822, Example 2.9 and the paragraph immediately
   before Theorem 2.13 give exactly
   S(A_chi,Z)/dim(A_chi)=chi(F(Z)) for each scalar character. Symmetry
   of S makes S(A_chi,Z)/z an algebraic integer. No commutativity or
   unitarity assumption is hidden in this identity. Commutativity is
   used separately to obtain the multiplicity-free I(1).
3. The dimension-63 congruences are necessary: 56/63=8/9 for the rational
   codegree-nine characters, and 72/63=8/7 for the cubic characters.
   For alpha=2cos(2pi/7), the standard integral basis 1,alpha,alpha²
   makes the latter condition precisely c1=c2=c3=t+a modulo seven.
4. The seven aggregate cases exhaust the nonnegative dimension equation.
   In the two exceptional cases the norm bound fails already in a single
   rational character or the three cubic characters. The bound follows
   from B-vv^T positive semidefinite, not positivity of a *-structure.
   Independent replay does not use the author's candidate enumeration.
5. Every odd divisor other than 63 has zero Y-coordinate. At dimension
   63 the unique constituent of I(1) has restriction V; any others have
   restriction U. The dimension of I(Y) forces an odd number of U's.
   The dimension of each I(C_l) consequently forces an odd number of
   central dimension-nine simples restricting to C_l. Even-dimensional
   central objects vanish from both parity equations regardless of their
   multiplicities, so no classification of their columns is required.
6. Ring simplicity is checked directly. The accepted nonbraided result
   excludes the modular possibility by 49 not dividing 504 and the
   symmetric possibility by the published non-group-like tensor.
   Liu--Palcoux--Ren 2102.01663v4 Theorem 5.1 explicitly applies to
   arbitrary complex fusion categories and makes the center simple.
   ENO 0809.3031 Corollary 7.2 then contradicts the forced dimension-nine
   simple. These implications do not assume unitarity.

Primary statements were checked directly in their source texts. The
shortest source for the central character identity is Ostrik itself;
Deshpande's later generalization is a compatible additional reference.

Replay: `python phase5/root/verify_941_independent.py`.
The original author's `verify_odd_columns.py` additionally checks all 729
coefficients of the published tensor identification and the cubic
characters against the source products.

Conclusion: accepted as a general exclusion, not merely an exclusion
within a particular construction or categorical class.



# Independent audit: dimension 168


**Verdict: PASS.** The argument in
`phase5/integral168/GENERAL_EXCLUSION.md` establishes that R9_2_1965 has
no complex fusion categorification, using the already independently
audited phase-four group-theoretical exclusion. No mathematical gap was
found. The new proof applies to arbitrary complex fusion categories,
including nonunitary categories; it does not assume that the original
category is braided.

The author's files were not modified. The original verifier was replayed
from a copy with only two path changes: inputs still come from the author's
directory, while the replay certificate is written here. Its replay passed.
A separate verifier, `independent_replay.py`, uses only the Python standard
library, reconstructs the quotient tensor from the displayed rules, and
reads the rank-nine tensor directly from the original compressed census.

## Categorical audit

1. **Positive spherical structure and central characters.** The source is
   integral, so EGNO Proposition 9.6.5 and Corollary 9.6.6 supply its
   canonical positive spherical structure. Ostrik Theorem 2.13 was checked
   directly: the distinguished object has dimension `dim(C)/f_E` and
   multiplicity `dim E`; there is no missing factor of `dim E` in its
   dimension formula. These statements apply to noncommutative fusion
   rings. For a scalar character, the pullback through the forgetful
   homomorphism is exactly the S-matrix character of Ostrik Example 2.9.
   Consequently equation (1) is valid in the required scope.

2. **Forced dimension-three restrictions.** The two displayed scalar
   characters have formal codegree 56. Their distinguished objects are
   distinct, have dimension three, and contain the tensor unit exactly
   once after forgetting. The only possibilities are `1+2g` and `1+u`.
   The correctly ordered noncommutative induction formula gives
   `B[0,5]=1`, excluding `1+2g`. Thus both restrictions are `1+u`.

3. **Centralization without unitarity.** The S entries equal nine.
   Balancing expresses them as sums of roots of unity weighted by
   positive dimensions, with total weight nine. Equality forces every
   constituent twist to be one, so the double braiding itself is the
   identity. This is stronger than a numerical trace observation: the
   balancing identity identifies monodromy with the scalar twist on each
   simple summand, including multiplicity spaces. Pairwise centralization
   is preserved under tensor products, summands, and duals; therefore the
   generated subcategory is symmetric. Its twist is identically one.
   Deligne's classification with the canonical positive spherical
   structure makes it Tannakian. A super-Tannakian loophole is absent.

4. **Central Rep(C2) and the quotient.** Trivial universal grading makes
   the forgetful map on central invertibles injective. Any nontrivial
   invertible in the Tannakian subcategory would generate Rep(C2) and
   forget to g. Its restriction to the original category is fully
   faithful, so EGNO Theorem 8.23.3 applies. Free-module adjunction gives
   `Hom(Q(X),Q(Y)) = Hom(X,Y tensor (1+g))`, up to the harmless left/right
   convention since g is central. Different g-orbits therefore give
   disjoint simple images. The fixed dimension-two object has a
   two-dimensional semisimple endomorphism algebra and splits into two
   distinct simples. Their dimensions add to two, so each is invertible.
   Neither is the unit, by the same adjunction. This proves the complete
   six-simple list, not merely a list of candidate objects. The three
   invertibles form C3, which acts trivially on the singleton of
   dimension-three objects and the pair of dimension-six objects under
   both left and right tensor multiplication. The quotient rules follow.

5. **Dimension-84 contradiction.** The quotient is commutative, so its
   six formal-codegree constituents in I(1) are all multiplicity one.
   The dimension-one constituent is the central unit because the tensor
   unit occurs in I(1). The coordinate budgets, the modulo-three step,
   and both positive-semidefinite obstructions are correct. The completed
   square is exactly
   `-(11*t-40)^2/22-36/11`, strictly negative for every real t.
   Thus the contradiction does not depend on a search bound or on the
   prior lower-rank exclusion of R6_4_38.

6. **Perfect Tannaka group and order.** Since central Rep(C2) is
   impossible and central invertibles inject into `{1,g}`, the Tannaka
   group has trivial abelianization. It is nontrivial because the
   subcategory contains a three-dimensional simple. De-equivariantizing
   its centralizer gives rational algebraic-integer dimension
   `168^2/|G|^2`. This implies `|G|` divides 168. Every proper-divisor
   order is solvable: the two three-prime possibilities, 42 and 84, have
   normal Sylow-seven subgroups and solvable quotients; all other
   possibilities have at most two prime factors. Hence the perfect
   group has order 168. The Tannakian subcategory is Lagrangian, and
   EGNO Corollary 9.13.6 makes the hypothetical original category
   group-theoretical. This contradicts the phase-four theorem within
   exactly its audited scope.

## Independent finite replay

`independent_replay_receipt.json` records the following checks:

- Exact original compressed-census identification and canonical tensor hash.
- All fusion axioms and 6,561 source associativity equations.
- Exact adjoint closure and complete central-involution orbit structure.
- Both scalar characters over Q(sqrt(-7)): all 162 multiplicativity
  equations and formal codegree 56.
- Quotient tensor reconstructed from the displayed rules, all its fusion
  axioms and 1,296 associativity equations, and all 486 quotient-map
  coefficient equations.
- Quotient induction Gram matrix recomputed both by ordered induction and
  Casimir multiplication, with matching results.
- Formal-codegree multiplicities established by exact rational eigenspace
  ranks, independently of the author's SymPy characteristic polynomial.
- All **595** nonnegative distinguished restriction-vector assignments
  with the required dimensions and total restriction. Of these, **510**
  have residual quadratic form **-2** on the a-minus-a-squared vector;
  the remaining **85** have negative two-by-two minors between **-130**
  and **-10**.
- All proper divisors of 168 and the unique possible Sylow-seven counts
  for 42 and 84.
- The accepted phase-four GT exclusion, its independent PASS verdict,
  and all source hashes recorded by that independent audit.

The author's optional R6_4_38 identification also passes the copied
verifier. The independent mathematical contradiction does not use that
identification.

Replay commands:

```
python phase5/audit_integral168/author_verifier_replay.py
python -S phase5/audit_integral168/independent_replay.py
```

The first retains the author's SymPy dependency; the second needs only
standard Python. Neither writes to the original author's directory.

## Sources checked directly

- Ostrik, *Pivotal fusion categories of rank 3*, arXiv:1309.4822,
  Proposition 2.4, Theorem 2.5, Example 2.9, and Theorem 2.13:
  https://arxiv.org/pdf/1309.4822
- Etingof--Gelaki--Nikshych--Ostrik, *Tensor Categories*, Proposition
  9.6.5, Corollary 9.6.6, Theorem 8.23.3, symmetric-category
  classification in Section 9.9, and Corollary 9.13.6:
  https://math.mit.edu/~etingof/egnobookfinal.pdf
- The Deshpande paper cited by the author was opened as a consistency
  check; the central scalar-character identity already follows directly
  from the quoted Ostrik construction:
  https://arxiv.org/pdf/1611.04486

The audit does not claim to replace the established external categorical
theorems with computation. It verifies their exact hypotheses and the
intermediate mathematical deductions, while the replay verifies all
finite premises used here.



# Independent audit: the orbifold model


**Verdict: PASS, with the near-group existence theorem explicitly cited.**
R9_2_1848 is realized by a unitary fusion category obtained from a unitary
near-group category `NG(C18,18)` by Izumi's isotropic-subgroup orbifold.
The categorical construction is justified by literature, and an independent
exact verifier matches all 729 source coefficients. No claim is made that
this audit reconstructs or freshly checks the source near-group associator.

## The source category is asserted to exist exactly

Paul G. Budinski's 2021 thesis, *Exotic Fusion Categories and Their Modular
Data*, Table 3.1 includes four `C18+18` solutions. In §3.3.1 (printed p.41)
the author explicitly states that the list is proved complete for `n<=20`
using §3.3.2. Thus C18 lies within the range of the claimed proof. Immediately before §3.3, printed p.40, the author also states that the defining polynomials were explicitly found for every Galois orbit for n<=19, although omitted for space. This includes C18.

Section 3.3.2, printed pp.46–47, specifically addresses the distinction
between numerical roots and exact solutions. It replaces the approximate
parameters by specified roots of algebraic polynomials, clears denominators
so each residual is an algebraic integer, and checks that all conjugates of
that residual have modulus below one. The norm then forces the residual to
vanish. This is an exact algebraic certification method, not an assertion
that a small numerical residual alone is enough. The section says this is
how the listed solutions are proved exact; C14 is used to explain the
method. The C18 polynomial and all root-isolation/error records are not
included in the proposed certificate, so this audit relies on the thesis's
stated construction rather than independently replaying that computation.

The table's `J_18^1` has pairing parameter `m=1`; §3.1 gives
`<x,y>=exp(2*pi*i*x*y/18)` and `a(x)=exp(-pi*i*x^2/18)`.
The near-group reconstruction is Theorem 3.1.1, citing Evans–Gannon
Corollary 5, in the Cuntz-algebra/unitary setting developed there.
There is no requirement to extend a classification of unitary categories
to arbitrary spherical categories: here a single existing unitary model is
used to prove existence.

## All orbifold hypotheses hold

Izumi, *A Cuntz algebra approach to the classification of near-group
categories*, arXiv:1512.04288v2, §12.1 and Theorem 12.5, constructs the
orbifold inside endomorphisms of an actual crossed-product factor.
Its assumptions are an existing C* near-group category with `m=|G|` and
an isotropic subgroup `H subset Hperp`; no extra numerical ansatz is used.

For `G=C18`, choose `H={0,6,12}`. Direct exponent arithmetic gives

- `Hperp={0,3,6,9,12,15}`;
- `H subset Hperp`;
- `a(h)=1` for every h in H, so one can choose `g_a=0`;
- `G/H=C6`, `Hperp/H=C2`, and `G/Hperp=C3`.

The theorem and the preceding irreducible decomposition give six distinct
invertibles and three distinct noninvertibles. With `g` generating C6
and `X=sigma`, their fusion laws are

`g^6=1`, `g^3 X=X`, `Xg=g^(-1)X`,

`X^2=1+g^3+2*(X+gX+g^2X)`.

These objects are closed under multiplication and duals, and X generates
them: X² includes all three noninvertibles and g³, while products of two
of the noninvertibles produce a generator of C6. Thus the generated
category has exactly these nine simples. Their noninvertible dimension is
`(9+3sqrt(11))/3 = 3+sqrt(11)`.

Unitary associators are inherited from the endomorphism category and
crossed-product construction. The theorem supplies coherence; checking
ring associativity alone is not being used to infer it.

The subgroup calculation in fact works for every unit nondegenerate
bicharacter parameter m on C18 and every corresponding quadratic
refinement: H has odd order and is isotropic, forcing a|H=1. Thus the
fusion-ring conclusion does not depend on a delicate choice among the
four displayed C18 solutions.

## Independent exact transport

`verify_independent.py` does not import the model author's generator or
use the saved model tensor. It reads R9_2_1848 from the original research
verification corpus and derives every product from the quotient-group
arithmetic and the displayed theorem formula. The resulting model-to-source
map is

`[0,1,4,8,3,2,5,7,6]`.

It verifies all 729 coefficients, the unit, all associativity equations,
both Frobenius reciprocity identities, duality, and the FP dimension
equations in `Q(sqrt(11))`. All checks pass. The original source SHA256 is
`42681407529a88aaaf34a909975776d8d1008ee8a99b6e231263dcb1aae9ff5c`.
The receipt is `independent_verification.json`. The author's final `phase5/quadratic_noncomm/REPORT.md` was also inspected: its construction, basis map, scope limitation and quoted theorem hypotheses agree with this audit.

## Primary sources inspected

- Budinski thesis PDF and its extracted text, preserved in
  `phase5/quadratic_noncomm/Budinski2021.pdf` and `.txt`:
  <https://ualberta.scholaris.ca/bitstreams/3f73f320-a2a2-4184-ad81-d8708764f725/download>.
  Source SHA256: `48e02112b25b13d54893d919b435bcb24c8215545ae98aa13db1e47bd10dfb78`.
  Relevant locations: Theorem 3.1.1, Table 3.1, §§3.3.1–3.3.2.
- Izumi full paper <https://arxiv.org/pdf/1512.04288v2>, §12.1,
  Lemma 12.2, the decomposition preceding Theorem 12.3, Theorem 12.5,
  and Remark 12.6(1). The file named `Izumi2016-orbifold.pdf` in the
  author's new folder is a later slide deck; this audit uses the full
  arXiv paper for the theorem and its proof.

No original author files, earlier phases, repositories, or online pages
were modified by this audit.

