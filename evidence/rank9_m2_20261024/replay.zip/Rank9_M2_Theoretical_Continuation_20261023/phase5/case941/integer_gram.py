import json,itertools,sys,time
from pathlib import Path
import sympy as s
from sympy.matrices.normalforms import hermite_normal_form
P=Path(__file__).resolve().parent;j=json.load(open(P/'candidates.json'));cs=[x for x in j['columns']if x[-1]not in[7,8,9]];B=j['B'];A=[];b=[];rn=[]
for i,k in itertools.combinations_with_replacement(range(9),2):A.append([v[i]*v[k]for v in cs]);b.append(B[i][k]);rn.append(['gram',i,k])
for z,n in [(1,1),(56,4),(63,1),(72,3)]:A.append([int(v[0]and v[-1]==z)for v in cs]);b.append(n);rn.append(['low_count',z])
M=s.Matrix(A);bb=s.Matrix(b);print('size',M.shape,flush=True)
for p in [2,3,5,7,11,13]:
 E=[[int(v)%p for v in row]+[int(q)%p]for row,q in zip(A,b)];Q=[[int(i==k)for k in range(len(A))]for i in range(len(A))];r=0
 for k in range(len(cs)):
  hits=[i for i in range(r,len(A))if E[i][k]]
  if not hits:continue
  i=hits[0];E[i],E[r]=E[r],E[i];Q[i],Q[r]=Q[r],Q[i];inv=pow(E[r][k],-1,p);E[r]=[x*inv%p for x in E[r]];Q[r]=[x*inv%p for x in Q[r]]
  for i in range(len(A)):
   if i!=r and E[i][k]:
    mul=E[i][k];E[i]=[(a-mul*c)%p for a,c in zip(E[i],E[r])];Q[i]=[(a-mul*c)%p for a,c in zip(Q[i],Q[r])]
  r+=1
 if any(not any(row[:-1])and row[-1]for row in E):
  i=next(i for i,row in enumerate(E)if not any(row[:-1])and row[-1]);print('CONGRUENCE',p,'rhs',E[i][-1],[(rn[k],a)for k,a in enumerate(Q[i])if a],flush=True)
 else:print('mod',p,'consistent',flush=True)
if '--z3' in sys.argv:
 import z3
 z3.set_param(proof=True);ss=z3.Solver();xx=[z3.Int('x'+str(i))for i in range(len(cs))];ss.add(*[x>=0 for x in xx]);ss.add(*[z3.Sum([a*x for a,x in zip(row,xx)if a])==q for row,q in zip(A,b)]);ss.set(timeout=180000)
 ans=ss.check();print('Z3',ans,flush=True)
 if ans==z3.unsat:(P/'integer_gram.z3proof').write_text(str(ss.proof()))
 if ans==z3.sat:print(ss.model(),flush=True)
 (P/'integer_gram.smt2').write_text(ss.to_smt2());(P/'integer_gram_z3.json').write_text(json.dumps({'result':str(ans)},indent=2))
else:
 H=hermite_normal_form(M);print('hnf',H.shape,'aug',hermite_normal_form(M.row_join(bb)).shape,flush=True);print('same lattice',H==hermite_normal_form(M.row_join(bb)),flush=True)
