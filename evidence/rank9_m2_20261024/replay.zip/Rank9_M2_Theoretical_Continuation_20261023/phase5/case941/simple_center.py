import json,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent; ROOT=P.parents[1]
sys.path.insert(0,str(ROOT/'phase2/integral_theory'))
import center_lp,center_symmetry
base=center_lp.modular_integral_columns
def filt(cs,a,D):return [x for x in base(cs,a,D)if x[-1] not in [7,8,9]]
center_lp.modular_integral_columns=filt
R=center_lp.inputs('R9_2_941');h=int(sys.argv[1])if len(sys.argv)>1 else 4
A,b,meta=center_symmetry.symmetric_data(R,h);print('system',len(A),len(A[0]),flush=True)
y,why=center_lp.exact_separator(A,b,120);print('result',why,'ray',y,flush=True)
(P/f'simple_h{h}.json').write_text(json.dumps({'metadata':meta,'ray':y,'solver_report':why},indent=2)+'\n')
