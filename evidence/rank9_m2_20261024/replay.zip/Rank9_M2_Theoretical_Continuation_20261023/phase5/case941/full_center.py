import sys,json,itertools,time,math
from pathlib import Path
import numpy as np
import sympy as s
from scipy.optimize import milp,Bounds,LinearConstraint,linprog
from scipy.sparse import csc_matrix
P=Path(__file__).resolve().parent
j=json.load(open(P/'candidates.json'));R=j['tensor'];B=j['B'];D=j['D'];ds=j['dimensions']
z=s.Symbol('z');f=z**3+z**2-2*z-1
def mul(a,b):return s.rem(a*b,f,z).expand()
def enc(a):return [int(s.expand(a).coeff(z,k))for k in range(3)]
cubic=[z,z*z-2,1-z-z*z]
for perm in itertools.permutations(cubic):
 ch=[1,0,1,0,0,0,*perm]
 if all(mul(ch[i],ch[j])==s.expand(sum(R[i][j][k]*ch[k]for k in range(9))) for i,j in itertools.product(range(9),repeat=2)):break
else:raise ValueError('no cubic character')
chs=[ds,[1,-1,0,-1,-1,-1,1,1,1]]+[[1,*[(-1 if i==2 else -2 if i==a else 1 if i in [1,3,4,5] else 0)for i in range(1,9)]]for a in [1,3,4,5]]
chs+=[[mul(s.expand(x).subs(z,y),1)for x in ch]for y in cubic]
zs=[1,63,56,56,56,56,72,72,72]
assert all(sum(mul(x,x)for x in chi).expand()==s.Integer(504//dd)for chi,dd in zip(chs,zs))
cs=[v for v in j['columns']if '--allow-pp' in sys.argv or v[-1]not in[7,8,9]]
labs=[]
for v in cs:
 if v[0]:labs.extend((h,v)for h,d in enumerate(zs)if d==v[-1])
 else:labs.append((None,v))
rows=[];rhs=[];rn=[]
for i,k in itertools.combinations_with_replacement(range(9),2):rows.append([v[i]*v[k]for h,v in labs]);rhs.append(B[i][k]);rn.append(['gram',i,k])
for a in range(9):rows.append([int(h==a)for h,v in labs]);rhs.append(1);rn.append(['count',a])
for a,b in itertools.combinations(range(9),2):
 vals=[]
 for h,v in labs:
  pol=0
  if h==b:pol+=zs[a]*sum(chs[a][i]*v[i]for i in range(9))
  if h==a:pol-=zs[b]*sum(chs[b][i]*v[i]for i in range(9))
  vals.append(enc(pol))
 for k in range(3):
  line=[v[k]for v in vals]
  if not any(line):continue
  g=math.gcd(*line);rows.append([x//g for x in line]);rhs.append(0);rn.append(['Ssym',a,b,k])
if '--gram-only' in sys.argv: rows,rhs,rn=rows[:54],rhs[:54],rn[:54]
A=np.array(rows,dtype=float);bb=np.array(rhs,dtype=float)
print('system',A.shape,'labels',len(labs),flush=True)
fun=np.ones(len(labs)) if '--rank'in sys.argv else np.zeros(len(labs))
res=linprog(fun,A_eq=csc_matrix(A),b_eq=bb,bounds=(0,None),method='highs') if '--lp' in sys.argv else milp(fun,integrality=np.ones(len(labs)),bounds=Bounds(0,np.inf),constraints=LinearConstraint(csc_matrix(A),bb,bb),options={'time_limit':240})
print(res.message, 'obj',res.fun,flush=True)
out={'characters':[[enc(x)for x in ch]for ch in chs],'labels':labs,'rows':rn,'solver_message':res.message,'is_exclusion':False}
if res.x is not None:
 xx=[float(x) for x in res.x] if '--lp' in sys.argv else [int(round(x))for x in res.x];assert '--lp' in sys.argv or all(sum(x*a for x,a in zip(xx,row))==b for row,b in zip(rows,rhs));out['exact_solution']=[(labs[i],x)for i,x in enumerate(xx)if x];out['rank']=sum(xx);print('rank',sum(xx),[(v[-1],x)for (h,v),x in out['exact_solution']],flush=True)
(P/('full_center_lp.json'if '--lp' in sys.argv else 'full_center_rank.json'if '--rank'in sys.argv else 'full_center_allowpp.json'if '--allow-pp' in sys.argv else 'full_center_gram.json'if '--gram-only' in sys.argv else 'full_center.json')).write_text(json.dumps(out,indent=2)+'\n')
