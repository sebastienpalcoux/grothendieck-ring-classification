"""Exact standard-library certificate for R9_2_941 odd center restrictions.
No optimizer, numerical eigenvalues, or precomputed candidate list is used.
"""
import json,itertools,math,hashlib
from pathlib import Path
from fractions import Fraction as Q
P=Path(__file__).resolve().parent;ROOT=P.parents[1]
R=json.load(open(ROOT/'work/verification_corpus.json'))['tensors']['R9_2_941'];n=9
d=[1,7,8,7,7,7,9,9,9];D=504
assert all(sum(R[i][j][k]*d[k]for k in range(n))==d[i]*d[j]for i in range(n)for j in range(n))
assert all(R[i][j][k]==R[j][i][k]==R[i][k][j]for i,j,k in itertools.product(range(n),repeat=3))
assert all(R[i][j][0]==int(i==j)for i,j in itertools.product(range(n),repeat=2))
assert all(sum(R[i][j][k]*R[k][a][b]for k in range(n))==sum(R[j][a][k]*R[i][k][b]for k in range(n))for i,j,a,b in itertools.product(range(n),repeat=4))
# Exact identification with the independently copied published tensor.
pub=json.load(open(ROOT/'phase3/audit_models/published_504_tensor.json'));perm=pub['source_to_published_map']
assert all(R[i][j][k]==pub['tensor'][perm[i]][perm[j]][perm[k]]for i,j,k in itertools.product(range(n),repeat=3))
# No nontrivial proper based subring.
subrings=[]
for mask in range(1<<8):
 inds=[0]+[i for i in range(1,n)if mask&(1<<(i-1))];outside=set(range(n))-set(inds)
 if all(not R[i][j][k]for i in inds for j in inds for k in outside):subrings.append(inds)
assert subrings==[[0],list(range(n))]
B=[[sum(R[t][i][k]*R[t][j][k]for t in range(n)for k in range(n))for j in range(n)]for i in range(n)]
def inverse(M):
 E=[[Q(x)for x in row]+[Q(i==j)for j in range(len(M))]for i,row in enumerate(M)]
 for k in range(len(M)):
  p=next(i for i in range(k,len(M))if E[i][k]);E[k],E[p]=E[p],E[k];a=E[k][k];E[k]=[x/a for x in E[k]]
  for i in range(len(M)):
   if i!=k:
    a=E[i][k];E[i]=[x-a*y for x,y in zip(E[i],E[k])]
 return [row[len(M):]for row in E]
Bi=inverse(B)
# Q[t]/(t^3+t^2-2t-1). Elements use ascending coefficient order.
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def scale(a,q):return tuple(x*q for x in a)
def mul(a,b):
 c=[Q(0)]*5
 for i in range(3):
  for j in range(3):c[i+j]+=a[i]*b[j]
 for k in [4,3]:
  c[k-3]+=c[k];c[k-2]+=2*c[k];c[k-1]-=c[k]
 return tuple(c[:3])
one=(Q(1),Q(0),Q(0));zero=(Q(0),)*3
alpha=(Q(0),Q(1),Q(0));beta=(Q(-2),Q(0),Q(1));gamma=(Q(1),Q(-1),Q(-1))
# Identify the correct cyclic ordering from the tensor, without assumptions.
for perm in itertools.permutations([alpha,beta,gamma]):
 chi=[one,zero,one,zero,zero,zero,*perm]
 if all(mul(chi[i],chi[j])==tuple(sum(R[i][j][k]*chi[k][a]for k in range(n))for a in range(3))for i,j in itertools.product(range(n),repeat=2)):break
else:raise AssertionError('no cubic character')
rational=[d,[1,-1,0,-1,-1,-1,1,1,1]]+[[1]+[(-1 if i==2 else -2 if i==j else 1 if i in [1,3,4,5]else 0)for i in range(1,n)]for j in [1,3,4,5]]
centraldims=[1,63,56,56,56,56]
assert all(sum(x*x for x in ch)*z==D for ch,z in zip(rational,centraldims))
assert all(sum(R[i][j][k]*ch[k]for k in range(n))==ch[i]*ch[j]for ch in rational for i,j in itertools.product(range(n),repeat=2))
assert tuple(sum(mul(x,x)[k]for x in chi)for k in range(3))==(Q(7),Q(0),Q(0))
def integral(a):
 # Characteristic polynomial of multiplication by a over Q. Algebraic
 # integrality requires all its rational coefficients to be integers.
 M=[[mul(a,tuple(Q(i==j)for i in range(3)))[k]for j in range(3)]for k in range(3)]
 tr=sum(M[i][i]for i in range(3));tr2=sum(M[i][j]*M[j][i]for i,j in itertools.product(range(3),repeat=2))
 det=sum((1 if p in [(0,1,2),(1,2,0),(2,0,1)]else-1)*M[0][p[0]]*M[1][p[1]]*M[2][p[2]]for p in itertools.permutations(range(3)))
 return all(x.denominator==1 for x in [tr,(tr*tr-tr2)/2,det])
def vectors(z):
 def rec(i,rest,vs):
  if i==n:
   if rest==0:yield tuple(vs)
   return
  for a in range(min(math.isqrt(B[i][i]),rest//d[i],1 if i==0 else 999)+1):yield from rec(i+1,rest-a*d[i],vs+[a])
 yield from rec(0,z,[])
def admissible(v,z):
 if v[0] and z not in [1,56,63,72]:return False
 if any(Q(dd*sum(x*y for x,y in zip(ch,v)),z).denominator!=1 for ch,dd in zip(rational,centraldims)):return False
 a=tuple(Q(72,z)*sum(v[i]*chi[i][k]for i in range(n))for k in range(3))
 if not integral(a):return False
 if any(v[i]*v[j]>B[i][j]for i,j in itertools.product(range(n),repeat=2)):return False
 if sum(v[i]*v[j]*Bi[i][j]for i,j in itertools.product(range(n),repeat=2))>1:return False
 return True
odd=[z for z in range(1,D+1,2)if D%z==0];cases={};counts={}
for z in odd:
 vs=list(vectors(z));counts[z]=len(vs);cases[z]=[v for v in vs if admissible(v,z)]
# The purely arithmetic parity assertion is checked for EVERY odd candidate.
for z,vs in cases.items():
 for v in vs:
  for i in [6,7,8]:assert (z*(v[2]+v[i])+v[0]*v[2])%2==int(z==9 and v[i]==1)
# Independently replay the seven aggregate cases used in the paper proof.
aggregates=[]
for t in [0,1]:
 for a in range(8):
  r=(t+a)%7
  for c in range(3*r,8,7):
   rem=63-t-8*a-9*c
   if rem>=0 and rem%7==0:aggregates.append((t,a,rem//7,c))
assert aggregates==[(0,0,9,0),(0,0,0,7),(0,1,4,3),(0,7,1,0),(1,0,5,3),(1,1,0,6),(1,6,2,0)]
assert cases[63]==[(0,1,1,1,1,1,1,1,1),(1,0,1,0,0,0,2,2,2)]
assert B[0][2]%2==1
# Dimension identities from FI(X): sum_Z z_Z v_Z,i = D*d_i.
assert all(sum(B[i][j]*d[j]for j in range(n))==D*d[i]for i in range(n))
# Low odd columns at dimension63 have v0*v2=1, even dimensions56,72
# have v0*v2 even; for completeness low even dimension condition checked.
low_even={}
for z in [56,72]:
 low_even[z]=[v for v in vectors(z)if v[0]and admissible(v,z)]
 assert all(v[2]%2==0 for v in low_even[z])
# Equivalent full Gram parity certificate, written using source indices.
terms=[(0,6),(1,2),(1,6),(2,3),(2,4),(2,5),(2,6),(2,7),(2,8),(3,6),(4,6),(5,6),(6,6),(6,7),(6,8)]
assert sum(B[i][j]for i,j in terms)==937
out={'status':'PASS','tensor_sha256':hashlib.sha256(json.dumps(R,separators=(',',':')).encode()).hexdigest(),'dimensions':d,'D':D,'B':B,'odd_dimensions':odd,'odd_raw_vector_counts':counts,'odd_candidates':cases,'even_low_candidate_counts':{z:len(vs)for z,vs in low_even.items()},'even_low_v2_values':{z:sorted(set(v[2]for v in vs))for z,vs in low_even.items()},'parity_terms':terms,'parity_rhs':937,'consequence':'For each i=6,7,8, an odd number of central simples have restriction X_i and dimension9.','arithmetic_only':True,'seven_aggregate_cases':aggregates,'published_all729_match':True,'simple_ring':True}
(P/'odd_columns_verified.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
