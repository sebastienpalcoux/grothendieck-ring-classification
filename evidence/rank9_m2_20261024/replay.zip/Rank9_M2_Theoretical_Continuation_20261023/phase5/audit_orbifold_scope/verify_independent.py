#!/usr/bin/env python3
"""Independent exact finite audit; does not import the author's code.

The categorical argument is in REPORT.md. This checks its concrete metric,
the unsimplified double Fourier projections, and the resulting rank12 tensor.
It does not substitute for the Radchenko--Wheeler existence theorem.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import hashlib
import json
import sympy as s

G = list(product(range(8), range(4)))
H = [(0,0), (4,0), (0,2), (4,2)]
def add(u,v): return ((u[0]+v[0])%8, (u[1]+v[1])%4)
def sub(u,v): return ((u[0]-v[0])%8, (u[1]-v[1])%4)
def bp(u,v): return (-F(u[0]*v[0],8)+F(u[1]*v[1],4))%1
def qp(u): return (F(u[0]+u[1],2)-F(u[0]**2,16)+F(u[1]**2,8))%1
def sign(phase):
    phase %= 1
    assert phase in (0,F(1,2))
    return 1 if phase == 0 else -1
def eta(char,h): return (-1)**(char[0]*(h[0]//4)+char[1]*(h[1]//2))
chars=list(product(range(2),repeat=2))
assert all(qp(add(u,v)) == (qp(u)+qp(v)+bp(u,v))%1 for u in G for v in G)
assert all(qp(sub((0,0),u)) == qp(u) for u in G)
assert all(any(bp(u,v) for v in G) for u in G if u != (0,0))
assert all(bp(h,k)==0 for h in H for k in H)
Hp=[u for u in G if all(bp(u,h)==0 for h in H)]
assert Hp==[(x,y) for x,y in G if x%2==0 and y%2==0]
assert all(qp(h)==(-bp(h,(0,1)))%1 for h in H)
# Independently reduce RW's gamma formulas with row vectors and omega.
for x,y in G:
    ug=(x+8*y,4*x+33*y)
    omega=ug[0]*y-ug[1]*x
    assert qp((x,y)) == (F(x+y+x*y,2)+F(omega,64))%1
    for z,w in G:
        assert bp((x,y),(z,w)) == F((ug[0]-x)*w-(ug[1]-y)*z,32)%1

A=list(product(range(4),range(2)))
invertible_ranks=[]
for r in A:
    # p tau(p) acting on v_k=S_(r+k)lambda_k, expanded as a double sum.
    P=s.zeros(4)
    for col,k in enumerate(H):
        for h,l in product(H,repeat=2):
            row=H.index(add(add(k,h),l))
            P[row,col] += s.Rational(sign(qp(h)-bp(h,r)),16)
    assert P*P==P
    expected=int(all(qp(h)==bp(h,r) for h in H))
    assert P.rank()==expected
    invertible_ranks.append(expected)

noninvertible_ranks=[]
for char in chars:
    P=s.zeros(32)
    for col,g in enumerate(G):
        for h,l in product(H,repeat=2):
            dest=sub(g,h)
            coeff=(sign(qp(h))*sign(-bp(h,g))*eta(char,h)
                   *sign(-bp(l,dest))*eta(char,l))
            P[G.index(dest),col] += s.Rational(coeff,16)
    assert P*P==P
    assert P.rank()==2
    # Compare with independently simplified character selection / averaging.
    for col,g in enumerate(G):
        Q=s.zeros(32,1)
        if all(sign(bp(h,g))==eta(char,h) for h in H):
            for h in H: Q[G.index(sub(g,h)),0]+=s.Rational(sign(qp(h)),4)
        assert P[:,col]==Q
    noninvertible_ranks.append(P.rank())

# Build all products from the proved quotient-group formulas.
n=12
N=[[[0]*n for _ in range(n)] for _ in range(n)]
def ai(v): return A.index((v[0]%4,v[1]%2))
def ci(v): return 8+chars.index((v[0]%2,v[1]%2))
for i,j in product(range(n),repeat=2):
    if i<8 and j<8:
        N[i][j][ai((A[i][0]+A[j][0],A[i][1]+A[j][1]))]=1
    elif i<8:
        N[i][j][ci((A[i][0]+chars[j-8][0],A[i][1]+chars[j-8][1]))]=1
    elif j<8:
        N[i][j][ci((chars[i-8][0]-A[j][0],chars[i-8][1]-A[j][1]))]=1
    else:
        u,v=chars[i-8],chars[j-8]
        for k in (0,2):
            N[i][j][ai((u[0]-v[0]+k,u[1]-v[1]-1))]=1
        for k in range(8,12): N[i][j][k]=2
dual=[]
for i in range(n):
    candidates=[j for j in range(n) if N[i][j][0]]
    assert len(candidates)==1 and N[i][candidates[0]][0]==1
    dual.append(candidates[0])
for i,j in product(range(n),repeat=2):
    assert N[0][i][j]==int(i==j)==N[i][0][j]
    assert N[i][j]==N[j][i]
    for k in range(n):
        assert N[i][j][k]==N[dual[i]][k][j]==N[k][dual[j]][i]
        assert N[i][j][k]==N[dual[j]][dual[i]][dual[k]]
        for l in range(n):
            assert sum(N[i][j][t]*N[t][k][l] for t in range(n))==sum(N[j][k][t]*N[i][t][l] for t in range(n))
def mul(x,y): return (x[0]*y[0]+2*x[1]*y[1],x[0]*y[1]+x[1]*y[0])
dims=[(1,0)]*8+[(4,3)]*4
for i,j in product(range(n),repeat=2):
    assert mul(dims[i],dims[j])==tuple(sum(N[i][j][k]*dims[k][a] for k in range(n)) for a in (0,1))
assert dual[8:]==[9,8,11,10]
receipt={
    "status":"PASS", "scope":"Auxiliary rank12 algebraic orbifold; no census promotion",
    "metric_group":"C8 x C4", "source_gamma":[[1,4],[8,33]],
    "isotropic_H":H, "Hperp":Hp, "g_a":[0,1],
    "invertible_representatives":A, "invertible_block_ranks":invertible_ranks,
    "noninvertible_block_ranks":list(map(int,noninvertible_ranks)),
    "projectors_idempotent":True, "rank":12, "invertible_group":"C4 x C2",
    "duality":dual, "noninvertible_FPdim":"4+3sqrt(2)",
    "unit_associativity_reciprocity_duality_FPdim":True,
    "tensor_sha256":hashlib.sha256(json.dumps(N,separators=(",", ":")).encode()).hexdigest(),
    "existence_dependency":"Radchenko--Wheeler Proposition10, Theorem10, Lemma4; general categorical extension independently audited in REPORT.md"
}
out=Path(__file__).with_name("independent_verification.json")
out.write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt,indent=2))
