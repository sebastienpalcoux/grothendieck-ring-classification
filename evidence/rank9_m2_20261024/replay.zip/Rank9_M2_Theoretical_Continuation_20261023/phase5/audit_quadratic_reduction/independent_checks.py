#!/usr/bin/env python3
"""Independent finite audit of the three commutative TY/Morita reductions.

The final completion search deliberately omits the author's m-invariance
prefilters: it enumerates every weak composition of 8, every quotient
automorphism and every alpha, then checks full ring axioms.
"""
import hashlib
import itertools as it
import json
import math
from pathlib import Path
import numpy as np
import sympy as sp

HERE=Path(__file__).resolve().parent
BASE=HERE.parents[1]
AUTHOR=BASE/'phase5/quadratic_comm/ty_module_subtask'
CORPUS=json.loads((BASE/'work/verification_corpus.json').read_text())['tensors']

def need(p, why):
    if not p: raise RuntimeError(why)

def read(name): return json.loads((AUTHOR/name).read_text())
def digest(x): return hashlib.sha256(json.dumps(x,separators=(',',':')).encode()).hexdigest()

def candidates_independent(G, matrices):
    """Enumerate the exact finite Gram-image domain, with no search cutoff."""
    V=sp.Matrix.hstack(*G.columnspace()); r=6; result=set(); domains=[]
    idx=[i*r for i in range(r)]+list(range(1,r))
    GG=np.array(G.tolist(),dtype=np.int64)
    diag=[int(G[i,i]) for i in range(36)]
    for a,b in it.product(range(6),repeat=2):
        vals=[int(i==a) for i in range(6)]+[int(i==b) for i in range(1,6)]
        if (a==0)!=(b==0): continue
        try: sol, pars=V.extract(idx,range(V.cols)).gauss_jordan_solve(sp.Matrix(vals))
        except ValueError: continue
        affine=V*sol; c=affine.subs({p:0 for p in pars}); W=affine.jacobian(pars)
        if W.cols:
            piv=list(W.T.rref()[1]); H=W*W.extract(piv,range(W.cols)).inv()
            offset=c-H*c.extract(piv,[0])
            bounds=[math.isqrt(diag[i]) for i in piv]
            domains.append({'row':a,'column':b,'free_coordinates':piv,'bounds':bounds,
                            'grid_size':math.prod(v+1 for v in bounds)})
            den=math.lcm(*[int(x.q) for x in list(H)+list(offset)])
            h=np.array((H*den).tolist(),dtype=np.int64)
            off=np.array(offset*den,dtype=np.int64).reshape(36)
            values=(off+h@np.array(z,dtype=np.int64) for z in it.product(*(range(v+1) for v in bounds)))
        else:
            den=math.lcm(*[int(x.q) for x in c]); values=[np.array(c*den,dtype=np.int64).reshape(36)]
        for numerator in values:
            if np.any(numerator<0) or np.any(numerator%den): continue
            v=numerator//den
            if any(v[i]*v[i]>diag[i] for i in range(36)):continue
            if np.any(np.outer(v,v)>GG):continue
            A=v.reshape(6,6)
            if all(np.array_equal(A@M,M@A) for M in matrices):result.add(tuple(map(int,v)))
    return sorted(result),domains

records=[]; all_tensors={}
for rid,g,Y in [('R9_2_137',1,8),('R9_2_1607',5,3),('R9_2_1976',8,5)]:
    R=CORPUS[rid]; raw=np.array(R,dtype=np.int64)
    need(np.array_equal(raw,np.transpose(raw,(1,0,2))),'source commutative')
    inv=[i for i in range(9) if sum(R[i][i])==1 and R[i][i][0]==1]
    need(len(inv)==4 and all(R[a][Y][Y]==1 for a in inv),'TY invertibles')
    need([i for i in range(9) if R[g][i][i]]==[Y],'unique fixed object')
    need(R[Y][Y]==[int(i in inv) for i in range(9)],'TY square')
    outside=[i for i in range(9) if i not in inv+[Y]]
    orbits=[]; unseen=set(outside)
    while unseen:
        x=min(unseen); orbit={next(j for j in range(9) if R[a][x][j]) for a in inv}
        stabilizer=[a for a in inv if R[a][x][x]]
        orbits.append({'orbit':sorted(orbit),'stabilizer':stabilizer}); unseen-=orbit
    need(len(orbits)==2 and all(len(o['orbit'])==len(o['stabilizer'])==2 for o in orbits),'two TY orbits')
    h1=next(i for i in orbits[0]['stabilizer'] if i); h2=next(i for i in orbits[1]['stabilizer'] if i)
    need(h1!=h2 and R[h1][h2][g]==1,'unique isotropic g')
    for a in outside: need(R[g][a][a]==0,'free g-action')
    for oi,o in enumerate(orbits):
        for x in o['orbit']:
            need(R[Y][x]==[int(i in orbits[1-oi]['orbit']) for i in range(9)],'TY module graph')
    # Complete fixed-block scalar anti-module domain: at most eight tuples.
    domains=[range(-R[i][Y][Y],R[i][Y][Y]+1,2) for i in range(1,9)]
    anti=[]
    for rest in it.product(*domains):
        v=(1,)+rest
        if all(v[i]*v[j]==sum(R[i][j][k]*v[k] for k in range(9)) for i,j in it.product(range(9),repeat=2)):
            anti.append(v)
    need(len(anti)==1,'complete anti-module branch count')
    saved=read(rid+'_morita_candidates.json'); branch=saved['branches'][0]
    need(tuple(t[0][0] for t in branch['T'])==anti[0],'anti-module branch binding')
    labels=[]; seen=set()
    for i in range(9):
        if i in seen:continue
        if i==Y:labels.extend([(i,1),(i,-1)]);seen.add(i)
        else:
            j=next(k for k in range(9) if R[g][i][k]);labels.append((i,0));seen.update([i,j])
    need([list(a) for a in labels]==branch['labels'],'module labels')
    M=[]
    for i in range(9):
        mat=[]
        for x,sx in labels:
            row=[]
            for y,sy in labels:
                if sx and sy: v=(R[i][x][y]+sx*sy*anti[0][i])//2
                elif sx or sy:v=R[i][x][y]
                else:
                    gx=next(j for j in range(9) if R[g][x][j]);v=R[i][x][y]+R[i][gx][y]
                row.append(v)
            mat.append(row)
        M.append(np.array(mat,dtype=np.int64))
    need([x.tolist() for x in M]==branch['M'],'module action reconstruction')
    for i,j in it.product(range(9),repeat=2):
        need(np.array_equal(M[i]@M[j],sum(R[j][i][k]*M[k] for k in range(9))),'anti-module law')
    need(np.array_equal(M[g],np.eye(6,dtype=int)),'all first rows/columns are unit vectors')
    G=sp.Matrix(36,36,lambda p,q:sum(int(m[q//6,p//6]*m[q%6,p%6]) for m in M))
    need(G.tolist()==branch['G'] and G.rank()==8,'full Morita Gram')
    actions,boxes=candidates_independent(G,M)
    need(actions==sorted(map(tuple,branch['candidates'])) and len(actions)==10,'exhaustive action list')
    cols=sp.Matrix.hstack(*(sp.Matrix(np.outer(a,a).reshape(1296).tolist()) for a in actions))
    weights,parameters=cols.gauss_jordan_solve(sp.Matrix(list(G)))
    need(parameters.rows==0 and sorted(weights)==[1]*8+[2]*2,'unique Gram multiplicities')
    D=read(rid+'_d8_dual_candidates.json')
    group=D['G'];Q=D['Q'];cosets=D['cosets'];qof=[next(q for q,c in enumerate(cosets) if a in c) for a in range(8)]
    B=[np.array(v,dtype=np.int64) for v in D['module_actions']]
    need(len(set(tuple(x.reshape(36)) for x in B[:8]))==8,'faithful invertible actions')
    for a,b in it.product(range(8),repeat=2):need(np.array_equal(B[a]@B[b],B[group[a][b]]),'invertible group binding')
    orders=[]
    for a in range(8):
        v=0
        for power in range(1,9):
            v=group[v][a]
            if v==0:orders.append(power);break
    need(sorted(orders)==[1,2,2,2,2,2,4,4],'D8 group type')
    auts=[(0,)+p for p in it.permutations(range(1,4))
          if all(((0,)+p)[Q[a][b]]==Q[((0,)+p)[a]][((0,)+p)[b]] for a,b in it.product(range(4),repeat=2))]
    reconstructed=[]; tested=0
    for theta in auts:
        if any(not np.array_equal(B[8+a]@B[g0],B[8+Q[a][theta[qof[g0]]]]) for a,g0 in it.product(range(4),range(8))):continue
        for alpha in range(4):
            for v in it.product(range(9),repeat=3):
                m=v+(8-sum(v),)
                if m[-1]<0:continue
                tested+=1;N=np.zeros((12,12,12),dtype=np.int64)
                for a,b in it.product(range(8),repeat=2):N[a,b,group[a][b]]=1
                for a,b in it.product(range(8),range(4)):
                    N[a,8+b,8+Q[qof[a]][b]]=1;N[8+b,a,8+Q[b][theta[qof[a]]]]=1
                for a,b in it.product(range(4),repeat=2):
                    shift=Q[a][theta[b]]
                    for k in cosets[Q[shift][alpha]]:N[8+a,8+b,k]=1
                    for k in range(4):N[8+a,8+b,8+k]=m[Q[shift][k]]
                if any(not np.array_equal(B[a]@B[b],sum(N[a,b,k]*B[k] for k in range(12))) for a,b in it.product(range(12),repeat=2)):continue
                if any(np.count_nonzero(N[a,:,0])!=1 or np.max(N[a,:,0])!=1 for a in range(12)):continue
                dual=[int(np.argmax(N[a,:,0])) for a in range(12)]
                if any(dual[dual[a]]!=a or not np.array_equal(B[dual[a]],B[a].T) for a in range(12)):continue
                if any(N[a,b,c]!=N[dual[a],c,b] for a,b,c in it.product(range(12),repeat=3)):continue
                if not np.array_equal(np.einsum('iju,ukl->ijkl',N,N),np.einsum('jku,iul->ijkl',N,N)):continue
                reconstructed.append((tuple(theta),alpha,m,digest(N.tolist())))
    stored=[(tuple(c['theta']),c['alpha'],tuple(c['multiplicities']),digest(c['N'])) for c in D['candidates']]
    need(sorted(reconstructed)==sorted(stored) and len(stored)==28,'all completion branches including every right action')
    filters=read(rid+'_dual_filters.json'); field_bad=[]; lower=[]; survivors=[]
    lowerdata={r['id']:r for r in read('lower_rank_dependencies.json')['rows']}
    for ci,c in enumerate(D['candidates']):
        N=c['N'];L=list(map(sp.Matrix,N));cas=sum((L[i]*L[c['dual'][i]] for i in range(12)),sp.zeros(12))
        t=sp.Symbol('t'); factors=cas.charpoly(t).as_poly().factor_list()[1]
        foreign=[]
        for f,e in factors:
            if f.degree()==1:continue
            if f.degree()!=2:foreign.append(str(f.as_expr()));continue
            disc=int(sp.discriminant(f.as_expr(),t))
            if not(disc>0 and disc%2==0 and math.isqrt(disc//2)**2==disc//2):foreign.append(str(f.as_expr()))
        need(sorted(foreign)==sorted(filters[ci]['foreign_field_factors']),'field-factor binding')
        if foreign:field_bad.append(ci);continue
        if 'lower_matches' in filters[ci]:
            J=filters[ci]['adjoint_basis'];want={k for i in range(12) for k in range(12) if N[i][c['dual'][i]][k]}
            while True:
                more=want|{k for i in want for j in want for k in range(12) if N[i][j][k]}
                if more==want:break
                want=more
            need(J==sorted(want),'adjoint subring')
            match=filters[ci]['lower_matches'][0]; p=match['map'];lr=lowerdata[match['id']]
            for i,j,k in it.product(range(6),repeat=3):need(N[J[i]][J[j]][J[k]]==lr['N'][p[i]][p[j]][p[k]],'lower-rank tensor transport')
            need(lr['decision']['certificate']['scope']=='general','lower exclusion scope')
            lower.append(ci)
        else:survivors.append(ci)
    need(len(field_bad)==20 and lower==[0,4,20,24] and survivors==[12,25,26,27],'filter partition')
    all_tensors[rid]=D
    records.append({'id':rid,'source_sha256':digest(R),'TY_orbits':orbits,'isotropic_involution':g,
                    'anti_branches':1,'exact_Gram_domain_boxes':boxes,'action_candidates':10,
                    'Gram_weights':list(map(int,weights)),'unpruned_completion_tuples_checked':tested,
                    'complete_ring_count':28,'field_excluded':field_bad,'lower_excluded':lower,'survivors':survivors})
    print(rid,'PASS',flush=True)

isos=read('survivor_isomorphisms.json')
for cl in isos['classes']:
    ref=cl['representative']; target=all_tensors[ref['id']]['candidates'][ref['candidate_index']]['N']
    for member in cl['members']:
        source=all_tensors[member['id']]['candidates'][member['candidate_index']]['N'];p=member['map_to_representative']
        need(sorted(p)==list(range(12)) and p[0]==0,'survivor transport bijection')
        for i,j,k in it.product(range(12),repeat=3):need(source[i][j][k]==target[p[i]][p[j]][p[k]],'survivor full transport')
need(sorted(c['selfdual_count'] for c in isos['classes'])==[6,8,10],'three distinct isomorphism types')

# Independent cohomology and tensor witnesses for the subsequent TY-origin
# associator obstruction.  No indicator assumption about the ambient category.
beta=lambda a,b:(-1)**((a//2)*(b%2))
inflated=lambda a,b,c:(-1)**((a%2)*(b%2)*(c%2))
omega2=lambda a,b,c:(-1)**(a*((b+c)//4))
for a,b,c in it.product(range(4),repeat=3):
    need(beta(b,c)*beta(a,(b+c)%4)*beta((a+b)%4,c)*beta(a,b)==inflated(a,b,c),
         'C2 class inflation is an explicit C4 coboundary')
for a,b,c,d in it.product(range(4),repeat=4):
    need(omega2(b,c,d)*omega2(a,(b+c)%4,d)*omega2(a,b,c)==
         omega2((a+b)%4,c,d)*omega2(a,b,(c+d)%4),'rotation class-two cocycle')
need(math.prod(omega2(1,j,1) for j in range(4))==-1,'nontrivial rotation cyclic invariant')
associator_witnesses=[]
for rid,D in all_tensors.items():
    G=D['G']
    def group_order(x):
        y=0
        for n in range(1,9):
            y=G[y][x]
            if y==0:return n
    for ci in [26,27]:
        N=D['candidates'][ci]['N'];dual=D['candidates'][ci]['dual']
        pairs=[(r,s) for r in range(8) for s in range(8)
               if group_order(r)==4 and group_order(s)==2 and N[r][8]==N[8][s]]
        need(pairs,'rotation/reflection stabilizer relation')
        r,s=pairs[0]
        need(all(N[r][x]==N[x][s] for x in range(8,12)),'all noninvertible stabilizer relations')
        overlap=sum(N[y][s][k]*N[k][dual[y]][r] for y in range(12) for k in range(12))
        need(overlap==4,'supplementary induction overlap')
        associator_witnesses.append({'id':rid,'candidate_index':ci,'rotation':r,'reflection':s,'overlap':overlap})
gates=[]
for rid in all_tensors:
    path=BASE/'phase2/signed'/('gate_'+rid+'.json');gate=json.loads(path.read_text())
    need(gate['id']==rid and gate['complete'] and gate['outcome']=='galois_pseudo_unitarity','source gate outcome')
    need(gate['tensor_sha256']==digest(CORPUS[rid]),'source gate tensor binding')
    gates.append({'id':rid,'gate_file':str(path.relative_to(BASE)),
                  'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
out={'status':'PASS','records':records,'ring_survivor_classes_before_associator':3,
     'TY_origin_survivor_classes_after_associator':2,'associator_witnesses':associator_witnesses,
     'source_Galois_PU_dependencies':gates,
     'scope':'necessary categorical reduction; no existence of a survivor is asserted',
     'author_documents_sha256':{n:hashlib.sha256((AUTHOR/n).read_bytes()).hexdigest() for n in ['THEOREM.md','DUAL_COMPLETION.md','FORCED_D8_ASSOCIATOR.md']}}
(HERE/'independent_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS: all categorical reduction finite premises and all completion branches',flush=True)
