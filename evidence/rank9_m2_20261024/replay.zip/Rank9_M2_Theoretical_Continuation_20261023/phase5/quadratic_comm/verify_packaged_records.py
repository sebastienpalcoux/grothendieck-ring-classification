"""Portable exact verification of the packaged quadratic records.

Uses only the standard library and files inside this directory. This verifies
finite ring certificates, not the separately stated categorical theorems.
"""
from pathlib import Path
import hashlib, itertools, json

P = Path(__file__).resolve().parent
T = P / 'ty_module_subtask'
def read(p): return json.loads(p.read_text())
def digest(x): return hashlib.sha256(json.dumps(x,separators=(',',':')).encode()).hexdigest()
def mm(a,b):
    return [[sum(x*y for x,y in zip(row,col)) for col in zip(*b)] for row in a]
def iso(A,B,f):
    n=len(A)
    assert sorted(f)==list(range(n)) and f[0]==0
    assert all(A[i][j][k]==B[f[i]][f[j]][f[k]] for i,j,k in itertools.product(range(n),repeat=3))
def based(N,du):
    n=len(N)
    assert all(N[0][i][j]==N[i][0][j]==int(i==j) for i,j in itertools.product(range(n),repeat=2))
    assert all(N[i][j][0]==int(j==du[i]) for i,j in itertools.product(range(n),repeat=2))
    assert all(N[i][j][k]==N[du[i]][k][j] for i,j,k in itertools.product(range(n),repeat=3))
    sparse=[[[(k,v) for k,v in enumerate(N[i][j]) if v] for j in range(n)] for i in range(n)]
    for i,j,k in itertools.product(range(n),repeat=3):
        a=[0]*n;b=[0]*n
        for u,v in sparse[i][j]:
            for l,w in sparse[u][k]:a[l]+=v*w
        for u,v in sparse[j][k]:
            for l,w in sparse[i][u]:b[l]+=v*w
        assert a==b

sources=read(P/'source_dependencies.json')['tensors']
structure=read(T/'structure_certificate.json')
for r in structure['records']:
    N=sources[r['id']]
    assert digest(N)==r['tensor_sha256']
    du=[next(j for j in range(9) if N[i][j][0]) for i in range(9)]
    based(N,du)
    g=r['unique_isotropic_free_involution']
    assert all(N[g][i][i]==0 for i in r['nonintegral_basis'])

allc={}
lower={x['id']:x for x in read(T/'lower_rank_dependencies.json')['rows']}
counts=[]
for rid in sources:
    data=read(T/(rid+'_d8_dual_candidates.json'));allc[rid]=data['candidates']
    assert len(data['candidates'])==28
    actions=data['module_actions'];products=[[mm(a,b) for b in actions] for a in actions]
    filters=read(T/(rid+'_dual_filters.json'))
    for ci,c in enumerate(data['candidates']):
        N=c['N'];based(N,c['dual'])
        for i,j in itertools.product(range(12),repeat=2):
            assert products[i][j]==[[sum(N[i][j][k]*actions[k][a][b] for k in range(12)) for b in range(6)] for a in range(6)]
        row=filters[ci];assert row['candidate_index']==ci
        if 'lower_matches' in row:
            J=row['adjoint_basis'];S=[[[N[i][j][k] for k in J] for j in J] for i in J]
            assert all(not N[i][j][k] for i in J for j in J for k in range(12) if k not in J)
            match=row['lower_matches'][0];target=lower[match['id']]
            iso(S,target['N'],match['map'])
            assert target['decision']['status']=='excluded'
        if row['status']=='excluded_in_pseudo_unitary_scope_by_formal_codegree_field':
            # Every such case has identity theta. Its Q characters give
            # x^2-Mx-2=0 and f=8+4x^2. |M|=2,4,6 forces a foreign field.
            assert c['theta']==list(range(4))
            Q=data['Q'];bad=[]
            for vals in itertools.product([-1,1],repeat=3):
                ch=(1,)+vals
                if all(ch[Q[a][b]]==ch[a]*ch[b] for a,b in itertools.product(range(4),repeat=2)):
                    m=sum(a*b for a,b in zip(ch,c['multiplicities']))
                    if abs(m) in [2,4,6]:bad.append(m)
            assert bad
    statuses=[r['status'] for r in filters]
    assert statuses.count('excluded_in_pseudo_unitary_scope_by_formal_codegree_field')==20
    assert statuses.count('excluded_by_existing_general_lower_rank_result')==4
    assert statuses.count('unresolved')==4
    counts.append({'id':rid,'candidate_count':28,'field_filtered':20,'lower_rank_filtered':4})

classes=read(T/'survivor_isomorphisms.json')['classes']
assert len(classes)==3
for cl in classes:
    ref=cl['representative'];B=allc[ref['id']][ref['candidate_index']]['N']
    for member in cl['members']:
        A=allc[member['id']][member['candidate_index']]['N']
        iso(A,B,member['map_to_representative'])

quotients=read(P/'central_lift_reduction_certificate.json')['candidate_quotient_rings']
for q in quotients:
    N=q['tensor'];based(N,q['dual'])
    for r in q['maps']:
        S=sources[r['id']];F=r['source_to_quotient_matrix'];assert digest(S)==r['source_sha256']
        for i,j,k in itertools.product(range(9),range(9),range(6)):
            assert sum(S[i][j][u]*F[u][k] for u in range(9))==sum(F[i][a]*F[j][b]*N[a][b][k] for a,b in itertools.product(range(6),repeat=2))

out={'status':'PASS','standard_library_only':True,'external_file_dependencies':[],
     'scope':'Exact stored tensors, actions, field witnesses, lower transports, common isomorphisms, conditional quotient maps. Categorical premises are separately stated in the proof files.',
     'sources':counts,'common_initial_isomorphism_types':3,
     'common_types_after_separately_verified_associator_obstruction':2,
     'associator_verifier':'ty_module_subtask/forced_associator_check.py',
     'source_status_changes':[],
     'hashes':{str(p.relative_to(P)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(P.rglob('*.json')) if p.name!='packaged_records_receipt.json'}}
(P/'packaged_records_receipt.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS: all packaged finite records; no external files or third-party packages required.')
