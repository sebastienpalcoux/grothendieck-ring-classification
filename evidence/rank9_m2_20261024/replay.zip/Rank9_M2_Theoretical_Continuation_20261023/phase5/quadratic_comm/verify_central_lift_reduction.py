"""Exact source-ring maps forced conditionally by a central free involution.
These based dimension-preserving ring maps are necessary, not tensor functors.
"""
from pathlib import Path
import itertools,json,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1]
C=json.load(open(R/'work/verification_corpus.json'))['tensors']
source_data=[(137,8,[3,6],7,[4,5],2,1),(1607,3,[1,2],4,[7,8],6,5),(1976,5,[1,2],6,[3,4],7,8)]
outs=[]
for group in ['V4','C4']:
    e=[0,2,1,3]
    G=[[a^b if group=='V4' else e.index((e[a]+e[b])%4) for b in range(4)] for a in range(4)]
    # Basis: 1,h,u,hu,X,Y; h stabilizes both large objects.
    T=[[[0]*6 for _ in range(6)] for _ in range(6)]
    for a,b in itertools.product(range(4),repeat=2):T[a][b][G[a][b]]=1
    for a in range(4):
        for x in range(2):T[a][4+x][4+(x^(a//2))]=T[4+x][a][4+(x^(a//2))]=1
    for x,y in itertools.product(range(2),repeat=2):
        for a in ([0,1] if x==y else [2,3]):T[4+x][4+y][a]=1
        T[4+x][4+y][4]=T[4+x][4+y][5]=4
    assert all(sum(T[i][j][r]*T[r][k][l] for r in range(6))==sum(T[j][k][r]*T[i][r][l] for r in range(6)) for i,j,k,l in itertools.product(range(6),repeat=4))
    du=[next(j for j in range(6) if T[i][j][0]) for i in range(6)]
    assert du[4:]==[4,5]
    assert all(T[i][j][k]==T[du[i]][k][j] for i,j,k in itertools.product(range(6),repeat=3))
    maps=[]
    for rid,tau,o1,h1,o2,h2,g in source_data:
        S=C[f'R9_2_{rid}'];F=[[0]*6 for _ in range(9)]
        for i in [0,g]:F[i][0]=1
        for i in [h1,h2]:F[i][1]=1
        F[tau][2]=F[tau][3]=1
        for i in o1:F[i][4]=1
        for i in o2:F[i][5]=1
        for i,j,k in itertools.product(range(9),range(9),range(6)):
            lhs=sum(S[i][j][r]*F[r][k] for r in range(9))
            rhs=sum(F[i][a]*F[j][b]*T[a][b][k] for a,b in itertools.product(range(6),repeat=2))
            assert lhs==rhs
        maps.append({'id':f'R9_2_{rid}','free_involution':g,'source_to_quotient_matrix':F,'coefficient_checks':9*9*6,'source_sha256':hashlib.sha256(json.dumps(S,separators=(',',':')).encode()).hexdigest()})
    outs.append({'invertible_group':group,'rank':6,'tensor':T,'dual':du,'maps':maps})
out={'status':'PASS','categorical_premise_required':'The uniquely isotropic/free involution g has a half-braiding in C. This has NOT been established.','general_classification_changes':[],'candidate_quotient_rings':outs}
(P/'central_lift_reduction_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS: two rank6 quotient-ring possibilities and six exact source maps; no existence inference.')
