"""Exact ring hypotheses for the TY(V4) module/Morita reduction.

The categorical conclusions use the explicitly cited TY module theorem;
this checker does not manufacture associators or claim a categorification.
"""
from pathlib import Path
import itertools,json,hashlib
P=Path(__file__).resolve().parent;R=P.parents[2]
C=json.load(open(R/'work/verification_corpus.json'))['tensors']


def mul_q(a,b):
 return (a[0]*b[0]+2*a[1]*b[1],a[0]*b[1]+a[1]*b[0])

def add_q(a,b):return(a[0]+b[0],a[1]+b[1])

def multiple(v,n):return(v[0]*n,v[1]*n)

out=[]
for rid,expected_g in [('R9_2_137',1),('R9_2_1607',5),('R9_2_1976',8)]:
 T=C[rid];n=len(T);unit=0
 dual=[next(j for j in range(n) if T[i][j][0]) for i in range(n)]
 G=[i for i in range(n) if sum(T[i][dual[i]])==1]
 assert len(G)==4 and all(T[g][g][0]==1 for g in G)
 def prod(a,b):
  assert sum(T[a][b])==1
  return T[a][b].index(1)
 Ys=[i for i in range(n) if i not in G and T[i][dual[i]]==[int(k in G) for k in range(n)]]
 assert len(Ys)==1;Y=Ys[0];D=sorted(G+[Y]);Xs=[i for i in range(n) if i not in D]
 assert len(Xs)==4
 dims=[(1,0) if i in G else (2,0) if i==Y else (4,3) for i in range(n)]
 for i,j in itertools.product(range(n),repeat=2):
  z=(0,0)
  for k in range(n):z=add_q(z,multiple(dims[k],T[i][j][k]))
  assert z==mul_q(dims[i],dims[j])
 assert all(T[g][Y][Y]==T[Y][g][Y]==1 for g in G)
 assert all(not T[i][j][k] for i,j in itertools.product(D,repeat=2) for k in Xs)
 assert all(not T[i][x][k] for i in D for x in Xs for k in D)
 orbits=[];seen=set()
 for x in Xs:
  if x in seen:continue
  o=sorted(prod(g,x) for g in G);o=sorted(set(o));assert len(o)==2
  stab=[g for g in G if prod(g,x)==x]
  assert len(stab)==2
  orbits.append({'basis':o,'stabilizer':stab});seen.update(o)
 assert len(orbits)==2 and orbits[0]['stabilizer']!=orbits[1]['stabilizer']
 h1=next(g for g in orbits[0]['stabilizer'] if g);h2=next(g for g in orbits[1]['stabilizer'] if g)
 g=prod(h1,h2);assert g==expected_g
 assert all(prod(g,x)!=x for x in Xs)
 for orbit,other in [(orbits[0],orbits[1]),(orbits[1],orbits[0])]:
  for x in orbit['basis']:
   assert T[Y][x]==[int(k in other['basis']) for k in range(n)]
   assert [T[x][dual[x]][k] for k in D]==[int(k in orbit['stabilizer']) for k in D]
 # Coordinate order 00,10,01,11 = 1,h1,h2,g. Module stabilizers force
 # chi(h1,h1)=-1, chi(h1,h2)=1, chi(h2,h2)=-1.
 order=[0,h1,h2,g];coords=[(0,0),(1,0),(0,1),(1,1)]
 chi=[[(-1)**((a[0]*b[0]+a[1]*b[1])%2) for b in coords] for a in coords]
 assert len(set(tuple(row) for row in chi))==4
 isotropic=[order[i] for i in range(1,4) if chi[i][i]==1]
 assert isotropic==[g]
 out.append({'id':rid,'tensor_sha256':hashlib.sha256(json.dumps(T,separators=(',',':')).encode()).hexdigest(),'integral_subcategory_basis':D,'TY_noninvertible':Y,'nonintegral_basis':Xs,'V4_orbits':orbits,'anisotropic_generators':[h1,h2],'unique_isotropic_free_involution':g,'bicharacter_basis_order':order,'forced_nonalt_bicharacter':chi,'dimension_equations_checked':81,'algebra':'1 + b'+str(g),'necessary_dual_rank':12,'necessary_dual_dimensions':['1']*8+['4+3sqrt(2)']*4})
# The pointed dual group: V4 semidirect C2 swapping its two generators.
E=list(itertools.product(range(2),repeat=3));ix={x:i for i,x in enumerate(E)}
def smul(a,b):
 x,y,t=a;u,v,s=b
 if t:u,v=v,u
 return((x+u)%2,(y+v)%2,(t+s)%2)
GT=[[ix[smul(a,b)] for b in E] for a in E]
orders=[]
for a in E:
 x=(0,0,0)
 for j in range(1,9):
  x=smul(x,a)
  if x==(0,0,0):orders.append(j);break
assert sorted(orders)==[1,2,2,2,2,2,4,4]
assert all(smul(smul(a,b),c)==smul(a,smul(b,c)) for a,b,c in itertools.product(E,repeat=3))
center=[i for i,a in enumerate(E) if all(smul(a,b)==smul(b,a) for b in E)]
assert len(center)==2
result={'status':'PASS_exact_ring_hypotheses','classification_changes':[],'records':out,'pointed_dual_group':{'name':'D8_order_8','elements':E,'table':GT,'orders':orders,'center':center},'categorical_proof':'THEOREM.md'}
(P/'structure_certificate.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'records':[{'id':r['id'],'Y':r['TY_noninvertible'],'h1_h2':r['anisotropic_generators'],'g':r['unique_isotropic_free_involution']} for r in out]},indent=2))
