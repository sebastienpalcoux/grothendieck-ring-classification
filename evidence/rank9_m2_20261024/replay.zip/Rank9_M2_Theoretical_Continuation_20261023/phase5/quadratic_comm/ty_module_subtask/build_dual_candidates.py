"""Exhaust rank-12 two-orbit completions of the forced Morita actions."""
from pathlib import Path
import json,itertools,sympy as s,numpy as np
P=Path(__file__).resolve().parent
outs=[]
for rid in ['R9_2_137','R9_2_1607','R9_2_1976']:
 data=json.load(open(P/(rid+'_morita_candidates.json')));assert data['anti']['complete'] and len(data['branches'])==1
 b=data['branches'][0];A=[np.array(v,dtype=np.int64).reshape(6,6) for v in b['candidates']]
 flat=[x.reshape(36) for x in A]
 S=s.Matrix.hstack(*[s.Matrix(np.outer(x,x).reshape(1296).tolist()) for x in flat])
 rhs=s.Matrix(sum(b['G'],[]));sol,par=S.gauss_jordan_solve(rhs);assert par.rows==0
 assert all(v.is_Integer for v in sol)
 mult=[int(v) for v in sol];assert S*s.Matrix(mult)==rhs
 assert all(v>0 for v in mult) and sum(mult)==12
 perms=[i for i,a in enumerate(A) if np.array_equal(a.sum(axis=0),np.ones(6,dtype=int)) and np.array_equal(a.sum(axis=1),np.ones(6,dtype=int))]
 unit=next(i for i in perms if np.array_equal(A[i],np.eye(6,dtype=int)));invs=[unit]+[i for i in perms if i!=unit]
 assert len(invs)==8 and all(mult[i]==1 for i in invs)
 non=[i for i in range(len(A)) if i not in invs];assert len(non)==2 and all(mult[i]==2 for i in non)
 G=[[next(k for k,l in enumerate(invs) if np.array_equal(A[i]@A[j],A[l])) for j in invs] for i in invs]
 H=[g for g in range(8) if all(G[g][k]==G[k][g] for k in range(8))];assert len(H)==2 and H[0]==0
 cosets=sorted(set(tuple(sorted(G[g][h] for h in H)) for g in range(8)))
 qof=[next(i for i,c in enumerate(cosets) if g in c) for g in range(8)]
 Q=[[qof[G[a[0]][bb[0]]] for bb in cosets] for a in cosets];assert Q[0]==list(range(4))
 base=A[non[0]];B=[A[i] for i in invs]+[A[invs[c[0]]]@base for c in cosets]
 assert all(any(np.array_equal(v,A[i]) for i in non) for v in B[8:])
 pi=[0 if np.array_equal(v,base) else 1 for v in B[8:]];assert sorted(pi)==[0,0,1,1]
 auts=[]
 for p in itertools.permutations(range(1,4)):
  th=(0,)+p
  if all(th[th[i]]==i for i in range(4)) and all(th[Q[i][j]]==Q[th[i]][th[j]] for i,j in itertools.product(range(4),repeat=2)):auts.append(th)
 models=[];considered=0
 for th in auts:
  if any(not np.array_equal(B[8+a]@B[g],B[8+Q[a][th[qof[g]]]]) for a in range(4) for g in range(8)):continue
  for alpha in range(4):
   if th[alpha]!=alpha:continue
   for x,y,z in itertools.product(range(9),repeat=3):
    w=8-x-y-z
    if w<0:continue
    m=(x,y,z,w)
    if any(m[q]!=m[th[q]] or m[q]!=m[Q[q][alpha]] for q in range(4)):continue
    if any(m[q]!=m[Q[q][Q[g][th[g]]]] for q,g in itertools.product(range(4),repeat=2)):continue
    considered+=1;N=np.zeros((12,12,12),dtype=np.int64)
    for g,h in itertools.product(range(8),repeat=2):N[g,h,G[g][h]]=1
    for g,a in itertools.product(range(8),range(4)):
     N[g,8+a,8+Q[qof[g]][a]]=1;N[8+a,g,8+Q[a][th[qof[g]]]]=1
    for a,c in itertools.product(range(4),repeat=2):
     shift=Q[a][th[c]]
     for g in cosets[Q[shift][alpha]]:N[8+a,8+c,g]=1
     for q in range(4):N[8+a,8+c,8+q]=m[Q[shift][q]]
    if any(not np.array_equal(B[i]@B[j],sum((N[i,j,k]*B[k] for k in range(12)),np.zeros((6,6),dtype=int))) for i,j in itertools.product(range(12),repeat=2)):continue
    dual=[next(j for j in range(12) if N[i,j,0]) for i in range(12)]
    if any(not np.array_equal(B[dual[i]],B[i].T) for i in range(12)):continue
    assert np.array_equal(np.einsum('iju,ukl->ijkl',N,N),np.einsum('jku,iul->ijkl',N,N))
    assert all(N[i,j,k]==N[dual[i],k,j] for i,j,k in itertools.product(range(12),repeat=3))
    models.append({'theta':list(th),'alpha':alpha,'multiplicities':list(m),'dual':dual,'N':N.tolist()})
 result={'id':rid,'status':'necessary_dual_completions_complete','module_branch_count':1,'gram_candidate_count':len(A),'gram_candidate_multiplicities':mult,'invertible_candidate_indices':invs,'noninvertible_candidate_indices':non,'G':G,'H':H,'cosets':cosets,'Q':Q,'pi':pi,'module_actions':[v.tolist() for v in B],'pre_action_candidate_count':considered,'candidates':models}
 (P/(rid+'_d8_dual_candidates.json')).write_text(json.dumps(result,indent=2)+'\n')
 print(rid,'candidates',len(models),'weights',mult,'pi',pi,'parameters',[(r['theta'],r['alpha'],r['multiplicities']) for r in models],flush=True)
 outs.append({k:v for k,v in result.items() if k not in ['candidates','module_actions']})
(P/'dual_completion_summary.json').write_text(json.dumps(outs,indent=2)+'\n')
