from pathlib import Path
import json,sys,itertools
P=Path(__file__).resolve().parent;R=P.parents[2];sys.path.insert(0,str(R/'work'))
from common import based_iso
D={rid:json.load(open(P/(rid+'_d8_dual_candidates.json'))) for rid in ['R9_2_137','R9_2_1607','R9_2_1976']}
S={rid:json.load(open(P/(rid+'_dual_filters.json'))) for rid in D}
reps=[];classes=[]
for rid in D:
 for f in S[rid]:
  if not f['status'].startswith('unresolved'):continue
  i=f['candidate_index'];N=D[rid]['candidates'][i]['N'];found=False
  for j,r in enumerate(reps):
   iso=based_iso(N,r['N'])
   if iso is not None:classes[j]['members'].append({'id':rid,'candidate_index':i,'map_to_representative':iso});found=True;break
  if not found:
   reps.append({'id':rid,'candidate_index':i,'N':N});classes.append({'representative':{'id':rid,'candidate_index':i},'members':[{'id':rid,'candidate_index':i,'map_to_representative':list(range(12))}]})
old=json.load(open(R/'phase4/quadratic_noncomm/1975_d8_dual_candidates.json'))['candidates']
for j,r in enumerate(reps):
 classes[j]['matches_1975']=[]
 for k,c in enumerate(old):
  iso=based_iso(r['N'],c['N'])
  if iso is not None:classes[j]['matches_1975'].append({'alpha':c['alpha'],'a':c['a'],'candidate_index':k,'map':iso})
 classes[j]['selfdual_count']=sum(r['N'][i][i][0] for i in range(12))
assert len(classes)==3
(P/'survivor_isomorphisms.json').write_text(json.dumps({'status':'PASS','classes':classes},indent=2)+'\n')
print(json.dumps(classes,indent=2))
