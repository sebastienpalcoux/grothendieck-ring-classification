"""Exact FP-field obstruction and lower-rank adjoint transports."""
from pathlib import Path
import sys,json,itertools,math,sympy as s
P=Path(__file__).resolve().parent;R=P.parents[2]
sys.path.insert(0,str(R/'work'))
from common import based_iso,coarse
census=[v for v in json.load(open(R/'phase3/audit_baseline/rank6_census.json')) if v['m']==4]
ledger={v['id']:v for v in json.load(open(R/'phase3/audit_baseline/rank6_ledger.json'))}
t=s.symbols('t');out=[];lowerrows={}
for rid in ['R9_2_137','R9_2_1607','R9_2_1976']:
 D=json.load(open(P/(rid+'_d8_dual_candidates.json')));answers=[]
 for ci,r in enumerate(D['candidates']):
  N=r['N'];mat=list(map(s.Matrix,N));cas=sum((mat[i]*mat[r['dual'][i]] for i in range(12)),s.zeros(12))
  factors=cas.charpoly(t).as_poly().factor_list()[1]
  def good(p):
   if p.degree()==1:return True
   if p.degree()!=2:return False
   a,b,c=map(int,p.all_coeffs());delta=b*b-4*a*c
   return delta>0 and delta%2==0 and math.isqrt(delta//2)**2==delta//2
  foreign=[str(p.as_expr()) for p,e in factors if not good(p)]
  row={'candidate_index':ci,'theta':r['theta'],'alpha':r['alpha'],'multiplicities':r['multiplicities'],'regular_Casimir_factors':[[str(p.as_expr()),e] for p,e in factors],'foreign_field_factors':foreign}
  if foreign:row['status']='excluded_in_pseudo_unitary_scope_by_formal_codegree_field'
  else:
   J={0}
   for x in range(12):J.update(k for k,v in enumerate(N[x][r['dual'][x]]) if v)
   while True:
    K=J|{k for i in J for j in J for k,v in enumerate(N[i][j]) if v}
    if K==J:break
    J=K
   J=sorted(J);row['adjoint_rank']=len(J)
   if len(J)==6:
    S=[[[N[i][j][k] for k in J] for j in J] for i in J];co=coarse(S);matches=[]
    for rr in census:
     if coarse(rr['N'])!=co:continue
     iso=based_iso(S,rr['N'])
     if iso is not None:
      matches.append({'id':rr['id'],'map':iso,'status':ledger[rr['id']]['status']})
      lowerrows[rr['id']]={**rr,'decision':ledger[rr['id']]}
    assert len(matches)==1
    row['adjoint_basis']=J;row['lower_matches']=matches
    row['status']='excluded_by_existing_general_lower_rank_result' if matches[0]['status']=='excluded' else 'unresolved_lower_rank_adjoint'
   else:row['status']='unresolved'
  answers.append(row)
 (P/(rid+'_dual_filters.json')).write_text(json.dumps(answers,indent=2)+'\n')
 counts={st:sum(v['status']==st for v in answers) for st in sorted({v['status'] for v in answers})};print(rid,counts,flush=True)
 print('lower',[(v['candidate_index'],v.get('lower_matches')) for v in answers if 'lower_matches' in v],flush=True)
 out.append({'id':rid,'counts':counts,'survivor_indices':[v['candidate_index'] for v in answers if v['status'].startswith('unresolved')]})
(P/'dual_filter_summary.json').write_text(json.dumps(out,indent=2)+'\n')
(P/'lower_rank_dependencies.json').write_text(json.dumps({'source_census':'phase3/audit_baseline/rank6_census.json','source_ledger':'phase3/audit_baseline/rank6_ledger.json','rows':list(lowerrows.values())},indent=2)+'\n')
