from pathlib import Path
import json,sympy as s
P=Path(__file__).resolve().parent
D=json.load(open(P/'R9_2_137_d8_dual_candidates.json'));t=s.symbols('t');out=[]
for i in [12,25,26]:
 r=D['candidates'][i];N=list(map(s.Matrix,r['N']))
 W=s.Matrix.hstack(*s.Matrix.vstack(*(N[a]*N[b]-N[b]*N[a] for a in range(12) for b in range(a))).nullspace())
 assert W.cols in[4,8]
 C=sum((N[a]*N[r['dual'][a]] for a in range(12)),s.zeros(12));Pi=W*(W.T*W).inv()*W.T
 # The regular representation outside its scalar blocks has dimension 4 or 8;
 # it must therefore consist entirely of degree-two irreducible blocks.
 F=(s.eye(12)+Pi)*C/2
 out.append({'candidate_index':i,'theta':r['theta'],'alpha':r['alpha'],'one_dimensional_irreducible_count':W.cols,'two_dimensional_irreducible_count':(12-W.cols)//4,'formal_codegree_regular_multiplicity_polynomial':[[str(p.as_expr()),e] for p,e in F.charpoly(t).as_poly().factor_list()[1]],'I1_distinguished_simple_count':W.cols+(12-W.cols)//4})
(P/'survivor_formal_codegrees.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
