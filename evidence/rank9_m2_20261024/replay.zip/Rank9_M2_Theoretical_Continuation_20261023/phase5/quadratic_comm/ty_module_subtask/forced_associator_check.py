"""Exact witnesses for the forced D8 associator obstruction.

No numerical roots of unity, external packages, or categorical assumptions are
encoded as tests. The categorical proof is in FORCED_D8_ASSOCIATOR.md.
"""
from pathlib import Path
import hashlib
import json

P = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def order(G, x):
    y = 0
    for k in range(1, len(G) + 1):
        y = G[y][x]
        if y == 0:
            return k
    raise AssertionError("Not a finite group element")


def product(xs):
    z = 1
    for x in xs:
        z *= x
    return z


# The nonalternating bicharacter on V4 is diag(-1,-1).
chi = [[(-1) ** (((a & 1) * (b & 1)) + ((a >> 1) * (b >> 1)))
        for b in range(4)] for a in range(4)]
assert sum(chi[a][a] for a in range(4)) == 0
ty_nu4_Y = sum(chi[a][a] for a in range(4)) // 2
ty_weighted_nu4 = 4 + 2 * ty_nu4_Y
assert ty_nu4_Y == 0 and ty_weighted_nu4 == 4

# Pullback to C4 of either C2 3-class is a coboundary. A concrete cochain
# for the nontrivial one is beta(a,b)=(-1)^(floor(a/2)*(b mod 2)).
beta = lambda a, b: (-1) ** ((a // 2) * (b % 2))
pullback = lambda a, b, c: (-1) ** ((a % 2) * (b % 2) * (c % 2))
for a in range(4):
    for b in range(4):
        for c in range(4):
            delta = (beta(b, c) * beta(a, (b + c) % 4)
                     * beta((a + b) % 4, c) * beta(a, b))
            assert delta == pullback(a, b, c)
assert product(pullback(1, j, 1) for j in range(4)) == 1

# A representative of class 2 in H^3(C4,C*) has cyclic invariant -1.
rotation_class_2 = lambda a, b, c: (-1) ** (a * ((b + c) // 4))
assert product(rotation_class_2(1, j, 1) for j in range(4)) == -1

records = []
for rid in [137, 1607, 1976]:
    path = P / f"R9_2_{rid}_d8_dual_candidates.json"
    obj = json.loads(path.read_text())
    G = obj["G"]
    orders = [order(G, x) for x in range(8)]
    assert sorted(orders) == [1, 2, 2, 2, 2, 2, 4, 4]
    rotations = [x for x in range(8) if orders[x] == 4]
    r = rotations[0]
    rinv = next(x for x in range(8) if G[r][x] == 0)
    assert rotations == sorted([r, rinv])
    # Morita-invariance of the weighted indicator yields 4 = 6 + 2 nu4(r).
    forced_nu4_rotation = (ty_weighted_nu4 - 6) // 2
    assert forced_nu4_rotation == -1
    q = {g: i for i, coset in enumerate(obj["cosets"]) for g in coset}
    witnesses = []
    for case in [26, 27]:
        c = obj["candidates"][case]
        N, dual = c["N"], c["dual"]
        assert c["theta"] != list(range(4))
        s = next(x for x in range(8)
                 if orders[x] == 2 and q[x] == c["theta"][q[r]])
        X = 8
        assert N[r][X] == N[X][s]
        assert sum(N[r][X]) == 1
        # Every simple noninvertible is fixed by the cyclic action (r,s).
        assert all(N[r][a] == N[a][s] for a in range(8, 12))
        # Supplementary PU trace proof: these inductions share four labels,
        # counted with multiplicity, whereas their fourth twist powers differ.
        overlap = sum(N[Y][s][k] * N[k][dual[Y]][r]
                      for Y in range(12) for k in range(12))
        assert overlap == 4
        witnesses.append({
            "candidate_index": case,
            "theta": c["theta"],
            "alpha": c["alpha"],
            "rotation_r": r,
            "rotation_order": orders[r],
            "reflection_s": s,
            "reflection_order": orders[s],
            "simple_X": X,
            "rX_equals_Xs": N[r][X],
            "cyclic_stabilizer_order": 4,
            "left_cyclic_associator_class_mod4": 2,
            "right_pulledback_associator_class_mod4": 0,
            "cyclic_obstruction_invariant": -1,
            "I_r_I_s_overlap": overlap,
            "verdict": "excluded_for_TY_origin_associator_general_complex",
        })
    records.append({"source_id": obj["id"], "input_sha256": digest(path),
                    "invertible_orders": orders, "witnesses": witnesses,
                    "remaining_labelled_uniform_cases": [12, 25]})

out = {
    "status": "PASS",
    "scope": "general complex categories, conditional on proved TY-origin Morita reduction",
    "chi": chi,
    "TY_nu4_Y": ty_nu4_Y,
    "TY_weighted_nu4": ty_weighted_nu4,
    "D8_forced_nu4_rotation": -1,
    "C2_to_C4_pullback_beta": [[beta(a, b) for b in range(4)] for a in range(4)],
    "pullback_coboundary_checks": 64,
    "records": records,
    "new_source_resolutions": 0,
    "remaining_uniform_ring_isomorphism_types": 2,
}
(P / "forced_associator_certificate.json").write_text(json.dumps(out, indent=2) + "\n")
print(json.dumps({k: v for k, v in out.items() if k not in ["chi", "records"]}, indent=2))
for record in records:
    print(record["source_id"], [(w["candidate_index"], w["rotation_r"], w["reflection_s"], w["I_r_I_s_overlap"]) for w in record["witnesses"]])
