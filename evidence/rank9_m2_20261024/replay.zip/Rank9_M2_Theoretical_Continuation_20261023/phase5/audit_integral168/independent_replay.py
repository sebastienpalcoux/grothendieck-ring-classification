#!/usr/bin/env python3
"""Independent standard-library audit; never writes the author's directory."""
from pathlib import Path
from fractions import Fraction
from itertools import product
from collections import Counter
import gzip,hashlib,json
if not __debug__:raise SystemExit('Run without -O')
HERE=Path(__file__).resolve().parent
BASE=HERE.parents[1]
AUTHOR=HERE.parent/'integral168'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def digest(o):return hashlib.sha256(json.dumps(o,separators=(',',':')).encode()).hexdigest()
def mm(a,b):return [[sum(x*y for x,y in zip(row,col)) for col in zip(*b)] for row in a]
def rank(a):
 a=[[Fraction(x) for x in row] for row in a];r=0
 for j in range(len(a[0])):
  k=next((k for k in range(r,len(a)) if a[k][j]),None)
  if k is None:continue
  a[r],a[k]=a[k],a[r];z=a[r][j];a[r]=[x/z for x in a[r]]
  for k in range(r+1,len(a)):
   z=a[k][j]
   if z:a[k]=[x-z*y for x,y in zip(a[k],a[r])]
  r+=1
 return r

def validate(N,ds):
 n=len(N);dual=[next(j for j in range(n) if N[i][j][0]) for i in range(n)]
 assert sum(x*x for x in ds) in (84,168)
 for i,j,k in product(range(n),repeat=3):
  assert type(N[i][j][k]) is int and N[i][j][k]>=0
  assert N[0][i][j]==N[i][0][j]==int(i==j)
  assert N[i][j][0]==int(j==dual[i])
  assert N[i][j][k]==N[dual[j]][dual[i]][dual[k]]
  assert N[i][j][k]==N[dual[i]][k][j]
 for i,j in product(range(n),repeat=2):
  assert sum(N[i][j][k]*ds[k] for k in range(n))==ds[i]*ds[j]
 for i,j,k,l in product(range(n),repeat=4):
  assert sum(N[i][j][a]*N[a][k][l] for a in range(n))==sum(N[j][k][a]*N[i][a][l] for a in range(n))
 return dual

def gram(N,dual):
 n=len(N);b=[[0]*n for _ in range(n)]
 for j,t in product(range(n),repeat=2):
  for a,coef in enumerate(N[t][j]):
   if coef:
    for k,v in enumerate(N[a][dual[t]]):b[k][j]+=coef*v
 assert b==list(map(list,zip(*b)))
 return b

counts=Counter()
for physical,line in enumerate(gzip.open(BASE/'inputs/rank9_M2_verified/FusionRingMultiplicationTables.txt.gz','rt'),1):
 N=json.loads(line.replace('{','[').replace('}',']'));m=max(v for a in N for b in a for v in b);counts[m]+=1
 if m==2 and counts[m]==1965:break
else:raise AssertionError('Original ring missing')
assert N==json.loads((AUTHOR/'source_tensor.json').read_text())
assert digest(N)=='07dac58d848bd451d8a3d9231bfd1c23c1b0117541e6de5055fa0ab90314c4f9'
ds=[1,6,6,6,6,1,2,3,3];dual=validate(N,ds)
ad={k for i in range(9) for k,v in enumerate(N[i][dual[i]]) if v}
while True:
 new=ad|{k for i in ad for j in ad for k,v in enumerate(N[i][j]) if v}
 if new==ad:break
 ad=new
assert ad==set(range(9))
B=gram(N,dual);assert B[0][5]==1
for i in range(9):assert N[5][i]==N[i][5]
orbits=[];left=set(range(9))
while left:
 i=min(left);j=N[5][i].index(1);orb=sorted({i,j});orbits.append(orb);left-=set(orb)
assert orbits==[[0,5],[1,3],[2,4],[6],[7,8]]

# Independent arithmetic in Q[s]/(s^2+7).
def mul(v,w):return (v[0]*w[0]-7*v[1]*w[1],v[0]*w[1]+v[1]*w[0])
def summ(vs):return tuple(sum(x[i] for x in vs) for i in (0,1))
for eps in (1,-1):
 chi=[(x,0) for x in ds]
 for i in (1,3):chi[i]=(-1,eps)
 for i in (2,4):chi[i]=(-1,-eps)
 for i,j in product(range(9),repeat=2):
  assert mul(chi[i],chi[j])==summ([(N[i][j][k]*chi[k][0],N[i][j][k]*chi[k][1]) for k in range(9)])
 assert summ([mul(chi[i],chi[dual[i]]) for i in range(9)])==(56,0)
 assert chi[0][0]+chi[6][0]==3

# Build the quotient entirely from the displayed theoretical multiplication rules.
T=[[[0]*6 for _ in range(6)] for _ in range(6)]
for i,j in product(range(3),repeat=2):T[i][j][(i+j)%3]=1
for i in range(3):
 for j in (3,4,5):T[i][j][j]=T[j][i][j]=1
T[3][3]=[1,1,1,2,0,0]
T[3][4]=T[4][3]=[0,0,0,0,3,0]
T[3][5]=T[5][3]=[0,0,0,0,0,3]
T[4][4]=[0,0,0,0,2,4];T[5][5]=[0,0,0,0,4,2]
T[4][5]=T[5][4]=[1,1,1,3,2,2]
assert T==json.loads((AUTHOR/'forced_d84_tensor.json').read_text())
e=[1,1,1,3,6,6];dt=validate(T,e)
P=[[1,0,0,0,0,0],[0,0,0,0,1,0],[0,0,0,0,0,1],[0,0,0,0,1,0],[0,0,0,0,0,1],[1,0,0,0,0,0],[0,1,1,0,0,0],[0,0,0,1,0,0],[0,0,0,1,0,0]]
for i,j,k in product(range(9),range(9),range(6)):
 assert sum(N[i][j][a]*P[a][k] for a in range(9))==sum(P[i][a]*P[j][b]*T[a][b][k] for a,b in product(range(6),repeat=2))
BT=gram(T,dt)
# A separate Casimir-multiplication construction agrees with induction.
cas=[sum(T[t][dt[t]][i] for t in range(6)) for i in range(6)]
CM=[[sum(cas[t]*T[t][j][i] for t in range(6)) for j in range(6)] for i in range(6)]
assert BT==CM
for val,mult in [(3,2),(4,1),(28,2),(84,1)]:
 assert 6-rank([[BT[i][j]-val*int(i==j) for j in range(6)] for i in range(6)])==mult
assert BT==[[6,3,3,8,4,4],[3,6,3,8,4,4],[3,3,6,8,4,4],[8,8,8,28,12,12],[4,4,4,12,52,24],[4,4,4,12,24,52]]

# Exhaust every distinguished restriction-vector assignment with the required
# dimensions and row sum, before using PSD. This separately checks the proof's
# budget and quadratic argument without a numerical solver.
budget=[5,3,3,8,4,4]
def options(dim):
 return [(1,a,b,y,x,z) for a,b,y,x,z in product(range(4),range(4),range(9),range(5),range(5)) if 1+a+b+3*y+6*x+6*z==dim]
opts={k:options(k) for k in (3,21,28)}
assignments=unbalanced=balanced=0;minors=[]
for v,w in product(opts[3],repeat=2):
 rem=[budget[i]-v[i]-w[i] for i in range(6)]
 if min(rem)<0:continue
 for q in opts[21]:
  rem2=[rem[i]-q[i] for i in range(6)]
  if min(rem2)<0:continue
  for x in opts[28]:
   y=tuple(rem2[i]-x[i] for i in range(6))
   if y not in opts[28]:continue
   assignments+=1;vectors=[v,w,q,x,y]
   M=[[BT[i][j]-int(i==0 and j==0)-sum(vec[i]*vec[j] for vec in vectors) for j in range(6)] for i in range(6)]
   if any(vec[1:3]!=(1,1) for vec in (v,w,q)):
    assert M[1][1]+M[2][2]-2*M[1][2]==-2;unbalanced+=1
   else:
    m=M[1][1]*M[3][3]-M[1][3]**2
    assert m<0;minors.append(m);balanced+=1
assert assignments and balanced and unbalanced
# Independently compare coefficients after multiplying by 22.
assert [-1672,880,-121]==[-1600-72,880,-121]
# 22*(84-3*t²-(5/2)*(8-t)²) = -(11*t-40)² -72.

# Elementary order restriction for a nontrivial perfect Tannaka group.
def pf(n):
 out=[];p=2
 while p*p<=n:
  if n%p==0:
   out.append(p)
   while n%p==0:n//=p
  p+=1
 if n>1:out.append(n)
 return out
proper=[k for k in range(1,168) if 168%k==0]
three=[k for k in proper if len(pf(k))>=3];assert three==[42,84]
sylow={k:[v for v in range(1,k//7+1) if (k//7)%v==0 and v%7==1] for k in three}
assert all(v==[1] for v in sylow.values())

old=json.loads((BASE/'phase4/integral/GT_verification.json').read_text())
audit=json.loads((BASE/'phase4/audit_integral_gt/audit_verdict.json').read_text())
assert audit['status']=='PASS' and 'R9_2_1965' in audit['group_theoretical_exclusions']
assert 'R9_2_1965' in old['accepted_group_theoretical_exclusions']
for name,s in audit['source_sha256_after_corrections'].items():assert sha(BASE/'phase4/integral'/name)==s
receipt={'status':'PASS','id':'R9_2_1965','source_matches_original_compressed_census':True,'physical_line':physical,'source_tensor_sha256':digest(N),'source_duals':dual,'adjoint_closure':sorted(ad),'central_g_orbits':orbits,'source_B_0_5':B[0][5],'scalar_character_checks':162,'forced_quotient_reconstructed_from_displayed_rules':True,'forced_quotient_tensor_sha256':digest(T),'forced_tensor_map_checks':486,'quotient_Gram_recomputed_two_ways':True,'formal_codegree_eigenspaces':{'3':2,'4':1,'28':2,'84':1},'exhaustive_distinguished_restriction_assignments':assignments,'unbalanced_negative_quadratic_forms':unbalanced,'balanced_negative_minor_count':balanced,'balanced_minor_range':[min(minors),max(minors)],'proper_divisors_168':proper,'three_prime_proper_divisors_and_Sylow7_counts':sylow,'phase4_GT_audit_and_all_source_hashes_match':True,'author_files_sha256':{p.name:sha(p) for p in sorted(AUTHOR.iterdir()) if p.is_file()},'author_verifier_replay':'PASS, using a copy with only input/output path rewrites','categorical_verdict':'General exclusion PASS; see REPORT.md for premise-by-premise audit'}
(HERE/'independent_replay_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':'PASS','assignments':assignments,'unbalanced':unbalanced,'balanced':balanced,'negative_minor_range':receipt['balanced_minor_range']}))
