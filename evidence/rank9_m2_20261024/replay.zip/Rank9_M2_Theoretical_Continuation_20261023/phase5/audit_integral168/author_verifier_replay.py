#!/usr/bin/env python3
"""Exact finite premises of the general R9_2_1965 exclusion.

The categorical implications are proved in GENERAL_EXCLUSION.md.  This verifier
does not silently treat a ring computation as a categorical construction.
"""
import hashlib
import itertools
import json
from pathlib import Path
import sympy as sp

HERE = Path(__file__).resolve().parent.parent / "integral168"
RESEARCH = HERE.parents[1]


def check(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(obj):
    return hashlib.sha256(json.dumps(obj, separators=(",", ":")).encode()).hexdigest()


def read(name):
    return json.loads((HERE / name).read_text())


def validate(R, d):
    n = len(R)
    check(all(len(row) == n and all(len(v) == n for v in row) for row in R), "shape")
    check(all(type(x) is int and x >= 0 for row in R for v in row for x in v), "coefficients")
    dual = []
    for i in range(n):
        check(R[0][i] == R[i][0] == [int(i == k) for k in range(n)], "unit")
        candidates = [j for j in range(n) if R[i][j][0]]
        check(len(candidates) == 1 and R[i][candidates[0]][0] == 1, "dual")
        dual.append(candidates[0])
    for i, j, k in itertools.product(range(n), repeat=3):
        check(R[i][j][k] == R[dual[j]][dual[i]][dual[k]], "dual antiautomorphism")
        check(R[i][j][k] == R[dual[i]][k][j], "Frobenius reciprocity")
    for i, j in itertools.product(range(n), repeat=2):
        check(sum(R[i][j][k] * d[k] for k in range(n)) == d[i] * d[j], "dimensions")
    for i, j, k, ell in itertools.product(range(n), repeat=4):
        check(sum(R[i][j][t] * R[t][k][ell] for t in range(n)) ==
              sum(R[j][k][t] * R[i][t][ell] for t in range(n)), "associativity")
    return dual


def gram(R, dual):
    n = len(R)
    # FI(X_j) = sum_t X_t X_j X_t^*, including noncommutative rings.
    return [[sum(R[t][j][k] * R[k][dual[t]][i]
                 for t in range(n) for k in range(n))
             for j in range(n)] for i in range(n)]


R = read("source_tensor.json")
d = [1, 6, 6, 6, 6, 1, 2, 3, 3]
dual = validate(R, d)
check(sum(x*x for x in d) == 168, "global dimension")
check(digest(R) == "07dac58d848bd451d8a3d9231bfd1c23c1b0117541e6de5055fa0ab90314c4f9", "source binding")
check([i for i, x in enumerate(d) if x == 1] == [0, 5], "invertibles")
check(dual == [0, 2, 1, 4, 3, 5, 6, 7, 8], "source duals")
adjoint = {k for i in range(9) for k in range(9) if R[i][dual[i]][k]}
adjoint_stages = [sorted(adjoint)]
while True:
    enlarged = adjoint | {k for i in adjoint for j in adjoint for k in range(9) if R[i][j][k]}
    if enlarged == adjoint:
        break
    adjoint = enlarged
    adjoint_stages.append(sorted(adjoint))
check(adjoint == set(range(9)), "universal grading is trivial")
g_action = [R[5][i].index(1) for i in range(9)]
check(g_action == [5, 3, 4, 1, 2, 0, 6, 8, 7], "central involution action")
check(all(R[5][i] == R[i][5] and sum(R[5][i]) == 1 for i in range(9)), "g central in ring")
B = gram(R, dual)
check(B[0][5] == 1, "restriction bound excluding 1+2g")

# Exact arithmetic in Q(sqrt(-7)): a+b*s is represented by (a,b).
def add(x, y): return (x[0]+y[0], x[1]+y[1])
def mul(x, y): return (x[0]*y[0]-7*x[1]*y[1], x[0]*y[1]+x[1]*y[0])
def scale(c, x): return (c*x[0], c*x[1])
def total(xs):
    out = (0, 0)
    for x in xs: out = add(out, x)
    return out

characters = []
for sign in [1, -1]:
    z, zb = (-1, sign), (-1, -sign)
    chi = [(1, 0), z, zb, z, zb, (1, 0), (2, 0), (3, 0), (3, 0)]
    for i, j in itertools.product(range(9), repeat=2):
        check(mul(chi[i], chi[j]) == total(scale(R[i][j][k], chi[k]) for k in range(9)), "scalar character")
    f = total(mul(chi[i], chi[dual[i]]) for i in range(9))
    check(f == (56, 0), "formal codegree 56")
    check(add(chi[0], chi[6]) == (3, 0), "centralization character value")
    characters.append({"values_a_b_sqrt_minus7": chi, "formal_codegree": 56})

T = read("forced_d84_tensor.json")
e = [1, 1, 1, 3, 6, 6]
dt = validate(T, e)
check(sum(x*x for x in e) == 84, "quotient dimension")
check(all(T[i][j] == T[j][i] for i in range(6) for j in range(6)), "quotient commutative")

# Images of source simples under the forced free-module tensor functor.
P = [[1,0,0,0,0,0], [0,0,0,0,1,0], [0,0,0,0,0,1],
     [0,0,0,0,1,0], [0,0,0,0,0,1], [1,0,0,0,0,0],
     [0,1,1,0,0,0], [0,0,0,1,0,0], [0,0,0,1,0,0]]
for i, j, k in itertools.product(range(9), range(9), range(6)):
    check(sum(R[i][j][t] * P[t][k] for t in range(9)) ==
          sum(P[i][a] * P[j][b] * T[a][b][k] for a in range(6) for b in range(6)), "forced quotient ring map")
BT = gram(T, dt)
expected = [[6,3,3,8,4,4], [3,6,3,8,4,4], [3,3,6,8,4,4],
            [8,8,8,28,12,12], [4,4,4,12,52,24], [4,4,4,12,24,52]]
check(BT == expected, "D84 induction Gram")
f = sp.Symbol("f")
expected_polynomial = (f-3)**2*(f-4)*(f-28)**2*(f-84)
check(sp.expand(sp.Matrix(BT).charpoly(f).as_expr()-expected_polynomial) == 0, "D84 codegrees")
check(sorted([84//x for x in [3,3,4,28,28,84]]) == [1,3,3,21,28,28], "I1 dimensions")

# The elementary integer-pair step and the polynomial upper bound used in the proof.
pair_options = [(a, 2-a) for a in range(3)]
pair_solutions = [p for p in itertools.product(pair_options, repeat=3)
                  if sum(a for a,b in p) == sum(b for a,b in p) == 3]
for pairs in pair_solutions:
    if pairs != ((1,1),)*3:
        check(sum((a-b)**2 for a,b in pairs) == 8, "unbalanced pair obstruction")
        check(BT[1][1]+BT[2][2]-2*BT[1][2]-8 == -2, "negative residual quadratic form")
t = sp.Symbol("t", real=True)
bound = 84-3*t*t-sp.Rational(5,2)*(8-t)**2
completed = -(11*t-40)**2/sp.Integer(22)-sp.Rational(36,11)
check(sp.expand(bound-completed) == 0, "strictly negative minor bound")

# Optional identification with the pre-existing lower-rank census entry;
# the mathematical exclusion above does not depend on this lower decision.
lower = read("d84_lower_match.json")
perm = lower["source_to_target"]
LT = lower["tensor"] if "tensor" in lower else lower["target_tensor"]
for i,j,k in itertools.product(range(6), repeat=3):
    check(T[i][j][k] == LT[perm[i]][perm[j]][perm[k]], "lower-rank tensor match")
check(lower["id"] == "R6_4_38", "lower-rank ID")

# Bind the independently audited, all-twists group-theoretical obstruction.
dependencies = {}
for relative in ["phase4/integral/GROUP_THEORETICAL_OBSTRUCTIONS.md",
                 "phase4/audit_integral_gt/AUDIT.md",
                 "phase4/audit_integral_gt/audit_verdict.json"]:
    path = RESEARCH / relative
    check(path.is_file(), "missing group-theoretical dependency: " + relative)
    dependencies[relative] = hashlib.sha256(path.read_bytes()).hexdigest()

certificate = {
    "id": "R9_2_1965", "verdict": "exact finite premises PASS",
    "categorical_conclusion": "general exclusion, subject to the proof in GENERAL_EXCLUSION.md and its cited GT obstruction",
    "source_tensor_sha256": digest(R), "dimensions": d, "duals": dual,
    "adjoint_closure_stages": adjoint_stages, "g_action": g_action,
    "induction_gram": B, "scalar_characters": characters,
    "forced_quotient_tensor_sha256": digest(T), "forced_quotient_images": P,
    "quotient_induction_gram": BT,
    "quotient_formal_codegrees": [3,3,4,28,28,84],
    "quotient_distinguished_dimensions": [1,3,3,21,28,28],
    "lower_ring": lower["id"], "lower_map": perm,
    "minor_upper_bound": "-(11*t-40)^2/22-36/11 < 0",
    "existing_GT_dependencies_sha256": dependencies,
    "checks": {"source_associativity_equations":9**4,
               "quotient_associativity_equations":6**4,
               "source_character_equations":2*9**2,
               "quotient_ring_map_equations":9**2*6,
               "lower_tensor_comparisons":6**3}
}
(Path(__file__).resolve().parent / "author_replay_certificate.json").write_text(json.dumps(certificate, indent=2)+"\n")
print("PASS: exact premises for the general exclusion of R9_2_1965")
