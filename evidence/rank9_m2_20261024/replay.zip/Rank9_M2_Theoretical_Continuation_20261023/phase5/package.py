"""Append fifth-continuation evidence to the immutable version-four archive."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json,sys
P=Path(__file__).resolve().parent
baseline,output=map(Path,sys.argv[1:])
expected='93a0e4f4ac7c4a65b700076f2128fae7747f46fe041c76161e08eb21d93b8621'
if hashlib.sha256(baseline.read_bytes()).hexdigest()!=expected:raise ValueError('Expected immutable version-four archive')
if baseline.resolve()==output.resolve():raise ValueError('Keep baseline separate')
root='Rank9_M2_Theoretical_Continuation_20261023/'
with ZipFile(baseline) as z:files={n[len(root):]:z.read(n) for n in z.namelist() if not n.endswith('/')}
original=dict(files)
for name in ('README.md','HANDOFF.md','verify.py','SHA256SUMS.json'):files['phase5/baseline_documents/'+name]=files[name]
files['README.md']=b'''# Rank-nine multiplicity two: fifth research continuation

Current research partition: **2043 excluded, 36 unitary models, 4 unresolved**,
out of 2083 exact-multiplicity-two rings.

Five of the preceding nine residuals are settled: general exclusions of
R9_2_12,941,959,1965 and a unitary model of R9_2_1848. The remaining cases
are R9_2_137,1607,1975,1976; all four have no braided categorification.

Read phase5/REPORT.md and the manuscript in phase5/manuscript/.
The current classification authority is phase5/results/ledger.json;
accepted changes are in phase5/accepted.json. Every changed classification
has a separate categorical audit and exact arithmetic replay.

Install requirements.txt and run python3 verify.py. This checks packaged
hashes, all phase-five accepted finite evidence, every ledger identity,
and all 26244 coefficients of the 36 model transports. The proofs are
reviewed mathematical arguments, not proof-assistant formalizations.
Use python3 verify.py --baseline to additionally replay phase four.
Use python3 verify.py --frontier to also replay the auxiliary Morita and
orbifold evidence; it makes no further rank-nine classification changes.

All previous research evidence is preserved. Earlier ledgers are historical
snapshots, not current status. The phase-three correction of invalid early
half-E6 claims and phase-four independent R8_3_436 repair remain in force.
No universal unitary-table parameterization premise is reinstated.

Downloaded primary papers and their extracted text are not redistributed;
their source URLs and recorded hashes are retained. Local-cache paths in
research reports refer to the original research workspace. Exact arithmetic
replays do not require those downloaded papers or network access.

The four residuals have further necessary Morita-ring reductions and model
construction investigations. Necessary rings and failed ansatzes are not
categorical classifications. Read their reports for exact scope.

No GitHub repository or website was modified. Another agent is performing
an online audit/revision; before future publication reconcile these exact
tensor-bound changes with that agent's current decisions and heads.
The ordered/clean publication handoff is HANDOFF.md. The old private Atlas
is out of scope. The 142 prior multiplicity-one records are unchanged.
'''
files['HANDOFF.md']=(P/'HANDOFF.md').read_bytes()
files['verify.py']=b'''"""Verify the current research package without network access."""
from pathlib import Path
import hashlib,json,subprocess,sys
P=Path(__file__).resolve().parent
manifest=json.loads((P/'SHA256SUMS.json').read_text())
for rel,expected in manifest.items():
    if hashlib.sha256((P/rel).read_bytes()).hexdigest()!=expected:
        raise ValueError('Archive hash mismatch: '+rel)
print('PASS: '+str(len(manifest))+' packaged file hashes.',flush=True)
if '--baseline' in sys.argv:
    subprocess.run([sys.executable,str(P/'phase4/verify.py')],check=True,cwd=P)
subprocess.run([sys.executable,str(P/'phase5/verify.py')]+(['--frontier'] if '--frontier' in sys.argv else []),check=True,cwd=P)
'''
for path in sorted(P.rglob('*')):
    if not path.is_file():continue
    rel=path.relative_to(P)
    if '__pycache__' in rel.parts or 'render' in rel.parts:continue
    if path.suffix in {'.pyc','.tmp','.aux','.toc','.out'}:continue
    if path.suffix=='.pdf' and 'manuscript' not in rel.parts:continue
    if path.suffix=='.txt' and path.with_suffix('.pdf').exists():continue
    files['phase5/'+rel.as_posix()]=path.read_bytes()
changed={'README.md','HANDOFF.md','verify.py','SHA256SUMS.json'}
if any(files[k]!=v for k,v in original.items() if k not in changed):raise ValueError('Earlier evidence changed')
files.pop('SHA256SUMS.json')
manifest={k:hashlib.sha256(v).hexdigest() for k,v in sorted(files.items())}
files['SHA256SUMS.json']=(json.dumps(manifest,indent=2)+'\n').encode()
output.parent.mkdir(parents=True,exist_ok=True)
with ZipFile(output,'w',ZIP_DEFLATED,compresslevel=9) as z:
    for name,content in sorted(files.items()):z.writestr(root+name,content)
with ZipFile(output) as z:
    if z.testzip() is not None:raise ValueError('ZIP CRC failure')
print(json.dumps({'path':str(output),'files':len(files),'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'preserved_earlier_research_files':len(original)-len(changed)},indent=2))
