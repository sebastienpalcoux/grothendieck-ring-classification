"""Exact applicability and witness check for the forced D8 associator.

The categorical lemma is proved in the sibling TY module report. This
checks its hypotheses for 1975 and all cyclic stabilizer relations in
the three remaining labelled representative dual tensors.
"""
from pathlib import Path
import hashlib
import itertools
import json
import math

P=Path(__file__).resolve().parent
def sha(x):return hashlib.sha256(json.dumps(x,separators=(',',':')).encode()).hexdigest()
D=json.loads((P/'1975_associator_inputs.json').read_text())
R=D['source_tensor'];assert sha(R)==D['source_tensor_sha256']
G=[0,5,6,7];Y=8;Xs=[1,2,3,4]
def prod(N,i,j):
    assert sum(N[i][j])==1
    return N[i][j].index(1)
assert all(R[g][g][0]==1 and R[g][Y][Y]==R[Y][g][Y]==1 for g in G)
assert R[Y][Y]==[int(i in G)for i in range(9)]
orbits=[([1,3],7),([2,4],6)]
for (o,h),(other,_) in [(orbits[0],orbits[1]),(orbits[1],orbits[0])]:
    for x in o:
        assert sorted(set(prod(R,g,x)for g in G))==o
        assert [g for g in G if prod(R,g,x)==x]==[0,h]
        assert R[Y][x]==[int(i in other)for i in range(9)]
assert prod(R,7,6)==5 and all(prod(R,5,x)!=x for x in Xs)
out=[]
for c in D['candidates']:
    N=c['N'];assert sha(N)==c['tensor_sha256']
    GT=[[prod(N,i,j)for j in range(8)]for i in range(8)]
    orders=[]
    for g in range(8):
        v=0
        for k in range(1,9):
            v=GT[v][g]
            if v==0:orders.append(k);break
    assert orders==[1,2,2,2,2,2,4,4]
    center=[g for g in range(8)if all(GT[g][h]==GT[h][g]for h in range(8))]
    assert center==[0,1]
    assert all(N[g][x]==N[x][g]for g in range(8)for x in range(8,12))
    # These coordinates are bound to the saved phase-four module actions:
    # four integral pointed-sector bimodules have row0 supported at 0 or3.
    acts=c['module_actions']
    E=[g for g in range(8)if next(j for j,v in enumerate(acts[g][:6])if v)==0
       or next(j for j,v in enumerate(acts[g][:6])if v)==3]
    assert E==[0,1,2,3]
    relations=[(g,x,h)for g in range(8)for x in range(8,12)for h in range(8)
               if N[g][x]==N[x][h]]
    assert len(relations)==64
    forbidden=[r for r in relations if orders[r[0]]==4 and orders[r[2]]==2]
    assert forbidden==[]
    cyclic=[]
    for tau_sign in [1,-1]:
        # H3 restriction classes for the forced pointed category:
        # rotations have class2 in Z4; even involutions class0;
        # the odd reflections have C2 class0 or1 according to tau.
        ks=[0 if orders[g]==1 or g in E else
            2 if orders[g]==4 else int(tau_sign==-1) for g in range(8)]
        failures=[]
        for g,x,h in relations:
            n=math.lcm(orders[g],orders[h])
            left=(n//orders[g])**2*ks[g]
            right=(n//orders[h])**2*ks[h]
            if (left-right)%n:failures.append([g,x,h,(left-right)%n])
        assert not failures
        cyclic.append({'tau_sign':tau_sign,'restriction_classes':ks,
                       'relations_checked':len(relations),'nonzero_restrictions':failures})
    out.append({'alpha':c['alpha'],'a':c['a'],'tensor_sha256':c['tensor_sha256'],
                'orders':orders,'even_pointed_sector':E,'theta':'identity',
                'forbidden_rotation_reflection_relations':forbidden,
                'cyclic_stabilizer_checks':cyclic})
result={'status':'PASS','source':'R9_2_1975','source_tensor_sha256':sha(R),
        'TY_nonintegral_orbits':[{'basis':o,'stabilizer':[0,h]}for o,h in orbits],
        'TY_noninvertible':8,'unique_isotropic_free_involution':5,
        'forced_rotation_associator_class':2,'candidates':out,
        'additional_candidates_excluded':0,'classification_changes':[],
        'remaining_dual_types':3,'source_status':'unresolved',
        'categorical_dependency':'../quadratic_comm/ty_module_subtask/FORCED_D8_ASSOCIATOR.md',
        'scope':'Passing cyclic restrictions is necessary only; no associator or model is constructed.'}
(P/'1975_forced_associator_certificate.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k]for k in ['status','source','additional_candidates_excluded','remaining_dual_types','source_status']},indent=2))
