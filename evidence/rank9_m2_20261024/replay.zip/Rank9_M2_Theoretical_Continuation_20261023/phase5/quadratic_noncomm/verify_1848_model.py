"""Exact binding of Izumi's isotropic orbifold formula to R9_2_1848.

The existence of the source unitary NG(C18,18) is a literature dependency,
Budinski (2021), Table 3.1 and section 3.3.2. This script does not reconstruct
or independently reverify its associator. No floating calculation is used.
"""
from pathlib import Path
import hashlib
import itertools
import json

P = Path(__file__).resolve().parent


def digest(x):
    return hashlib.sha256(json.dumps(x, separators=(",", ":")).encode()).hexdigest()


def model_tensor():
    # Basis: g^0,...,g^5, X,gX,g^2X. Xg=g^-1 X; g^3X=X.
    N = [[[0] * 9 for _ in range(9)] for _ in range(9)]
    for i, j in itertools.product(range(9), repeat=2):
        if i < 6 and j < 6:
            N[i][j][(i + j) % 6] = 1
        elif i < 6:
            N[i][j][6 + (i + j - 6) % 3] = 1
        elif j < 6:
            N[i][j][6 + (i - 6 - j) % 3] = 1
        else:
            N[i][j][(i - j) % 6] = 1
            N[i][j][(i - j + 3) % 6] = 1
            for k in range(6, 9):
                N[i][j][k] = 2
    return N


def main():
    rec = json.loads((P / "1848_model.json").read_text())
    R = rec["source_tensor"]
    assert digest(R) == rec["source_tensor_sha256"]
    N = model_tensor()
    assert N == rec["model_tensor"]
    p = rec["model_to_census"]
    assert sorted(p) == list(range(9))
    assert all(N[i][j][k] == R[p[i]][p[j]][p[k]]
               for i, j, k in itertools.product(range(9), repeat=3))
    # The chosen source J_18^1 has pairing exp(2*pi*i*x*y/18)
    # and a(x)=exp(-pi*i*x*x/18). Check roots of unity by exponents.
    H = [0, 6, 12]
    Hperp = [g for g in range(18) if all(g * h % 18 == 0 for h in H)]
    assert Hperp == [0, 3, 6, 9, 12, 15]
    assert all(h in Hperp for h in H)
    assert all(h * h % 36 == 0 for h in H)  # a|H=1; g_a=0.
    assert len(Hperp) // len(H) == 2
    assert 18 // len(H) == 6 and 18 // len(Hperp) == 3
    # Check associativity and Frobenius reciprocity without numerical roots.
    dual = [(-i) % 6 for i in range(6)] + [6, 7, 8]
    assert all(N[i][j][k] == N[dual[i]][k][j]
               for i, j, k in itertools.product(range(9), repeat=3))
    assert all(sum(N[i][j][u] * N[u][k][l] for u in range(9)) ==
               sum(N[i][u][l] * N[j][k][u] for u in range(9))
               for i, j, k, l in itertools.product(range(9), repeat=4))
    # In Z[sqrt(11)], d=3+sqrt(11), delta=3d.
    def mul(x, y):
        return (x[0]*y[0]+11*x[1]*y[1], x[0]*y[1]+x[1]*y[0])
    assert mul((3, 1), (3, 1)) == (2 + 6*3, 6)
    assert mul((9, 3), (9, 3)) == (18 + 18*9, 18*3)
    receipt = {
        "status": "PASS", "id": "R9_2_1848", "classification": "modelled",
        "model": "Izumi H=C3 orbifold of Budinski J_18^1 unitary NG(C18,18)",
        "tensor_equalities": 729, "model_to_census": p,
        "source_tensor_sha256": digest(R), "model_tensor_sha256": digest(N),
        "H": H, "H_perp": Hperp, "invertible_group": "C6",
        "noninvertible_count": 3, "noninvertible_dimension": "3+sqrt(11)",
        "multiplicity": 2, "unitary": True,
        "categorical_dependencies": [
            "Budinski 2021 Table 3.1, n=18; section 3.3.2 exactness argument",
            "Izumi arXiv:1512.04288v2, Theorem 12.5 and preceding decomposition"
        ],
        "scope": "Exact tensor transport; source near-group associator existence is cited, not freshly replayed."
    }
    (P / "1848_model_verification.json").write_text(json.dumps(receipt, indent=2)+"\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
