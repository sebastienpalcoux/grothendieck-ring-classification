"""A necessary module calculation, conditional on an algebra 1+sum X.

The rank-twelve tensor here is the isotropic orbifold formula for the
Radchenko--Wheeler C8 x C4 datum. This script does NOT reconstruct the
category or its algebra. It proves this particular algebra cannot lead
directly to a rank-nine Morita dual if the categorical inputs exist.
"""
from pathlib import Path
import itertools
import json
import sympy as s

P = Path(__file__).resolve().parent
G = list(itertools.product(range(4), range(2)))
Q = list(itertools.product(range(2), repeat=2))
H = [(0, 0), (2, 0)]
alpha = (0, 1)


def add(x, y, mod):
    return tuple((a+b) % c for a, b, c in zip(x, y, mod))


N = [[[0]*12 for _ in range(12)] for _ in range(12)]
for i, g in enumerate(G):
    for j, h in enumerate(G):
        N[i][j][G.index(add(g, h, (4, 2)))] = 1
    for j, q in enumerate(Q):
        k = 8+Q.index(add(g, q, (2, 2)))
        N[i][8+j][k] = N[8+j][i][k] = 1
for i, q in enumerate(Q):
    for j, r in enumerate(Q):
        z = add(add(q, r, (2, 2)), alpha, (2, 2))
        for h in H:
            N[8+i][8+j][G.index(add(z, h, (4, 2)))] = 1
        for k in range(8, 12):
            N[8+i][8+j][k] = 2

L = list(map(s.Matrix, N))
du = [next(j for j in range(12) if N[i][j][0]) for i in range(12)]
assert all(L[i]*L[j] == sum((N[i][j][k]*L[k] for k in range(12)), s.zeros(12))
           for i, j in itertools.product(range(12), repeat=2))
B = s.eye(12)+sum(L[8:], s.zeros(12))
F = s.eye(12)
for i in range(8, 12):
    for j in range(8):
        F[i, j] = 1
assert B == F*F.T
assert F.det() == 1
M = [F.inv()*x*F for x in L]
assert all(x.is_Integer and x >= 0 for m in M for x in m)
assert all(M[du[i]] == M[i].T for i in range(12))
assert all(M[i]*M[j] == sum((N[i][j][k]*M[k] for k in range(12)), s.zeros(12))
           for i, j in itertools.product(range(12), repeat=2))
# The first eight induction rows are mutually orthogonal norm-one vectors.
# After removing those forced coordinates, the final four rows have Gram I4.
assert B[:8, :8] == s.eye(8)
assert B[8:, 8:] - B[8:, :8]*B[:8, 8:] == s.eye(4)
# Unique Gram factor, up to module basis permutation; exactly 12 modules.
# Independent group-action check: permutations preserving the two distinct
# module dimensions and commuting with all source matrices must restrict to
# translations on the regular eight-element G orbit. Each translation forces
# a unique permutation on the four remaining coordinates.
perms = []
for g in G:
    first = [G.index(add(x, g, (4, 2))) for x in G]
    found = []
    for last in itertools.permutations(range(8, 12)):
        p = first+list(last)
        if all(m[p[i], p[j]] == m[i, j] for m in M
               for i, j in itertools.product(range(12), repeat=2)):
            found.append(p)
    expected = first+[8+Q.index(add(x, g, (2, 2))) for x in Q]
    assert found == [expected]
    perms.extend(found)
out = {
    "status": "PASS", "categorical_status": "conditional module obstruction only",
    "source_group": "C8 x C4", "source_orbifold_invertibles": "C4 x C2",
    "source_orbifold_tensor": N, "dual": du, "algebra_object": [1]+[0]*7+[1]*4,
    "induction_gram": list(map(list, B.tolist())), "induction_factor": F.tolist(),
    "module_actions": [m.tolist() for m in M], "module_rank": 12,
    "module_permutation_centralizer": perms,
    "direct_morita_dual_rank_lower_bound": 12,
    "reason": "Common-center Lagrangian Cauchy--Schwarz: module_rank^2 <= source_rank*dual_rank.",
    "invertible_dual_group_constraint": "Subgroup of abelian C4 x C2, so not D8.",
    "limitations": [
        "Does not construct the order-32 source category, orbifold, or algebra.",
        "Commuting permutation matrices are candidate actions, not proven invertible objects.",
        "Does not exclude other nonintegral algebra objects or iterated Morita constructions."
    ]
}
(P / "order32_canonical_algebra_probe.json").write_text(json.dumps(out, indent=2, default=int)+"\n")
print(json.dumps({k: out[k] for k in ["status", "categorical_status", "module_rank", "direct_morita_dual_rank_lower_bound", "invertible_dual_group_constraint"]}, indent=2))
