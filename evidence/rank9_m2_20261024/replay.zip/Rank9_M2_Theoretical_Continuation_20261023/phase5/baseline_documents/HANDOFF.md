# Current research and publication handoff

Research date: 24 October 2026. No online revision has been performed.

Use `phase4/results/` as the current classification authority:
2,039 excluded, 35 unitary models, 9 unresolved, out of 2,083 exact-M2 rings.
The prior 142 M1 rings are unchanged. Rank nine cumulatively through M2:
2,141 excluded, 75 modeled, 9 unresolved, out of 2,225. The project-wide
frontier is now 16, including seven earlier-rank cases.

New general-complex exclusions: R9_2_585, 1025, 1303, 1709, 1759, 1988.
New unitary models: R9_2_746, 1209, 1254.
Remaining: R9_2_12, 137, 941, 959, 1607, 1848, 1965, 1975, 1976.
All remaining rings are non-braided; this is not general nonexistence.
The integral residuals 12,941,959,1965 are not group-theoretical, and
941 is not weakly group-theoretical. Preserve these exact scopes.

R8_3_436 remains generally excluded by a NEW proof. Withdraw the previous
universal Galois-unitarization/table-parameterization proposition. Follow
`phase4/r8_scope/PUBLICATION_HANDOFF.md` for the exact affected proof files,
historical supersession notices, and manuscript-generator replacement.

For the later online revision, update BOTH repositories and BOTH parts
of the public GitHub Atlas, following the existing ordered/clean policy.
Integrate rank/multiplicity entries in the ordinary tables; do not create
a separate rank-nine feature section. Regenerate usual manuscripts and
update the classification code with the cyclic internal-end obstruction
and the other accepted new proofs/model records. Retain source tensor IDs,
explicit basis transports, scope fields, and independent audit links.
The former private Atlas is out of scope.

All eighteen former residual cases received new investigation. Nine remain
unresolved; no timeout, necessary-condition survivor, failed ansatz, or
Morita candidate is a categorical classification. See per-family reports
for exact future research boundaries.

Archive version-three research is preserved byte-for-byte except current
README/HANDOFF/hash/verification entry points; their prior versions are
retained under phase4/baseline_documents or verify_phase1.py.
