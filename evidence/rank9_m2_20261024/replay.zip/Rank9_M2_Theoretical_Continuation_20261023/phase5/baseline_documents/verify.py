"""Verify the packaged current research without network access."""
from pathlib import Path
import hashlib,json,subprocess,sys
P=Path(__file__).resolve().parent
manifest=json.loads((P/'SHA256SUMS.json').read_text())
for rel,expected in manifest.items():
    if hashlib.sha256((P/rel).read_bytes()).hexdigest()!=expected:
        raise ValueError('Archive hash mismatch: '+rel)
print('PASS: '+str(len(manifest))+' packaged file hashes.',flush=True)
if '--baseline' in sys.argv:
    subprocess.run([sys.executable,str(P/'phase3/verify_audit.py')],check=True,cwd=P)
subprocess.run([sys.executable,str(P/'phase4/verify.py')],check=True,cwd=P)
