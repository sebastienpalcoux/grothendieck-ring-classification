# Rank-nine multiplicity two: fourth research continuation

Current partition: **2,039 excluded, 35 unitary models, 9 unresolved**,
out of 2,083 exact-multiplicity-two rings. Nine of the previous eighteen
unresolved cases are settled: six exclusions and three models.

Read `phase4/REPORT.md` and the manuscript in `phase4/manuscript/`.
The current classification authority is `phase4/results/ledger.json`;
the accepted changes are listed in `phase4/accepted.json`.

The R8_3_436 exclusion has an independent replacement proof in
`phase4/r8_scope/REPAIR.md`. Its old unitary-table parameterization premise
is withdrawn, not silently restored. See the separate categorical audit.

All nine residual rings have no braided categorification. The four integral
residuals have no group-theoretical categorification; R9_2_941 additionally
has no weakly group-theoretical categorification. Their general existence
remains unresolved. Construction obstructions and feasible necessary
conditions are not general classification decisions.

Install `requirements.txt`, then run `python3 verify.py` for the current
finite replay and full model-transport check. It first checks archive hashes.
`python3 verify.py --baseline` also replays the phase-three baseline audit.
For optional fresh research generators, see each proof and audit report.
The new all-group scan requires GAP with SmallGrp. Building the PDF requires
Pandoc, XeLaTeX, and the stated DejaVu fonts. Neither is needed for the
default accepted-certificate replay.

All earlier research bytes are preserved. Earlier `results/`, `phase2/`,
and `phase3/` ledgers are historical snapshots, not the current status.
In particular, the first two phases' invalid half-E6 subring claims remain
superseded by the phase-three correction. The original first-pass verifier
is retained as `verify_phase1.py`; its historical totals are not current.

The 142 multiplicity-one records are unchanged. No repository or website
was changed in this research continuation. The publication handoff is
`HANDOFF.md`; public revision remains a later user-authorized step.
