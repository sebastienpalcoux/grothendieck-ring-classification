"""Derive phase-five classifications without changing any earlier snapshot."""
from pathlib import Path
import json,hashlib,collections,copy
P=Path(__file__).resolve().parent;B=P.parent;O=P/'results';O.mkdir(exist_ok=True)
def read(p):return json.loads((B/p).read_text())
def write(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
old=read('phase4/results/ledger.json');new=copy.deepcopy(old)
proofs={
12:('integral120/reductions_certificate.json','integral120/THEORY.md','audit_integral120/REPORT.md','fermion_parity_and_solvable_descent'),
959:('integral120/reductions_certificate.json','integral120/THEORY.md','audit_integral120/REPORT.md','fermion_parity_and_solvable_descent'),
941:('case941/odd_columns_verified.json','case941/EXCLUSION_THEOREM.md','root/AUDIT_941.md','odd_center_dimension_parity'),
1965:('integral168/certificate.json','integral168/GENERAL_EXCLUSION.md','audit_integral168/REPORT.md','central_symmetric_lagrangian_obstruction')}
changes=[]
for r in new:
    num=int(r['id'].split('_')[-1])
    if num in proofs:
        assert r['status']=='unresolved'
        record,proof,audit,kind=proofs[num]
        for name in (record,proof,audit):assert (P/name).is_file(),name
        r['status']='excluded'
        r['exclusion_certificates']=[{'record_file':'phase5/'+record,'proof':'phase5/'+proof,'independent_audit':'phase5/'+audit,'certificate_kind':kind,'scope':'general_complex_fusion_category'}]
        for scope in ('general_complex','pivotal','spherical','pseudo_unitary','unitary','group_theoretical','weakly_group_theoretical','braided'):r['categorification_scopes'][scope]='excluded'
        r['categorification_scopes']['general_exclusion_proof']='phase5/'+proof
        r['phase5_research_report']='phase5/'+proof
        if num==941:r['literature_identification']['classification_effect']='Now generally excluded by phase5/case941/EXCLUSION_THEOREM.md; earlier unresolved status is superseded.'
        changes.append({'id':r['id'],'old_status':'unresolved','new_status':'excluded','proof':'phase5/'+proof,'independent_audit':'phase5/'+audit})
    elif num==1848:
        assert r['status']=='unresolved'
        r['status']='unitarily_realized'
        r['models']=[{'record_file':'phase5/quadratic_noncomm/1848_model.json','model':'Izumi isotropic C3 orbifold of the unitary near-group category NG(C18,18)','proof':'phase5/quadratic_noncomm/REPORT.md','independent_audit':'phase5/audit_model1848/REPORT.md'}]
        for scope in ('general_complex','pivotal','spherical','pseudo_unitary','unitary'):r['categorification_scopes'][scope]='realized'
        r['categorification_scopes']['existence_model']='phase5/quadratic_noncomm/1848_model.json'
        r['phase5_research_report']='phase5/quadratic_noncomm/REPORT.md'
        changes.append({'id':r['id'],'old_status':'unresolved','new_status':'unitarily_realized','proof':'phase5/quadratic_noncomm/REPORT.md','independent_audit':'phase5/audit_model1848/REPORT.md'})
    elif r['status']=='unresolved':
        r['phase5_research_report']='phase5/quadratic_noncomm/REPORT.md' if num==1975 else 'phase5/quadratic_comm/REPORT.md'
models=read('phase4/results/models.json');m=read('phase5/quadratic_noncomm/1848_model.json')
p=m['model_to_census'];inv=[p.index(i) for i in range(9)]
assert 'model_tensor' in m
model={'id':'R9_2_1848','status':'unitarily_realized','model':'Izumi isotropic C3 orbifold of unitary NG(C18,18)','parameters':{'G':'C18','H':[0,6,12],'H_perp':[0,3,6,9,12,15],'source_category':'Budinski J_18^1','source_existence_scope':'Cited exact unitary construction; no new associator reconstruction claimed.'},'tensor':m['model_tensor'],'basis_map_source_to_model':inv,'all_729_coefficients':True,'record_file':'phase5/quadratic_noncomm/1848_model.json','proof':'phase5/quadratic_noncomm/REPORT.md','independent_audit':'phase5/audit_model1848/REPORT.md'}
models.append(model);models.sort(key=lambda r:int(r['id'].split('_')[-1]))
counts=collections.Counter(r['status'] for r in new)
assert counts=={'excluded':2043,'unitarily_realized':36,'unresolved':4}
summary={'rank':9,'exact_multiplicity':2,'total':2083,'excluded':2043,'modelled':36,'unresolved':4,'new_general_exclusions':4,'new_unitary_models':1,'remaining_ids':['R9_2_137','R9_2_1607','R9_2_1975','R9_2_1976'],'all_nine_previous_residuals_investigated':True,'rank9_cumulative_through_M2':{'total':2225,'excluded':2145,'modelled':76,'unresolved':4},'baseline_earlier_rank_frontier':7,'all_ranks_remaining_relative_to_phase4_baseline':11,'rank9_multiplicity1_unchanged':142,'online_changes':False,'online_work':'Paused; another agent is editing after an audit. Merge this research only after reconciling that agent\'s current repository state.','baseline_ledger_sha256':hashlib.sha256((B/'phase4/results/ledger.json').read_bytes()).hexdigest(),'R8_3_436':read('phase4/results/summary.json')['R8_3_436'],'limits':'Counts are for this research lineage. The other online agent may make independent audit corrections. Necessary-condition survivors are not models or exclusions.'}
write('ledger.json',new);write('models.json',models);write('new_models.json',[model]);write('classification_changes.json',changes);write('summary.json',summary);write('unresolved.json',[r for r in new if r['status']=='unresolved'])
(P/'accepted.json').write_text(json.dumps({'new_exclusions':[12,941,959,1965],'new_unitary_models':[1848],'remaining':[137,1607,1975,1976],'classification_authority':'phase5/results/ledger.json','all_other_general_statuses_unchanged':True,'R8_3_436_repair_unchanged':True,'online_changes':False},indent=2)+'\n')
print(json.dumps(summary,indent=2))
