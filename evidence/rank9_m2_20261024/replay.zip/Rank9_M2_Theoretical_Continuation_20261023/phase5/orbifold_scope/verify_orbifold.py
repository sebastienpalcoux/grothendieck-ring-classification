#!/usr/bin/env python3
"""Exact finite checks for ALGEBRAIC_ORBIFOLD.md; Python standard library only.

This verifies the concrete metric, averaging ranks and resulting tensor.
Existence uses the categorical proof and RW's reconstruction, not this script.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
G = list(product(range(8), range(4)))
H = [(0, 0), (0, 2), (4, 0), (4, 2)]
K = list(product(range(4), range(2)))
CHARS = list(product(range(2), range(2)))
M = len(H)
N = len(G)


def add(x, y):
    return ((x[0] + y[0]) % 8, (x[1] + y[1]) % 4)


def neg(x):
    return ((-x[0]) % 8, (-x[1]) % 4)


def qexp(x):
    a, b = x
    return (8 * (a + b) - a * a + 2 * b * b) % 16


def bexp(x, y):
    return (-2 * x[0] * y[0] + 4 * x[1] * y[1]) % 16


def sign(e):
    assert e % 16 in (0, 8)
    return 1 if e % 16 == 0 else -1


def chi_exp(eta, h):
    return 8 * ((eta[0] * (h[0] // 4) + eta[1] * (h[1] // 2)) % 2)


def bchar(g):
    return (g[0] % 2, g[1] % 2)


def zeros(n):
    return [[F(0) for _ in range(n)] for _ in range(n)]


def matmul(a, b):
    n = len(a)
    return [[sum(a[i][k] * b[k][j] for k in range(n))
             for j in range(n)] for i in range(n)]


def rank(a):
    a = [row[:] for row in a]
    r = 0
    for j in range(len(a[0])):
        p = next((i for i in range(r, len(a)) if a[i][j]), None)
        if p is None:
            continue
        a[r], a[p] = a[p], a[r]
        x = a[r][j]
        a[r] = [v / x for v in a[r]]
        for i in range(len(a)):
            if i != r and a[i][j]:
                x = a[i][j]
                a[i] = [v - x * w for v, w in zip(a[i], a[r])]
        r += 1
    return r


def subgroup(gens):
    s = {(0, 0)}
    frontier = [(0, 0)]
    while frontier:
        g = frontier.pop()
        for h in gens:
            v = add(g, h)
            if v not in s:
                s.add(v)
                frontier.append(v)
    return frozenset(s)


assert 1 * 33 - 4 * 8 == 1 and 1 + 33 == N + 2
for x in G:
    assert qexp(neg(x)) == qexp(x)
    assert 2 * qexp(x) % 16 == bexp(x, x)
    for y in G:
        assert qexp(add(x, y)) == (qexp(x) + qexp(y) + bexp(x, y)) % 16
        assert bexp(x, y) == bexp(y, x)
        # Direct RW gamma formula, with omega(u,v)=u1*v2-u2*v1.
        omega = (x[0] + 8*x[1])*y[1] - (4*x[0]+32*x[1])*y[0]
        # For B, use omega(u gamma-u,v), hence first component 8*x[1].
        omega_b = 8*x[1]*y[1] - (4*x[0]+32*x[1])*y[0]
        assert (omega_b - 2*bexp(x, y)) % 32 == 0
    assert all(bexp(x, y) == 0 for y in G) == (x == (0, 0))
    xx, yy = x
    omega_q = -4*xx*xx - 32*xx*yy + 8*yy*yy
    assert (32*(xx+yy+xx*yy)+omega_q-4*qexp(x)) % 64 == 0

assert all(bexp(h, k) == 0 for h in H for k in H)
Hperp = [g for g in G if all(bexp(g, h) == 0 for h in H)]
assert Hperp == [(x, y) for x, y in G if x % 2 == y % 2 == 0]
assert all(qexp(h) == bexp(h, (0, 1)) for h in H)
assert any(qexp(h) != 0 for h in H)
isotropic_order4 = {
    subgroup((g, k)) for g in G for k in G
    if len(subgroup((g, k))) == 4
    and all(bexp(a, b) == 0 for a in subgroup((g, k)) for b in subgroup((g, k)))
}
assert isotropic_order4 == {frozenset(H)}

# Phase checks in the S and T blocks of tau^2(lambda_h).
for h in H:
    for g in G:
        assert (2*qexp(h)-bexp(h, add(g, h))+bexp(g, h)) % 16 == 0
        assert (2*qexp(h)+qexp(g)-qexp(add(g, neg(h)))
                -qexp(h)-bexp(g, h)) % 16 == 0

invertible_ranks = []
for r in K:
    a, b = zeros(M), zeros(M)
    for j, k in enumerate(H):
        for h in H:
            i = H.index(add(k, h))
            a[i][j] += F(1, M)
            b[i][j] += F(sign(qexp(h)-bexp(h, r)), M)
    p = matmul(a, b)
    assert matmul(p, p) == p
    expected = int(all(qexp(h) == bexp(h, r) for h in H))
    assert rank(p) == expected
    invertible_ranks.append(expected)
assert sum(invertible_ranks) == N // M**2 == 2

noninvertible_ranks = []
for eta in CHARS:
    a, b = zeros(N), zeros(N)
    for j, g in enumerate(G):
        # Action of p_1 on T_g p_eta.
        a[j][j] = sum(F(sign(chi_exp(eta, h)-bexp(h, g)), M) for h in H)
        # Action of tau(p_1) on T_g p_eta, before p_1 acts.
        for h in H:
            i = G.index(add(g, neg(h)))
            b[i][j] += F(sign(qexp(h)-bexp(h, g)+chi_exp(eta, h)), M)
    p = matmul(a, b)
    expected = zeros(N)
    for j, g in enumerate(G):
        if bchar(g) == eta:
            for h in H:
                expected[G.index(add(g, neg(h)))][j] += F(sign(qexp(h)), M)
    assert p == expected and matmul(p, p) == p
    assert rank(p) == N // M**2
    noninvertible_ranks.append(rank(p))

# Complete tensor in basis K followed by H-hat.
n = len(K) + len(CHARS)
T = [[[0] * n for _ in range(n)] for _ in range(n)]
for i, g in enumerate(K):
    for j, h in enumerate(K):
        T[i][j][K.index(((g[0]+h[0]) % 4, (g[1]+h[1]) % 2))] = 1
    for j, eta in enumerate(CHARS):
        idx = len(K)+CHARS.index(((eta[0]+g[0]) % 2, (eta[1]+g[1]) % 2))
        T[i][len(K)+j][idx] = T[len(K)+j][i][idx] = 1
for i, eta in enumerate(CHARS):
    for j, mu in enumerate(CHARS):
        for k, g in enumerate(K):
            if bchar(g) == ((eta[0]-mu[0]) % 2, (eta[1]-mu[1]+1) % 2):
                T[len(K)+i][len(K)+j][k] = 1
        for k in range(len(K), n):
            T[len(K)+i][len(K)+j][k] = 2
dual = []
for i in range(n):
    candidates = [j for j in range(n) if T[i][j][0] == 1]
    assert len(candidates) == 1
    dual.append(candidates[0])
assert all(dual[dual[i]] == i for i in range(n))
assert all(dual[i] != i for i in range(len(K), n))
for i, j, k in product(range(n), repeat=3):
    assert T[i][j][k] == T[dual[i]][k][j] == T[k][dual[j]][i]
for i, j, k, l in product(range(n), repeat=4):
    assert sum(T[i][j][a]*T[a][k][l] for a in range(n)) == sum(
        T[j][k][a]*T[i][a][l] for a in range(n))
for i in range(n):
    assert T[0][i] == T[i][0] == [int(k == i) for k in range(n)]


def qmul(a, b):
    return (a[0]*b[0]+2*a[1]*b[1], a[0]*b[1]+a[1]*b[0])


dims = [(1, 0)]*8 + [(4, 3)]*4
for i, j in product(range(n), repeat=2):
    assert qmul(dims[i], dims[j]) == tuple(
        sum(T[i][j][k]*dims[k][a] for k in range(n)) for a in range(2))
global_dim = tuple(sum(qmul(x, x)[a] for x in dims) for a in range(2))
assert global_dim == (144, 96)

record = {
    'status': 'PASS',
    'scope': 'Exact finite metric, Fourier-block, and fusion-tensor checks; categorical existence uses ALGEBRAIC_ORBIFOLD.md and cited RW theorem.',
    'new_census_promotions': [],
    'gamma': [[1, 4], [8, 33]],
    'group': 'C8 x C4',
    'H': H,
    'H_perp': Hperp,
    'unique_isotropic_order4_subgroup': True,
    'g_a': [0, 1],
    'q_on_H_exponents_mod16': [qexp(h) for h in H],
    'invertible_projection_ranks': invertible_ranks,
    'noninvertible_projection_ranks': noninvertible_ranks,
    'basis_invertibles': K,
    'basis_noninvertibles': CHARS,
    'invertible_group': 'C4 x C2',
    'dual': dual,
    'FP_dimensions_in_basis_1_sqrt2': dims,
    'FP_global_dimension_in_basis_1_sqrt2': global_dim,
    'associativity_coefficients_checked': n**4,
    'fusion_tensor': T,
    'fusion_tensor_sha256': hashlib.sha256(json.dumps(T, separators=(',', ':')).encode()).hexdigest(),
}
record['source_files_sha256'] = {
    name: hashlib.sha256((HERE/name).read_bytes()).hexdigest()
    for name in ['ALGEBRAIC_ORBIFOLD.md', 'Radchenko_Wheeler_2609.21892v1.pdf', 'TPE_2610.11652v1.pdf']
    if (HERE/name).exists()
}
(HERE/'orbifold_verification.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps({k: record[k] for k in ['status', 'invertible_group', 'invertible_projection_ranks',
    'noninvertible_projection_ranks', 'associativity_coefficients_checked', 'new_census_promotions']}))
