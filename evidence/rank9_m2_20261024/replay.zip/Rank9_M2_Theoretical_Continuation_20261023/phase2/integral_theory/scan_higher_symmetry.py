import json,subprocess,time,os,signal
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
U=json.load(open(ROOT/'results/unresolved.json'))
ids=[r['id']for r in U if r['dimension_field_degree']==1 and r['scalar_character_rank']==9 and r['id']not in ['R9_2_907','R9_2_812','R9_2_813'] and (HERE/(r['id']+'_modular_center.json')).exists() and json.load(open(HERE/(r['id']+'_modular_center.json')))['outcome']=='no_conclusion']
def run(rid):
 start=time.time();p=subprocess.Popen(['python',str(HERE/'center_symmetry.py'),rid,'12'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True,env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'})
 try:out,_=p.communicate(timeout=240);status='completed'if p.returncode==0 else'error'
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM);out,_=p.communicate();status='timeout_no_conclusion'
 return {'id':rid,'status':status,'seconds':time.time()-start,'log':out[-2000:]}
out=[]
with ThreadPoolExecutor(max_workers=2)as pool:
 for result in pool.map(run,ids):
  out.append(result);(HERE/'higher_symmetry_campaign.json').write_text(json.dumps(out,indent=2)+'\n');print(result,flush=True)
