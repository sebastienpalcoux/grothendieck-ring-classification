"""Independent bounded-bitvector enumeration of the complete anti-module domain.

Uses neither the discovery Boolean-product encoder nor its variable merging.
Eight-bit arithmetic is exact here: each matrix-product entry has absolute value
at most 3*2^2=12, and each fusion-linear entry at most 9*2*2=36.
"""
from pathlib import Path
import itertools,json,time,z3
ROOT=Path(__file__).resolve().parents[2]

def canon(T):
 f=len(T[0])
 return min(tuple(tuple(e[a]*e[b]*T[i][a][b] for a in range(f) for b in range(f)) for i in range(len(T))) for e in itertools.product([-1,1],repeat=f))

def run(rid,g):
 R=json.load(open(ROOT/'work/verification_corpus.json'))['tensors'][rid];n=len(R)
 assert n==9 and max(v for row in R for col in row for v in col)<=2
 fixed=[i for i in range(n) if R[g][i][i]];assert len(fixed)==3
 du=[next(j for j in range(n) if R[i][j][0]) for i in range(n)]
 assert all(R[i][j]==R[j][i] for i,j in itertools.product(range(n),repeat=2))
 S=z3.SolverFor('QF_BV');S.set(timeout=60000)
 T=[[[z3.BitVec(f't{i}_{a}_{b}',8) for b in range(3)] for a in range(3)] for i in range(n)]
 for i,a,b in itertools.product(range(n),range(3),range(3)):
  bound=R[i][fixed[a]][fixed[b]]
  S.add(z3.Or([T[i][a][b]==v for v in range(-bound,bound+1,2)]))
  S.add(T[i][a][b]==T[du[i]][b][a])
  if i==0:S.add(T[i][a][b]==int(a==b))
 for i,j,a,b in itertools.product(range(n),range(n),range(3),range(3)):
  S.add(sum(T[i][a][h]*T[j][h][b] for h in range(3))==sum(R[i][j][k]*T[k][a][b] for k in range(n)))
 ans=[];start=time.time()
 while True:
  status=S.check()
  assert status!=z3.unknown, S.reason_unknown()
  if status==z3.unsat:break
  M=S.model();vals=[]
  for i in range(n):
   rows=[]
   for a in range(3):
    row=[]
    for b in range(3):
     v=M.eval(T[i][a][b]).as_long();row.append(v if v<128 else v-256)
    rows.append(row)
   vals.append(rows)
  ans.append(canon(vals))
  for e in itertools.product([-1,1],repeat=3):
   S.add(z3.Or([T[i][a][b]!=e[a]*e[b]*vals[i][a][b] for i,a,b in itertools.product(range(n),range(3),range(3))]))
 cert=json.load(open(ROOT/'phase2/weak_integral'/f'morita_{rid}_{g}.json'))
 expected=[canon(b['T']) for b in cert['branches']]
 assert len(ans)==18 and sorted(ans)==sorted(expected)
 return {'id':rid,'independent_encoding':'8-bit bounded matrix equations, complete QF_BV enumeration','complete':True,'gauge_branches':len(ans),'matches_saved_branches':True,'seconds':time.time()-start}

if __name__=='__main__':
 out=[run('R9_2_396',1),run('R9_2_1265',5)]
 Path(__file__).with_name('morita48_anti_audit.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(out,indent=2))
