#include <iostream>
#include <vector>
#include <functional>
using I=long long;using W=__int128_t;
int main(){int n,D;if(!(std::cin>>n>>D)||n<2||n>9)return 2;
std::vector<I>d(n),b(n),v(n);std::vector<std::vector<I>>B(n,std::vector<I>(n)),A=B;I den;
for(auto &x:d)std::cin>>x;for(auto&r:B)for(auto&x:r)std::cin>>x;
for(auto&r:A)for(auto&x:r)std::cin>>x;std::cin>>den;
for(int i=0;i<n;i++){b[i]=0;while((b[i]+1)*(b[i]+1)<=B[i][i])b[i]++;}b[0]=1;
std::function<void(int,I)>dfs=[&](int k,I z){if(k==n){if(!z||D%z)return;
W q=0;for(int i=0;i<n;i++)for(int j=0;j<n;j++)q+=W(v[i])*A[i][j]*v[j];if(q>den)return;
for(I x:v)std::cout<<x<<' ';std::cout<<z<<'\n';return;}
for(v[k]=0;v[k]<=b[k]&&z+d[k]*v[k]<=D;v[k]++){bool ok=true;for(int i=0;i<k;i++)if(v[i]*v[k]>B[i][k]){ok=false;break;}if(ok)dfs(k+1,z+d[k]*v[k]);}};
dfs(0,0);}
