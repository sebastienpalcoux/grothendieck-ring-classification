"""Exact central-invertible exclusions and residual dimension-96 reduction."""
from pathlib import Path
from collections import Counter
import itertools,json,hashlib

ROOT=Path(__file__).resolve().parents[2]
IDS=['R9_2_1356','R9_2_1857','R9_2_1933','R9_2_2029']

def source_check(rid,R,d):
 n=len(R);assert n==9 and Counter(d)=={1:3,2:3,3:1,6:2}
 assert sum(x*x for x in d)==96
 assert all(sum(R[i][j][k]*d[k] for k in range(n))==d[i]*d[j] for i in range(n) for j in range(n))
 du=[next(j for j in range(n) if R[i][j][0]) for i in range(n)]
 inv=[i for i in range(n) if sum(R[i][du[i]])==1];assert inv==[i for i in range(n) if d[i]==1]
 g=next(i for i in inv if i)
 assert all(sum(R[g][i])==1 for i in range(n))
 noncentral=[i for i in range(n) if R[g][i]!=R[i][g]]
 perm=[R[g][i].index(1) for i in range(n)]
 assert all(perm[perm[perm[i]]]==i for i in range(n))
 seen=set();cycles=[]
 for i in range(n):
  if i in seen:continue
  cyc=[];j=i
  while j not in cyc:cyc.append(j);seen.add(j);j=perm[j]
  assert j==i;cycles.append(cyc)
 assert sorted((d[c[0]],len(c)) for c in cycles)==[(1,3),(2,3),(3,1),(6,1),(6,1)]
 J={0};stages=[]
 for i in range(n):J.update(k for k in range(n) if R[i][du[i]][k])
 stages.append(sorted(J))
 while True:
  K=J|{k for i in J for j in J for k in range(n) if R[i][j][k]}
  if K==J:break
  J=K;stages.append(sorted(J))
 assert len(J)==n
 if noncentral:
  assert all(any(R[h][i]!=R[i][h] for i in range(n)) for h in inv if h)
 return {'id':rid,'status':'excluded' if noncentral else 'structural_reduction','scope':'general_complex_fusion_category','criterion':'solvable_adjoint_central_invertible' if noncentral else 'dimension96_triality_descent','dimensions':d,'invertibles':inv,'generator':g,'generator_is_central':not noncentral,'noncommuting_indices':noncentral,'left_generator_action':perm,'right_generator_action':[R[i][g].index(1) for i in range(n)],'character_cycles':cycles,'adjoint_generation':stages,'commutative':all(R[i][j]==R[j][i] for i in range(n) for j in range(n)),'tensor_sha256':hashlib.sha256(json.dumps(R,separators=(',',':')).encode()).hexdigest()}

def orthogonal_check():
 # V4 plus its character group; q(x,y)=(-1)^(x dot y).
 def q(v):return ((v&1)*((v>>2)&1)+((v>>1)&1)*((v>>3)&1))%2
 def linear(cols,v):
  out=0
  for j in range(4):
   if (v>>j)&1:out^=cols[j]
  return out
 els=[]
 for cols in itertools.product(range(1,16),repeat=4):
  p=tuple(linear(cols,v) for v in range(16))
  if len(set(p))==16 and all(q(p[v])==q(v) for v in range(16)):els.append(p)
 assert len(els)==72
 one=tuple(range(16));idx={p:i for i,p in enumerate(els)}
 def mul(a,b):return tuple(a[b[v]] for v in range(16))
 def order(a):
  p=one
  for n in range(1,73):
   p=mul(p,a)
   if p==one:return n
  raise AssertionError
 inv=[a for a in els if order(a)==2]
 for a,b in itertools.product(inv,repeat=2):
  if order(mul(a,b))!=4:continue
  S={one};todo=[one]
  while todo:
   z=todo.pop()
   for gen in [a,b]:
    w=mul(z,gen)
    if w not in S:S.add(w);todo.append(w)
  if len(S)==8:break
 else:raise AssertionError('No dihedral Sylow subgroup')
 assert Counter(order(x) for x in S)=={1:1,2:5,4:2}
 return {'group':'O(V4 + V4hat, evaluation quadratic form)','order':72,'sylow_order':8,'sylow_isomorphism_type':'D8','sylow_generators':[list(a),list(b)],'sylow_element_order_counts':dict(Counter(order(x) for x in S))}

if __name__=='__main__':
 tensors=json.load(open(ROOT/'work/verification_corpus.json'))['tensors']
 profiles={p['id']:p for p in json.load(open(ROOT/'results/unresolved.json'))}
 checks=[source_check(rid,tensors[rid],[int(c[0]) for c in profiles[rid]['dimension_coefficients']]) for rid in IDS]
 assert [x['id'] for x in checks if x['status']=='excluded']==['R9_2_1356','R9_2_1933']
 out={'kind':'dimension96_central_exclusions_and_structural_reduction','scope':'general_complex_fusion_category','sources':checks,'orthogonal_group_check':orthogonal_check(),'conclusion':'1356 and1933 are excluded by noncentrality of every nontrivial invertible. Any categorification of1857 or2029 is B^C3, where B_ad is tensor equivalent to Rep(D8), U(B)=V4, and each nontrivial grading component has rank two.'}
 Path(__file__).with_name('dimension96_reduction.json').write_text(json.dumps(out,indent=2)+'\n')
 Path(__file__).with_name('central_invertible_exclusions.json').write_text(json.dumps([x for x in checks if x['status']=='excluded'],indent=2)+'\n')
 print(json.dumps({'ids':IDS,'hypotheses':'PASS','orthogonal_group':'PASS','exclusions':['R9_2_1356','R9_2_1933']}))
