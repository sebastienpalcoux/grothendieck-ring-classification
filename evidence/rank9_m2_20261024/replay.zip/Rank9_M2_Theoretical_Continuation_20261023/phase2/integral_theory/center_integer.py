"""Bounded exact integer joint-center relaxation; unknown is no conclusion."""
import sys,json,time,hashlib
from pathlib import Path
import z3
from center_symmetry import symmetric_data
from center_lp import inputs
def run(rid,timeout=60000):
 start=time.time();R=inputs(rid);A,b,meta=symmetric_data(R,4);m=len(A);cols=len(A[0]);slack={}
 for j in range(cols):
  nz=[i for i in range(m)if A[i][j]]
  if len(nz)==1 and A[nz[0]][j]==1:slack[j]=nz[0]
 used=[j for j in range(cols)if j not in slack];ineq=set(slack.values())
 solver=z3.SolverFor('QF_LIA');solver.set(timeout=timeout);xx={j:z3.Int('z'+str(j))for j in used}
 diag=[i for i,row in enumerate(meta['rows'])if row[0]=='gram'and row[1]==row[2]]
 for j in used:
  ub=min(b[i]//A[i][j]for i in diag if A[i][j]>0);solver.add(xx[j]>=0,xx[j]<=ub)
 for i,row in enumerate(A):
  lhs=z3.Sum([row[j]*xx[j]for j in used if row[j]]);solver.add(lhs<=b[i]if i in ineq else lhs==b[i])
 print(rid,'integer variables',len(used),'rows',m,flush=True);ans=solver.check()
 out={'id':rid,'outcome':'excluded'if ans==z3.unsat else'no_conclusion','kind':'integer_joint_center_rational_S_symmetry','solver_result':str(ans),'timeout_ms':timeout,'metadata':meta,'seconds':time.time()-start,'tensor_sha256':hashlib.sha256(json.dumps(R,separators=(',',':')).encode()).hexdigest()}
 if ans==z3.sat:
  model=solver.model();vv=[model.eval(xx[j]).as_long()for j in used];assert all(v>=0 for v in vv)
  for i,row in enumerate(A):
   val=sum(row[j]*v for j,v in zip(used,vv));assert val<=b[i]if i in ineq else val==b[i]
  out['witness']=[[j,v]for j,v in zip(used,vv)if v]
 Path(__file__).with_name(rid+'_integer_center.json').write_text(json.dumps(out,indent=2)+'\n');print(rid,str(ans),time.time()-start,flush=True)
if __name__=='__main__':run(sys.argv[1],int(sys.argv[2])if len(sys.argv)>2 else 60000)
