"""Rational-character S symmetry coupled to the all-column center relaxation."""
import sys,json,time,math,hashlib
from pathlib import Path
from collections import Counter
from center_lp import data,inputs,exact_separator,verify_ray
from rings import Characters
import sympy as s
def symmetric_data(R,height=4):
 A,b,meta=data(R,height,True);a=Characters(R);D=meta['D'];chars=[];dims=[];bydim=Counter()
 for f,m in a.components:
  if f.degree()!=1:continue
  K,ds,dd,_=a.component(f);vec=[int(s.Rational(str(x.to_list()[0])))if x.to_list()else 0 for x in ds];fval=sum(vec[i]*vec[a.du[i]]for i in range(len(R)));assert D%fval==0
  chars.append(vec);dims.append(D//fval);bydim[D//fval]+=1
 total=Counter({D//int(f):int(m)for f,m in a.C.eigenvals().items()});chosen=[];labs=[]
 for j,lab in enumerate(meta['labels']):
  if lab[0]=='slack' or lab[0][0]==0:chosen.append(j);labs.append((None,lab));continue
  v,z,ti=lab
  for h,d in enumerate(dims):
   if d==z:chosen.append(j);labs.append((h,lab))
  if total[z]>bydim[z]:chosen.append(j);labs.append((None,lab))
 AA=[[row[j]for j in chosen]for row in A];bb=list(b);extra=[]
 for h in range(len(chars)):
  AA.append([int(hh==h)for hh,lab in labs]);bb.append(1);extra.append(('character_count',h))
 for h in range(len(chars)):
  for k in range(h):
   row=[]
   for hh,lab in labs:
    v=lab[0]
    value=0
    if hh==h:value-=dims[k]*sum(x*y for x,y in zip(chars[k],v))
    if hh==k:value+=dims[h]*sum(x*y for x,y in zip(chars[h],v))
    row.append(value)
   g=math.gcd(*row)or 1;AA.append([x//g for x in row]);bb.append(0);extra.append(('S_symmetry',h,k))
 meta.pop('labels');meta['rational_characters']=chars;meta['rational_central_dimensions']=dims;meta['extra_rows']=extra;meta['variables']=len(chosen);return AA,bb,meta
def run(rid,height=4):
 start=time.time();R=inputs(rid);A,b,meta=symmetric_data(R,height);print(rid,'symmetry',len(A),len(A[0]),flush=True)
 y,why=exact_separator(A,b);out={'id':rid,'outcome':'excluded'if y else'no_conclusion','kind':'joint_integral_center_rational_S_symmetry','metadata':meta,'ray':y,'solver_report':why,'seconds':time.time()-start,'tensor_sha256':hashlib.sha256(json.dumps(R,separators=(',',':')).encode()).hexdigest()}
 Path(__file__).with_name(rid+(''if height==4 else f'_h{height}')+'_symmetry.json').write_text(json.dumps(out,indent=2)+'\n');print(rid,out['outcome'],out['seconds'],flush=True)
if __name__=='__main__':run(sys.argv[1],int(sys.argv[2])if len(sys.argv)>2 else 4)
