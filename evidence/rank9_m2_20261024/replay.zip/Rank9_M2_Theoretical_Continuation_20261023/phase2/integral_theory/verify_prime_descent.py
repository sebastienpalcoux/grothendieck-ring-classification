from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[2]
def verify(R,p):
 n=len(R);d=[1,1,2]+[6]*(n-3);assert n-3==(p-1)//6
 assert sum(x*x for x in d)==6*p
 assert all(sum(R[i][j][k]*d[k]for k in range(n))==d[i]*d[j]for i in range(n)for j in range(n))
 du=[next(j for j in range(n)if R[i][j][0])for i in range(n)]
 assert [i for i in range(n)if sum(R[i][du[i]])==1]==[0,1]
 assert R[1][1]==[1]+[0]*(n-1)
 assert all(R[1][i]==R[i][1]==[int(k==i)for k in range(n)]for i in range(2,n))
 J={0};stages=[]
 for i in range(n):J.update(k for k in range(n)if R[i][du[i]][k])
 stages.append(sorted(J))
 while True:
  K=J|{k for i in J for j in J for k in range(n)if R[i][j][k]}
  if K==J:break
  J=K;stages.append(sorted(J))
 assert J==set(range(n))
 assert p>6 and all(p%q for q in range(2,int(p**.5)+1))
 return {'id':'R9_2_907','kind':'preserved_central_subcategory_6p','scope':'general_complex_fusion_category','p':p,'dimensions':d,'involution':1,'fixed_nonunits':list(range(2,n)),'adjoint_generation':stages,'tensor_sha256':hashlib.sha256(json.dumps(R,separators=(',',':')).encode()).hexdigest()}
if __name__=='__main__':
 R=json.load(open(ROOT/'work/verification_corpus.json'))['tensors']['R9_2_907'];c=verify(R,37)
 Path(__file__).with_name('R9_2_907_prime_descent.json').write_text(json.dumps(c,indent=2)+'\n');print(json.dumps(c,indent=2))
