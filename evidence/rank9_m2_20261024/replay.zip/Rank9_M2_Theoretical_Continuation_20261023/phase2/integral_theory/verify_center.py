"""Exact replay, no numerical optimizer involved."""
import json,time,hashlib
from pathlib import Path
from center_lp import data,inputs,verify_ray
HERE=Path(__file__).resolve().parent
out=[]
for path in sorted(HERE.glob('R9_2_*_center.json')):
 c=json.load(open(path))
 if c['outcome']!='excluded':continue
 start=time.time();R=inputs(c['id']);h=c['metadata']['height'];mod=c['metadata'].get('modular_integrality',False)
 A,b,meta=data(R,h,mod);assert verify_ray(A,b,c['ray'])
 assert all(meta[k]==c['metadata'][k]for k in ['dimensions','D','candidate_columns','variables','trace_types','trace_order_bound','height'])
 digest=hashlib.sha256(json.dumps(R,separators=(',',':')).encode()).hexdigest()
 if 'tensor_sha256'in c:assert c['tensor_sha256']==digest
 else:c['tensor_sha256']=digest;path.write_text(json.dumps(c,indent=2)+'\n')
 out.append({'id':c['id'],'file':path.name,'status':'PASS','scope':'general_complex_integral_fusion_categories','tensor_sha256':digest,'rows':len(b),'variables':len(A[0]),'ray_dot_rhs':sum(x*y for x,y in zip(b,c['ray'])),'seconds':time.time()-start})
 (HERE/'center_verification.json').write_text(json.dumps(out,indent=2)+'\n');print(out[-1],flush=True)
