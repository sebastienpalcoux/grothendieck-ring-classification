"""Check the continuation partition, tensor maps, and accepted replay receipts.

Use --fresh to rerun the family-specific exact verifiers as well. Neither mode
claims to automate the mathematical review of the supporting categorical proofs.
"""
from pathlib import Path
import json,sys,subprocess,hashlib,collections,os
ROOT=Path(__file__).resolve().parents[1]
def read(p):return json.load(open(ROOT/p))
def run(p,*args):subprocess.run([sys.executable,str(ROOT/p),*args],check=True,env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'))
def main(fresh=False):
 manifest=ROOT/'SHA256SUMS.json';hashcount=None
 if manifest.exists():
  hashes=json.load(open(manifest));hashcount=len(hashes)
  assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==v for p,v in hashes.items())
 if fresh:
  for p,args in [
   ('phase2/signed/verify_nonzero_products.py',[]),
   ('phase2/signed/verify_nonzero_products.py',['--gates']),
   ('phase2/integral_theory/verify_center.py',[]),
   ('phase2/quadratic_theory/verify_quadratic_center.py',[]),
   ('phase2/signed/audit_theoretical.py',[]),
   ('phase2/signed/audit_ordinary_swap.py',[]),
   ('phase2/signed/audit_R920.py',[]),
   ('phase2/models/additional_model_audit.py',[]),
  ]:run(p,*args)
  accepted=read('phase2/accepted.json')['new_exclusions']
  if 'quadratic_neutral_block'in accepted:run('phase2/quadratic_theory/verify_quadratic_neutral.py')
  if 'solvable_central_invertibles'in accepted:run('phase2/integral_theory/verify_dimension96_reduction.py')
  if 'larger_fixed_block_morita'in accepted:run('phase2/weak_integral/morita_replay.py')
 run('phase2/integrate.py');run('phase2/verify_models.py')
 S=read('phase2/results/summary.json');A=read('phase2/accepted.json')
 base={x['id']:x for x in read('results/ledger.json')};now=read('phase2/results/ledger.json');oldU={x['id']for x in read('results/unresolved.json')}
 assert len(base)==len(now)==S['total']==2083 and len(oldU)==81
 corpus=read('work/verification_corpus.json')['tensors']
 for row in now:
  rid=row['id'];assert hashlib.sha256(json.dumps(corpus[rid],separators=(',',':')).encode()).hexdigest()==row['tensor_sha256']
  assert row['rank']==9 and row['exact_multiplicity']==2
  if rid not in oldU:assert row==base[rid]
  assert not(row['models']and row['exclusion_certificates'])
 counts=collections.Counter(x['status']for x in now)
 assert counts['excluded']==S['excluded']and counts['unitarily_realized']==S['modelled']and counts['unresolved']==S['unresolved']
 assert sum(counts.values())==2083 and S['new_excluded']+S['new_modelled']+S['unresolved']==81
 signed=read('phase2/signed/verification.json');gates=read('phase2/signed/gate_verification.json');center=read('phase2/integral_theory/center_verification.json');quad=read('phase2/quadratic_theory/verification.json')
 assert len(signed)==9 and all(x['status']=='PASS'and x['independent_completeness']=='UNSAT'for x in signed)
 assert len(gates)==20 and all(x['status']=='PASS'and x['independent_completeness']=='UNSAT'for x in gates)
 assert len(center)==15 and all(x['status']=='PASS'and x['ray_dot_rhs']<0 for x in center)
 assert len(quad)==2 and all(x['PASS']and x['bTy']<0 and x['minimum_ATy']>=0 and x['raw_enumeration']['native_matches_independent_python']for x in quad)
 assert read('phase2/signed/audit.json')['verdict']=='APPROVED'
 assert read('phase2/signed/ordinary_swap_audit.json')['verdict']=='APPROVED'
 assert read('phase2/signed/R920_audit.json')['verdict']=='APPROVED'
 assert read('phase2/models/additional_model_audit.json')['status']=='PASS'
 if 'quadratic_neutral_block'in A['new_exclusions']:
  assert read('phase2/signed/neutral_audit.json')['verdict']=='APPROVED'
  nr=read('phase2/quadratic_theory/neutral_verification.json')
  assert len(nr)==2 and all(x['PASS']and x['bTy']<0 and x['minimum_ATy']>=0 for x in nr)
 if 'solvable_central_invertibles'in A['new_exclusions']:
  sr=read('phase2/results/solvable_central_independent_verification.json')
  assert len(sr)==2 and all(x['status']=='PASS'for x in sr)
 if 'larger_fixed_block_morita'in A['new_exclusions']:
  mr=read('phase2/weak_integral/morita48_exclusions.json')
  assert len(mr)==2 and all(x['replayed']and x['complete_branches']==18 for x in mr)
  ma=read('phase2/integral_theory/morita48_anti_audit.json')
  assert len(ma)==2 and all(x['complete']and x['gauge_branches']==18 and x['matches_saved_branches']for x in ma)
 for e in read('phase2/results/new_exclusions.json'):
  assert e['id']in oldU and (ROOT/e['certificate']).is_file()and (ROOT/e['theory']).is_file()
 for model in read('phase2/results/new_models.json'):
  if 'proof'in model:assert (ROOT/model['proof']).is_file(),model['proof']
 if 'R9_2_2029'in A['new_models']:assert (ROOT/'phase2/integral_theory/d4_zesting_audit.md').is_file()
 report={'status':'PASS','total':2083,'former_unresolved':81,'new_excluded':S['new_excluded'],'new_modelled':S['new_modelled'],'unresolved':S['unresolved'],'model_tensor_replay':'PASS','accepted_exclusion_receipts':'PASS','baseline_classifications_preserved':2002,'fresh_certificate_replay_requested':fresh,'package_manifest_files_checked':hashcount,'mathematical_proof_review':'Supporting categorical proofs and independent audits accompany the finite certificates; this script is not a formal proof assistant.'}
 (ROOT/'phase2/results/final_verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main('--fresh'in sys.argv)
