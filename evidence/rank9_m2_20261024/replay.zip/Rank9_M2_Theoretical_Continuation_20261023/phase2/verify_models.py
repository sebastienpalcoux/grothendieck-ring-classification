"""Independent integer replay of accepted phase-two model identifications."""
from pathlib import Path
import json, hashlib, itertools

ROOT=Path(__file__).resolve().parents[1]
def digest(R):return hashlib.sha256(json.dumps(R,separators=(',',':')).encode()).hexdigest()
def verify():
 corpus=json.load(open(ROOT/'work/verification_corpus.json'))['tensors']
 ledger={x['id']:x for x in json.load(open(ROOT/'results/ledger.json'))}
 accepted=json.load(open(ROOT/'phase2/accepted.json'))
 files=accepted['model_files']; expected=set(accepted['new_models'])
 out=[]; seen=set()
 for f in files:
  for row in json.load(open(ROOT/f)):
   rid=row['id']
   if rid not in expected:continue
   assert row.get('status')=='unitarily_realized',(rid,row.get('status'))
   assert rid not in seen;seen.add(rid)
   R=corpus[rid];M=row['tensor'];p=row['basis_map_source_to_model'];n=len(R)
   assert n==len(M)==9 and p[0]==0 and sorted(p)==list(range(n))
   assert digest(R)==ledger[rid]['tensor_sha256']
   assert all(R[i][j][k]==M[p[i]][p[j]][p[k]] for i,j,k in itertools.product(range(n),repeat=3))
   assert all(isinstance(x,int)and x>=0 for a in M for b in a for x in b)
   assert max(x for a in M for b in a for x in b)==2
   assert all(M[0][i][j]==int(i==j)==M[i][0][j] for i,j in itertools.product(range(n),repeat=2))
   dual=[]
   for i in range(n):
    candidates=[j for j in range(n)if M[i][j][0]]
    assert len(candidates)==1 and M[i][candidates[0]][0]==1;dual.append(candidates[0])
   assert all(dual[dual[i]]==i for i in range(n))
   assert all(M[i][j][k]==M[dual[j]][dual[i]][dual[k]] for i,j,k in itertools.product(range(n),repeat=3))
   for i,j,k,l in itertools.product(range(n),repeat=4):
    assert sum(M[i][j][a]*M[a][k][l]for a in range(n))==sum(M[j][k][a]*M[i][a][l]for a in range(n))
   out.append({'id':rid,'status':'PASS','model_file':f,'source_tensor_sha256':digest(R),'model_tensor_sha256':digest(M),'basis_map_source_to_model':p,'structure_constants_checked':n**3,'associativity_equations_checked':n**4,'scope':'Integer tensor identity and based-ring axioms; categorical existence is proved in the accompanying theory, not inferred from this replay.'})
 assert seen==expected,(seen,expected)
 (ROOT/'phase2/results/model_verification.json').write_text(json.dumps(out,indent=2)+'\n')
 print('PASS',len(out),'model identifications')
 return out
if __name__=='__main__':verify()
