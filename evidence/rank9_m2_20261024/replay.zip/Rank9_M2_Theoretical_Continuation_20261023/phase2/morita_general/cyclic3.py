"""Exact C3-Fourier necessary module equations, including noncommutative rings.

Convention: row-source left-action matrices form an anti-representation.
Every entry is a sum of N(i,x;y) third roots of unity. No categorical
dimension or pivotality assumption is used. A SAT result is inconclusive.
"""
from pathlib import Path
import json,sys,itertools,time
import z3
BASE=Path(__file__).resolve().parents[2]

def add(x,y):return (x[0]+y[0],x[1]+y[1])
def mul(x,y):return (x[0]*y[0]-x[1]*y[1],x[0]*y[1]+x[1]*y[0]-x[1]*y[1])
def conj(x):return (x[0]-x[1],-x[1])
def domain(n):
    return sorted({(a-c,b-c) for a in range(n+1) for b in range(n-a+1) for c in [n-a-b]})

def problem(R,g,timeout=30000):
    n=len(R);unit=[1]+[0]*(n-1)
    assert all(sum(v)==1 for v in R[g]);g2=R[g][g].index(1);assert g2!=0 and R[g2][g]==unit
    fixed=[x for x in range(n)if R[x][g][x]];assert fixed
    f=len(fixed);du=[next(j for j in range(n)if R[i][j][0])for i in range(n)]
    S=z3.SolverFor('QF_NIA');S.set(timeout=timeout);T=[]
    for i in range(n):
        M=[]
        for a in range(f):
            row=[]
            for b in range(f):
                if i==0:z=(int(a==b),0)
                elif not R[i][fixed[a]][fixed[b]]:z=(0,0)
                else:
                    z=z3.Ints(f't_{i}_{a}_{b}_0 t_{i}_{a}_{b}_1')
                    S.add(z3.Or(*[z3.And(z[0]==x,z[1]==y)for x,y in domain(R[i][fixed[a]][fixed[b]])]))
                row.append(z)
            M.append(row)
        T.append(M)
    for i,a,b in itertools.product(range(n),range(f),range(f)):
        x=T[du[i]][b][a];y=conj(T[i][a][b]);S.add(x[0]==y[0],x[1]==y[1])
    for i,j,a,b in itertools.product(range(1,n),range(1,n),range(f),range(f)):
        lhs=(0,0)
        for h in range(f):lhs=add(lhs,mul(T[i][a][h],T[j][h][b]))
        rhs=tuple(sum(R[j][i][k]*T[k][a][b][q]for k in range(n))for q in range(2))
        S.add(lhs[0]==rhs[0],lhs[1]==rhs[1])
    return S,T,fixed

def verify_witness(R,g,T,fixed):
    n=len(R);f=len(fixed);du=[next(j for j in range(n)if R[i][j][0])for i in range(n)]
    assert fixed==[x for x in range(n)if R[x][g][x]]
    for i,a,b in itertools.product(range(n),range(f),range(f)):
        assert tuple(T[i][a][b])in domain(R[i][fixed[a]][fixed[b]])
        assert tuple(T[du[i]][b][a])==conj(T[i][a][b])
    assert all(tuple(T[0][a][b])==(int(a==b),0)for a,b in itertools.product(range(f),repeat=2))
    for i,j,a,b in itertools.product(range(n),range(n),range(f),range(f)):
        lhs=(0,0)
        for h in range(f):lhs=add(lhs,mul(T[i][a][h],T[j][h][b]))
        rhs=tuple(sum(R[j][i][k]*T[k][a][b][q]for k in range(n))for q in range(2))
        assert lhs==rhs

def discover(R,g,timeout=30000):
    start=time.time();S,T,fixed=problem(R,g,timeout);result=S.check()
    rec={'kind':'cyclic_three_fourier_module','involution':None,'generator':g,'fixed':fixed,'solver_result':str(result),'outcome':'excluded'if result==z3.unsat else'no_conclusion'}
    if result==z3.sat:
        m=S.model();W=[[[[int(q)if isinstance(q,int)else m.eval(q).as_long()for q in z]for z in row]for row in M]for M in T]
        verify_witness(R,g,W,fixed);rec['witness']=W
    rec['seconds']=time.time()-start
    return rec

if __name__=='__main__':
    C=json.load(open(BASE/'work/verification_corpus.json'));out=[]
    for rid,g in [('R9_2_1356',1),('R9_2_1857',3),('R9_2_1933',1),('R9_2_2029',5)]:
        rec={'id':rid,**discover(C['tensors'][rid],g)};out.append(rec)
        (Path(__file__).parent/'cyclic3_results.json').write_text(json.dumps(out,indent=2)+'\n')
        print(rid,rec['outcome'],rec['solver_result'],round(rec['seconds'],2),flush=True)
