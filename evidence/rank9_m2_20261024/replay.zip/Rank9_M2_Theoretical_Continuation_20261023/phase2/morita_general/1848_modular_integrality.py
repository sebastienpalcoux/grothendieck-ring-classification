"""Exploratory noncommutative modular S-ratio integrality filter.

No exclusion is asserted unless all necessary column patterns disappear.
For a central restriction v, S(A_E,Z) = (D/f_E) lambda_E(v).
The regular Casimir acts by e_E f_E.  The operator E below acts by e_E.
Thus (D/z) E C^{-1} N_v has algebraic-integer eigenvalues.
"""
from quadratic1848 import *
from higher_traces import high_columns

def run():
 R=json.load(open(BASE/'work/verification_corpus.json'))['tensors']['R9_2_1848']
 data,L,proof=prepare(R); ch=chars(R); N=ch.N; n=9
 W=s.Matrix.hstack(*s.Matrix.vstack(*(N[i]*N[j]-N[j]*N[i]for i in range(n)for j in range(i))).nullspace())
 assert W.cols==5
 P=W*(W.T*W).inv()*W.T; E=2*s.eye(n)-P
 assert E*W==W and (E-s.eye(n))*(E-2*s.eye(n))==s.zeros(n)
 G,cols=high_columns(data,L); D=data['global_dimension']; dims=data['dimensions']; out=[]
 for kind,vs in [('low',[list(L[:,j])for j in range(L.cols)]),('high',[[0]+list(v)for v,z in cols])]:
  for idx,v in enumerate(vs):
   Nv=sum((int(x)*M for x,M in zip(v,N)),s.zeros(n))
   assert all(Nv*M==M*Nv for M in N)
   z=tuple(sum(Q(int(v[i]))*dims[i][c]for i in range(n))for c in range(2))
   norm=z[0]**2-11*z[1]**2; alpha=mul(D,(z[0]/norm,-z[1]/norm),11)
   cp=(E*ch.C.inv()*Nv).charpoly(t).all_coeffs()
   power=(Q(1),Q(0)); good=True; failures=[]
   for k,c in enumerate(cp):
    if k: power=mul(power,alpha,11)
    coeff=tuple(Q(c)*x for x in power)
    if any(x.denominator!=1 for x in coeff):
     good=False; failures.append({'coefficient_degree':k,'pair':list(map(str,coeff))})
   out.append({'kind':kind,'index':idx,'column':list(map(int,v)),'passes':good,'failures':failures})
 rejected={r['index']for r in out if r['kind']=='high' and not r['passes']}
 patterns=json.load(open(Path(__file__).with_name('1848_integral_gram.json')))['patterns']
 survivors=[k for k,p in enumerate(patterns)if all(p[j]==0 for j in rejected)]
 rec={'id':'R9_2_1848','criterion':'noncommutative_modular_ratio_integrality','columns':out,'surviving_gram_patterns':survivors,'outcome':'no_conclusion' if survivors and all(r['passes']for r in out if r['kind']=='low')else'candidate_exclusion_requires_theory_audit'}
 Path(__file__).with_suffix('.json').write_text(json.dumps(rec,indent=2)+'\n')
 print('rejected', sorted(rejected),'surviving patterns',len(survivors),'low pass',all(r['passes']for r in out if r['kind']=='low'))
if __name__=='__main__':run()
