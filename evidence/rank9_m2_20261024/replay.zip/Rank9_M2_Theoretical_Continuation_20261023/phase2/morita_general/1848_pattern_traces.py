"""Refine the finite weighted-center trace relaxation by complete integer Gram patterns."""
from quadratic1848 import *
from higher_traces import high_columns
from balanced_traces import positive_pair
from collections import Counter
import numpy as np
from scipy.optimize import linprog
def run(limit=None,modular=False):
 R=json.load(open(BASE/'work/verification_corpus.json'))['tensors']['R9_2_1848'];data,L,proof=prepare(R)
 rec=json.load(open(Path(__file__).with_name('1848_integral_gram.json')));G,cols=high_columns(data,L);vs=[tuple(v)for v,z in cols]
 assert rec['columns']==list(map(list,vs))
 D=data['global_dimension'];q=11;norm=D[0]**2-q*D[1]**2;ratio=((D[0]**2+q*D[1]**2)/norm,2*D[0]*D[1]/norm)
 def hat(z):
  v=mul(ratio,(z[0],-z[1]),q)
  return v if positive_pair(v,q)else(-v[0],-v[1])
 dims=data['dimensions'];low=Counter(tuple(sum(Q(int(L[i,j]))*dims[i][c]for i in range(9))for c in range(2))for j in range(L.cols))
 patterns=[];rejected=[]
 modular_survivors=set(json.load(open(Path(__file__).with_name('1848_modular_integrality.json')))['surviving_gram_patterns'])if modular else set(range(len(rec['patterns'])))
 for k,pat in enumerate(rec['patterns']):
  if k not in modular_survivors:continue
  counts=low.copy()
  for (_,z),cnt in zip(cols,pat):counts[z]+=cnt
  if any(counts[z]!=counts[hat(z)]for z in list(counts)):rejected.append(k)
  else:patterns.append((k,pat))
 print('GALOIS',len(patterns),'of',len(rec['patterns']),flush=True)
 ep=(0,0,0,0,1,1,1,1);A,b,meta=system_rotation(R,data,L,ep,6);A,b=append_clifford(R,data,L,A,b,meta)
 countrows=[[int(tuple(v)==w)for v,ti in meta['labels']]+[0]*(len(A[0])-len(meta['labels']))for w in vs]
 AA=A+countrows;out=[];start=time.time()
 for k,pat in patterns[:limit]:
  bb=b+pat
  # Avoid exact-rational reconstruction for clearly feasible systems.
  am=np.array(AA,dtype=float);bm=np.array(bb,dtype=float);scale=np.maximum(1,np.maximum(np.max(abs(am),axis=1),abs(bm)))
  sol=linprog(np.zeros(am.shape[1]),A_eq=am/scale[:,None],b_eq=bm/scale,bounds=(0,None),method='highs',options={'time_limit':5})
  ray=None
  if sol.status==2:ray=farkas(AA,bb)
  if ray is not None:check_farkas(AA,bb,ray)
  out.append({'pattern':k,'solver_status':int(sol.status),'ray':ray,'outcome':'excluded'if ray is not None else'no_conclusion'})
  print('PATTERN',k,out[-1]['outcome'],round(time.time()-start,2),flush=True)
  Path(__file__).with_name('1848_modular_pattern_traces.json'if modular else'1848_pattern_traces.json').write_text(json.dumps({'id':'R9_2_1848','kind':'integer_gram_pattern_trace_refinement','modular_filter':modular,'galois_rejected':rejected,'galois_survivors':[x[0]for x in patterns],'attempts':out,'outcome':'no_conclusion'if len(out)<len(patterns)or any(x['ray']is None for x in out)else'excluded'},indent=2)+'\n')
  if ray is None:break
if __name__=='__main__':run(modular='--modular'in sys.argv)
