"""Exact weighted-center trace test for the C6/C2 quadratic ring R9_2_1848.

The I(1) columns are forced without search by their dimensions, multiplicities
and the equal rows of the induction Gram matrix. Only a verified rational
separating ray is accepted. Reuses the general relative cyclotomic trace proof.
"""
from pathlib import Path
import sys,json,itertools,types,time
from fractions import Fraction as Q
BASE=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(BASE/'work'),str(BASE/'sources')]
from scalar_characters import chars
from exact import *
from higher_traces import build_system,farkas,check_farkas,indicator_choices,trace_types,mul
from tensor_rotation import system_rotation
import sympy as s

def prepare(R):
 n=len(R);a=chars(R);f,K,ds,D,pD,emb=a.fp();assert n==9
 d=ds[5];assert ds==[K.one]*5+[d]*3+[K.one]and d*d==6*d+K(2)
 B=s.Matrix(n,n,lambda j,i:sum(R[b][j][k]*R[k][a.du[b]][i]for b,k in itertools.product(range(n),repeat=2)))
 assert all(B.row(i)==B.row(5)for i in (6,7))
 roots=discover_roots(a.scalar_codegree_polynomial,K);residual,rem=a.C.charpoly(t).as_poly().div(a.scalar_codegree_polynomial);assert rem.is_zero
 spectral=[(r,1)for r in roots]
 for p,m in residual.factor_list()[1]:
  assert m%4==0
  q=s.Poly(p.as_expr().subs(t,2*t)/2**p.degree(),t,domain=s.QQ)
  spectral +=[(r,2)for r in discover_roots(q,K)for _ in range(m//4)]
 assert sorted(e for _,e in spectral)==[1]*5+[2]
 assert sorted(tuple(ec(D/r))for r,e in spectral)==sorted(tuple(ec(x))for x in [K.one,K.one+3*d]+[K(2)+3*d]*4)
 columns=[];proof=[]
 for r,e in spectral:
  beta=D/r
  # All columns lie in range(B), so rho coordinates coincide. B[0,i]=0
  # for i=1..4 forces their vanishing in I(1). Thus exactly e*1+b*sum rho+c*g.
  candidates=[]
  for b in range(7):
   for c in range(4):
    if K(e+c)+3*b*d==beta:candidates.append([e,0,0,0,0,b,b,b,c])
  assert len(candidates)==1
  columns.append(candidates[0]);proof.append({'irrep_degree':e,'dimension':ec(beta),'column':candidates[0]})
 L=s.Matrix.hstack(*map(s.Matrix,columns))
 assert all(sum(e*col[i]for (_,e),col in zip(spectral,columns))==B[0,i]for i in range(n))
 ch=types.SimpleNamespace(C=B,n=n,du=a.du)
 data={'ch':ch,'factor':f,'K':K,'ds':ds,'D':D,'embedding':emb,'q':11,'conductor':44,'dimensions':[(Q(1),Q(0))]*5+[(Q(3),Q(1))]*3+[(Q(1),Q(0))],'global_dimension':(Q(66),Q(18)),'primes':[2,3,11]}
 return data,L,proof

def append_clifford(R,data,L,A,b,meta):
 # d/2 is not an algebraic integer: polynomial x^2-3x-1/2.
 # Hence left g exchanges the two right-(1+g) structures on each rho.
 # The project pair-insertion lemma then gives nu3(rho)=-omega^j;
 # relative trace to Q(sqrt11) is -1 or 1/2. Convex hull is necessary.
 labels=meta['labels'];ts,_=trace_types(11,[2,3,11],6)
 dims=data['dimensions'];DD=data['global_dimension'];LL=L*L.T
 for obj in (5,6,7):
  prev=len(A[0]);nv=prev+2
  for row in A:row.extend([0,0])
  low=tuple(sum(Q(int(LL[obj,j]))*dims[j][c]for j in range(9))for c in range(2))
  rows=[[Q(0)]*nv for c in range(2)]
  for j,(v,ti) in enumerate(labels):
   z=tuple(sum(Q(v[i-1])*dims[i][c]for i in range(1,9))for c in range(2));val=mul(z,ts[ti][2],11)
   for c in range(2):rows[c][j]=v[obj-1]*val[c]
  for c in range(2):
   rows[c][prev]=DD[c];rows[c][prev+1]=-DD[c]/2;rhs=-low[c]
   den=s.ilcm(*[x.denominator for x in rows[c]+[rhs]])
   A.append([int(x*den)for x in rows[c]]);b.append(int(rhs*den))
  A.append([0]*prev+[1,1]);b.append(1)
 return A,b

def run(height=6,rotation=False,clifford=False):
 R=json.load(open(BASE/'work/verification_corpus.json'))['tensors']['R9_2_1848'];data,L,proof=prepare(R);out=[];start=time.time()
 for ep in indicator_choices(R):
  A,b,meta=(system_rotation if rotation else build_system)(R,data,L,ep,height)
  if clifford:
   assert height==6
   A,b=append_clifford(R,data,L,A,b,meta)
  print('SYSTEM',height,rotation,'indicators',ep,'columns',len(A[0]),'rows',len(b),flush=True)
  y=farkas(A,b)
  if y is not None:check_farkas(A,b,y)
  out.append({'indicators':ep,'ray':y,'meta':{k:v for k,v in meta.items()if k!='labels'}})
  print('RAY',y is not None,'seconds',round(time.time()-start,2),flush=True)
  if y is None:break
 rec={'id':'R9_2_1848','kind':'weighted_quadratic_center_traces','forced_I1_columns':proof,'height':height,'rotation':rotation,'clifford':clifford,'outcome':'excluded'if all(a['ray']is not None for a in out)else'no_conclusion','cases':out,'seconds':time.time()-start}
 (Path(__file__).parent/f'1848_traces_h{height}_r{int(rotation)}_c{int(clifford)}.json').write_text(json.dumps(rec,indent=2)+'\n')
 return rec
if __name__=='__main__':run(int(sys.argv[1])if len(sys.argv)>1 else 6,'--rotation'in sys.argv,'--clifford'in sys.argv)
