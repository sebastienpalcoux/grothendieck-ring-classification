"""Complete high-column multiplicity enumeration, not an existence test."""
from quadratic1848 import *
from higher_traces import high_columns
import z3
def run():
 R=json.load(open(BASE/'work/verification_corpus.json'))['tensors']['R9_2_1848'];data,L,proof=prepare(R);G,cols=high_columns(data,L)
 S=z3.SolverFor('QF_LIA');v=z3.Ints(' '.join('x'+str(i)for i in range(len(cols))))
 for x in v:S.add(x>=0)
 for i,j in itertools.combinations_with_replacement(range(8),2):S.add(sum(x*c[i]*c[j]for x,(c,z)in zip(v,cols))==int(G[i,j]))
 out=[];start=time.time()
 while S.check()==z3.sat:
  m=S.model();vv=[m.eval(x).as_long()for x in v];out.append(vv)
  S.add(z3.Or([x!=a for x,a in zip(v,vv)]))
  assert len(out)<100000,'enumeration budget'
 rec={'id':'R9_2_1848','kind':'high_center_integer_gram','columns':[list(c)for c,z in cols],'dimensions':[list(map(str,z))for c,z in cols],'complete':True,'patterns':out,'seconds':time.time()-start}
 Path(__file__).with_suffix('.json').write_text(json.dumps(rec,indent=2)+'\n');print('PATTERNS',len(out),rec['seconds'],flush=True)
if __name__=='__main__':run()
