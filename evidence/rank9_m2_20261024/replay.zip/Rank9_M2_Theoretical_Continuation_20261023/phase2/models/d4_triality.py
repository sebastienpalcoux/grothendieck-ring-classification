"""Exact D4 level-two WZW tensor and its diagram-triality equivariantization.

The Weyl alternant is evaluated in Q(zeta32), without numerical rounding.
Only the tensor-unit pairing of the fixed nonunit simple enters a nontrivial
triality trace; it is normalized to one. See d4_triality.md.
"""
from pathlib import Path
import hashlib
import itertools
import json
import sys
import sympy as sp

P=Path(__file__).resolve().parent
ROOT=P.parents[1]
sys.path[:0]=[str(ROOT/'sources'),str(ROOT/'work')]
from exact import field,t
from match_models import based_iso,coarse
from oriented_signed import validate_general


def seed():
    K=field(sp.Poly(t**16+1,t))
    labels=[a for a in itertools.product(range(3),repeat=4)
            if a[0]+2*a[1]+a[2]+a[3]<=2]
    assert len(labels)==11 and labels[0]==(0,0,0,0)
    # Twice the four fundamental weights, in orthonormal e-coordinates.
    fundamental=[(2,0,0,0),(2,2,0,0),(1,1,1,-1),(1,1,1,1)]
    shifted=[tuple(sum(a[i]*fundamental[i][j]for i in range(4))+[6,4,2,0][j]
                   for j in range(4))for a in labels]
    W=[]
    for perm in itertools.permutations(range(4)):
        sign=(-1)**sum(perm[i]>perm[j]for i in range(4)for j in range(i+1,4))
        for signs in itertools.product([-1,1],repeat=4):
            if sp.prod(signs)==1:W.append((perm,signs,sign))
    assert len(W)==192
    U=[]
    for lam in shifted:
        row=[]
        for mu in shifted:
            coeff=[0]*16
            for perm,signs,det in W:
                exponent=-sum(lam[i]*signs[i]*mu[perm[i]]for i in range(4))%32
                coeff[exponent%16]+=det*((-1)**(exponent//16))
            row.append(K(list(reversed(coeff))))
        U.append(row)
    norm=4*8**4
    # -1 belongs to W(D4), so every Weyl alternant is real and charge
    # conjugation is the identity. This also certifies normalization.
    assert all(sum((U[i][j]*U[k][j]for j in range(11)),K.zero)==K(norm*int(i==k))
               for i,k in itertools.product(range(11),repeat=2))
    inverse0=[K.one/x for x in U[0]]
    R=[[[0]*11 for _ in range(11)]for _ in range(11)]
    for a,b,c in itertools.product(range(11),repeat=3):
        val=sum((U[a][j]*U[b][j]*U[c][j]*inverse0[j]for j in range(11)),K.zero)/K(norm)
        q=val.to_list()
        assert not q or len(q)==1 and q[0].denominator==1 and q[0]>=0
        R[a][b][c]=int(q[0])if q else 0
    validate_general(R,nonnegative=True)
    dimensions=[]
    for i in range(11):
        q=(U[i][0]/U[0][0]).to_list()
        assert len(q)==1 and q[0].denominator==1
        dimensions.append(int(q[0]))
    sigma=[labels.index((a[3],a[1],a[0],a[2]))for a in labels]
    assert all(R[a][b][c]==R[sigma[a]][sigma[b]][sigma[c]]
               for a,b,c in itertools.product(range(11),repeat=3))
    fixed=[i for i in range(11)if sigma[i]==i]
    assert fixed==[0,labels.index((0,1,0,0))]
    f=fixed[1]
    invertibles=[i for i,d in enumerate(dimensions)if d==1]
    assert len(invertibles)==4 and dimensions[f]==2
    assert R[f][f]==[int(i in invertibles)for i in range(11)]
    assert all(R[i][i][0]==1 for i in range(11))
    return R,labels,dimensions,sigma


def equivariantize(R,sigma):
    n=len(R);orbits=[];seen=set()
    for a in range(n):
        if a in seen:continue
        orbit=sorted({a,sigma[a],sigma[sigma[a]]})
        assert len(orbit)in [1,3]
        seen.update(orbit);orbits.append(orbit)
    labels=[(orbit,e)for orbit in orbits for e in (range(3)if len(orbit)==1 else [0])]
    assert len(labels)==9
    T=[[[0]*9 for _ in range(9)]for _ in range(9)]
    for i,j,k in itertools.product(range(9),repeat=3):
        A,a=labels[i];B,b=labels[j];C,c=labels[k]
        value=sum(R[x][y][z]for x in A for y in B for z in C)
        if len(A)==len(B)==len(C)==1:
            # The fixed subcategory has just 1,f with f^2=sum(Inv).
            # Its fixed Hom-lines have normalized trace one.
            value+=R[A[0]][B[0]][C[0]]*(2 if (a+b-c)%3==0 else -1)
        assert value>=0 and value%3==0
        T[i][j][k]=value//3
    validate_general(T,nonnegative=True)
    return T,labels


def construct():
    R,weights,dims,sigma=seed()
    T,labels=equivariantize(R,sigma)
    return T,{'wzw_type':'D4','level':2,'seed_weights':[list(a)for a in weights],
              'seed_dimensions':dims,'seed_tensor':R,'triality_permutation':sigma,
              'equivariant_labels':labels,'normalization_square':16384,
              'cyclotomic_polynomial':'x^16+1','seed_dimension':sum(x*x for x in dims)}


def main():
    T,data=construct()
    corpus=json.loads((ROOT/'work/verification_corpus.json').read_text())['tensors']
    out=[]
    for name,U in corpus.items():
        if coarse(T)!=coarse(U):continue
        perm=based_iso(U,T)
        if perm is not None:
            out.append({'id':name,'status':'unitarily_realized',
                        'model':'Spin(8)_2 WZW category equivariantized by order-three Dynkin triality',
                        'tensor':T,'basis_map_source_to_model':perm,'parameters':data,
                        'proof':'phase2/models/d4_triality.md'})
    (P/'d4_triality_models.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'models':[(r['id'],r['basis_map_source_to_model'])for r in out],
                      'seed_rank':11,'seed_dimension':data['seed_dimension'],
                      'rank':len(T),'multiplicity':max(c for row in T for entry in row for c in entry)}))


if __name__=='__main__':main()
