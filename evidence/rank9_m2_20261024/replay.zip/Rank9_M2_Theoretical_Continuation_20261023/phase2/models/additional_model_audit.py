"""Independent coherence replay for the weak-integral agent's models 21 and 389."""
from pathlib import Path
import hashlib
import itertools
import json
import sys

P = Path(__file__).resolve().parent
ROOT = P.parents[1]
sys.path[:0] = [str(ROOT/'sources'), str(ROOT/'phase2/weak_integral')]
from mr_orbifold import construct as mr_construct
from projective_ty import constructor as ty_construct
from oriented_signed import validate_general


def check_match(tensor, record, source):
    validate_general(tensor, nonnegative=True)
    assert tensor == record['tensor']
    permutation = record['basis_map_source_to_model']
    assert sorted(permutation) == list(range(9)) and permutation[0] == 0
    assert all(source[i][j][k] == tensor[permutation[i]][permutation[j]][permutation[k]]
               for i,j,k in itertools.product(range(9), repeat=3))
    return {'id': record['id'], 'basis_map_source_to_model': permutation,
            'tensor_sha256': hashlib.sha256(json.dumps(tensor,separators=(',',':')).encode()).hexdigest(),
            'full_tensor_checks': 729, 'status': 'PASS'}


def main():
    # All exponents are in Z/16, with representative degrees 0,...,15.
    n = 16
    w = lambda a,b,c: 2*a*((b+c)//16) % 16
    mu = lambda a,b: (-2*a*int(b>0)) % 16
    beta = lambda a: 7*a % 16
    for a,b,c,d in itertools.product(range(n), repeat=4):
        assert (w(b,c,d)-w((a+b)%n,c,d)+w(a,(b+c)%n,d)
                -w(a,b,(c+d)%n)+w(a,b,c)) % n == 0
    for a,b,c in itertools.product(range(n), repeat=3):
        assert (mu(a,b)+mu((a+b)%n,c)-mu(b,c)-mu(a,(b+c)%n)
                +w(a,b,c)-w(-a%n,-b%n,-c%n)) % n == 0
    for a,b in itertools.product(range(n), repeat=2):
        assert (mu(a,b)+mu(-a%n,-b%n)) % n == 0
        # Central hexagon for the pointed object 8 with character beta.
        assert (beta((a+b)%n)-beta(a)-beta(b)-w(a,8,b)+w(8,a,b)+w(a,b,8)) % n == 0
    for a in range(n):
        # Tensor-square half-braiding of the lift of 8 is the identity.
        assert (2*beta(a)+w(8,8,a)-w(8,a,8)+w(a,8,8)) % n == 0
        # Inversion preserves this central lift with identity equivariance.
        assert (beta(a)-beta(-a%n)-mu(8,-a%n)+mu(-a%n,8)) % n == 0
    # psi has self-braiding -1 (exponent8); the diagonal lift is bosonic.
    assert (8+beta(8)) % n == 0 and w(8,8,8) == 0 and mu(8,8) == 0
    data = {'tensorator_mod16': [[mu(a,b) for b in range(n)] for a in range(n)],
            'square_coherence_mod16': [0]*n}
    source = json.loads((ROOT/'work/verification_corpus.json').read_text())['tensors']
    mr = json.loads((ROOT/'phase2/weak_integral/mr_models.json').read_text())
    checks=[]
    for sign in [1,-1]:
        tensor,_ = mr_construct(data,boson_sign=sign)
        record = next(r for r in mr if r['id']=='R9_2_389' and r['parameters']['boson_equivariant_sign']==sign)
        # The closed-form tensorator may change basis labels relative to an
        # earlier solver-produced gauge. Find an exact isomorphism if necessary.
        from match_models import based_iso
        perm = based_iso(source['R9_2_389'],tensor)
        assert perm is not None
        local = dict(record,tensor=tensor,basis_map_source_to_model=perm)
        checks.append(check_match(tensor,local,source['R9_2_389']))
    t21 = ty_construct(5)
    r21 = next(r for r in json.loads((ROOT/'phase2/weak_integral/models.json').read_text()) if r['id']=='R9_2_21')
    checks.append(check_match(t21,r21,source['R9_2_21']))
    out={'status':'PASS','categorical_audit':'additional_model_audit.md',
         'mr_closed_formula':'omega(a,b,c)=zeta16^(2*a*floor((b+c)/16)); mu(a,b)=zeta16^(-2*a*1_(b>0)); c=1',
         'mr_cocycle_checks':16**4,'mr_tensorator_checks':16**3,
         'mr_square_coherence_checks':16**2,'mr_central_hexagon_checks':16**2,
         'mr_central_square_checks':16,'mr_central_transport_checks':16,
         'tensor_checks':checks}
    (P/'additional_model_audit.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'status':'PASS','ids':['R9_2_21','R9_2_389'],'tensor_checks':3*729}))


if __name__=='__main__': main()
