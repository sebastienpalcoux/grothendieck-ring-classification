"""Reconstruct and exactly replay the eight models owned by this directory.

Run from any working directory. This does not classify other model agents'
records and does not modify the phase-one results.
"""
from pathlib import Path
import hashlib
import itertools
import json
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT / 'sources'), str(ROOT / 'work'), str(HERE)]
from oriented_signed import validate_general
from fib_s3 import construct as fib
from ty_s3 import construct as ty_eq
from ising_psu10 import construct as diagonal
from ordinary_swap import construct as swap
from d4_triality import construct as triality
from d4_zest_triality import construct as zested_triality
from match_models import ty


def digest(value):
    return hashlib.sha256(json.dumps(value, separators=(',', ':')).encode()).hexdigest()


def ah_tensor():
    data = json.loads((HERE / 'ah3_source_data.json').read_text())
    coeff = data['output_first_coefficients']
    dual = data['dual_nonunit']
    assert len(coeff) == 8 ** 3 and sorted(dual) == list(range(8))
    tensor = [[[0] * 9 for _ in range(9)] for _ in range(9)]
    for i in range(9):
        tensor[0][i][i] = tensor[i][0][i] = 1
    for i in range(8):
        tensor[i + 1][dual[i] + 1][0] = 1
    for k, i, j in itertools.product(range(8), repeat=3):
        tensor[i + 1][j + 1][k + 1] = coeff[64 * k + 8 * i + j]
    return tensor


def main():
    base = ty((3,))
    sigma = [0, 2, 1, 3]
    constructed = {
        'R9_2_515': diagonal()[0],
        'R9_2_748': ty_eq(base, sigma, [0, 0, 0, 0])[0],
        'R9_2_1211': ty_eq(base, sigma, [0, 0, 0, 1])[0],
        'R9_2_1372': ah_tensor(),
        'R9_2_1373': fib()[0],
        'R9_2_1983': swap()[0],
        'R9_2_1857': triality()[0],
        'R9_2_2029': zested_triality(2)[0],
    }
    records = []
    filenames = ['ah_models.json', 'fib_s3_models.json', 'ty_s3_models.json',
                 'ising_psu10_models.json', 'ordinary_swap_models.json',
                 'd4_triality_models.json', 'd4_zest_triality_new_models.json']
    for filename in filenames:
        for record in json.loads((HERE / filename).read_text()):
            records.append((filename, record))
    assert len(records) == 8 and {r['id'] for _, r in records} == set(constructed)
    corpus = json.loads((ROOT / 'work/verification_corpus.json').read_text())['tensors']
    checked = []
    for filename, record in records:
        rid = record['id']
        model = constructed[rid]
        validate_general(model, nonnegative=True)
        assert model == record['tensor'], (rid, 'independent reconstruction differs')
        permutation = record['basis_map_source_to_model']
        assert sorted(permutation) == list(range(9)) and permutation[0] == 0
        source = corpus[rid]
        for i, j, k in itertools.product(range(9), repeat=3):
            assert source[i][j][k] == model[permutation[i]][permutation[j]][permutation[k]], (rid, i, j, k)
        assert max(c for row in model for entry in row for c in entry) == 2
        checked.append({'id': rid, 'model_file': filename,
                        'basis_map_source_to_model': permutation,
                        'source_tensor_sha256': digest(source),
                        'model_tensor_sha256': digest(model),
                        'full_tensor_checks': 729,
                        'fusion_axioms': 'PASS', 'reconstruction': 'PASS'})
    manifest = {'scope': 'Eight new models owned by phase2/models; other agents remain separate',
                'status': 'PASS', 'model_count': len(checked),
                'full_tensor_checks': 729 * len(checked), 'models': checked,
                'references': ['models_theory.md', 'ordinary_swap.md',
                               '../signed/ordinary_swap_audit.md', 'd4_triality.md',
                               'd4_zest_triality.md']}
    (HERE / 'replay_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'status': 'PASS', 'model_count': len(checked),
                      'ids': sorted(constructed), 'full_tensor_checks': 729 * len(checked)}))


if __name__ == '__main__':
    main()
