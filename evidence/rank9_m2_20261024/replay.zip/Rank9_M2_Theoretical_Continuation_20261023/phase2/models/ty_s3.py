'''Exact equivariantization by S3 acting through inversion on TY(A).
Both weak-action coherences inflated from H^2(C2,Aut_tensor(Id))=C2.
Action on fixed multiplicity-one fusion lines is the identity; m is odd.
'''
from pathlib import Path
import sys,json,itertools
P=Path(__file__).resolve().parent;B=P.parents[1]
sys.path[:0]=[str(B/'sources'),str(B/'work')]
from exact import field,t,require
from match_models import based_iso,coarse,ty
from oriented_signed import validate_general
import sympy as s

def construct(R,sigma,parity=None):
 K=field(s.Poly(t*t+t+1,t));w=K([1,0]);z=K.zero;o=K.one;n=len(R)
 parity=parity or [0]*n
 G=list(itertools.product(range(3),range(2)))
 seen=set();labels=[]
 for a in range(n):
  if a in seen:continue
  O=sorted({a,sigma[a]});seen.update(O)
  for j in range(3):labels.append((O,j))
 def chi(label,a,g):
  O,j=label;r,e=g
  if a not in O:return z
  if len(O)==2:
   if e:return z
   return w**((j*r*(1 if a==O[0] else -1))%3)
  if j==0:return o
  if j==1:return K((-1)**e)
  return K(0 if e else 2 if r==0 else -1)
 def inv(g):r,e=g;return ((-r if not e else r)%3,e)
 r=len(labels);out=[[[0]*r for j in range(r)]for i in range(r)]
 chars={(i,a,g):chi(L,a,g) for i,L in enumerate(labels) for a in L[0] for g in G}
 channels=[(a,b,c,R[a][b][c])for a,b,c in itertools.product(range(n),repeat=3)if R[a][b][c]]
 for i,j,k in itertools.product(range(r),repeat=3):
  v=z
  A=labels[i][0];BB=labels[j][0];C=labels[k][0]
  for a,b,c,N in channels:
   if a not in A or b not in BB or c not in C:continue
   v+=sum((chars[i,a,g]*chars[j,b,g]*chars[k,c,inv(g)]*K(N*((-1)**((parity[a]+parity[b]-parity[c])//2)if g[1]else 1))for g in G),z)
  v=(v/K(6)).to_list();require(not v or len(v)==1 and v[0].denominator==1 and v[0]>=0,'integral character product')
  out[i][j][k]=int(v[0])if v else 0
 validate_general(out)
 return out,labels

def main():
 data=json.load(open(B/'work/verification_corpus.json'))['tensors'];out=[];attempts=[]
 for m in [3,5,7,9]:
  R=ty((m,));sigma=[(-a)%m for a in range(m)]+[m]
  for p in range(2):
   T,labels=construct(R,sigma,[0]*m+[p]);hits=[]
   if len(T)==9 and max(v for a in T for b in a for v in b)==2:
    for name,U in data.items():
     if coarse(T)!=coarse(U):continue
     iso=based_iso(U,T)
     if iso is not None:
      hits.append(name);out.append({'id':name,'model':f'TY(C{m})^S3 by inversion, parity coherence {p}','tensor':T,'basis_map_source_to_model':iso,'labels':labels,'base_group':f'C{m}','bicharacter':f'chi(a,b)=exp(2pi i ab/{m})','tau':f'1/sqrt({m})','sigma':sigma,'parity':p,'status':'unitarily_realized','existence':'Orthogonal automorphism inversion of the Tambara-Yamagami category, pulled back S3 -> C2. Optional weak action coherence is the nontrivial parity natural automorphism on m when both group elements are odd.'})
   print(m,p,'rank',len(T),'mult',max(v for a in T for b in a for v in b),'hits',hits,flush=True);attempts.append({'group':m,'parity':p,'rank':len(T),'matches':hits})
 (P/'ty_s3_models.json').write_text(json.dumps(out,indent=2)+'\n');(P/'ty_s3_attempts.json').write_text(json.dumps(attempts,indent=2)+'\n')
if __name__=='__main__':main()
