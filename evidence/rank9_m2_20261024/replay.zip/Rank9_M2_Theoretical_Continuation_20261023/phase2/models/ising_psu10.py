from pathlib import Path
import sys,json
P=Path(__file__).resolve().parent;B=P.parents[1]
sys.path[:0]=[str(B/'sources'),str(B/'work')]
from positive_models import product,ng2,su2
from literature_models import free_involution_quotient
from match_models import based_iso,coarse

def construct():
 A=ng2(0);C=su2(10,True);R=product(A,C)
 # Ising basis1,psi,sigma; PSU2_10 basisV0,V2,...,V10.
 Q,aux=free_involution_quotient(R,1*6+5)
 return Q,aux

def main():
 R,aux=construct();data=json.load(open(B/'work/verification_corpus.json'))['tensors'];out=[]
 for name,T in data.items():
  if coarse(T)!=coarse(R):continue
  p=based_iso(T,R)
  if p is not None:out.append({'id':name,'model':'Diagonal-fermion quotient (Ising box PSU(2)_10)_{1+psi box V10}','tensor':R,'basis_map_source_to_model':p,'status':'unitarily_realized','parameters':aux,'reference':'Standard unitary Ising and SU(2)_10 WZW categories. V10 centralizes all even labels and has twist -1, hence diagonal psi box V10 has specified central boson lift; ordinary central algebra quotient. Existing project free-involution quotient theorem.'})
 print([(x['id'],x['basis_map_source_to_model'])for x in out]);(P/'ising_psu10_models.json').write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()
