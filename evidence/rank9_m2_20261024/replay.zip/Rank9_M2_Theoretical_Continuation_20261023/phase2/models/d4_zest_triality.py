"""Triality-equivariant Tannakian zest of Spin(8)_2, realizing R9_2_2029.

Uses the categorical zesting theorem and equivariant trivialization proved
in d4_zest_triality.md. Exact seed and equivariantization from d4_triality.py.
"""
from pathlib import Path
import itertools
import json
import sys

P=Path(__file__).resolve().parent
ROOT=P.parents[1]
sys.path[:0]=[str(P),str(ROOT/'sources')]
from d4_triality import seed,equivariantize
from oriented_signed import validate_general
from match_models import based_iso,coarse


def multiply(a,b):
    """F4=F2[t]/(t²+t+1), encoded in the two binary coefficients."""
    value=0
    for i in range(2):
        if b>>i&1:value^=a<<i
    if value&4:value^=7
    return value


def construct(kappa=2):
    R,weights,dimensions,sigma=seed()
    degrees=[(a[0]%2)^((a[2]%2)*2)^((a[3]%2)*3)for a in weights]
    v=weights.index((2,0,0,0))
    currents={0:0,1:v,2:sigma[v],3:sigma[sigma[v]]}
    for a,b in itertools.product(range(4),repeat=2):
        assert R[currents[a]][currents[b]]==[int(i==currents[a^b])for i in range(11)]
    assert all(degrees[sigma[i]]==multiply(2,degrees[i])for i in range(11))
    assert all(sigma[currents[a]]==currents[multiply(2,a)]for a in range(4))
    assert all(not R[a][b][c] or degrees[c]==degrees[a]^degrees[b]
               for a,b,c in itertools.product(range(11),repeat=3))
    cocycle=lambda a,b:multiply(kappa,multiply(multiply(a,b),multiply(a,b)))
    table=[[cocycle(a,b)for b in range(4)]for a in range(4)]
    for a,b,c in itertools.product(range(4),repeat=3):
        assert cocycle(a,b)^cocycle(a^b,c)==cocycle(b,c)^cocycle(a,b^c)
    for a,b in itertools.product(range(4),repeat=2):
        assert cocycle(a,b)==cocycle(b,a)
        assert cocycle(multiply(2,a),multiply(2,b))==multiply(2,cocycle(a,b))
    T=[[[0]*11 for _ in range(11)]for _ in range(11)]
    for a,b in itertools.product(range(11),repeat=2):
        current=currents[cocycle(degrees[a],degrees[b])]
        for c in range(11):
            output=R[current][c].index(1)
            T[a][b][output]+=R[a][b][c]
    validate_general(T,nonnegative=True)
    assert all(T[a][b][c]==T[sigma[a]][sigma[b]][sigma[c]]
               for a,b,c in itertools.product(range(11),repeat=3))
    fixed=[i for i in range(11)if sigma[i]==i]
    assert fixed==[0,weights.index((0,1,0,0))]
    assert T[fixed[1]][fixed[1]]==[int(i in currents.values())for i in range(11)]
    tensor,labels=equivariantize(T,sigma)
    return tensor,{'seed_weights':weights,'seed_tensor':R,'seed_dimensions':dimensions,
                   'degrees_F4':degrees,'currents_F4':currents,
                   'triality_permutation':sigma,'kappa_F4':kappa,
                   'lambda_F4':table,'associator_scalar_cocycle':'1',
                   'zested_seed_tensor':T,'equivariant_labels':labels,
                   'existence_reference':'Galindo-Mora-Rowell arXiv:2311.17255 Proposition4.2; equivariant Tannakian trivialization by Schur-Zassenhaus'}


def main():
    corpus=json.loads((ROOT/'work/verification_corpus.json').read_text())['tensors']
    out=[]
    for kappa in [2,3]:
        T,data=construct(kappa)
        for name,U in corpus.items():
            if coarse(T)!=coarse(U):continue
            permutation=based_iso(U,T)
            if permutation is not None:
                out.append({'id':name,'status':'unitarily_realized',
                            'model':'Triality equivariantization of the Tannakian-zested Spin(8)_2 category',
                            'tensor':T,'basis_map_source_to_model':permutation,
                            'parameters':data,'proof':'phase2/models/d4_zest_triality.md'})
    (P/'d4_zest_triality_models.json').write_text(json.dumps(out,indent=2)+'\n')
    canonical=[r for r in out if r['parameters']['kappa_F4']==2]
    assert len(canonical)==1 and canonical[0]['id']=='R9_2_2029'
    (P/'d4_zest_triality_new_models.json').write_text(json.dumps(canonical,indent=2)+'\n')
    print(json.dumps({'models':[(r['id'],r['parameters']['kappa_F4'],r['basis_map_source_to_model'])for r in out]}))


if __name__=='__main__':main()
