'''Structural match only; quotient by fermion is NOT an ordinary category model.'''
from pathlib import Path
import sys,json
P=Path(__file__).resolve().parent;B=P.parents[1]
sys.path[:0]=[str(B/'sources'),str(B/'work')]
from positive_models import su2
from match_models import based_iso
from oriented_signed import validate_general
R=su2(34,True);T=[[[R[i][j][k]+R[i][j][17-k]for k in range(9)]for j in range(9)]for i in range(9)]
validate_general(T)
N=json.load(open(B/'work/verification_corpus.json'))['tensors']['R9_2_920'];p=based_iso(N,T);assert p is not None
record={'id':'R9_2_920','status':'structural_identification_only_NOT_a_categorical_model','parent':'PSU(2)_34','orbit_object':'V34, a central fermion','tensor':T,'basis_map_source_to_folded':p,'warning':'A fermionic orbit ring does not itself supply an ordinary fusion-category model.','generator_matrix':T[1]}
(P/'folded_so3_diagnostic.json').write_text(json.dumps(record,indent=2)+'\n');print(p)
