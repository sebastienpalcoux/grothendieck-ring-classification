from pathlib import Path
import sys,json,re,hashlib,itertools
P=Path(__file__).resolve().parent; B=P.parents[1]
sys.path[:0]=[str(B/'sources'),str(B/'work')]
from match_models import based_iso,coarse
from oriented_signed import validate_general
src=json.loads((P/'ah3_source_data.json').read_text());v=src['output_first_coefficients'];assert len(v)==8**3
D=[0,1,3,2,4,5,6,7];R=[[[0]*9 for j in range(9)]for i in range(9)]
for i in range(9):R[0][i][i]=R[i][0][i]=1
for i in range(8):R[i+1][D[i]+1][0]=1
for k,i,j in itertools.product(range(8),repeat=3):R[i+1][j+1][k+1]=v[64*k+8*i+j]
validate_general(R)
x=json.load(open(B/'work/verification_corpus.json'))['tensors'];hits=[]
for name,T in x.items():
 if coarse(R)==coarse(T):
  perm=based_iso(T,R)
  if perm is not None:hits.append({'id':name,'model':'Asaeda-Haagerup category AH3','tensor':R,'basis_map_source_to_model':perm,'reference':'Grossman-Snyder, The Brauer-Picard group of the Asaeda-Haagerup fusion categories, arXiv:1202.4396v2, Section 4.3, Table 3 and ancillary AH3Modules','source_url':'https://arxiv.org/src/1202.4396v2/anc/AH3Modules','source_sha256':src['source_sha256'],'status':'unitarily_realized'})
print([(z['id'],z['basis_map_source_to_model'])for z in hits]);(P/'ah_models.json').write_text(json.dumps(hits,indent=2)+'\n')
