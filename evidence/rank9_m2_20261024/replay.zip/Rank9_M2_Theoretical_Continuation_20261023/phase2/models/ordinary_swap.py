'''Ordinary swap equivariantization of half-E6 box_sVec half-E6.
The categorical derivation and scalar coherence audit are in ordinary_swap.md.
Canonical basis: 1,t,t2,t3,X,Y,tY,t2Y,t3Y, t4=1.
'''
from pathlib import Path
import sys,json,itertools
P=Path(__file__).resolve().parent;B=P.parents[1]
sys.path[:0]=[str(B/'sources'),str(B/'work')]
from exact import require
from match_models import based_iso,coarse
from oriented_signed import validate_general
from fermionic_products import local_certificate,fusion_tensor

def construct():
 local=local_certificate(2,2);Q=fusion_tensor(2,2)
 # With ordinary algebra equivariance phi=+1 on 1 and b,
 # u exchanges e0,e1. Coherence u*S(u)=1; mu after exchange=-mu.
 mu={(0,0):(0,1),(0,1):(1,1),(1,0):(1,-1),(1,1):(0,-1)}
 scalar=[]
 for a,b in itertools.product(range(2),repeat=2):
  c,v=mu[1-a,1-b];d,w=mu[a,b];require(c==d and v==-w,'ordinary swap lift square not sign')
  scalar.append({'a':a,'b':b,'component':c,'transformed_coefficient':v,'negative_original':-w})
 R=[[[0]*9 for j in range(9)]for i in range(9)]
 for i,j in itertools.product(range(4),repeat=2):R[i][j][(i+j)%4]=1
 for i in range(4):
  R[i][4][4]=R[4][i][4]=1
  for j in range(4):R[i][5+j][5+(i+j)%4]=R[5+j][i][5+(i+j)%4]=1
 R[4][4]=[1]*4+[2]+[1]*4
 for i in range(4):R[4][5+i]=R[5+i][4]=[0]*4+[1]*5
 for i,j in itertools.product(range(4),repeat=2):
  R[5+i][5+j][(i+j+1)%4]=1
  R[5+i][5+j][4]=1
  R[5+i][5+j][5+(i+j+2)%4]=1
  R[5+i][5+j][5+(i+j+3)%4]=1
 validate_general(R)
 # Exact forgetful functor into the previously constructed relative product.
 # Q basis(1,g,a,b,u,v), X->a+b, Y_even->u, Y_odd->v.
 F=[[1,0,0,0,0,0],[0,1,0,0,0,0],[1,0,0,0,0,0],[0,1,0,0,0,0],[0,0,1,1,0,0],
    [0,0,0,0,1,0],[0,0,0,0,0,1],[0,0,0,0,1,0],[0,0,0,0,0,1]]
 for i,j,k in itertools.product(range(9),range(9),range(6)):
  require(sum(R[i][j][l]*F[l][k]for l in range(9))==sum(F[i][a]*F[j][b]*Q[a][b][k]for a in range(6)for b in range(6)),'forgetful tensor identity')
 return R,{'categorical_inputs':local,'ordinary_swap_scalar_checks':scalar,'forgetful_matrix':F,'forgetful_identity_checks':486}

def main():
 R,aux=construct();data=json.load(open(B/'work/verification_corpus.json'))['tensors'];out=[]
 for name,T in data.items():
  if coarse(T)!=coarse(R):continue
  p=based_iso(T,R)
  if p is not None:out.append({'id':name,'model':'Ordinary-swap equivariantization of the equal half-E6 diagonal-fermion product','tensor':R,'basis_map_source_to_model':p,'status':'unitarily_realized','certificate':aux,'reference':'Aasen-Lake-Walker arXiv:1709.01941; existing project diagonal-fermion product theorem; new ordinary-swap proposition in ordinary_swap.md'})
 print([(x['id'],x['basis_map_source_to_model'])for x in out]);(P/'ordinary_swap_models.json').write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()
