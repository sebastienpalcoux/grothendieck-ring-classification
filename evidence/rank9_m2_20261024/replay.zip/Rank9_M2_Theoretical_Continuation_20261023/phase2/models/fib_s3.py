'''Permutation equivariantization (Fib box Fib)^S3, action through S3 -> C2.
Simple objects are equivariant bundles on base-simple orbits.
Fusion computed by the finite-group character averaging formula; tensorator on
multiplicity lines is the canonical permutation of the two factors.
'''
from pathlib import Path
import sys,json,itertools
P=Path(__file__).resolve().parent;B=P.parents[1]
sys.path[:0]=[str(B/'sources'),str(B/'work')]
from exact import field,t,require
from match_models import based_iso,coarse
from oriented_signed import validate_general
import sympy as s

def construct():
 K=field(s.Poly(t*t+t+1,t));w=K([1,0]);z=K.zero;o=K.one
 # g=(r,e), x^3=y^2=1, yxy=x^-1. Odd elements swap factors.
 G=list(itertools.product(range(3),range(2)))
 base=list(itertools.product(range(2),repeat=2))
 labels=[('00',j)for j in range(3)]+[('01/10',j)for j in range(3)]+[('11',j)for j in range(3)]
 def N(a,b,c):
  return int(all((cc==bb if aa==0 else cc==aa if bb==0 else cc in (0,1)) for aa,bb,cc in zip(a,b,c)))
 def chi(label,a,g):
  orbit,j=label;r,e=g
  if orbit=='00' and a!=(0,0) or orbit=='11' and a!=(1,1):return z
  if orbit=='01/10':
   if a not in [(0,1),(1,0)] or e:return z
   return w**((j*r*(1 if a==(0,1) else -1))%3)
  if j==0:return o
  if j==1:return K((-1)**e)
  return K(0 if e else 2 if r==0 else -1)
 def inv(g):r,e=g;return ((-r if not e else r)%3,e)
 n=len(labels);R=[[[0]*n for j in range(n)]for i in range(n)]
 for i,j,k in itertools.product(range(n),repeat=3):
  v=sum((chi(labels[i],a,g)*chi(labels[j],b,g)*chi(labels[k],c,inv(g))
    for g in G for a,b,c in itertools.product(base,repeat=3) if N(a,b,c)),z)/K(6)
  v=v.to_list();require(not v or len(v)==1 and v[0].denominator==1 and v[0]>=0,'character integral')
  R[i][j][k]=int(v[0])if v else 0
 validate_general(R)
 return R,labels

def main():
 R,labels=construct();data=json.load(open(B/'work/verification_corpus.json'))['tensors'];out=[]
 for name,T in data.items():
  if coarse(T)!=coarse(R):continue
  p=based_iso(T,R)
  if p is not None:out.append({'id':name,'model':'(Fib box Fib)^S3, sign quotient acts by swapping factors','tensor':R,'basis_map_source_to_model':p,'labels':labels,'status':'unitarily_realized','existence':'The canonical permutation action of S2 on the Deligne product Fib box Fib pulled back along S3 -> S2, followed by finite-group equivariantization.','fusion_formula':'G-invariant Hom character average on equivariant simple bundles; exact Q(zeta3) arithmetic.'})
 print('rank',len(R),'mult',max(v for a in R for b in a for v in b),'hits',[(x['id'],x['basis_map_source_to_model'])for x in out]);(P/'fib_s3_models.json').write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()
