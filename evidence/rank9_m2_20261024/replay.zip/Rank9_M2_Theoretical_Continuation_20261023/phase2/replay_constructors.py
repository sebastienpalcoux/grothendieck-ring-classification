"""Regenerate the accepted explicit models, then replay all tensor maps."""
from pathlib import Path
import subprocess,sys,time,json,os
from concurrent.futures import ThreadPoolExecutor,as_completed
ROOT=Path(__file__).resolve().parents[1]
SCRIPTS=['models/ah_model.py','models/fib_s3.py','models/ising_psu10.py','models/ordinary_swap.py','models/ty_s3.py','weak_integral/projective_ty.py','group_models/dihedral_extension_models.py','group_models/pullback_equivariant_models.py','weak_integral/mr_orbifold.py','models/d4_triality.py','models/d4_zest_triality.py']
def one(p):
 start=time.monotonic()
 r=subprocess.run([sys.executable,str(ROOT/'phase2'/p)],capture_output=True,text=True,env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'))
 assert r.returncode==0,(p,r.stdout,r.stderr)
 return {'script':p,'status':'PASS','seconds':time.monotonic()-start,'output':r.stdout.strip()}
if __name__=='__main__':
 out=[]
 with ThreadPoolExecutor(max_workers=3)as pool:
  for future in as_completed([pool.submit(one,p)for p in SCRIPTS]):
   row=future.result();out.append(row);print(row['script'],'PASS',round(row['seconds'],2),flush=True)
 (ROOT/'phase2/results/constructor_verification.json').write_text(json.dumps(out,indent=2)+'\n')
 subprocess.run([sys.executable,str(ROOT/'phase2/verify_models.py')],check=True)
