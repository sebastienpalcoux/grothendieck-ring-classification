"""Explicit involutory cyclic actions and exact central-boson quotient scan."""
from pathlib import Path
import json,sys,itertools,z3
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT/'sources')]
from mr_orbifold import construct
from match_models import based_iso
C=json.load(open(ROOT/'work/verification_corpus.json'))
IDS=[389,1025,1254,1709,1759,1988]
out=[]
for p,r in itertools.product([2,6,10,14],[7,15]):
 mu=[[(-p*r*a*((r*b)//16))%16 for b in range(16)]for a in range(16)]
 w=lambda a,b,c:p*a*((b+c)//16)
 assert all((mu[a][b]+mu[(a+b)%16][c]-mu[b][c]-mu[a][(b+c)%16]-w(r*a%16,r*b%16,r*c%16)+w(a,b,c))%16==0 for a,b,c in itertools.product(range(16),repeat=3))
 j=(-p//2)%8
 assert all((mu[8][a]-mu[a][8]-j*(r-1)*a)%16==0 for a in range(16))
 cs=[z3.BitVec(f'c{a}',4)for a in range(16)];s=z3.SolverFor('QF_BV')
 for a in range(16):s.add(cs[r*a%16]==cs[a])
 for a,b in itertools.product(range(16),repeat=2):s.add(cs[a]+cs[b]-cs[(a+b)%16]==mu[a][b]+mu[r*a%16][r*b%16])
 s.add(cs[8]==mu[8][8])
 # All coherent squares modulo monoidal natural-isomorphism changes are small;
 # enumerate all solutions (at most16) directly.
 count=0
 while s.check()==z3.sat:
  m=s.model();co=[m.eval(c,model_completion=True).as_long()for c in cs]
  s.add(z3.Or(*[cs[a]!=co[a]for a in range(16)]));count+=1
  data={'cyclic_automorphism_multiplier':r,'cocycle_class':p,'tensorator_mod16':mu,'square_coherence_mod16':co,'central_boson_character_parameter':j}
  for sign in [1,-1]:
   try:T,pars=construct(data,boson_sign=sign)
   except AssertionError as exc:
    print('FAIL',p,r,co,sign,str(exc));raise
   matches=[]
   if len(T)==9:
    for k in IDS:
     iso=based_iso(C['tensors'][f'R9_2_{k}'],T)
     if iso is not None:matches.append([k,iso])
   out.append({'p':p,'r':r,'coherence':co,'boson_sign':sign,'rank':len(T),'max_mult':max(v for a in T for b in a for v in b),'matches':matches})
  if count>20:raise RuntimeError('Unexpected large coherent-square family')
 print(p,r,count,[(v['rank'],v['matches'])for v in out if v['p']==p and v['r']==r],flush=True)
(Path(__file__).parent/'mr_variants.json').write_text(json.dumps(out,indent=2)+'\n')
