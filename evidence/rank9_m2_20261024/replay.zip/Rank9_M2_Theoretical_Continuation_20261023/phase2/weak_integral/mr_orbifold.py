"""A boson quotient of an inversion orbifold of a cyclic Ising extension."""
from pathlib import Path
import sys,json,itertools
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT/'sources')]
from positive_models import ng2
from oriented_signed import validate_general
from match_models import based_iso

def construct(data,boson_sign=1):
 I=ng2(0);B=[(i,a)for i in range(3)for a in range(16)if (a%2)==int(i==2)];idx={x:i for i,x in enumerate(B)};n=len(B)
 R=[[[I[i][j][k]*int((a+b)%16==c)for k,c in B]for j,b in B]for i,a in B]
 multiplier=data.get('cyclic_automorphism_multiplier',15)
 sg=[idx[i,multiplier*a%16]for i,a in B];mu=data['tensorator_mod16'];co=data['square_coherence_mod16']
 labs=[];seen=set()
 for a in range(n):
  if a in seen:continue
  A=sorted({a,sg[a]});seen.update(A)
  for sign in ([1,-1]if len(A)==1 else [0]):labs.append((A,sign))
 m=len(labs);T=[[[0]*m for _ in range(m)]for _ in range(m)]
 for i,(A,s) in enumerate(labs):
  for j,(BB,t) in enumerate(labs):
   for k,(CC,u) in enumerate(labs):
    c=CC[0];dim=sum(R[a][b][c]for a in A for b in BB)
    if len(CC)==1:
     trace=0
     for a in A:
      for b in BB:
       if sg[a]!=a or sg[b]!=b or not R[a][b][c]:continue
       ca,cb,cc=B[a][1],B[b][1],B[c][1]
       # u_a u_b J_ab^-1 / u_c; all fixed simples are pointed.
       exponent=(co[ca]+co[cb]-co[cc]-2*mu[ca][cb])%32
       assert exponent in [0,16],exponent
       trace+=s*t*u*((-1)**(exponent//16))*R[a][b][c]
     assert (dim+trace)%2==0;T[i][j][k]=(dim+trace)//2
    else:T[i][j][k]=dim
 validate_general(T)
 gg=idx[1,8];g=next(i for i,(A,s)in enumerate(labs)if A==[gg]and s==boson_sign)
 assert T[g][g]==[1]+[0]*(m-1)
 act=[row.index(1)for row in T[g]];assert all(sum(row)==1 for row in T[g]);assert all(act[i]!=i for i in range(m))
 orbits=[];seen=set()
 for i in range(m):
  if i in seen:continue
  O=sorted([i,act[i]]);orbits.append(O);seen.update(O)
 Q=[[[sum(T[A[0]][BB[0]][k]for k in CC)for CC in orbits]for BB in orbits]for A in orbits]
 validate_general(Q)
 return Q,{'prequotient_labels':[[A,s]for A,s in labs],'D16_labels':[list(x)for x in B],'prequotient_tensor':T,'central_boson_index':g,'quotient_orbits':orbits,'boson_equivariant_sign':boson_sign}

def main():
 D=json.load(open(Path(__file__).parent/'mr_inversion.json'));C=json.load(open(ROOT/'work/verification_corpus.json'));out=[]
 for sign in [1,-1]:
  T,pars=construct(D,boson_sign=sign);print('tensor',len(T),max(v for a in T for b in a for v in b))
  for r in json.load(open(ROOT/'results/unresolved.json')):
   p=based_iso(C['tensors'][r['id']],T)
   if p is not None:
    out.append({'id':r['id'],'status':'unitarily_realized','model':'Inversion orbifold of cyclic generalized Moore-Read category, dimension16','tensor':T,'basis_map_source_to_model':p,'parameters':pars,'proof':'phase2/weak_integral/mr_orbifold.md','action_certificate':'phase2/weak_integral/mr_inversion.json'});print(r['id'],p)
 (Path(__file__).parent/'mr_models.json').write_text(json.dumps(out,indent=2)+'\n')
 canonical=[]
 for record in out:
  if any(old['id']==record['id']for old in canonical):continue
  item=dict(record);item['status']='unitarily_realized';canonical.append(item)
 (Path(__file__).parent/'mr_new_models.json').write_text(json.dumps(canonical,indent=2)+'\n')
if __name__=='__main__':main()
