"""Full exact coherence solver for fermion/charge-mixing D16 automorphisms.

No based-ring automorphism alone is accepted: all tensor-functor and action
equations, the central transport equation, and algebra equivariance are required.
"""
from pathlib import Path
import sys,json,itertools,time,z3
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT/'sources')]
from positive_models import ng2
from ising_square_action import fs

def build(p=2,r=15,v=1,bits=4):
 n=16;mod=2**bits;scale=mod//16;I=ng2(0)
 B=[(i,a)for i in range(3)for a in range(16)if (a%2)==int(i==2)];ix={x:i for i,x in enumerate(B)};N=len(B)
 R=[[[I[i][j][k]*int((a+b)%16==c)for k,c in B]for j,b in B]for i,a in B]
 sg=[ix[(i^(v*(a//2)%2))if i<2 else 2,r*a%16]for i,a in B]
 assert all(sg[sg[a]]==a for a in range(N))
 assert all(R[a][b][c]==R[sg[a]][sg[b]][sg[c]]for a,b,c in itertools.product(range(N),repeat=3))
 labs=[(a,b,c)for a,b,c in itertools.product(range(N),repeat=3)if R[a][b][c]]
 jj={l:z3.BitVec('j%d_%d_%d'%l,bits)for l in labs};cc=[z3.BitVec(f'c{a}',bits)for a in range(N)]
 s=z3.SolverFor('QF_BV');s.set(timeout=90000);eqs=[]
 def add(terms,rhs):
  eqs.append((terms,rhs%mod));s.add(sum(co*(jj[k]if isinstance(k,tuple)else cc[k])for co,k in terms)==rhs)
 for a in range(N):add([(1,(0,a,a))],0);add([(1,(a,0,a))],0);add([(1,a),(-1,sg[a])],0)
 for a,b,c in labs:
  add([(1,(a,b,c)),(1,(sg[a],sg[b],sg[c])),(-1,a),(-1,b),(1,c)],0)
 fusion=[[ [c for c in range(N)if R[a][b][c]]for b in range(N)]for a in range(N)]
 def exponent(a,b,c,d,e,f):
  ii=[B[x][0]for x in [a,b,c,d,e,f]];ac,bc,cc0=[B[x][1]for x in [a,b,c]]
  return scale*(8*fs(*ii)+p*ac*((bc+cc0)//16))
 for a,b,c in itertools.product(range(N),repeat=3):
  for e in fusion[a][b]:
   for d in fusion[e][c]:
    for f in fusion[b][c]:
     if d not in fusion[a][f]:continue
     add([(1,(a,b,e)),(1,(e,c,d)),(-1,(b,c,f)),(-1,(a,f,d))],exponent(*(sg[x]for x in [a,b,c,d,e,f]))-exponent(a,b,c,d,e,f))
 g=ix[1,8];j=(-p//2)%8
 def halfbraid(a):
  i,k=B[a];return scale*(j*k+[0,8,12][i])
 for a in range(N):
  ga=fusion[g][a][0]
  add([(1,(g,a,ga)),(-1,(a,g,ga))],halfbraid(sg[a])-halfbraid(a))
 add([(1,(g,g,0)),(-1,g)],0)
 print('variables',len(jj)+N,'equations',len(eqs),'p,r,v,bits',p,r,v,bits,flush=True)
 start=time.time();status=s.check();print('status',status,'seconds',time.time()-start,flush=True)
 if status!=z3.sat:return {'status':str(status),'p':p,'r':r,'v':v,'bits':bits,'variables':len(jj)+N,'equations':len(eqs)}
 m=s.model();J={l:m.eval(x,model_completion=True).as_long()for l,x in jj.items()};C=[m.eval(x,model_completion=True).as_long()for x in cc]
 assert all((sum(co*(J[k]if isinstance(k,tuple)else C[k])for co,k in terms)-rhs)%mod==0 for terms,rhs in eqs)
 data={'status':'sat_exactly_verified','p':p,'r':r,'v':v,'bits':bits,'modulus':mod,'labels':B,'tensor':R,'automorphism':sg,'tensorator_labels':labs,'tensorator_exponents':[J[l]for l in labs],'square_coherence_exponents':C,'boson_index':g,'boson_character':j,'equations':len(eqs)}
 return data

if __name__=='__main__':
 p,r,v,bits=map(int,sys.argv[1:])if len(sys.argv)>1 else (2,15,1,4)
 result=build(p,r,v,bits)
 (Path(__file__).parent/f'mr_mixed_{p}_{r}_{v}_{bits}.json').write_text(json.dumps(result,indent=2)+'\n')
