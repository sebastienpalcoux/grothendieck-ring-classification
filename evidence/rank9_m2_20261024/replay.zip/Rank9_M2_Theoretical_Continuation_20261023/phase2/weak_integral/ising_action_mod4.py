"""Exact sign-coherence equations for a candidate C2 action on Ising x Vec(C4)."""
import sys,json,itertools
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT/'sources')]
from positive_models import ng2,cyclic,product
from oriented_signed import validate_general
from match_models import based_iso

def gauss(rows,n):
 piv={}
 for co,rhs in rows:
  x=sum(1<<a for a in co) | (int(rhs)<<n)
  while x&((1<<n)-1):
   j=(x&-x).bit_length()-1
   if j in piv:x^=piv[j]
   else:piv[j]=x;break
  else:
   if x>>n:return None
 sol=[0]*n
 for j,x in sorted(piv.items(),reverse=True):
  sol[j]=(x>>n)^sum(sol[k] for k in range(j+1,n)if (x>>k)&1)%2
 return sol

def fs(a,b,c,d,e,f):
 # a,b,c,d,e,f Ising indices 0,1,2.
 if a==b==c==2:return (e*f)%2 # magnitude1/sqrt2
 if a!=2 and b==2 and c!=2:return a*c%2
 if a==2 and b!=2 and c==2:return b*d%2
 return 0

def build():
 R=product(ng2(0),cyclic(4));n=len(R)
 sigma=[]
 for i,a in itertools.product(range(3),range(4)):
  sigma.append(4*((i+a)%2)+(-a)%4 if i<2 else 8+(2-a)%4)
 assert all(sigma[sigma[i]]==i for i in range(n))
 assert all(R[i][j][k]==R[sigma[i]][sigma[j]][sigma[k]]for i,j,k in itertools.product(range(n),repeat=3))
 labels=[(i,j,k)for i,j,k in itertools.product(range(n),repeat=3)if R[i][j][k]];ix={x:i for i,x in enumerate(labels)};nv=len(labels)+n;rows=[]
 def eq(keys,rhs,signs=None):
  rows.append(([ix[k]if isinstance(k,tuple)else len(labels)+k for k in keys],rhs,signs or [1]*len(keys)))
 for i in range(n):eq([(0,i,i)],0);eq([(i,0,i)],0)
 for a,b,c in itertools.product(range(n),repeat=3):
  for e in range(n):
   if not R[a][b][e]:continue
   for d in range(n):
    if not R[e][c][d]:continue
    for f in range(n):
     if not R[b][c][f]or not R[a][f][d]:continue
     exp=fs(*(x//4 for x in [a,b,c,d,e,f]))^fs(*(sigma[x]//4 for x in [a,b,c,d,e,f]))
     eq([(a,b,e),(e,c,d),(b,c,f),(a,f,d)],2*exp,[1,1,-1,-1])
 for i,j,k in labels:eq([(i,j,k),(sigma[i],sigma[j],sigma[k]),i,j,k],0,[1,1,-1,-1,1])
 for i in range(n):eq([i,sigma[i]],0,[1,-1])
 import z3
 X=[z3.BitVec('x'+str(i),2)for i in range(nv)];solver=z3.SolverFor('QF_BV')
 for inds,rhs,signs in rows:solver.add(sum(sign*X[j]for j,sign in zip(inds,signs))==rhs)
 result=solver.check();sol=[solver.model().eval(x,model_completion=True).as_long()for x in X]if result==z3.sat else None
 print('labels',len(labels),'equations',len(rows),'sol',sol is not None)
 if sol is not None:
  assert all(sum(sign*sol[j]for j,sign in zip(inds,signs))%4==rhs for inds,rhs,signs in rows)
  data={'tensor':R,'automorphism':sigma,'tensorator_labels':labels,'tensorator_sign_exponents':sol[:len(labels)],'square_coherence_sign_exponents':sol[len(labels):],'equations':len(rows)}
  (Path(__file__).parent/'ising_action_mod4.json').write_text(json.dumps(data)+'\n')
 return sol
if __name__=='__main__':build()
