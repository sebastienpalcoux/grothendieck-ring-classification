"""General-size finite solver for the existing involution anti-module criterion.
The equations and coefficient bounds are exactly those in involution_module.py;
only the finite enumeration backend and allowed fixed-block size change.
"""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/"work"),str(ROOT/"sources")]
from common import *
from signed_pb import FiniteProblem
import z3,itertools,time,collections
def enumerate_anti(R,g,timeout=10000,max_seconds=90):
 n=len(R);assert all(R[i][j]==R[j][i]for i in range(n)for j in range(n));du=[next(j for j in range(n)if R[i][j][0])for i in range(n)]
 assert R[g][g]==[1]+[0]*(n-1)
 fixed=[i for i in range(n)if R[g][i][i]];f=len(fixed)
 if not f:return {'outcome':'not_applicable','reason':'no fixed objects'}
 vals={};bounds=[];mapping={};seen=set()
 for i,a,b in itertools.product(range(1,n),range(f),range(f)):
  if (i,a,b)in seen:continue
  orbit={(i,a,b),(du[i],b,a)};seen|=orbit;bound=R[i][fixed[a]][fixed[b]];assert all(R[j][fixed[x]][fixed[y]]==bound for j,x,y in orbit)
  if not bound:continue
  ix=len(bounds);bounds.append(bound)
  for t in orbit:mapping[t]=ix
 def ent(i,a,b):
  if i==0:return -1 if a==b else None
  return mapping.get((i,a,b))
 eqs=set()
 for i,j,a,b in itertools.product(range(1,n),range(1,n),range(f),range(f)):
  row=collections.Counter()
  for h in range(f):
   x,y=ent(i,a,h),ent(j,h,b)
   if x is None or y is None:continue
   if x==y and x>=0 and bounds[x]==1:x=y=-1
   row[tuple(sorted((x,y)))]+=1
  for k in range(n):
   x=ent(k,a,b)
   if x is not None:row[tuple(sorted((-1,x)))]-=R[i][j][k]
  q=tuple(sorted((m,c)for m,c in row.items()if c))
  if q:eqs.add(q)
 # Reuse the exact Boolean states / weighted-equality encoder.
 P=object.__new__(FiniteProblem);P.states=[];P.s=z3.SolverFor('QF_FD');P.s.set(timeout=timeout)
 for k,b in enumerate(bounds):
  if b==1:
   neg=z3.Bool(f'm{k}');states={-1:neg,1:z3.Not(neg)}
  else:
   pos,neg=z3.Bools(f'mp{k} mn{k}');P.s.add(z3.Not(z3.And(pos,neg)));states={-2:neg,2:pos,0:z3.Not(z3.Or(pos,neg))}
  P.states.append(states)
 for eq in eqs:
  weights=[];constant=0
  for (a,b),co in eq:
   if a==b==-1:constant+=co;continue
   if a==b and bounds[a]==1:constant+=co;continue
   if a==b:weights.append((z3.Or(P.states[a][-2],P.states[a][2]),co*4));continue
   aa={1:z3.BoolVal(True)}if a==-1 else P.states[a];bb={1:z3.BoolVal(True)}if b==-1 else P.states[b]
   for x,cx in aa.items():
    for y,cy in bb.items():
     if x*y:weights.append((z3.And(cx,cy),co*x*y))
  positive=[];rhs=-constant
  for cond,w in weights:
   if w<0:positive.append((z3.Not(cond),-w));rhs-=w
   else:positive.append((cond,w))
  P.s.add(z3.PbEq(positive,rhs))
 t=time.time();branches=[];allms=[]
 while time.time()-t<max_seconds:
  result=P.check()
  if result==z3.unsat:return {'complete':True,'fixed':fixed,'branches':branches,'seconds':time.time()-t}
  if result!=z3.sat:return {'complete':False,'reason':str(result),'fixed':fixed,'branches':branches,'seconds':time.time()-t}
  vv=P.values();T=[[[int(a==b)if i==0 else vv[mapping[i,a,b]]if (i,a,b)in mapping else 0 for b in range(f)]for a in range(f)]for i in range(n)]
  A=[np.array(x,dtype=np.int64)for x in T]
  assert all(np.array_equal(A[i]@A[j],sum((R[i][j][k]*A[k]for k in range(n)),np.zeros((f,f),dtype=np.int64)))for i,j in itertools.product(range(n),repeat=2))
  gauges=set()
  for signs in itertools.product([-1,1],repeat=f):
   v=[None]*len(bounds)
   for (i,a,b),ix in mapping.items():
    val=T[i][a][b]*signs[a]*signs[b]
    assert v[ix]is None or v[ix]==val
    v[ix]=val
   gauges.add(tuple(v))
  for v in gauges:P.s.add(z3.Not(z3.And([P.states[k][v[k]]for k in range(len(v))])))
  branches.append(T)
 return {'complete':False,'reason':'total time','fixed':fixed,'branches':branches,'seconds':time.time()-t}

if __name__=='__main__':
 C=json.load(open(ROOT/'work/verification_corpus.json'));rid=sys.argv[1];g=int(sys.argv[2]);r=enumerate_anti(C['tensors'][rid],g)
 (Path(__file__).parent/f'anti_{rid}_{g}.json').write_text(json.dumps(r,separators=(',',':'))+'\n')
 print(rid,g,r['complete'],len(r['branches']),r['seconds'],flush=True)
