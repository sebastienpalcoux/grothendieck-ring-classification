"""Parity-coherence V4 equivariantization of TY(C_p), p odd.
Independent tensor constructor: even part Rep(D_{2p} x C2), one odd simple.
The action and existence proof are in projective_ty.md.
"""
from pathlib import Path
import sys,json,itertools,hashlib
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'sources')]
from complete_models import generalized_dihedral
from positive_models import cyclic,product
from match_models import based_iso
from oriented_signed import validate_general

def constructor(p):
 assert p%2==1 and p>=3
 E=product(generalized_dihedral((p,)),cyclic(2));r=len(E);n=r+1
 dims=[1]*4+[2]*(r-4)
 T=[[[0]*n for _ in range(n)] for _ in range(n)]
 for i,j,k in itertools.product(range(r),repeat=3):T[i][j][k]=E[i][j][k]
 for i in range(r):T[i][r][r]=T[r][i][r]=dims[i];T[r][r][i]=dims[i]
 validate_general(T)
 # The multiplier beta((a,b),(c,d))=(-1)^(b*c) satisfies the cocycle equation.
 G=list(itertools.product(range(2),repeat=2));add=lambda a,b:tuple(x^y for x,y in zip(a,b));beta=lambda a,b:(-1)**(a[1]*b[0])
 for a,b,c in itertools.product(G,repeat=3):assert beta(a,b)*beta(add(a,b),c)==beta(b,c)*beta(a,add(b,c))
 # beta's alternating form is nondegenerate: unique projective irrep has dimension2.
 assert all(any(beta(a,b)!=beta(b,a)for b in G)for a in G[1:])
 return T

def main():
 c=json.load(open(ROOT/'work/verification_corpus.json'));T=constructor(5)
 matches=[]
 for rid in [r['id'] for r in json.load(open(ROOT/'results/unresolved.json'))]:
  p=based_iso(c['tensors'][rid],T)
  if p is not None:
   matches.append({'id':rid,'status':'unitarily_realized','model':'Parity-twisted V4 equivariantization of TY(C5)','tensor':T,'basis_map_source_to_model':p,'parameters':{'A':'C5','chi':'exp(2*pi*i*a*b/5)','tau':'1/sqrt(5)','G':'C2 x C2','action':'(a,b) acts by a-th power of inversion','coherence':'eta(g,h)_m=(-1)^(g[1]*h[0]); eta(g,h)_x=1 for x in C5'},'proof':'phase2/weak_integral/projective_ty.md','reference':'Gelaki-Naidu-Nikshych arXiv:0905.3117 Section4: orthogonal action on TY; explicit parity 2-cocycle modification'})
 print([(x['id'],x['basis_map_source_to_model']) for x in matches])
 (Path(__file__).parent/'models.json').write_text(json.dumps(matches,indent=2)+'\n')
if __name__=='__main__':main()
