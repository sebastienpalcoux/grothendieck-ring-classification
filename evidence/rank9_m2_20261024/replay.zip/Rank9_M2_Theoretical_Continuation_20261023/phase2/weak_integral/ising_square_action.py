"""Exact sign-coherence equations for a candidate C2 action on Ising x Vec(C4)."""
import sys,json,itertools
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT/'sources')]
from positive_models import ng2,cyclic,product
from oriented_signed import validate_general
from match_models import based_iso

def gauss(rows,n):
 piv={}
 for co,rhs in rows:
  x=sum(1<<a for a in co) | (int(rhs)<<n)
  while x&((1<<n)-1):
   j=(x&-x).bit_length()-1
   if j in piv:x^=piv[j]
   else:piv[j]=x;break
  else:
   if x>>n:return None
 sol=[0]*n
 for j,x in sorted(piv.items(),reverse=True):
  sol[j]=(x>>n)^sum(sol[k] for k in range(j+1,n)if (x>>k)&1)%2
 return sol

def fs(a,b,c,d,e,f):
 # a,b,c,d,e,f Ising indices 0,1,2.
 if a==b==c==2:return (e*f)%2 # magnitude1/sqrt2
 if a!=2 and b==2 and c!=2:return a*c%2
 if a==2 and b!=2 and c==2:return b*d%2
 return 0

def build():
 R=product(ng2(0),ng2(0));n=len(R)
 sigma=[]
 for i,j in itertools.product(range(3),repeat=2):
  flip=(i==2)^(j==2)
  act=lambda k:1-k if flip and k<2 else k
  sigma.append(3*act(j)+act(i))
 assert all(sigma[sigma[i]]==i for i in range(n))
 assert all(R[i][j][k]==R[sigma[i]][sigma[j]][sigma[k]]for i,j,k in itertools.product(range(n),repeat=3))
 labels=[(i,j,k)for i,j,k in itertools.product(range(n),repeat=3)if R[i][j][k]];ix={x:i for i,x in enumerate(labels)};nv=len(labels)+n;rows=[]
 def eq(keys,rhs):
  S=set()
  for k in keys:
   j=ix[k]if isinstance(k,tuple)else len(labels)+k
   if j in S:S.remove(j)
   else:S.add(j)
  rows.append((S,rhs))
 for i in range(n):eq([(0,i,i)],0);eq([(i,0,i)],0)
 for a,b,c in itertools.product(range(n),repeat=3):
  for e in range(n):
   if not R[a][b][e]:continue
   for d in range(n):
    if not R[e][c][d]:continue
    for f in range(n):
     if not R[b][c][f]or not R[a][f][d]:continue
     exp=fs(*(x//3 for x in [a,b,c,d,e,f]))^fs(*(sigma[x]//3 for x in [a,b,c,d,e,f]))^fs(*(x%3 for x in [a,b,c,d,e,f]))^fs(*(sigma[x]%3 for x in [a,b,c,d,e,f]))
     assert sum(all(x//3==2 for x in [a,b,c])for _ in [0])+sum(all(x%3==2 for x in [a,b,c])for _ in [0]) == int(all(sigma[x]//3==2 for x in [a,b,c]))+int(all(sigma[x]%3==2 for x in [a,b,c]))
     eq([(a,b,e),(e,c,d),(b,c,f),(a,f,d)],exp)
 for i,j,k in labels:eq([(i,j,k),(sigma[i],sigma[j],sigma[k]),i,j,k],0)
 for i in range(n):eq([i,sigma[i]],0)
 sol=gauss(rows,nv)
 print('labels',len(labels),'equations',len(rows),'sol',sol is not None)
 if sol is not None:
  assert all(sum(sol[j]for j in co)%2==rhs for co,rhs in rows)
  data={'tensor':R,'automorphism':sigma,'tensorator_labels':labels,'tensorator_sign_exponents':sol[:len(labels)],'square_coherence_sign_exponents':sol[len(labels):],'equations':len(rows)}
  (Path(__file__).parent/'ising_square_action.json').write_text(json.dumps(data)+'\n')
 return sol
if __name__=='__main__':build()

def equivariant(data,coherence_shift=(0,0)):
 import sympy as s
 R=data['tensor'];sg=data['automorphism'];n=len(R);t={tuple(l):v for l,v in zip(data['tensorator_labels'],data['tensorator_sign_exponents'])}
 c=[v^(coherence_shift[0]*int(i//3==2))^(coherence_shift[1]*int(i%3==2))for i,v in enumerate(data['square_coherence_sign_exponents'])]
 assert all(c[i]==c[sg[i]]for i in range(n))
 labels=[];seen=set()
 for a in range(n):
  if a in seen:continue
  A=sorted({a,sg[a]});seen.update(A)
  if len(A)==1:
   for sign in [1,-1]:labels.append({'orbit':A,'u':sign*(s.I if c[a]else 1)})
  else:labels.append({'orbit':A,'u':0})
 m=len(labels);T=[[[0]*m for _ in range(m)]for _ in range(m)]
 for i,X in enumerate(labels):
  for j,Y in enumerate(labels):
   for k,Z in enumerate(labels):
    z=Z['orbit'][0];dim=sum(R[a][b][z]for a in X['orbit']for b in Y['orbit'])
    if len(Z['orbit'])==1:
     tr=sum(X['u']*Y['u']*((-1)**t[a,b,z])*R[a][b][z]for a in X['orbit']for b in Y['orbit']if sg[a]==a and sg[b]==b and R[a][b][z])
     v=s.simplify((s.Integer(dim)+s.sympify(tr)/Z['u'])/2);assert v.is_Integer and v>=0,(i,j,k,v)
     T[i][j][k]=int(v)
    else:T[i][j][k]=dim
 validate_general(T)
 return T,[{'orbit':x['orbit'],'equivariant_scalar':str(x['u'])}for x in labels],c

if __name__=='__main__':
 data=json.load(open(Path(__file__).parent/'ising_square_action.json'));C=json.load(open(ROOT/'work/verification_corpus.json'));out=[]
 for shift in [(0,0),(1,1)]:
  T,labs,ce=equivariant(data,shift);print('m',max(x for M in T for row in M for x in row))
  for r in json.load(open(ROOT/'results/unresolved.json')):
   p=based_iso(C['tensors'][r['id']],T)
   if p is not None:
    z={'id':r['id'],'status':'unitarily_realized','model':'Boson-twisted swap equivariantization of Ising x Ising','tensor':T,'basis_map_source_to_model':p,'parameters':{'base':'Ising x Ising','action':'X maps to (psi x psi)^total_parity swap(X)','action_certificate':'phase2/weak_integral/ising_square_action.json','coherence_shift':shift,'coherence_exponents':ce,'equivariant_labels':labs},'proof':'phase2/weak_integral/ising_square_action.md'};out.append(z);print(r['id'],p)
 (Path(__file__).parent/'ising_square_models.json').write_text(json.dumps(out,indent=2)+'\n')
