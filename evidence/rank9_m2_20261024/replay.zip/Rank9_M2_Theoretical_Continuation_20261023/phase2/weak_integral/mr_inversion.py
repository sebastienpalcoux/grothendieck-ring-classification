"""Closed-form inversion action on Vec_C16^omega preserving the MR boson.

Every certificate equation is checked exactly; no solver is required.
"""
import itertools,json
from pathlib import Path
n=16;p=2;mod=16
w=lambda a,b,c:(p*a*((b+c)//n))%n
M=[[(-p*a*int(b>0))%n for b in range(n)]for a in range(n)];C=[0]*n
assert all(M[0][a]==M[a][0]==0 for a in range(n))
assert all((M[a][b]+M[(a+b)%n][d]-M[b][d]-M[a][(b+d)%n]+w(a,b,d)-w(-a%n,-b%n,-d%n))%16==0 for a,b,d in itertools.product(range(n),repeat=3))
assert all((M[a][b]+M[-a%n][-b%n]-C[a]-C[b]+C[(a+b)%n])%16==0 for a,b in itertools.product(range(n),repeat=2))
assert all((M[8][-a%n]-M[-a%n][8]-14*a)%16==0 for a in range(n));assert M[8][8]==C[8]
assert all((2*7*a+2*a)%16==0 for a in range(n)) # central square
assert (7*8)%16==8 # pointed self-braiding is -1
(Path(__file__).parent/'mr_inversion.json').write_text(json.dumps({'tensorator_mod16':M,'square_coherence_mod16':C,'boson_equivariant_scalar_exponent_mod32':0,'central_boson_character_parameter':7,'formula':'mu(a,b)=-2*a*int(b>0) mod16; c(a)=0'},indent=2)+'\n')
print('Closed-form inversion action: all exact coherence and central-lift checks passed.',flush=True)
