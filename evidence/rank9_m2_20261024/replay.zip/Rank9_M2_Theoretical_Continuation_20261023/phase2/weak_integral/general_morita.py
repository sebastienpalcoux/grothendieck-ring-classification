from general_anti import *
from module_dual_gram import module_matrices,system as partial_system
from full_morita_gram import full_gram,first_columns,system as full_system
from higher_traces import farkas,check_farkas
from rings import Characters

def solve(rid,g):
 C=json.load(open(ROOT/'work/verification_corpus.json'));R=C['tensors'][rid]
 try:a=json.load(open(Path(__file__).parent/f'anti_{rid}_{g}.json'))
 except FileNotFoundError:a=enumerate_anti(R,g);(Path(__file__).parent/f'anti_{rid}_{g}.json').write_text(json.dumps(a)+'\n')
 if not a['complete']:return {'id':rid,'g':g,'outcome':'incomplete_anti','data':a}
 ar=Characters(R).fp();results=[]
 for bi,TT in enumerate(a['branches']):
  T=[sum(m,[])for m in TT];labels,M=module_matrices(R,g,a['fixed'],T);G=full_gram(M);rnk=G.rank();nr=len(first_columns(M,g))
  if rnk>nr:results.append({'T':TT,'kind':'rank','rank':rnk,'required':nr});continue
  print(rid,g,'branch',bi,'rank',rnk,'dualrank',nr,flush=True)
  found=None
  for mi in range(1,len(labels)):
   try:ab,meta=partial_system(R,g,a['fixed'],T,mi,ar)
   except TimeoutError:continue
   if ab is None:found={'kind':'partial','module_simple':mi,'reason':meta};break
   A,b=ab
   if len(A[0]):y=farkas(A,b)
   elif any(b):y=[0]*len(b);j=next(j for j,v in enumerate(b)if v);y[j]=-1 if b[j]>0 else 1
   else:y=None
   if y is not None:check_farkas(A,b,y);found={'kind':'partial','module_simple':mi,'meta':meta,'y':y};break
  if found is None:
   try:ab,meta=full_system(R,g,a['fixed'],T)
   except TimeoutError:ab=None;meta={'reason':'timeout'}
   if ab is not None:
    A,b=ab
    if len(A[0]):y=farkas(A,b)
    elif any(b):y=[0]*len(b);j=next(j for j,v in enumerate(b)if v);y[j]=-1 if b[j]>0 else 1
    else:y=None
    if y is not None:check_farkas(A,b,y);found={'kind':'full','meta':meta,'y':y}
  results.append({'T':TT,'certificate':found})
  if found is None:return {'id':rid,'g':g,'outcome':'no_conclusion','branches':results,'total_anti':len(a['branches'])}
 return {'id':rid,'g':g,'outcome':'excluded','branches':results,'total_anti':len(a['branches'])}
if __name__=='__main__':
 rid=sys.argv[1];g=int(sys.argv[2]);t=time.time();r=solve(rid,g);r['seconds']=time.time()-t
 (Path(__file__).parent/f'morita_{rid}_{g}.json').write_text(json.dumps(r)+'\n');print(rid,g,r['outcome'],r['seconds'],flush=True)
