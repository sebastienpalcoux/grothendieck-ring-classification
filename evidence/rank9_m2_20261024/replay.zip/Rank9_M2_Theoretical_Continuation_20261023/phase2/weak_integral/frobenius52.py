"""Exact hypotheses for the dimension104 rank-two bimodule obstruction."""
from pathlib import Path
import sys,json,itertools
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'sources')]
from match_models import based_iso
from oriented_signed import validate_general

def closure(T,gens):
 S={0,*gens}
 while True:
  U=S|{k for i in S for j in S for k,n in enumerate(T[i][j]) if n}
  if U==S:return sorted(S)
  S=U

def group52():
 E=list(itertools.product(range(13),range(4)));idx={x:i for i,x in enumerate(E)}
 M=[[idx[((a+pow(5,b,13)*c)%13,(b+d)%4)]for c,d in E]for a,b in E]
 return E,M

def subgroup_audit():
 E,M=group52();n=len(M);inv=[next(j for j in range(n)if M[i][j]==0)for i in range(n)]
 def gen(S):
  S=set(S)|{0}
  while True:
   U=S|{M[x][y]for x in S for y in S}
   if U==S:return frozenset(S)
   S=U
 subs={frozenset({0})};queue=list(subs)
 for H in queue:
  for g in range(n):
   if g in H:continue
   J=gen(set(H)|{g})
   if J not in subs:subs.add(J);queue.append(J)
 rows=[]
 for H in sorted(subs,key=lambda h:(len(h),sorted(h))):
  classes={frozenset(M[M[g][h]][inv[g]] for g in H)for h in H}
  rows.append({'subgroup':sorted(H),'order':len(H),'number_of_conjugacy_classes':len(classes)})
 rank2=[r for r in rows if r['number_of_conjugacy_classes']==2]
 assert rank2 and all(r['order']==2 for r in rank2)
 H=set(rank2[0]['subgroup']);seen=set();double=[]
 for g in range(n):
  if g in seen:continue
  D={M[M[h][g]][k]for h in H for k in H};seen|=D
  K={h for h in H if M[M[inv[g]][h]][g]in H}
  double.append({'representative':g,'double_coset_size':len(D),'stabilizer_order':len(K),'simple_count':len(K),'simple_dimension':len(H)//len(K)})
 assert sorted(x['double_coset_size']for x in double)==[2]*2+[4]*12
 assert sum(x['simple_count']for x in double)==16
 return {'group':'C13 semidirect_5 C4','group_elements':[list(x)for x in E],'subgroup_classes_count':len(rows),'all_subgroups':rows,'rank_two_module_subgroup':sorted(H),'dual_double_cosets':double,'dual_rank':16,'dual_dimension_type':{'1':4,'2':12},'Schur_multiplier_argument':'Every subgroup has cyclic normal Sylow13 and cyclic quotient of order1,2,4, or is cyclic; H2=0 by coprime Lyndon-Hochschild-Serre.'}

def cert(R,r):
 assert r['dimension_field_degree']==2 and r['global_dimension_coefficients']==['104']
 B=[i for i,cs in enumerate(r['dimension_coefficients'])if len(cs)==1];O=[i for i in range(9)if i not in B]
 dims=[int(r['dimension_coefficients'][i][0])for i in B]
 assert sorted(dims)==[1]*4+[4]*3 and len(O)==2
 grades=[int(i in O)for i in range(9)]
 assert all(grades[k]==grades[i]^grades[j]for i,j,k in itertools.product(range(9),repeat=3)if R[i][j][k])
 T=[[[R[i][j][k]for k in B]for j in B]for i in B];validate_general(T)
 du=[next(j for j in range(7)if T[i][j][0])for i in range(7)]
 ad=closure(T,[k for i in range(7)for k,a in enumerate(T[i][du[i]])if a]);assert ad==list(range(7))
 inv=[i for i,d in enumerate(dims)if d==1];orders=[]
 for a in inv:
  b=0
  for m in range(1,5):
   b=T[b][a].index(1)
   if b==0:orders.append(m);break
 assert sorted(orders)==[1,2,4,4]
 assert all(T[g][i][i]==1 and sum(T[g][i])==1 for g in inv for i,d in enumerate(dims)if d==4)
 return {'kind':'solvable_prime_kernel_rank_two_bimodule','scope':'general_complex_fusion_category','id':r['id'],'neutral_basis':B,'odd_basis':O,'C2_grading':grades,'neutral_dimensions':dims,'neutral_adjoint_basis':ad,'neutral_invertibles':inv,'neutral_invertible_orders':orders,'forced_neutral_category':'Rep(C13 semidirect_5 C4)','odd_module_rank':2,'forced_dual_rank':16,'required_dual_rank':7,'proof':'phase2/weak_integral/frobenius52.md'}

def main():
 U=json.load(open(ROOT/'results/unresolved.json'));C=json.load(open(ROOT/'work/verification_corpus.json'));out=[]
 for r in U:
  if r['global_dimension_coefficients']==['104']:
   out.append({'id':r['id'],'status':'excluded','certificate':cert(C['tensors'][r['id']],r)})
 audit=subgroup_audit()
 (Path(__file__).parent/'frobenius52_certificates.json').write_text(json.dumps({'exclusions':out,'group_audit':audit},indent=2)+'\n')
 print([x['id']for x in out],len(audit['all_subgroups']),audit['dual_rank'])
if __name__=='__main__':main()
