"""Optimizer-free exact replay of larger fixed-block Morita certificates.

Exhaustiveness is replayed via the exact finite anti-module solver, and every
saved rational separating vector is checked after rebuilding its complete domain.
"""
from general_morita import *

def canonical(T):
 f=len(T[0]);return min(tuple(tuple(signs[a]*signs[b]*v[a][b]for a in range(f)for b in range(f))for v in T)for signs in itertools.product([-1,1],repeat=f))

def replay(rid,g):
 C=json.load(open(ROOT/'work/verification_corpus.json'));R=C['tensors'][rid]
 cert=json.load(open(Path(__file__).parent/f'morita_{rid}_{g}.json'))
 assert cert['outcome']=='excluded'
 fresh=enumerate_anti(R,g);assert fresh['complete']
 assert sorted(canonical(T)for T in fresh['branches'])==sorted(canonical(b['T'])for b in cert['branches'])
 ar=Characters(R).fp();counts=collections.Counter()
 for branch in cert['branches']:
  T=[sum(m,[])for m in branch['T']];labs,M=module_matrices(R,g,fresh['fixed'],T)
  if branch.get('kind')=='rank':
   rank=full_gram(M).rank();nr=len(first_columns(M,g))
   assert rank>nr and rank==branch['rank']and nr==branch['required'];counts['rank']+=1;continue
  witness=branch['certificate'];kind=witness['kind'];counts[kind]+=1
  if kind=='partial':ab,meta=partial_system(R,g,fresh['fixed'],T,witness['module_simple'],ar)
  else:assert kind=='full';ab,meta=full_system(R,g,fresh['fixed'],T)
  if ab is None:assert witness['reason']==meta
  else:assert witness['meta']==json.loads(json.dumps(meta));check_farkas(*ab,witness['y'])
 return {'id':rid,'status':'excluded','scope':'all_complex_categorifications','criterion':'complete larger-fixed-block split-involution Morita obstruction','involution':g,'fixed':fresh['fixed'],'complete_branches':len(cert['branches']),'certificate_counts':dict(counts),'certificate':f'phase2/weak_integral/morita_{rid}_{g}.json','proof':'phase2/weak_integral/morita48.md','replayed':True}

if __name__=='__main__':
 out=[replay('R9_2_396',1),replay('R9_2_1265',5)]
 (Path(__file__).parent/'morita48_exclusions.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(out,indent=2))
