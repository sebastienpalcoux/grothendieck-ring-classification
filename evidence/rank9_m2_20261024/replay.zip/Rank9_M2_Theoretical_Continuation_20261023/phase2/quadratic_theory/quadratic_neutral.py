"""Quadratic neutral-block relaxation for globally quadratic quartic rings.

Only neutral restriction columns are retained and only neutral Gram/trace rows
are imposed. Ambient global dimension, codegrees and modular tests are used.
The omitted charged block is not required to have a solution by this relaxation.
"""
import sys,json,math,collections,subprocess,time
from pathlib import Path
from fractions import Fraction as Q
import sympy as s
import quadratic_center as qc

def neutral_base(R):
 n=len(R);ch=qc.Characters(R);f,K,ds,D,pD,emb=ch.fp();assert f.degree()==4
 assert s.Poly(pD).degree()==2
 # Extract the quadratic global-dimension subfield inside the exact quartic field.
 co=list(map(Q,s.Poly(pD).all_coeffs()));assert co[0]==1
 disc=co[1]*co[1]-4*co[2];assert disc.denominator==1
 q=math.prod(int(p)for p,e in s.factorint(disc.numerator).items()if e%2)
 d0=-co[1]/2;d1=Q(math.isqrt(disc.numerator//q),2)
 sq=(D-K.convert(d0))/K.convert(d1);assert sq*sq==K.convert(q)
 def vector(x):
  z=list(map(lambda c:Q(str(c)),qc.ec(x)));return [Q(0)]*(4-len(z))+z
 sv=vector(sq);at=next(i for i in range(3)if sv[i])
 def coords(x):
  v=vector(x);b=v[at]/sv[at];out=[a-b*c for a,c in zip(v,sv)]
  if any(out[:-1]):return None
  return(out[-1],b)
 dims=[coords(d)for d in ds];active=[i for i,d in enumerate(dims)if d is not None];charged=[i for i in range(n)if i not in active]
 assert len(active)==6 and 0 in active and len(charged)==3
 assert all(ch.C[i,j]==0 for i in active for j in charged)
 assert all(R[i][j][k]==0 for i in active for j in active for k in charged)
 DD=coords(D);assert DD==(d0,d1)
 roots=qc.discover_roots(qc.codegree_poly(R),K);assert roots is not None;qc.check_roots(qc.codegree_poly(R),K,roots)
 vals=[coords(D/r)for r in roots];assert all(v is not None for v in vals);counts=collections.Counter(vals)
 dims=[d or(Q(0),Q(0))for d in dims]
 B=ch.C;inv=B.inv();den=math.lcm(*(int(a.q)for a in inv));Ai=[int(a*den)for a in inv]
 assert n*n*max(map(abs,Ai))*max(map(int,B.diagonal()))<2**120
 source=Path(__file__).with_name('quadratic_vectors.cpp');exe=source.with_suffix('')
 if not exe.exists()or exe.stat().st_mtime<source.stat().st_mtime:
  subprocess.run(['g++','-O3','-std=c++17',str(source),'-o',str(exe)],check=True)
 argv=[n,1]+[1]*n+list(map(int,B))+Ai+[den]
 proc=subprocess.run([str(exe)],input=' '.join(map(str,argv)),text=True,capture_output=True,check=True,timeout=120)
 raw=[tuple(map(int,line.split()))[:-1]for line in proc.stdout.splitlines()];raw=[v for v in raw if all(v[i]==0 for i in charged)];cols=[]
 for v in raw:
  z=(sum(v[i]*dims[i][0]for i in active),sum(v[i]*dims[i][1]for i in active))
  if v[0]:
   if z not in counts:continue
  else:
   norm=z[0]*z[0]-q*z[1]*z[1]
   if not norm or not qc.integer_pair(qc.div(DD,z,q),q):continue
   if z[1]and((2*z[0])**2/norm).denominator!=1:continue
  cols.append((v,z))
 premod=len(cols);cols=qc.modular_columns(cols,ch,DD,q)
 # Do not impose Galois closure within this block: a Galois permutation could
 # move a central object to the discarded block. Dropping it is conservative.
 norm=DD[0]*DD[0]-q*DD[1]*DD[1];assert norm.denominator==1
 primes=sorted(map(int,s.factorint(abs(norm.numerator))))
 return {'ch':ch,'q':q,'dims':dims,'D':DD,'counts':counts,'cols':cols,'galois_pairs':[],'primes':primes,'raw_columns':len(raw),'pre_modular_columns':premod,'pre_galois_dimensions':len({z for v,z in cols}),'post_galois_dimensions':len({z for v,z in cols}),'active':active}

def run(rid,height=3):
 start=time.monotonic();old=qc.base;qc.base=neutral_base
 try:A,b,meta=qc.system(qc.inputs(rid),height)
 finally:qc.base=old
 print(rid,'neutral system',len(b),len(A[0]),meta['candidate_columns'],flush=True)
 y,why=qc.exact_separator(A,b,timeout=90)
 out={'id':rid,'kind':'quadratic_neutral_block','outcome':'excluded'if y else 'no_conclusion','metadata':meta,'ray':y,'solver_report':why,'seconds':time.monotonic()-start}
 Path(__file__).with_name(rid+'_neutral_h'+str(height)+'.json').write_text(json.dumps(out,indent=2)+'\n')
 print(rid,out['outcome'],out['seconds'],flush=True)

if __name__=='__main__':run(sys.argv[1],int(sys.argv[2])if len(sys.argv)>2 else 3)
