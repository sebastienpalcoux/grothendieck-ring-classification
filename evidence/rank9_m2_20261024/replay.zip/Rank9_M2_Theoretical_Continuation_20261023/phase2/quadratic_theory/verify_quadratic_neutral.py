"""Exact fresh replay of the quadratic neutral-block exclusions."""
import hashlib,json,time
from pathlib import Path
import quadratic_center as qc
from quadratic_neutral import neutral_base
from verify_quadratic_center import raw_columns_check

def verify(rid):
    start=time.monotonic();here=Path(__file__).resolve().parent
    cert=json.loads((here/f'{rid}_neutral_h3.json').read_text());assert cert['outcome']=='excluded'
    R=qc.inputs(rid);old=qc.base;qc.base=neutral_base
    try:A,b,m=qc.system(R,3)
    finally:qc.base=old
    assert cert['metadata']==json.loads(json.dumps(m))
    y=cert['ray'];assert len(y)==len(b)and all(type(x)is int for x in y)
    inner=[sum(row[j]*c for row,c in zip(A,y))for j in range(len(A[0]))]
    sep=sum(x*c for x,c in zip(b,y));assert min(inner)>=0 and sep<0
    raw=raw_columns_check(R,m['active_neutral_block']);assert raw['columns']==m['raw_columns']
    return {'id':rid,'PASS':True,'scope':'general using signed Galois-pseudo-unitary gate','active_neutral_block':m['active_neutral_block'],'equations':len(b),'variables':len(A[0]),'central_columns':m['candidate_columns'],'bTy':sep,'minimum_ATy':min(inner),'raw_enumeration':raw,'system_sha256':hashlib.sha256(json.dumps({'A':A,'b':b},separators=(',',':')).encode()).hexdigest(),'seconds':time.monotonic()-start}

if __name__=='__main__':
    out=[]
    for rid in ['R9_2_500','R9_2_1235']:
        v=verify(rid);out.append(v);print(json.dumps(v),flush=True)
    Path(__file__).with_name('neutral_verification.json').write_text(json.dumps(out,indent=2)+'\n')
