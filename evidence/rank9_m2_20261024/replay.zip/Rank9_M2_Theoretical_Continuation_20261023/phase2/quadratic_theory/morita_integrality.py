"""Exact involution anti-module + FP dimensions of Morita-dual simples.
General complex scope: no pivotality or pseudo-unitarity assumption.
"""
import sys,json,itertools,time,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'work'),str(ROOT/'sources')]
import numpy as np
import sympy as s
import z3
from signed_pb import FiniteProblem
from rings import Characters
from exact import ec
from module_dual_gram import module_matrices,dual_dimensions

def nonintegral_halves(R):
 f,K,ds,D,pD,emb=Characters(R).fp()
 bad=[];polys={}
 for i,d in enumerate(ds):
  q=K.to_sympy(d/2)
  p=s.Poly(s.minpoly(q))
  if any(not z.is_Integer for z in p.monic().all_coeffs()):
   bad.append(i);polys[str(i)]=list(map(str,p.monic().all_coeffs()))
 return bad,polys

def solve(R,g,bad,timeout=10000,enumerate_all=False):
 n=len(R);assert all(R[i][j]==R[j][i]for i in range(n)for j in range(n));du=[next(j for j in range(n)if R[i][j][0])for i in range(n)]
 assert R[g][g]==[1]+[0]*(n-1)
 fixed=[i for i in range(n)if R[g][i][i]];f=len(fixed)
 if not f:return {'outcome':'not_applicable'}
 bounds=[];mapping={};seen=set()
 for i,a,b in itertools.product(range(1,n),range(f),range(f)):
  if (i,a,b)in seen:continue
  orbit={(i,a,b),(du[i],b,a)};seen|=orbit;bound=R[i][fixed[a]][fixed[b]];assert all(R[j][fixed[x]][fixed[y]]==bound for j,x,y in orbit)
  if not bound:continue
  ix=len(bounds);bounds.append(bound)
  for t in orbit:mapping[t]=ix
 def ent(i,a,b):return (-1 if a==b else None)if i==0 else mapping.get((i,a,b))
 eqs=set()
 for i,j,a,b in itertools.product(range(1,n),range(1,n),range(f),range(f)):
  row=collections.Counter()
  for h in range(f):
   x,y=ent(i,a,h),ent(j,h,b)
   if x is None or y is None:continue
   if x==y and x>=0 and bounds[x]==1:x=y=-1
   row[tuple(sorted((x,y)))]+=1
  for k in range(n):
   x=ent(k,a,b)
   if x is not None:row[tuple(sorted((-1,x)))]-=R[i][j][k]
  q=tuple(sorted((m,c)for m,c in row.items()if c))
  if q:eqs.add(q)
 P=object.__new__(FiniteProblem);P.states=[];P.s=z3.SolverFor('QF_FD');P.s.set(timeout=timeout)
 for k,b in enumerate(bounds):
  if b==1:
   neg=z3.Bool(f'm{k}');states={-1:neg,1:z3.Not(neg)}
  else:
   pos,neg=z3.Bools(f'mp{k} mn{k}');P.s.add(z3.Not(z3.And(pos,neg)));states={-2:neg,2:pos,0:z3.Not(z3.Or(pos,neg))}
  P.states.append(states)
 for eq in eqs:
  weights=[];constant=0
  for (a,b),co in eq:
   if a==b==-1:constant+=co;continue
   if a==b and bounds[a]==1:constant+=co;continue
   if a==b:weights.append((z3.Or(P.states[a][-2],P.states[a][2]),co*4));continue
   aa={1:z3.BoolVal(True)}if a==-1 else P.states[a];bb={1:z3.BoolVal(True)}if b==-1 else P.states[b]
   for x,cx in aa.items():
    for y,cy in bb.items():
     if x*y:weights.append((z3.And(cx,cy),co*x*y))
  positive=[];rhs=-constant
  for cond,w in weights:
   if w<0:positive.append((z3.Not(cond),-w));rhs-=w
   else:positive.append((cond,w))
  P.s.add(z3.PbEq(positive,rhs))
 for a,x in enumerate(fixed):
  if x in bad:P.s.add(P.states[mapping[g,a,a]][-1])
 meta={'involution':g,'fixed':fixed,'forced_swaps':sorted(set(fixed)&set(bad)),'variables':len(bounds),'equations':len(eqs)}
 t=time.time();reps=[]
 while True:
  result=P.check()
  if result==z3.unsat:return {'outcome':'excluded'if not reps else 'complete','witnesses':reps,'seconds':time.time()-t,**meta}
  if result!=z3.sat:return {'outcome':'incomplete','reason':str(result),'witnesses':reps,'seconds':time.time()-t,**meta}
  vv=P.values();T=[[[int(a==b)if i==0 else vv[mapping[i,a,b]]if (i,a,b)in mapping else 0 for b in range(f)]for a in range(f)]for i in range(n)]
  A=[np.array(x,dtype=np.int64)for x in T]
  assert all(np.array_equal(A[i]@A[j],sum((R[i][j][k]*A[k]for k in range(n)),np.zeros((f,f),dtype=np.int64)))for i,j in itertools.product(range(n),repeat=2))
  assert all(T[g][a][a]==-1 for a,x in enumerate(fixed)if x in bad)
  if not enumerate_all:return {'outcome':'no_conclusion','witness':T,'seconds':time.time()-t,**meta}
  reps.append(T)
  # Split-object sign gauges.
  for signs in itertools.product([-1,1],repeat=f):
   alt=vv[:]
   for (i,a,b),ix in mapping.items():alt[ix]=vv[ix]*signs[a]*signs[b]
   P.s.add(z3.Or([z3.Not(P.states[i][v])for i,v in enumerate(alt)]))
  if time.time()-t>timeout/1000:return {'outcome':'incomplete','reason':'total time allowance','witnesses':reps,'seconds':time.time()-t,**meta}

def scan():
 data=json.load(open(ROOT/'work/verification_corpus.json'))['tensors'];rows=json.load(open(ROOT/'results/unresolved.json'));out=[]
 for row in rows:
  R=data[row['id']]
  if row['scalar_character_rank']!=9:continue
  bad,polys=nonintegral_halves(R);reports=[]
  for g in row['invertibles'][1:]:
   if R[g][g]!=[1]+[0]*8:continue
   fixed=[i for i in range(9)if R[g][i][i]]
   if not set(fixed)&set(bad):continue
   z=solve(R,g,bad);reports.append(z)
   if z['outcome']=='excluded':break
  out.append({'id':row['id'],'outcome':'excluded'if any(z['outcome']=='excluded'for z in reports)else 'no_conclusion','nonintegral_half_polynomials':polys,'reports':reports})
  Path(__file__).with_name('morita_integrality_results.json').write_text(json.dumps(out,indent=2)+'\n')
  print(row['id'],out[-1]['outcome'],flush=True)
if __name__=='__main__':scan()
