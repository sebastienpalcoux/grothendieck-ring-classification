import sys,json,time,signal
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from morita_integrality import *
import full_morita_gram as fm
from higher_traces import farkas,check_farkas

def run(rid):
 R=json.load(open(ROOT/'work/verification_corpus.json'))['tensors'][rid];bad,polys=nonintegral_halves(R);out=[]
 for g in range(1,9):
  if R[g][g]!=[1]+[0]*8:continue
  fixed=[i for i in range(9)if R[g][i][i]]
  if not fixed:continue
  z=solve(R,g,bad,timeout=60000,enumerate_all=True)
  print(rid,'g',g,z['outcome'],len(z.get('witnesses',[])),flush=True)
  res={'g':g,'module_result':z,'branches':[]}
  for T in z.get('witnesses',[]):
   TT=[sum(a,[])for a in T]
   try:
    ab,meta=fm.system(R,g,z['fixed'],TT,node_limit=4000000)
    print(' full',meta,flush=True)
    if ab is None:b={'T':T,'excluded':True,'meta':meta}
    else:
     A,v=ab
     if A and len(A[0]):y=farkas(A,v)
     elif any(v):
      y=[0]*len(v);j=next(i for i,x in enumerate(v)if x);y[j]=-1 if v[j]>0 else 1
     else:y=None
     if y is not None:check_farkas(A,v,y)
     b={'T':T,'excluded':y is not None,'meta':meta,'y':y}
    res['branches'].append(b)
    print(' branch excluded',b['excluded'],flush=True)
    if not b['excluded']:break
   except Exception as e:res['error']=str(e);break
  res['excluded']=z['outcome']in ['excluded','complete']and len(res['branches'])==len(z.get('witnesses',[]))and all(b['excluded']for b in res['branches'])
  out.append(res);(HERE/('full_'+rid+'.json')).write_text(json.dumps(out,indent=2)+'\n')
  if res['excluded']:break
 return out
if __name__=='__main__':run(sys.argv[1])
