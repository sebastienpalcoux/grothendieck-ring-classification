"""Fresh integer replay; the LP solver is never called by this verifier."""
import hashlib,itertools,json,math,subprocess,sys,time
from pathlib import Path
from quadratic_center import ROOT,Characters,inputs,system

HERE=Path(__file__).resolve().parent

def raw_columns_check(R,active=None):
    """Independent Python exhaustive box enumeration checks the native enumerator."""
    B=Characters(R).C;n=len(R);inv=B.inv()
    den=math.lcm(*(int(x.q)for x in inv));A=[int(x*den)for x in inv]
    bounds=[math.isqrt(int(B[i,i]))for i in range(n)];bounds[0]=1
    if active is not None:
        for i in range(n):
            if i not in active:bounds[i]=0
    pairs=[(i,j,int(B[i,j]))for i in range(n)for j in range(i+1,n)]
    expected=set()
    for v in itertools.product(*(range(b+1)for b in bounds)):
        if not any(v)or any(v[i]*v[j]>b for i,j,b in pairs):continue
        if sum(v[i]*A[i*n+j]*v[j]for i in range(n)for j in range(n))<=den:
            expected.add(v)
    vals=[n,1]+[1]*n+list(map(int,B))+A+[den]
    p=subprocess.run([str(HERE/'quadratic_vectors')],input=' '.join(map(str,vals)),text=True,capture_output=True,check=True)
    native=[tuple(map(int,line.split()))[:-1]for line in p.stdout.splitlines()]
    if active is not None:native=[v for v in native if all(v[i]==0 for i in range(n)if i not in active)]
    assert len(native)==len(set(native)) and set(native)==expected
    return {'box_size':math.prod(b+1 for b in bounds),'columns':len(expected),'native_matches_independent_python':True}

def verify(rid,height=3):
    start=time.monotonic();path=HERE/f'{rid}_qcenter_h{height}.json';cert=json.loads(path.read_text())
    assert cert['id']==rid and cert['kind']=='joint_quadratic_center' and cert['outcome']=='excluded'
    R=inputs(rid);A,b,m=system(R,height)
    assert json.loads(json.dumps(m))==cert['metadata']
    y=cert['ray'];assert len(y)==len(b)and all(type(t)is int for t in y)
    inner=[sum(A[i][j]*y[i]for i in range(len(b)))for j in range(len(A[0]))]
    sep=sum(t*z for t,z in zip(b,y))
    assert min(inner)>=0 and sep<0
    raw=raw_columns_check(R)
    assert raw['columns']==m['raw_columns']
    payload=json.dumps({'A':A,'b':b},separators=(',',':')).encode()
    return {'id':rid,'height':height,'PASS':True,'scope':'general, using independently verified signed Galois-pseudo-unitary gate','equations':len(b),'variables':len(A[0]),'central_columns':m['candidate_columns'],'bTy':sep,'minimum_ATy':min(inner),'ray_nonzero_entries':sum(bool(t)for t in y),'system_sha256':hashlib.sha256(payload).hexdigest(),'raw_enumeration':raw,'seconds':time.monotonic()-start}

if __name__=='__main__':
    ids=sys.argv[1:]or['R9_2_1569','R9_2_1886'];out=[]
    for rid in ids:
        item=verify(rid);out.append(item);print(json.dumps(item),flush=True)
    (HERE/'verification.json').write_text(json.dumps(out,indent=2)+'\n')
