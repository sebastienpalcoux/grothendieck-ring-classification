"""Sanity controls; exact rational witnesses when recoverable from LP solutions."""
import json,sys
from fractions import Fraction
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
from quadratic_center import ROOT,system,inputs

def check(name,R,height=6):
    A,b,m=system(R,height)
    sol=linprog(np.zeros(len(A[0])),A_eq=np.array(A,dtype=float),b_eq=np.array(b,dtype=float),bounds=(0,None),method='highs')
    out={'name':name,'height':height,'equations':len(b),'variables':len(A[0]),'central_columns':m['candidate_columns'],'lp_success':bool(sol.success),'exact_primal_verified':False}
    if sol.success:
        for bound in [10**3,10**6,10**9]:
            x=[Fraction(float(t)).limit_denominator(bound)for t in sol.x]
            if min(x)>=0 and all(sum(v*t for v,t in zip(row,x))==rhs for row,rhs in zip(A,b)):
                out['exact_primal_verified']=True;out['primal_sparse']=[[i,str(t)]for i,t in enumerate(x)if t];break
        if not out['exact_primal_verified']:
            import sympy as sp
            support=[i for i,t in enumerate(sol.x)if t>1e-8]
            M=sp.Matrix([[row[i]for i in support]for row in A])
            try:
                xx,params=M.gauss_jordan_solve(sp.Matrix(b))
                if not params.rows and all(t>=0 for t in xx):
                    x=[Fraction(0)]*len(A[0])
                    for i,t in zip(support,xx):x[i]=Fraction(str(t))
                    assert all(sum(v*t for v,t in zip(row,x))==rhs for row,rhs in zip(A,b))
                    out['exact_primal_verified']=True;out['primal_sparse']=[[i,str(t)]for i,t in enumerate(x)if t]
            except ValueError:pass
    assert out['lp_success']
    return out

if __name__=='__main__':
    corpus=json.load(open(ROOT/'work/verification_corpus.json'));controls=[]
    for at in [9,44]:
        t=corpus['lower_models'][at];controls.append(check(t['name'],t['tensor']))
    R=np.array(inputs('R9_2_1569'));ix=[0,1,2,6,7,8]
    controls.append(check("R'(2), exact rank-six subring of R9_2_1569",R[np.ix_(ix,ix,ix)].tolist()))
    Path(__file__).with_name('positive_controls.json').write_text(json.dumps(controls,indent=2)+'\n')
    for out in controls:print({k:v for k,v in out.items()if k!='primal_sparse'},flush=True)
