import concurrent.futures,subprocess,sys,json,time
from pathlib import Path
P=Path(__file__).resolve().parent
ids=[114,128,1487,1635,1636,1959,516,1373,1569,1886,1976,1983,500,515,1235]
def run(n):
 rid='R9_2_'+str(n)
 try:
  z=subprocess.run([sys.executable,str(P/'morita_transport.py'),rid],capture_output=True,text=True,timeout=90)
  (P/('transport_'+rid+'.log')).write_text(z.stdout+'\n'+z.stderr)
  return {'id':rid,'returncode':z.returncode,'summary':z.stdout[-3000:]}
 except subprocess.TimeoutExpired as e:
  (P/('transport_'+rid+'.log')).write_text(str(e.stdout)+'\n'+str(e.stderr));return {'id':rid,'outcome':'incomplete','reason':'90-second bounded attempt'}
if __name__=='__main__':
 out=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as ex:
  for z in ex.map(run,ids):
   print(z,flush=True);out.append(z);(P/'transport_batch.json').write_text(json.dumps(out,indent=2)+'\n')
