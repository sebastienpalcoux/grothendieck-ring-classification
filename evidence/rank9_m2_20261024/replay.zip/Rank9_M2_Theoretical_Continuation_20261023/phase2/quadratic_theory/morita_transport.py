"""Reconstruct forced Morita-dual fusion ring from unique action columns.
Only accepts linearly independent actions and unique integral Gram solution.
"""
import sys,json,itertools,collections,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from morita_integrality import *
import full_morita_gram as fm
from match_models import based_iso,coarse

def forced_dual(R,g,fixed,T):
 labels,M=module_matrices(R,g,fixed,[sum(x,[])for x in T]);r=len(labels);G=fm.full_gram(M);cols=fm.first_columns(M,g);counts=collections.Counter(cols);unique=sorted(counts);V=s.Matrix.hstack(*G.columnspace())
 if G.rank()>len(cols):return {'excluded':'rank'}
 cs=[];classes=[]
 for t,c in enumerate(unique):
  can=set()
  for row in unique:can.update(fm.image_candidates(G,V,c,row,node_limit=4000000))
  for x in sorted(can):
   B=s.Matrix(r,r,x)
   if all(B*m==m*B for m in M):cs.append(x);classes.append(t)
 ident=tuple(int(i==j)for i in range(r)for j in range(r));ij=list(itertools.combinations_with_replacement(range(r*r),2))
 A=s.Matrix([[x[i]*x[j]for x in cs]for i,j in ij]+[[int(c==t)for c in classes]for t in range(len(unique))]);b=s.Matrix([int(G[i,j])for i,j in ij]+[counts[c]for c in unique])
 try:sol,pars=A.gauss_jordan_solve(b)
 except ValueError:return {'excluded':'linear_gram'}
 if pars.rows:return {'outcome':'ambiguous_gram','parameters':pars.rows}
 if any(not z.is_Integer or z<0 for z in sol):return {'excluded':'integer_gram','weights':list(map(str,sol))}
 if any(z>1 for z in sol):return {'outcome':'repeated_actions','weights':list(map(str,sol))}
 acts=[cs[i]for i,z in enumerate(sol)if z]
 if ident not in acts:return {'excluded':'missing_unit'}
 acts.remove(ident);acts.insert(0,ident);Q=s.Matrix.hstack(*map(s.Matrix,acts));d=len(acts)
 if Q.rank()!=d:return {'outcome':'dependent_actions'}
 inds=list(Q.T.rref()[1]);Qi=Q.extract(inds,range(d)).inv();Bm=[s.Matrix(r,r,x)for x in acts];N=[]
 for i in range(d):
  row=[]
  for j in range(d):
   v=s.Matrix(list(Bm[i]*Bm[j]));co=Qi*v.extract(inds,[0])
   if Q*co!=v or any(not z.is_Integer or z<0 for z in co):return {'excluded':'nonfusion_product','i':i,'j':j,'coefficients':list(map(str,co))}
   row.append(list(map(int,co)))
  N.append(row)
 assert all(N[0][i]==[int(j==i)for j in range(d)]for i in range(d))
 return {'outcome':'forced_dual','N':N,'actions':[list(x)for x in acts],'module_labels':labels,'gram_weights':list(map(int,sol))}

if __name__=='__main__':
 data=json.load(open(ROOT/'work/verification_corpus.json'));R=data['tensors'][sys.argv[1]];rid=sys.argv[1];out=[]
 bad,_=nonintegral_halves(R)
 for g in range(1,9):
  if R[g][g]!=[1]+[0]*8 or not any(R[g][i][i]for i in range(9)):continue
  z=solve(R,g,bad,timeout=60000,enumerate_all=True);branches=[]
  for T in z.get('witnesses',[]):
   try:
    b=forced_dual(R,g,z['fixed'],T)
    if b.get('outcome')=='forced_dual':
     N=b['N'];matches=[]
     if len(N)==9:
      c=coarse(N)
      for id,A in data['tensors'].items():
       if coarse(A)==c:
        p=based_iso(N,A)
        if p is not None:matches.append({'id':id,'permutation':p})
     b['matches']=matches
    branches.append({'T':T,**b});print(rid,g,b.get('outcome',b.get('excluded')),b.get('matches'),flush=True)
   except Exception as e:branches.append({'error':str(e)});print('ERR',e,flush=True)
  out.append({'g':g,'module_result':z,'branches':branches});(HERE/('transport_'+rid+'.json')).write_text(json.dumps(out,indent=2)+'\n')
