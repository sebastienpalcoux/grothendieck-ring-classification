import concurrent.futures,subprocess,sys,json,time
from pathlib import Path
P=Path(__file__).resolve().parent
ids=[114,128,1487,1635,1636,1959,516,1373,1569,1886,1607,1976,1983,137]
def run(n):
 rid='R9_2_'+str(n)
 try:
  z=subprocess.run([sys.executable,str(P/'quadratic_center.py'),rid,'6'],capture_output=True,text=True,timeout=240)
  (P/('center_'+rid+'.log')).write_text(z.stdout+'\n'+z.stderr)
  return {'id':rid,'returncode':z.returncode,'summary':z.stdout[-3000:]}
 except subprocess.TimeoutExpired as e:
  (P/('center_'+rid+'.log')).write_text(str(e.stdout)+'\n'+str(e.stderr));return {'id':rid,'outcome':'incomplete','reason':'240-second bounded attempt'}
if __name__=='__main__':
 out=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as ex:
  for z in ex.map(run,ids):
   print(z,flush=True);out.append(z);(P/'center_batch.json').write_text(json.dumps(out,indent=2)+'\n')
