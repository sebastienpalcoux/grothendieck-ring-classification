from pathlib import Path
import sys,json
BASE=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(BASE/'work'),str(BASE/'sources')]
import group48_models as m
OUT=Path(__file__).parent
m.save=lambda name,data:(OUT/name).write_text(json.dumps(data,indent=2)+'\n')
m.main()
