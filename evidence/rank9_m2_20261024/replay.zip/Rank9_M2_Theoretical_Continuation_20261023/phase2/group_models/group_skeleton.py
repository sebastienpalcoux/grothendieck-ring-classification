from pathlib import Path
import sys,json,collections,time
BASE=Path(__file__).resolve().parents[2];sys.path[:0]=[str(BASE/'work'),str(BASE/'sources')]
from group_scan import subgroups,rank_est
from group_theoretical import permutation_group,subgroup

def skeleton(G,H):
 inv=[x.index(0)for x in G];seen=set();out=[];H=set(H)
 for z in range(len(G)):
  if z in seen:continue
  D={G[G[a][z]][b]for a in H for b in H};seen|=D
  K=sorted(a for a in H if G[G[inv[z]][a]][z]in H)
  classes=[];used=set()
  for x in K:
   if x in used:continue
   C={G[G[a][x]][inv[a]]for a in K};classes.append(len(C));used|=C
  out.append({'z':z,'double_coset_size':len(D),'stabilizer':K,'classes':classes})
 return out

def main():
 out=[]
 _,A5=permutation_group(5,True)
 _,S5=permutation_group(5)
 for name,G in [('S5',S5),('A5xC2',[[2*A5[a//2][b//2]+((a%2)^(b%2))for b in range(120)]for a in range(120)])]:
  inv=[x.index(0)for x in G];seen=set()
  for H0 in subgroups(G):
   H=sorted(H0)
   if tuple(H)in seen:continue
   seen|={tuple(sorted(G[G[a][h]][inv[a]]for h in H))for a in range(len(G))}
   ss=skeleton(G,H);rank=sum(len(a['classes'])for a in ss)
   print(name,len(H),rank,[(len(x['stabilizer']),len(x['classes']))for x in ss],flush=True)
   out.append({'group':name,'H':H,'rank':rank,'skeleton':ss})
 (Path(__file__).parent/'skeleton120.json').write_text(json.dumps(out,indent=2))
if __name__=='__main__':main()
