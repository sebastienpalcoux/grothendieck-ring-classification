"""Bounded exact mod-two cohomology test for an A4-invariant pointed twist.
We test H^2(A4,V*) -> H^2(A4,C*) by evaluation at the fixed vector.
A passing cocycle would give an explicit semidirect-product 3-cocycle.
A failing test only rules out this cohomological construction.
"""
import json,itertools
from pathlib import Path
P=Path(__file__).parent
# Bit coordinates e1,e2,e3; fixed vector c=(1,1,1).
V=range(8)
def rot(x):return ((x&1)<<1)|((x&2)<<1)|((x&4)>>2)
def trans(x):return x^(7 if ((x&1)^((x>>1)&1)) else 0)
def comp(a,b):return tuple(a[b[x]] for x in V)
one=tuple(V);r=tuple(rot(x) for x in V);u=tuple(trans(x) for x in V)
H=[one];front=[one]
while front:
 a=front.pop()
 for b in [r,u]:
  c=comp(a,b)
  if c not in H:H.append(c);front.append(c)
assert len(H)==12
ix={a:i for i,a in enumerate(H)};mul=[[ix[comp(a,b)]for b in H]for a in H]
inv=[next(j for j in range(12)if mul[i][j]==0)for i in range(12)]
def dot(a,b):return(a&b).bit_count()%2
def act(h,m):
 # h acts on V* by inverse transpose.
 return sum(dot(m,H[inv[h]][1<<j])<<j for j in range(3))
vs=[(a,b,j)for a in range(1,12)for b in range(1,12)for j in range(3)]
vi={t:i for i,t in enumerate(vs)};n=len(vs)
def coeff(a,b,j):return 0 if a==0 or b==0 else 1<<vi[a,b,j]
rows=[]
for a,b,c,j in itertools.product(range(1,12),range(1,12),range(1,12),range(3)):
 mask=coeff(a,mul[b][c],j)^coeff(mul[a][b],c,j)^coeff(a,b,j)
 for k in range(3):
  if act(a,1<<k)&(1<<j):mask^=coeff(b,c,k)
 rows.append(mask)
ui=ix[u];ri=ix[r];v=comp(comp(r,u),H[inv[ri]]);vi2=ix[v]
assert mul[ui][vi2]==mul[vi2][ui] and ui!=vi2
# Nontrivial projective A4 multiplier iff commutator on normal V4 is -1.
constraint=sum(1<<vi[a,b,j]for a,b in [(ui,vi2),(vi2,ui)]for j in range(3))
rows.append(constraint|(1<<n))
pivots={};consistent=True
for row in rows:
 while row&((1<<n)-1):
  p=(row&((1<<n)-1)).bit_length()-1
  if p in pivots:row^=pivots[p]
  else:pivots[p]=row;break
 else:
  if row>>n:consistent=False;break
out={'group':'A4','module':'dual of natural 3-dimensional F2 representation fixing(1,1,1)','cochain_variables':n,'constraints':len(rows),'rank':len(pivots),'nontrivial_fixed_vector_projective_multiplier_feasible':consistent,'scope':'Only 3-cocycles obtained by cupping the translation crossed homomorphism with H²(A4,V*) are tested.'}
if consistent:
 sol=0
 for p,row in sorted(pivots.items()):
  bit=((row>>n)&1)^((row&sol).bit_count()%2)
  if bit:sol|=1<<p
 beta=[[0]*12 for _ in range(12)]
 for(a,b,j),i in vi.items():beta[a][b]|=((sol>>i)&1)<<j
 assert all(act(a,beta[b][c])^beta[a][mul[b][c]]^beta[mul[a][b]][c]^beta[a][b]==0 for a,b,c in itertools.product(range(12),repeat=3))
 assert dot(7,beta[ui][vi2]^beta[vi2][ui])==1
 out.update({'H_action_permutations':H,'H_multiplication':mul,'H_inverse':inv,'beta':beta,'nontrivial_commutator_pair':[ui,vi2]})
(P/'twisted96_cocycle_lead.json').write_text(json.dumps(out,indent=2)+'\n')
print({k:v for k,v in out.items() if k not in ['H_action_permutations','H_multiplication','H_inverse','beta']})
