LoadPackage("smallgrp");;
SetInfoLevel(InfoWarning,0);;
OUT := "rank9_m2_research/phase2/group_models/gap_models.jsonl";;

KData := function(G,els,H)
 local cls,irr,rows,c,a,j,ii,one;
 cls:=ConjugacyClasses(H); irr:=Irr(H);
 one:=Position(irr,TrivialCharacter(H));irr:=Concatenation([irr[one]],irr{Filtered([1..Length(irr)],j->j<>one)});
 rows:=List(irr,x->List(els,y->0));
 for c in [1..Length(cls)] do
  for a in Elements(cls[c]) do
   ii:=Position(els,a);
   for j in [1..Length(irr)] do rows[j][ii]:=irr[j][c];od;
  od;
 od;
 return rec(H:=H, rows:=rows,degrees:=List(irr,chi->chi[1]));
end;;
Skeleton := function(G,els,H)
 local cosets,dc,z,K,ks,objects,dims,c,r;
 objects:=[];dims:=[];
 for dc in DoubleCosets(G,H,H) do
  z:=Representative(dc);K:=Intersection(H,H^Inverse(z));
  ks:=KData(G,els,K);
  Append(dims,List(ks.degrees,d->d*Index(H,K)));
  Add(objects,rec(z:=z,K:=K,ks:=ks));
 od;
 Sort(dims);return rec(objects:=objects,dims:=dims);
end;;
Fusion := function(G,els,H,ss)
 local n,m,mul,inv,objs,o,z,stab,chi,orb,u,v,x,y,i,j,k,a,b,h,res,tr,cos,rows,R,one,pi;
 n:=Length(els);mul:=List(els,a->List(els,b->Position(els,a*b)));inv:=List(els,a->Position(els,Inverse(a)));
 objs:=[];
 for o in ss.objects do
  z:=Position(els,o.z);stab:=List(Elements(o.K),a->Position(els,a));orb:=List([1..n],x->0);
  for u in List(Elements(H),a->Position(els,a)) do
   for v in List(Elements(H),a->Position(els,a)) do orb[mul[mul[u][z]][inv[v]]]:=u;od;
  od;
  for chi in o.ks.rows do Add(objs,rec(z:=z,stab:=stab,chi:=chi,orb:=orb));od;
 od;
 one:=First([1..Length(objs)],i->objs[i].z=1 and ForAll(Elements(H),a->objs[i].chi[Position(els,a)]=1));
 if one=fail then Error("missing unit");fi;
 objs:=Concatenation([objs[one]],objs{Filtered([1..Length(objs)],j->j<>one)});
 cos:=List(RightTransversal(G,H),x->Position(els,Inverse(x)));
 rows:=[];
 for o in objs do
  Add(rows,List([1..n],x->List([1..n],a->0)));
  for x in [1..n] do
   u:=o.orb[x];if u<>0 then
    for a in [1..n] do rows[Length(rows)][x][a]:=o.chi[mul[mul[inv[u]][a]][u]];od;
   fi;
  od;
 od;
 m:=Length(objs);R:=List([1..m],i->List([1..m],j->List([1..m],k->0)));
 for k in [1..m] do
  z:=objs[k].z;stab:=objs[k].stab;chi:=objs[k].chi;
  for i in [1..m] do for j in [1..m] do
   res:=0;
   for a in stab do
    b:=mul[mul[inv[z]][a]][z];tr:=0;
    for x in cos do
     h:=mul[mul[inv[x]][a]][x];
     if els[h] in H then
      y:=mul[inv[x]][z];
      tr:=tr+rows[i][x][a]*rows[j][y][h];
     fi;
    od;
    res:=res+chi[inv[a]]*tr;
   od;
   res:=res/Length(stab);if not IsInt(res) or res<0 then Error("bad coefficient",res);fi;
   R[i][j][k]:=res;
  od;od;
 od;
 if not ForAll([1..m],i->ForAll([1..m],j->(R[1][i][j]=1 and R[i][1][j]=1 and i=j) or (R[1][i][j]=0 and R[i][1][j]=0 and i<>j)))then Error("unit failed");fi;
 return rec(R:=R,group_table:=List(mul,r->r-1),subgroup:=List(Elements(H),h->Position(els,h)-1));
end;;
patterns:=[
[48,[[1,1,1,1,2,2,2,4,4]]],
[72,[[1,1,1,1,2,4,4,4,4],[1,1,2,2,2,2,3,3,6]]],
[96,[[1,1,1,2,2,2,3,6,6]]],
[120,[[1,1,1,1,2,2,6,6,6]]],
[168,[[1,1,2,3,3,6,6,6,6]]],
[222,[[1,1,2,6,6,6,6,6,6]]],
[336,[[1,1,6,6,6,7,7,8,8]]],
[504,[[1,7,7,7,7,8,9,9,9]]]
];;
for pair in patterns do
 D:=pair[1];if D<>504 then continue;fi; Print("ORDER ",D," groups ",NumberSmallGroups(D),"\n");
 for gid in [157..NumberSmallGroups(D)] do
  G:=SmallGroup(D,gid);els:=Elements(G);if els[1]<>One(G)then Error("identity indexing");fi;
  for hc in ConjugacyClassesSubgroups(G) do
   H:=Representative(hc);
   if NrConjugacyClasses(H)>9 then continue;fi;
   ds:=List(Irr(H),chi->chi[1]);
   if not ForAny(pair[2],p->ForAll(Set(ds),d->Number(ds,x->x=d)<=Number(p,x->x=d)))then continue;fi;
   ss:=Skeleton(G,els,H);
   if not ss.dims in pair[2] then continue;fi;
   Print("CANDIDATE ",D,",",gid," H=",StructureDescription(H)," dims=",ss.dims,"\n");
   ff:=Fusion(G,els,H,ss);
   AppendTo(OUT,"{\"order\":",D,",\"group_id\":",gid,",\"group_name\":\"",StructureDescription(G),"\",\"subgroup_name\":\"",StructureDescription(H),"\",\"group_table\":",ff.group_table,",\"subgroup\":",ff.subgroup,",\"tensor\":",ff.R,"}\n");
  od;
  AppendTo("/workspace/scratch/90f37cc83103/rank9_m2_research/phase2/group_models/scan_finish_coverage.log","COMPLETE_GROUP ",D," ",gid,"\n");
 od;
AppendTo("/workspace/scratch/90f37cc83103/rank9_m2_research/phase2/group_models/scan_finish_coverage.log","ALL_COMPLETE\n");
od;
QUIT;
