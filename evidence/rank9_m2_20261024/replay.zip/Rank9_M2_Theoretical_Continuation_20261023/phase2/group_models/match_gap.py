from pathlib import Path
import json,sys,itertools,collections,hashlib
BASE=Path(__file__).resolve().parents[2];sys.path[:0]=[str(BASE/'work'),str(BASE/'sources')]
from common import coarse,based_iso,digest
OUT=Path(__file__).parent
D=json.load(open(BASE/'work/verification_corpus.json'));by=collections.defaultdict(list)
for rid,R in D['tensors'].items():by[coarse(R)].append((rid,R))
s=(OUT/'gap_models.jsonl').read_text().replace('\\\n','');decoder=json.JSONDecoder();out=[];attempts=[]
while s.strip():
 try:obj,end=decoder.raw_decode(s.lstrip())
 except json.JSONDecodeError:break
 s=s.lstrip()[end:];T=obj.pop('tensor');m=max(v for M in T for r in M for v in r);hits=[]
 if len(T)==9 and m==2:
  for rid,R in by[coarse(T)]:
   p=based_iso(R,T)
   if p is not None:
    model={'id':rid,'model':f"C(SmallGroup({obj['order']},{obj['group_id']}),1,H={obj['subgroup_name']},1)",'tensor':T,'tensor_sha256':digest(T),'basis_map_source_to_model':p,'parameters':obj,'status':'unitarily_realized','reference':'Untwisted H-biequivariant vector bundles on finite G (subgroup algebra bimodules in Vec(G)); exact stabilizer-character convolution.'};out.append(model);hits.append(rid)
 attempts.append({k:v for k,v in obj.items()if k not in['group_table','subgroup']}|{'subgroup':obj['subgroup'],'rank':len(T),'multiplicity':m,'tensor_sha256':digest(T),'matches':hits})
 print(obj['order'],obj['group_id'],obj['group_name'],obj['subgroup_name'],len(T),m,hits)
(OUT/'matches.json').write_text(json.dumps(out,indent=2));(OUT/'attempts.json').write_text(json.dumps(attempts,indent=2));print('TOTAL',len(out),len(set(r['id']for r in out)))
