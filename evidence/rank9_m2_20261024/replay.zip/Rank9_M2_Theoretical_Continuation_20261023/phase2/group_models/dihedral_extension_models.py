"""Exact two-model family Rep(V4 semidirect Dih(A)), |A|=9.

Everything is constructed from explicit groups and Clifford induced characters;
GAP and its SmallGroups catalogue are unnecessary for replay.
"""
from pathlib import Path
import itertools,json,sys
import sympy as s
BASE=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(BASE/'work'),str(BASE/'sources')]
from common import based_iso,digest
OUT=Path(__file__).parent

def model(cyclic):
 t=s.Symbol('t');K=s.QQ.alg_field_from_poly(s.Poly(s.cyclotomic_poly(9,t),t),alias='z9');z=K.unit
 A=list(range(9)) if cyclic else list(itertools.product(range(3),repeat=2))
 zero=0 if cyclic else(0,0)
 def add(a,b):return(a+b)%9 if cyclic else tuple((x+y)%3 for x,y in zip(a,b))
 def neg(a):return(-a)%9 if cyclic else tuple(-x%3 for x in a)
 def q(a):return a%3 if cyclic else a[0]
 def pairing(r,a):return(r*a)%9 if cyclic else 3*sum(x*y for x,y in zip(r,a))%9
 def rot(v):return(v[1],v[0]^v[1])
 def ref(v):return(v[0],v[0]^v[1])
 def act(a,e,v):
  if e:v=ref(v)
  for _ in range(q(a)):v=rot(v)
  return v
 V=list(itertools.product(range(2),repeat=2));els=list(itertools.product(V,A,range(2)));ix={g:i for i,g in enumerate(els)}
 def prod(x,y):
  v,a,e=x;w,b,f=y;u=act(a,e,w)
  return(tuple(x^y for x,y in zip(v,u)),add(a,b if e==0 else neg(b)),e^f)
 G=[[ix[prod(x,y)]for y in els]for x in els]
 assert G[0]==list(range(72)) and [row[0]for row in G]==list(range(72))
 assert all(G[G[i][j]][k]==G[i][G[j][k]]for i,j,k in itertools.product(range(72),repeat=3))
 rows=[[K.one]*72,[K((-1)**e)for v,a,e in els]]
 seen={zero};labels=['1','sign']
 for r in A:
  if r in seen:continue
  seen|={r,neg(r)};labels.append('inflated '+str(r))
  rows.append([K.zero if e else z**pairing(r,a)+z**(-pairing(r,a))for v,a,e in els])
 for sign in(1,-1):
  row=[]
  for v,a,e in els:
   if e==0:val=(3 if v==(0,0)else-1)if q(a)==0 else 0
   else:
    j=next(j for j in range(3)if(q(a)-2*j)%3==0);w=v
    for _ in range((-j)%3):w=rot(w)
    val=sign*((-1)**w[0])
   row.append(K(val))
  rows.append(row);labels.append('orbit3 '+str(sign))
 rows.append([K((3 if v==(0,0)else-1)*(2 if a==zero else-1))if e==0 and q(a)==0 else K.zero for v,a,e in els]);labels.append('orbit6')
 assert len(rows)==9
 # Each row is the explicit inflated or induced group character described above.
 # Orthogonality, degree sum and tensor coefficients are independently exact.
 assert sum(int(row[0].to_list()[0])**2 for row in rows)==72
 assert all(sum((x*y for x,y in zip(a,b)),K.zero)==K(72*int(i==j))for i,a in enumerate(rows)for j,b in enumerate(rows))
 T=[[[0]*9 for j in range(9)]for i in range(9)]
 for i,j,k in itertools.product(range(9),repeat=3):
  c=sum((rows[i][g]*rows[j][g]*rows[k][g]for g in range(72)),K.zero)/K(72);cc=c.to_list()
  assert len(cc)<=1 and(not cc or cc[0].denominator==1 and cc[0]>=0)
  T[i][j][k]=int(cc[0])if cc else 0
 return T,{'A':'C9'if cyclic else'C3 x C3','group_order':72,'group_table':G,'character_labels':labels,'character_field_polynomial':[str(x)for x in s.Poly(s.cyclotomic_poly(9,t),t).all_coeffs()],'character_values':[[[str(x)for x in c.to_list()]for c in row]for row in rows]}

def main():
 C=json.load(open(BASE/'work/verification_corpus.json'));out=[]
 for cyclic,rid,gid in[(True,'R9_2_812',15),(False,'R9_2_813',43)]:
  T,p=model(cyclic);bm=based_iso(C['tensors'][rid],T);assert bm is not None
  rec={'id':rid,'model':f"Rep(V4 semidirect Dih({p['A']}))",'status':'unitarily_realized','small_group':[72,gid],'tensor':T,'tensor_sha256':digest(T),'basis_map_source_to_model':bm,'parameters':p,'reference':'Explicit finite-group representation category. Clifford theory: characters inflated from Dih(A), or induced from V4 semidirect Dih(ker(A->C3)).','verification':'All729structureconstants exact inQ(zeta9), characterorthogonality and dimensions checked, group law associativity checked.'}
  out.append(rec);print(rid,'PASS',bm,flush=True)
 (OUT/'canonical_models.json').write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()
