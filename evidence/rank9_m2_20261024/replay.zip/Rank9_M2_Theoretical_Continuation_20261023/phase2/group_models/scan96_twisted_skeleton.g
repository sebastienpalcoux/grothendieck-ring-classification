LoadPackage("smallgrp");;
OUT:="/workspace/scratch/90f37cc83103/rank9_m2_research/phase2/group_models/twisted96_skeletons.jsonl";;
PrintTo(OUT,"");;
for gid in [1..NumberSmallGroups(96)] do
 G:=SmallGroup(96,gid);
 for hc in ConjugacyClassesSubgroups(G) do
  H:=Representative(hc);
  if Size(H)=12 and IdGroup(H)=[12,3] then
   dcs:=DoubleCosets(G,H,H);sizes:=SortedList(List(dcs,Size));
   if sizes=[12,12,72] then
    ints:=List(dcs,d->Intersection(H,H^Representative(d)));
    AppendTo(OUT,"{\"order\":96,\"group_id\":",gid,",\"group\":\"",StructureDescription(G),"\",\"subgroup\":\"A4\",\"sizes\":",sizes,",\"intersection_orders\":",SortedList(List(ints,Size)),",\"normalizer\":\"",StructureDescription(Normalizer(G,H)),"\"}\n");
   fi;
  elif Size(H)=24 and IdGroup(H)=[24,3] then
   dcs:=DoubleCosets(G,H,H);sizes:=SortedList(List(dcs,Size));
   if sizes=[24,72] then
    ints:=List(dcs,d->Intersection(H,H^Representative(d)));
    AppendTo(OUT,"{\"order\":96,\"group_id\":",gid,",\"group\":\"",StructureDescription(G),"\",\"subgroup\":\"SL2(3)\",\"sizes\":",sizes,",\"intersection_orders\":",SortedList(List(ints,Size)),",\"intersection_group_ids\":",List(ints,IdGroup),"}\n");
   fi;
  fi;
 od;
od;
AppendTo(OUT,"{\"status\":\"complete\",\"groups\":231}\n");
QUIT;
