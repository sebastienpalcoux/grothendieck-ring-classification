"""Four exact rank9 models from a fixed C2 action and odd abelian pullback.

Existence theorem and action transitivity are documented in PULLBACK_MODELS.md.
Tensor-only formulas are checked on the ordinary Rep models as positive controls.
"""
from pathlib import Path
import itertools,json,sys
BASE=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(BASE/'work'),str(BASE/'sources')]
from common import based_iso,digest
OUT=Path(__file__).parent

def quotient(cyclic):
 G=list(range(9))if cyclic else list(itertools.product(range(3),repeat=2))
 def add(a,b):return(a+b)%9 if cyclic else tuple((x+y)%3 for x,y in zip(a,b))
 def neg(a):return(-a)%9 if cyclic else tuple(-x%3 for x in a)
 def grade(a):return a%3 if cyclic else a[1]
 ix={a:i for i,a in enumerate(G)};E=[[[0]*12 for _ in range(12)]for _ in range(12)]
 for i,j in itertools.product(range(9),repeat=2):E[i][j][ix[add(G[i],G[j])]]=1
 for i,j in itertools.product(range(9),range(3)):E[i][9+j][9+(j+grade(G[i]))%3]=E[9+j][i][9+(j+grade(G[i]))%3]=1
 for j,k in itertools.product(range(3),repeat=2):
  ell=(j+k)%3
  for i,g in enumerate(G):
   if grade(g)==ell:E[9+j][9+k][i]=1
  E[9+j][9+k][9+ell]=2
 sigma=[ix[neg(g)]for g in G]+[9,11,10]
 return E,sigma,G

def equivariant(cyclic,xi):
 E,sigma,G=quotient(cyclic);seen=set();objs=[]
 for i in range(12):
  if i in seen:continue
  seen|={i,sigma[i]}
  if sigma[i]==i:
   objs.append({'support':[i],'sign':1});objs.append({'support':[i],'sign':-1})
  else:objs.append({'support':sorted([i,sigma[i]]),'sign':0})
 assert len(objs)==9 and objs[0]=={'support':[0],'sign':1}
 def tau(a,b,c):
  assert a in[0,9]and b in[0,9]and c in[0,9]
  if (a,b,c)==(9,9,0):return xi
  if (a,b,c)==(9,9,9):return 0
  return E[a][b][c]
 T=[[[0]*9 for _ in range(9)]for _ in range(9)]
 for i,j,k in itertools.product(range(9),repeat=3):
  A,B,C=objs[i],objs[j],objs[k];c=C['support'][0]
  dim=sum(E[a][b][c]for a in A['support']for b in B['support'])
  if C['sign']==0:n=dim
  else:
   trace=0
   if A['sign']and B['sign']:trace=A['sign']*B['sign']*C['sign']*tau(A['support'][0],B['support'][0],c)
   assert(dim+trace)%2==0;n=(dim+trace)//2
  assert n>=0;T[i][j][k]=n
 assert all(sum(T[i][j][u]*T[u][k][l]for u in range(9))==sum(T[j][k][u]*T[i][u][l]for u in range(9))for i,j,k,l in itertools.product(range(9),repeat=4))
 return T,{'cyclic':cyclic,'xi':xi,'quotient_tensor':E,'involution':sigma,'equivariant_objects':objs}

def main():
 C=json.load(open(BASE/'work/verification_corpus.json'));out=[]
 for cyclic,xi,rid in[(True,1,'R9_2_812'),(False,1,'R9_2_813'),(True,-1,'R9_2_1396'),(False,-1,'R9_2_1397')]:
  T,p=equivariant(cyclic,xi);bm=based_iso(C['tensors'][rid],T);assert bm is not None
  print(rid,'PASS',bm,flush=True)
  out.append({'id':rid,'model':f"Pulled-back {'LPR-24'if xi==-1 else'Rep(S4)'} action along Dih({'C9'if cyclic else'C3 x C3'})->S3",'status':'unitarily_realized','tensor':T,'tensor_sha256':digest(T),'source_tensor_sha256':digest(C['tensors'][rid]),'basis_map_source_to_model':bm,'verification':{'all_729_source_coefficients_equal':True,'associativity_all_6561_equations':True,'independent_categorical_audit':'phase2/integral_theory/pullback_model_audit.md','proof':'phase2/group_models/PULLBACK_MODELS.md'},'parameters':p,'reference':'LPR2010.10264v5 §4.4 gives unitary rank5 seed; solvable de-equivariantization and pullback theorem in PULLBACK_MODELS.md.'})
 (OUT/'pullback_models.json').write_text(json.dumps(out,indent=2)+'\n')
 (OUT/'pullback_new_models.json').write_text(json.dumps([r for r in out if r['parameters']['xi']==-1],indent=2)+'\n')
if __name__=='__main__':main()
