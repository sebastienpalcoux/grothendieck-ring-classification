"""Package the preserved baseline plus the reproducible theoretical continuation."""
from pathlib import Path
import json,shutil,os,hashlib,zipfile,sys,io
ROOT=Path(__file__).resolve().parents[1];WORK=ROOT.parent
NAME='Rank9_M2_Theoretical_Continuation_20261023'
STAGE=WORK/NAME;BASE=WORK/'Rank9_M2_Established_Methods_20261023'
SKIP={'__pycache__','gap_root','gap_debs','.library_helpers'}
SUFFIX={'.py','.cpp','.md','.json','.g','.tex','.bib'}
def main(checkpoint=False):
 if STAGE.exists():shutil.rmtree(STAGE)
 shutil.copytree(BASE,STAGE)
 (STAGE/'baseline_documents').mkdir()
 for f in ['README.md','HANDOFF.md']:shutil.move(STAGE/f,STAGE/'baseline_documents'/f)
 for directory,dirs,files in os.walk(ROOT/'phase2'):
  dirs[:]=[d for d in dirs if d not in SKIP and not d.startswith('.')]
  for name in files:
   p=Path(directory)/name
   if p.suffix not in SUFFIX:continue
   dest=STAGE/p.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
 S=json.load(open(STAGE/'phase2/results/summary.json'))
 state='In-progress checkpoint'if checkpoint else'Completed research pass'
 (STAGE/'README.md').write_text(f'''# Rank-nine multiplicity-two theoretical continuation

{state}. Exact multiplicity two: **{S['excluded']:,} excluded, {S['modelled']} unitary models, {S['unresolved']} unresolved**, out of 2,083 rings.

This continues the 81 unresolved records of the established-methods pass: {S['new_excluded']} additional general exclusions and {S['new_modelled']} additional unitary models. The 142 multiplicity-one input records are unchanged.

Read **[the research report](phase2/REPORT.md)** first. The current classification is **`phase2/results/ledger.json`**; `phase2/results/unresolved.json` gives the exact remaining profiles. `phase2/accepted.json` explicitly names every accepted addition. The earlier `results/` ledger and its certificates are preserved as the baseline; its original explanatory documents are in `baseline_documents/`.

Install the Python dependencies in `requirements.txt`; C++ certificate enumerators require `g++`. Run `python3 phase2/verify_continuation.py` to check the current partition, source hashes, model maps and accepted replay receipts. Add `--fresh` to rerun the exact exclusion verifiers. Run `python3 phase2/replay_constructors.py` to regenerate the model constructors. The mathematical criteria and their exact replay commands are documented beside the corresponding certificates. The original root `verify.py` replays the baseline and input audit.

No GitHub repository or website has been changed. AI-generated research; independent human verification remains pending.
''')
 (STAGE/'HANDOFF.md').write_text(f'''# Research handoff

{state}: {S['new_excluded']} of the former 81 are newly excluded, {S['new_modelled']} newly modelized, {S['unresolved']} remain unresolved. Cumulative exact-M2 counts: {S['excluded']} / {S['modelled']} / {S['unresolved']} (excluded / unitary model / unresolved).

The continuation ledger is in `phase2/results/`; the original baseline is in `results/`. Do not infer classifications from partial branches, feasible necessary systems, solver limits, model leads, or a signed gate alone. Use only `phase2/accepted.json` and the supporting proofs/replays.

Publication remains deferred. A later online revision should update rank nine, multiplicity two in the ordinary rank/multiplicity order of both repositories and the public GitHub Atlas, preserving the clean display policy. The former private Atlas is out of scope.
''')
 # Preserve every baseline byte; map its two relocated prose-document paths.
 old=STAGE/'manifests/SHA256SUMS.json'
 if old.exists():
  original=json.load(open(old));mapped={('baseline_documents/'+p if p in ['README.md','HANDOFF.md']else p):h for p,h in original.items()}
  assert all(hashlib.sha256((STAGE/p).read_bytes()).hexdigest()==h for p,h in mapped.items())
  old.unlink();(STAGE/'manifests/BASELINE_SHA256SUMS.json').write_text(json.dumps(mapped,indent=2)+'\n')
 hashes={str(p.relative_to(STAGE)):hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(STAGE.rglob('*'))if p.is_file()}
 (STAGE/'SHA256SUMS.json').write_text(json.dumps(hashes,indent=2)+'\n')
 target=WORK/(NAME+'.zip')
 buffer=io.BytesIO()
 with zipfile.ZipFile(buffer,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for p in sorted(STAGE.rglob('*')):
   if p.is_file():z.write(p,str(Path(NAME)/p.relative_to(STAGE)))
 payload=buffer.getvalue()
 with zipfile.ZipFile(io.BytesIO(payload))as z:assert z.testzip()is None
 temporary=WORK/(NAME+'.building.zip');temporary.write_bytes(payload);os.replace(temporary,target)
 assert hashlib.sha256(target.read_bytes()).digest()==hashlib.sha256(payload).digest()
 assert all(hashlib.sha256((STAGE/p).read_bytes()).hexdigest()==h for p,h in hashes.items())
 print(json.dumps({'file':str(target),'bytes':target.stat().st_size,'files':len(hashes)+1,'status':state,'counts':S}))
if __name__=='__main__':main('--checkpoint'in sys.argv)
