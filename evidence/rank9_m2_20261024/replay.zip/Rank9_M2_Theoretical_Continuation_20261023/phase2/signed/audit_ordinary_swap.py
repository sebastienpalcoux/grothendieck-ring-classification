"""Exact supplementary checks accompanying ordinary_swap_audit.md."""
from pathlib import Path
import sys,json,itertools,hashlib
HERE=Path(__file__).resolve().parent;BASE=HERE.parents[1]
sys.path.insert(0,str(BASE/'phase2/models'))
from ordinary_swap import construct

def run():
    R,aux=construct()
    T=json.loads((BASE/'work/verification_corpus.json').read_text())['tensors']['R9_2_1983']
    p=[0,1,3,5,8,7,6,4,2]
    assert all(T[i][j][k]==R[p[i]][p[j]][p[k]]for i,j,k in itertools.product(range(9),repeat=3))
    mu={(0,0):(0,1),(0,1):(1,1),(1,0):(1,-1),(1,1):(0,-1)}
    for i,j in itertools.product(range(2),repeat=2):
        deg,c=mu[i,j];assert mu[i,j^1]==(deg^1,c)
        d,e=mu[i^1,j];f,g=mu[i,j^1];assert d==f and e==-g
        d,e=mu[i^1,j^1];assert d==deg and e==-c
    choices={(a,b,c)for a in(1,3)for b in(0,2)for c in(1,3)if(b+c-a)%4==0};orbit=set()
    for r in range(4):
        a=(1+2*r)%4;uv=[(2+r)%4,(3+r)%4]
        b=next(x for x in uv if x%2==0);c=next(x for x in uv if x%2)
        orbit.add((a,b,c))
    assert orbit==choices
    digest=lambda N:hashlib.sha256(json.dumps(N,separators=(',',':')).encode()).hexdigest()
    return {'id':'R9_2_1983','verdict':'APPROVED','status':'unitarily_realized',
            'source_sha256':digest(T),'model_sha256':digest(R),'basis_map_source_to_model':p,
            'fresh_constructor_validation':'PASS','full_tensor_coefficients_checked':729,
            'forgetful_tensor_identities_checked':486,'pointed_balancing_checks':4,
            'pointed_right_linearity_checks':4,'pointed_swap_square_sign_checks':4,
            'Y_square_normalization_cases':len(choices),'theory_audit':'ordinary_swap_audit.md'}

if __name__=='__main__':
    out=run();(HERE/'ordinary_swap_audit.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
