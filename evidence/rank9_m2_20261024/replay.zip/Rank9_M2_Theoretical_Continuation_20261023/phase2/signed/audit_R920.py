"""Independent finite-hypothesis replay for the folded SO(3) obstruction.

Categorical arguments are audited separately in R920_audit.md.  This script
uses the elementary SU(2) fusion formula, not the model constructor.
"""
from pathlib import Path
import collections, hashlib, json, math

HERE = Path(__file__).resolve().parent
BASE = HERE.parents[1]
N = json.loads((BASE/'work/verification_corpus.json').read_text())['tensors']['R9_2_920']
source_to_folded = [0, 1, 3, 7, 5, 6, 4, 8, 2]

def su2(a,b,c,k=34):
    return int(abs(a-b)<=c<=min(a+b,2*k-a-b) and (a+b+c)%2==0)

parent = [[[su2(2*a,2*b,2*c) for c in range(18)] for b in range(18)] for a in range(18)]
folded = [[[parent[a][b][c]+parent[a][b][17-c] for c in range(9)] for b in range(9)] for a in range(9)]
assert all(N[a][b][c] == folded[source_to_folded[a]][source_to_folded[b]][source_to_folded[c]]
           for a in range(9) for b in range(9) for c in range(9))
assert all(folded[1][j] == ([int(c==1) for c in range(9)] if j==0 else
                           [int(c==j-1)+int(c==j)+int(c==j+1) for c in range(9)] if j<8 else
                           [int(c==7)+2*int(c==8) for c in range(9)]) for j in range(9))
# Verify the entire quotient map on all parent products, not merely its restriction.
orbit = [min(a,17-a) for a in range(18)]
for a in range(18):
    for b in range(18):
        row=[0]*9
        for c,m in enumerate(parent[a][b]): row[orbit[c]] += m
        assert row == folded[orbit[a]][orbit[b]]
v=[1]+[0]*8
invariants=[]
for power in range(5):
    invariants.append(v[0])
    v=[sum(v[j]*folded[1][j][c] for j in range(9)) for c in range(9)]
assert invariants == [1,0,1,1,3]
assert [a for a in range(18) if orbit[a]==0] == [0,17]
assert parent[1][1][1] == 1

# Riordan dimension identity used to identify the full TL p2 corner.
# Independently count noncrossing partitions without singleton blocks via
# decomposition at the block containing the first point.
riordan=[1]
for n in range(1,17):
    total=0
    # For a block of size k>=2, its k gaps contain smaller independent partitions.
    for k in range(2,n+1):
        coeff=[1]+[0]*(n-k)
        for _ in range(k):
            coeff=[sum(coeff[j]*riordan[m-j] for j in range(m+1)) for m in range(n-k+1)]
        total += coeff[n-k]
    riordan.append(total)
for n in range(17):
    assert sum(math.comb(n,j)*riordan[j] for j in range(n+1)) == math.comb(2*n,n)//(n+1)

gate=json.loads((HERE/'gate_verification_R9_2_920.json').read_text())
assert gate['status']=='PASS' and gate['independent_completeness']=='UNSAT'
assert gate['conclusion']=='galois_pseudo_unitarity'

out={
    'id':'R9_2_920','verdict':'APPROVED','scope':'general complex fusion categories',
    'source_sha256':hashlib.sha256(json.dumps(N,separators=(',',':')).encode()).hexdigest(),
    'categorical_audit':'R920_audit.md','hypothesis_replay':'PASS',
    'source_to_folded':source_to_folded,'source_generator_path':[0,1,8,2,6,4,5,3,7],
    'structure_constants_checked':729,'parent_quotient_products_checked':324,
    'low_invariant_dimensions':invariants,'unit_preimages_parent_indices':[0,17],
    'riordan_dimensions_checked':riordan,
    'pseudo_unitary_gate':'gate_verification_R9_2_920.json',
    'morphism_generation_assumed':False,'unitarity_assumed':False,
    'additional_assumptions':[],
    'references':[
      {'arxiv':'1501.06869','locations':['Lemma 2.2','Proposition 7.1','Proposition 4.1','Lemma 4.11']},
      {'arxiv':'0806.3484','locations':['Theorem 4.3','Lemma 4.4','Lemma 7.1']},
      {'arxiv':'math/0206301','locations':['Proposition 2.1']},
      {'arxiv':'1006.0569','locations':['Proposition 5.1','Corollary 5.6 (arXiv v1 numbering)']}
    ]
}
(HERE/'R920_audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
