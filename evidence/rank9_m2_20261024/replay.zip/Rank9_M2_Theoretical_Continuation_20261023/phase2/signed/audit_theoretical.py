"""Independent finite-hypothesis audit for the three categorical descent proofs."""
from pathlib import Path
import json,itertools,hashlib,collections
HERE=Path(__file__).resolve().parent;BASE=HERE.parents[1]
TENSORS=json.loads((BASE/'work/verification_corpus.json').read_text())['tensors']

def closure(R,S):
    S=set(S)|{0}
    while True:
        T=S|{k for i in S for j in S for k,x in enumerate(R[i][j])if x}
        if T==S:return sorted(S)
        S=T

def adjoint(R):
    n=len(R);dual=[next(j for j in range(n)if R[i][j][0])for i in range(n)]
    return closure(R,{k for i in range(n)for k,x in enumerate(R[i][dual[i]])if x})

def check_104(rid):
    R=TENSORS[rid];n=len(R)
    # Recover neutral component from the integer-dimension profile, then
    # recheck *every* dimension equation independently in Z[sqrt(26)].
    profile=next(r for r in json.loads((BASE/'results/unresolved.json').read_text())if r['id']==rid)
    dims=[(int(x[0]),0)if len(x)==1 else(0,1)for x in profile['dimension_coefficients']]
    assert sorted(dims)==[(0,1)]*2+[(1,0)]*4+[(4,0)]*3
    for i,j in itertools.product(range(n),repeat=2):
        a,b=dims[i];c,d=dims[j]
        assert (a*c+26*b*d,a*d+b*c)==tuple(sum(R[i][j][k]*dims[k][q]for k in range(n))for q in range(2))
    B=[i for i,d in enumerate(dims)if not d[1]];O=[i for i in range(n)if i not in B]
    assert len(B)==7 and len(O)==2
    g=[int(i in O)for i in range(n)]
    assert all(g[k]==g[i]^g[j]for i,j,k in itertools.product(range(n),repeat=3)if R[i][j][k])
    S=[[[R[i][j][k]for k in B]for j in B]for i in B]
    assert adjoint(S)==list(range(7))
    I=[i for i in B if dims[i]==(1,0)];orders=[]
    for i in I:
        x=0
        for q in range(1,5):
            assert sum(R[x][i])==1;x=R[x][i].index(1)
            if x==0:orders.append(q);break
    assert sorted(orders)==[1,2,4,4]
    assert all(R[g][i]==R[i][g]==[int(k==i)for k in range(n)]for g in I for i in B if dims[i]==(4,0))
    return {'id':rid,'status':'PASS','source_sha256':hashlib.sha256(json.dumps(R,separators=(',',':')).encode()).hexdigest(),
            'neutral_dimension':52,'neutral_rank':7,'odd_rank':2,'neutral_invertibles':'C4',
            'neutral_universal_grading':'trivial','odd_dimension_squared':26}

def check_222():
    rid='R9_2_907';R=TENSORS[rid];d=[1,1,2]+[6]*6
    assert sum(x*x for x in d)==222 and 37%6==1
    assert all(sum(R[i][j][k]*d[k]for k in range(9))==d[i]*d[j]for i,j in itertools.product(range(9),repeat=2))
    assert adjoint(R)==list(range(9))
    assert R[1][1]==[1]+[0]*8
    assert all(R[1][i]==R[i][1]==[int(k==i)for k in range(9)]for i in range(2,9))
    return {'id':rid,'status':'PASS','source_sha256':hashlib.sha256(json.dumps(R,separators=(',',':')).encode()).hexdigest(),
            'FPdim':222,'prime':37,'simple_dimensions':d,'universal_grading':'trivial','nontrivial_invertible_fixes_all_noninvertibles':True}

def check_group():
    E=list(itertools.product(range(13),range(4)));one=(0,0)
    def mul(x,y):return((x[0]+pow(5,x[1],13)*y[0])%13,(x[1]+y[1])%4)
    inv={x:next(y for y in E if mul(x,y)==one)for x in E}
    def close(H):
        H=set(H)|{one}
        while True:
            J=H|{mul(x,y)for x in H for y in H}
            if H==J:return frozenset(H)
            H=J
    subgroups={frozenset([one])};queue=list(subgroups)
    for H in queue:
        for x in E:
            if x in H:continue
            J=close(set(H)|{x})
            if J not in subgroups:subgroups.add(J);queue.append(J)
    assert len(subgroups)==30
    rank_by_order=collections.defaultdict(set);c2=[]
    for H in subgroups:
        classes={frozenset(mul(mul(x,y),inv[x])for x in H)for y in H}
        rank_by_order[len(H)].add(len(classes))
        if len(classes)==2:
            assert len(H)==2;c2.append(H)
    assert dict(rank_by_order)=={1:{1},2:{2},4:{4},13:{13},26:{8},52:{7}}
    assert len(c2)==13
    for H in c2:
        seen=set();types=collections.Counter()
        for x in E:
            if x in seen:continue
            D={mul(mul(h,x),k)for h in H for k in H};seen|=D
            K={h for h in H if mul(mul(inv[x],h),x)in H}
            assert len(D)*len(K)==4
            types[2//len(K)]+=len(K)
        assert types=={1:4,2:12} and sum(types.values())==16
    return {'status':'PASS','group':'C13 semidirect_5 C4','all_subgroups':30,
            'ordinary_irrep_counts_by_order':{str(k):list(v)for k,v in sorted(rank_by_order.items())},
            'rank_two_modules_up_to_subgroup_conjugacy':1,'all_C2_subgroups_checked':13,
            'dual_simple_dimensions':{'1':4,'2':12},'dual_rank':16}

if __name__=='__main__':
    records=[check_104('R9_2_1071'),check_104('R9_2_1724'),check_222()]
    out={'verdict':'APPROVED','scope':'general complex fusion categories',
         'theoretical_review':'audit.md','hypothesis_checks':records,'group_audit':check_group(),
         'hidden_WGT_assumption':False,'additional_assumptions':[]}
    (HERE/'audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
