"""Independent enumeration/filter and exact-ray audit of the neutral relaxation.

The categorical justification is in neutral_audit.md.  No LP is called here.
"""
from pathlib import Path
from fractions import Fraction as Q
import collections, hashlib, itertools, json, math, sys
import sympy as s

HERE=Path(__file__).resolve().parent
BASE=HERE.parents[1]
sys.path.insert(0,str(BASE/'phase2/quadratic_theory'))
import quadratic_center as qc
from quadratic_neutral import neutral_base

def multiply(x,y,q):
    return(x[0]*y[0]+q*x[1]*y[1],x[0]*y[1]+x[1]*y[0])

def integral(x,q):
    return (2*x[0]).denominator==1 and (x[0]**2-q*x[1]**2).denominator==1

def low_counts(B,D,q):
    counts=collections.Counter()
    for p,m in s.factor_list(B.charpoly().as_expr())[1]:
        co=[Q(t) for t in s.Poly(p).all_coeffs()]
        if len(co)==2:roots=[(-co[1]/co[0],Q(0))]
        else:
            assert len(co)==3
            a,b,c=co;disc=b*b-4*a*c
            h2=disc/q;assert h2.denominator==1
            h=math.isqrt(h2.numerator);assert h*h==h2
            roots=[(-b/(2*a),Q(h)/(2*a)),(-b/(2*a),-Q(h)/(2*a))]
        for a,b in roots:
            norm=a*a-q*b*b
            counts[((D[0]*a-q*D[1]*b)/norm,(D[1]*a-D[0]*b)/norm)]+=m
    return counts

def columns(R,data):
    n=len(R);active=data['active'];charged=set(range(n))-set(active);q=data['q'];D=data['D']
    # Direct tensor contraction, independent of rings.casimir.
    B=s.Matrix(n,n,lambda i,j:sum(R[h][i][k]*R[h][j][k]for h in range(n)for k in range(n)))
    assert B==data['ch'].C and B==B.T and B.det()>0
    assert all(B[i,j]==0 for i in active for j in charged)
    assert all(not R[i][j][k]for i in active for j in active for k in charged)
    assert all(data['ch'].du[i]in active for i in active)
    counts=low_counts(B,D,q);assert counts==data['counts']
    J=B.inv();bounds=[math.isqrt(int(B[i,i]))for i in active];bounds[active.index(0)]=1
    raw=[];filtered=[]
    for vv in itertools.product(*(range(b+1)for b in bounds)):
        if not any(vv):continue
        v=[0]*n
        for i,a in zip(active,vv):v[i]=a
        if any(v[i]*v[j]>B[i,j]for i in active for j in active):continue
        if sum(v[i]*J[i,j]*v[j]for i in active for j in active)>1:continue
        v=tuple(v);raw.append(v)
        z=tuple(sum(v[i]*data['dims'][i][c]for i in active)for c in range(2))
        if v[0]:
            if z not in counts:continue
        else:
            norm=z[0]**2-q*z[1]**2
            if not norm:continue
            ratio=((D[0]*z[0]-q*D[1]*z[1])/norm,(D[1]*z[0]-D[0]*z[1])/norm)
            if not integral(ratio,q):continue
            if z[1] and (4*z[0]**2/norm).denominator!=1:continue
        filtered.append((v,z))
    assert len(raw)==data['raw_columns']
    # For both exclusions the modular filter removes nothing.  This comparison
    # certifies the ray using every arithmetic-admissible column, independently
    # of the modular S-ratio filter's implementation.
    assert len(filtered)==data['pre_modular_columns']
    assert set(filtered)==set(data['cols'])
    return {'box_size':math.prod(b+1 for b in bounds),'raw_columns':len(raw),
            'arithmetic_columns':len(filtered),'modular_filter_removes_no_columns':True}

def packets():
    z=(Q(0),Q(0));one=(Q(1),Q(0));minus=(-Q(1),Q(0));half=(Q(0),Q(1,2));nhalf=(Q(0),-Q(1,2))
    expected={(one,one,one),(minus,one,minus),(z,minus,z),
              (half,z,nhalf),(nhalf,z,half),(z,half,z),(z,nhalf,z),(z,z,z)}
    observed,bound=qc.trace_types(2,[2],3)
    assert set(observed)==expected and bound==16
    assert set(qc.rotation_types(2,3,[1]))=={(one,),((-Q(1,2),Q(0)),)}
    return {'q':2,'height':3,'packets':8,'representative_order_bound':16,'direct_hand_list_matches':True}

def system(rid):
    old=qc.base;qc.base=neutral_base
    try:return qc.system(qc.inputs(rid),3)
    finally:qc.base=old

def verify(rid):
    R=qc.inputs(rid);data=neutral_base(R);raw=columns(R,data)
    A,b,m=system(rid)
    cert=json.loads((BASE/'phase2/quadratic_theory'/f'{rid}_neutral_h3.json').read_text())
    assert cert['metadata']==json.loads(json.dumps(m))
    y=cert['ray'];assert len(y)==len(b) and all(type(a)is int for a in y)
    inner=[sum(A[i][j]*y[i]for i in range(len(b)))for j in range(len(A[0]))]
    sep=sum(a*c for a,c in zip(b,y));assert min(inner)>=0 and sep==-896
    gates=json.loads((HERE/'gate_verification.json').read_text())
    if isinstance(gates,dict):
        gates=gates.get('records',gates.get('results',gates.get('gates',gates)))
    gate=next(g for g in gates if g['id']==rid)
    assert gate['status']=='PASS' and gate['conclusion']=='galois_pseudo_unitarity'
    return {'id':rid,'status':'PASS','verdict':'APPROVED','scope':'general complex fusion categories',
            'equations':len(b),'variables':len(A[0]),'bTy':sep,'minimum_ATy':min(inner),
            'neutral_indices':data['active'],'independent_enumeration':raw,
            'system_sha256':hashlib.sha256(json.dumps({'A':A,'b':b},separators=(',',':')).encode()).hexdigest()}

def control():
    witness=json.loads((HERE/'neutral_515_primal.json').read_text());A,b,m=system('R9_2_515')
    x=[Q(0)]*len(A[0])
    for i,t in witness['nonzero_primal']:x[i]=Q(t)
    assert all(t>=0 for t in x)
    assert all(sum(a*t for a,t in zip(row,x))==value for row,value in zip(A,b))
    assert witness['system_sha256']==hashlib.sha256(json.dumps({'A':A,'b':b},separators=(',',':')).encode()).hexdigest()
    return {'id':'R9_2_515','status':'PASS','exact_primal_verified':True,
            'equations':len(b),'variables':len(A[0]),'nonzero_coordinates':sum(bool(t)for t in x),
            'witness':'neutral_515_primal.json'}

if __name__=='__main__':
    out={'verdict':'APPROVED','theory':'neutral_audit.md','trace_packet_audit':packets(),
         'exclusions':[verify('R9_2_500'),verify('R9_2_1235')],'positive_control':control()}
    (HERE/'neutral_audit.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
