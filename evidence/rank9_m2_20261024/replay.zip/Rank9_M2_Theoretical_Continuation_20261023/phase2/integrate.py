"""Build a separate continuation ledger; preserve the established baseline."""
from pathlib import Path
import json,copy,hashlib,collections,re
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'phase2/results';OUT.mkdir(exist_ok=True)
def read(p):return json.load(open(ROOT/p))
def write(p,x):(OUT/p).write_text(json.dumps(x,indent=2)+'\n')
def rid(x):return f'R9_2_{x}'if isinstance(x,int)else x
def num(x):return int(x.rsplit('_',1)[1])
def main():
 baseline=read('results/ledger.json'); ledger=copy.deepcopy(baseline); byid={x['id']:x for x in ledger}
 previous=read('results/unresolved.json'); profiles={x['id']:copy.deepcopy(x)for x in previous}
 accepted=read('phase2/accepted.json'); exclusions=[]
 center={x['id']:x for x in read('phase2/integral_theory/center_verification.json')}
 for kind,ids in accepted['new_exclusions'].items():
  for identifier in ids:
   identifier=rid(identifier); assert identifier in profiles
   if kind=='signed_nonzero_products':proof=f'phase2/signed/{identifier}.json';theory='phase2/signed/THEOREM.md'
   elif kind=='joint_integral_center':
    assert center[identifier]['status']=='PASS';proof='phase2/integral_theory/'+center[identifier]['file'];theory='phase2/integral_theory/joint_center_theorem.md'
   elif kind=='prime_descent':proof='phase2/integral_theory/R9_2_907_prime_descent.json';theory='phase2/integral_theory/prime_descent.md'
   elif kind=='solvable_rank_two_module':proof='phase2/weak_integral/frobenius52_certificates.json';theory='phase2/weak_integral/frobenius52.md'
   elif kind=='joint_quadratic_center':proof=f'phase2/quadratic_theory/{identifier}_qcenter_h3.json';theory='phase2/quadratic_theory/THEOREM.md'
   elif kind=='folded_fermionic_so3':proof='phase2/signed/R920_audit.json';theory='phase2/quadratic_theory/R920_PROOF.md'
   elif kind=='solvable_central_invertibles':proof='phase2/integral_theory/central_invertible_exclusions.json';theory='phase2/integral_theory/dimension96_reduction.md'
   elif kind=='quadratic_neutral_block':proof=f'phase2/quadratic_theory/{identifier}_neutral_h3.json';theory='phase2/quadratic_theory/NEUTRAL_BLOCK_THEOREM.md'
   elif kind=='larger_fixed_block_morita':proof=f'phase2/weak_integral/morita_{identifier}_{1 if identifier=="R9_2_396"else 5}.json';theory='phase2/weak_integral/morita48.md'
   else:raise ValueError(kind)
   assert (ROOT/proof).is_file(),proof
   e={'id':identifier,'kind':kind,'scope':'general_complex_fusion_categories','certificate':proof,'theory':theory,'tensor_sha256':byid[identifier]['tensor_sha256']}
   row=byid[identifier];assert row['status']=='unresolved'
   row['status']='excluded';row['exclusion_certificates'].append({'record_file':proof,'certificate_kind':kind,'scope':e['scope'],'theory':theory})
   exclusions.append(e)
 newmodels=[]; want=set(accepted['new_models'])
 for file in accepted['model_files']:
  for model in read(file):
   if model['id'] not in want:continue
   assert model.get('status')=='unitarily_realized'
   model=copy.deepcopy(model);model['record_file']=file; identifier=model['id'];row=byid[identifier]
   assert row['status']=='unresolved'and identifier in profiles
   assert not any(x['id']==identifier for x in newmodels)
   row['status']='unitarily_realized';row['models'].append({'record_file':file,'model':model['model']})
   newmodels.append(model)
 assert {x['id']for x in newmodels}==want
 for gate in read('phase2/signed/summary.json')['general_to_PU_gates']:
  identifier=gate['id'];profiles[identifier]['general_to_PU_gate']='signed_sphericalization_global_dimension_Galois_orbit'
  profiles[identifier]['phase2_gate_certificate']=gate['certificate'];byid[identifier]['phase2_gate_certificate']=gate['certificate']
 # Attach actual per-ring output records as attempts, without promoting their
 # nested branch outcomes or solver reports to a classification.
 for identifier,profile in profiles.items():
  attempts=[]
  for folder in ['integral_theory','quadratic_theory','signed','weak_integral','group_models','models']:
   for f in sorted((ROOT/'phase2'/folder).glob('*.json')):
    if not re.search(re.escape(identifier)+r'(?:_|\.|$)',f.name):continue
    data=json.load(open(f)); outcome=data.get('outcome','recorded')if isinstance(data,dict)else'recorded'
    attempts.append({'record_file':str(f.relative_to(ROOT)),'outcome':outcome,'classification_authority':'Only accepted.json changes status'})
  for f in ['cyclic3_results.json','1848_modular_pattern_traces.json']:
   p=ROOT/'phase2/morita_general'/f
   if p.exists()and(identifier=='R9_2_1848'if f.startswith('1848')else identifier in ['R9_2_1356','R9_2_1857','R9_2_1933','R9_2_2029']):
    attempts.append({'record_file':str(p.relative_to(ROOT)),'outcome':'no_conclusion'})
  byid[identifier]['attempts'].extend(attempts);profile['phase2_attempts']=attempts
  profile['status']=byid[identifier]['status']
 unresolved=[profiles[x['id']]for x in ledger if x['status']=='unresolved']
 for profile in unresolved:
  identifier=profile['id'];commutative=byid[identifier]['commutative']
  scope={'general_complex':'unresolved','pivotal':'unresolved','spherical':'unresolved','pseudo_unitary':'unresolved','unitary':'unresolved','general_existence_equivalent_to_pseudo_unitary_existence':True,'existence_reduction':profile['general_to_PU_gate'],'braided':'unresolved'if commutative else'excluded','braided_exclusion_reason':None if commutative else'Every braided fusion category has a commutative Grothendieck ring; this tensor is noncommutative.','note':'A Galois-pseudo-unitarity gate is an existence reduction for this based ring. It is not a claim that every original categorification is itself pseudo-unitary or unitary.'}
  profile['categorification_scopes']=scope;byid[identifier]['categorification_scopes']=copy.deepcopy(scope)
 assert len(ledger)==2083 and len(byid)==2083
 assert all(a==b for a,b in zip(baseline,ledger)if a['id']not in profiles)
 counts=collections.Counter(x['status']for x in ledger)
 models=read('results/models.json')+newmodels
 assert len(models)==counts['unitarily_realized']
 assert all(not(x['exclusion_certificates']and x['models'])for x in ledger)
 assert all(x['general_to_PU_gate']not in [None,'unknown']for x in unresolved)
 summary={'rank':9,'exact_multiplicity':2,'total':len(ledger),'excluded':counts['excluded'],'modelled':counts['unitarily_realized'],'unresolved':counts['unresolved'],'previously_unresolved':81,'new_excluded':len(exclusions),'new_modelled':len(newmodels),'previous_multiplicity_one_unchanged':142,'scope':'General complex exclusions; every recorded model has a unitary construction. Necessary tests, partial exclusions, and unresolved proof gaps are not classifications.','online_changes':False}
 write('ledger.json',ledger);write('new_exclusions.json',sorted(exclusions,key=lambda x:num(x['id'])));write('new_models.json',sorted(newmodels,key=lambda x:num(x['id'])));write('models.json',sorted(models,key=lambda x:num(x['id'])));write('unresolved.json',unresolved);write('summary.json',summary)
 write('continuation81.json',[{'id':x['id'],'status':byid[x['id']]['status'],'tensor_sha256':x['tensor_sha256']}for x in previous])
 print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
