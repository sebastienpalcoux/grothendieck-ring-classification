# Rank nine, exact multiplicity two: established-method pass

**2,083 rings: 1,995 excluded, 7 unitarily modelled, 81 unresolved.**

This is the first phase requested on 23 October 2026: reuse literature criteria,
the project's established criteria, literature models and established project
constructions. New purpose-built criteria/models and online revision are deferred.
Neither GitHub repository nor the public Atlas has been changed.

The supplied archive also contains the 142 multiplicity-one rings already treated.
They are not counted again. All 2,225 inputs pass an independent exact fusion-axiom,
associativity and based-isomorphism audit, with no duplicates. The 142 older rings
match their previous identifiers and tensors up to recorded based isomorphisms.

## Results

* `results/summary.json`: final counts and categorical scope.
* `results/ledger.json` and `results/ledger.csv`: every new ring, its physical input
  line, tensor hash, status and certificate/model references.
* `results/models.json`: complete known-model tensors and coefficientwise basis maps.
* `results/unresolved.json`: exact number fields, dimensions, codegrees, invertibles,
  dualities and subrings for all 81 remaining rings.
* `results/verification.json`: successful replay results for all 2,083 records.
* `HANDOFF.md`: continuation instructions and limitations of unsuccessful searches.

All exclusions in the final ledger concern **general complex fusion categories**.
All seven positive results have unitary constructions. Successful necessary tests
and unsuccessful searches are never treated as models; scoped pseudo-unitary
obstructions are never promoted to general exclusions without a proved reduction.

## Known models

| Input identifier | Known unitary construction |
|---|---|
| `R9_2_369` | Representations of PGL(2,7) |
| `R9_2_936` | Representations of PSL(2,8) |
| `R9_2_1016` | Izumi near-group category for (D8,2); also subgroup-algebra bimodules in Vec(S4) |
| `R9_2_1374` | D16 even category: bosonic modularization of the even SU(2) level-28 category |
| `R9_2_1557` | C(PSL(2,7),1,S4,1), the subgroup-algebra bimodule category |
| `R9_2_1979` | Izumi near-group category for (Q8,2) |
| `R9_2_2083` | Representations of C19 semidirect C3 |

Every match checks the complete multiplication tensor. Model construction,
coherence/existence input, and comparison data are distinguished in the records.

## Established methods covered

The campaign covers negative-subring transfer through rank eight and multiplicity
two; rank-two and near-group restrictions; formal-codegree d-numbers; cyclotomic
and field-automorphism witnesses; integral Drinfeld-center divisibility including
noncommutative Wedderburn weights; primitive-codegree and quadratic-compression
tests; all proper-subring dimension indices; cyclic isotypic divisibility;
zero/one-spectrum pentagon criteria; involution-module equations; oriented signed
sphericalization; dimension-character field, norm and dimension-order tests;
central induction, Gram and twist-moment constraints; and applicable existing
Morita, character, modular, higher-indicator and tensor-rotation routines.

The model survey includes the complete lower-rank positive registries, tensor
products, standard quantum-group families, Tambara–Yamagami actions, pointed and
permutation equivariantizations, established zesting constructions, near-group
theorems, and explicit group-theoretical constructions. The attempt records retain
full-tensor failures and rank/multiplicity mismatches; they do not infer
nonexistence from an absent model.

"Covered" means that the family was surveyed, its actual hypotheses checked and
its eligible established implementation attempted. It does not mean that every
finite search completed on every unresolved ring, or that the consequences of all
literature have been exhausted. Limits and incomplete searches remain explicit in
the attempt records. In particular, some of the 81 cases retain unfinished signed
or induction searches. They are unresolved **in this pass**, not claims of new
mathematical open problems.

No multiplicity-one restriction was reused for multiplicity-two signed traces:
their domains are respectively {-1,1} and {-2,0,2}. No unproved positive-indicator
normalization or commutativity assumption is imposed on the oriented signed
problem. Finite solver adapters change enumeration backends, not the underlying
categorical criteria. The noncommutative induction implementation uses
dim(A_E)=D/f_E, multiplicity [I(1):A_E]=dim(E), and restriction coefficient
[F(A_E):1]=dim(E); the regular Casimir is distinguished from the induction Gram.

## Replay

Python 3.12+, a C++17 compiler and the packages in `requirements.txt` are sufficient:

```sh
python -m pip install -r requirements.txt
python verify.py
```

The verifier needs no network access. Input auditing and all selected classification
certificates are replayed using exact arithmetic. The categorical implications
are the cited mathematical theorems and the established project arguments, not a
numerical fit or the solver's ability to find a candidate.

`work/` preserves discovery, scope audits, exact certificates, unsuccessful
attempts and replay code. `sources/` preserves reused implementations and their
rank-nine adapters. `theory/` contains the scope explanation and relevant prior
project arguments. Source and deliverable hashes are recorded in `manifests/`.

## Primary references

* V. Ostrik, *On formal codegrees of fusion categories*, https://arxiv.org/abs/0810.3242.
* A. Schopieray, *Categorification of integral group rings extended by one dimension*,
  https://arxiv.org/abs/2208.07319.
* Z. Liu, S. Palcoux, Y. Ren and G. Vercleyen, *Triangular Prism Equations and
  Categorification*, https://arxiv.org/abs/2203.06522.
* M. Izumi, *A Cuntz algebra approach to the classification of near-group categories*,
  Theorem 6.1, https://arxiv.org/abs/1512.04288.
* A. Kirillov Jr. and V. Ostrik, *On a q-analogue of the McKay correspondence and
  the ADE classification of sl2 conformal field theories*,
  https://arxiv.org/abs/math/0101219.
* Z. Liu, S. Palcoux and Y. Ren, *Interpolated family of non group-like simple
  integral fusion rings of Lie type*, https://arxiv.org/abs/2102.01663.
* P. Etingof, S. Gelaki, D. Nikshych and V. Ostrik, *Tensor Categories*, AMS, 2015.
* The established project proof corpus is pinned to classification commit
  `8f1a0b8184eb8d7bb44a666afd78552e33c02f42` and census commit
  `388e450703f89d351afad9a328fd06b90b198f84`.
