# Continuation handoff

The established-method phase is complete as a bounded, certificate-backed research pass.

* Exact multiplicity two: **2,083** rings.
* General-complex exclusions: **1,995**.
* Known unitary models: **7**.
* Remaining records: **81**.
* No online revision has been made.

The next requested phase is theoretical new criteria and new models for the remaining cases,
under GPT-6 Astra Ultra. Publication is deferred until the user changes back to the publishing model.

`results/unresolved.json` supplies exact FP number fields, isolating intervals, dimension vectors,
formal-codegree factors, dualities and every proper based subring. Tensors are recoverable from
the original compressed input using `physical_line` in the ledger; `work/verification_corpus.json`
also contains every exact-multiplicity-two tensor keyed by its identifier.

Of the remaining records, **51** are weakly integral and a further **one** has the established
two-FP-value Galois-pseudo-unitarity reduction. The other **29** retain the full general-category
scope. Their FP dimension fields have degrees 1 (31 rings), 2 (44), 4 (3), and 6 (3).

## Incomplete established searches

The following source rings are already excluded in the spherical scope by established conditions,
but unrestricted oriented sphericalization has not yet been exhausted:

`R9_2_686`, `R9_2_690`, `R9_2_726`, `R9_2_728`, `R9_2_736`, `R9_2_1187`, `R9_2_1241`, `R9_2_1377`, `R9_2_1424`.

For these cases, preserve the partial branch certificates in `work/pb_<ID>.json`,
`work/pb_scan.json` and `work/signed_sieve.json`. Their remaining uncertainty is not evidence
that a model exists. Source-basis automorphisms and dual-compatible sign gauges can be used
to reduce the existing finite search. The latest R9_2_686 per-ring partial file contains more
progress than its earlier campaign record.

Other unresolved cases include induction/Gram/trace attempts that reached their explicit
discovery allowance. The detailed method records preserve finite failures, implementation
hypotheses and scoped obstructions separately. Do not promote a scoped obstruction or an
incomplete search to general nonexistence.

## Conventions and verification

`R9_2_i` is the i-th exact-multiplicity-two entry in the supplied order. All 142 multiplicity-one
identifiers are unchanged, with exact crosswalks in `work/multiplicity_one_crosswalk.json`.
No tensor was silently reordered or replaced.

All accepted exclusions and all model tensor matches have passed exact replay. A first complete
2,083-record replay was followed by fresh checks for the 17 later-decided records, reusing only
unchanged certificates for the others. The independent input check also confirms all 2,225
records are valid, pairwise nonisomorphic fusion rings.

The noncommutative induction adapter must retain **dim(A_E)=D/f_E**,
**[I(1):A_E]=dim(E)** and **[F(A_E):1]=dim(E)**. Its weighted dimension identity is
`sum_E dim(E)*dim(A_E)=D`. The two known noncommutative near-group models were also used
as positive controls. The final stored weighted records use this convention.

The signed trace domain for a multiplicity-two channel is `{-2,0,2}`. Neither commutativity
nor positive Frobenius–Schur normalization is imposed without a proof.

## Publication phase

When publication is authorized later, update the existing rank-nine multiplicity-two band
in the ordinary ordering of the two repositories and the public GitHub Atlas. Preserve the
clean/ordered policy and the existing multiplicity-one results. The former private Atlas
is outside the requested publication scope.
