"""Verify the corrected partition, explicit subring transfers and model maps."""
from pathlib import Path
import argparse
import hashlib
import itertools
import json
import subprocess
import sys

P = Path(__file__).resolve().parent
B = P.parent
sys.path[:0] = [str(B / 'work'), str(B / 'sources')]
from common import read as input_rows, digest


def load(path):
    return json.loads((B / path).read_text())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--fresh', action='store_true')
    args = parser.parse_args()
    # Check the delivered snapshot before any fresh command regenerates output.
    manifest = B / 'SHA256SUMS.json'
    files_checked = 0
    if manifest.exists():
        for name, wanted in json.loads(manifest.read_text()).items():
            assert hashlib.sha256((B / name).read_bytes()).hexdigest() == wanted, name
            files_checked += 1
    if args.fresh:
        commands = ['phase3/audit_small_subrings/verify.py',
                    'phase3/structural_checked.py',
                    'phase3/models_restored/products.py',
                    'phase3/models_restored/ising_zest.py',
                    'phase3/models_restored/shear.py',
                    'phase3/audit_exotic_models/shear_replay.py',
                    'phase3/group_models/s5_relative_twist.py',
                    'phase3/audit_models/audit_s5_relative_twist.py',
                    'phase3/integral_theory/verify_d48_models.py',
                    'phase3/audit_models/audit_d48_relative_twist.py',
                    'phase3/audit_models/audit_d48_relative_twist.py --exotic',
                    'phase3/audit_hopf20/verify.py',
                    'phase3/hopf20/hopf20.py',
                    'phase3/audit_hopf20/audit_965.py',
                    'phase3/audit_quadratic_symmetry/replay516.py',
                    'phase3/audit_quadratic_symmetry/replay1487.py',
                    'phase3/audit_quadratic_symmetry/replay1487.py 1959',
                    'phase3/audit_quadratic_symmetry/replay_galois.py',
                    'phase3/integrate.py']
        for name in commands:
            script, *arguments = name.split()
            subprocess.run([sys.executable, str(B / script), *arguments], cwd=B, check=True)
    rows = {r['id']: r for r in input_rows() if r['multiplicity'] == 2}
    ledger = load('phase3/results/ledger.json')
    assert len(rows) == len(ledger) == 2083
    by_id = {r['id']: r for r in ledger}
    assert set(rows) == set(by_id)
    for rid, row in by_id.items():
        assert row['tensor_sha256'] == rows[rid]['tensor_sha256']
        assert not any(c['record_file'] == 'work/structural.json'
                       for c in row['exclusion_certificates'])
        assert not (row['models'] and row['exclusion_certificates'])
    registry = {r['tensor_sha256']: r for r in load('phase3/verified_lower_negative_registry.json')}
    structural = load('phase3/structural_checked.json')
    transfers = 0
    for rec in structural:
        R = rows[rec['id']]['tensor']
        for c in rec['certificates']:
            J = c['subset']
            assert 0 in J and len(set(J)) == len(J)
            assert all(R[i][j][k] == 0 for i in J for j in J for k in range(9) if k not in J)
            S = [[[R[i][j][k] for k in J] for j in J] for i in J]
            assert digest(S) == c['subtensor_sha256']
            item = registry[c['negative_subtensor_sha256']]
            T = item['tensor']
            assert digest(T) == item['tensor_sha256']
            assert c['negative_proof'] == item['negative_proof']
            p = c['basis_map_subring_to_negative']
            assert sorted(p) == list(range(len(J))) and p[0] == 0
            assert all(S[i][j][k] == T[p[i]][p[j]][p[k]]
                       for i, j, k in itertools.product(range(len(J)), repeat=3))
            assert by_id[rec['id']]['status'] == 'excluded'
            transfers += 1
    models = load('phase3/results/models.json')
    seen = set()
    for model in models:
        rid = model['id']
        assert rid not in seen
        seen.add(rid)
        assert by_id[rid]['status'] == model['status'] == 'unitarily_realized'
        R, T = rows[rid]['tensor'], model['tensor']
        p = model['basis_map_source_to_model']
        assert sorted(p) == list(range(9)) and p[0] == 0
        assert all(R[i][j][k] == T[p[i]][p[j]][p[k]]
                   for i, j, k in itertools.product(range(9), repeat=3))
    counts = {status: sum(r['status'] == status for r in ledger)
              for status in ('excluded', 'unitarily_realized', 'unresolved')}
    summary = load('phase3/results/summary.json')
    assert counts['excluded'] == summary['excluded']
    assert counts['unitarily_realized'] == summary['modelled'] == len(models)
    assert counts['unresolved'] == summary['unresolved']
    assert sum(counts.values()) == 2083
    assert len(load('phase3/results/unresolved.json')) == summary['unresolved']
    accepted = load('phase3/accepted.json')
    for proof in accepted['additional_exclusions']:
        assert by_id[proof['id']]['status'] == 'excluded'
        assert proof in by_id[proof['id']]['exclusion_certificates']
        for key in ('record_file', 'independent_audit'):
            assert (B / proof[key]).is_file(), proof
    hopf_audit = load('phase3/audit_hopf20/verification.json')
    assert hopf_audit['status'] == 'PASS'
    assert load('phase3/audit_hopf20/audit_965.json')['status'] == 'PASS'
    s5_audit = load('phase3/audit_models/s5_relative_twist_audit.json')
    assert s5_audit['status'] == 'PASS' and s5_audit['coefficients_matched'] == 729
    ray_audit = load('phase3/audit_quadratic_symmetry/replay516.json')
    assert ray_audit['bTy'] < 0 and ray_audit['minimum_ATy'] >= 0
    galois_audit = load('phase3/audit_quadratic_symmetry/replay_galois.json')
    for result in galois_audit['checks']:
        if result['status'] == 'accepted_exclusion_via_audited_gate':
            assert by_id[result['id']]['status'] == 'excluded'
            assert result['tensor_sha256'] == rows[result['id']]['tensor_sha256']
    invalid = load('phase3/audit_baseline/invalid_half_E6_subrings.json')['affected']
    assert len(invalid) == 26
    assert all(by_id[x['id']].get('withdrawn_claims') for x in invalid)
    receipt = {'status': 'PASS', 'total': 2083, **counts,
               'full_model_coefficient_equalities': len(models) * 729,
               'explicit_negative_subring_transfers': transfers,
               'withdrawn_claims': 26, 'package_files_checked': files_checked,
               'fresh_requested': args.fresh,
               'scope': 'Finite replay is accompanied by the categorical audit reports; it is not formal proof verification.'}
    (P / 'verification.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
