"""Necessary split-module action search for a central involution.

For row-oriented action matrices, M_i M_j = sum N_{ji}^k M_k.
This extends only the anti-module equation search, not any later Morita Gram
classification. A feasible or incomplete search is not a categorification.
"""
from pathlib import Path
import importlib.util
import json
import sys
import types

P = Path(__file__).resolve().parent
B = P.parent
sys.path[:0] = [str(B / 'work'), str(B / 'sources')]

source = (B / 'phase2/weak_integral/general_anti.py').read_text()
source = source.replace(
    "n=len(R);assert all(R[i][j]==R[j][i]for i in range(n)for j in range(n));du=",
    "n=len(R);assert all(R[g][i]==R[i][g]for i in range(n));du=")
source = source.replace("R[i][j][k]", "R[j][i][k]")
assert "assert all(R[i][j]==R[j][i]" not in source
module = types.ModuleType('noncomm_general_anti')
module.__file__ = str(B / 'phase2/weak_integral/general_anti.py')
exec(compile(source, module.__file__, 'exec'), module.__dict__)


def main():
    import numpy as np
    C = json.loads((B / 'work/verification_corpus.json').read_text())
    rid = sys.argv[1] if len(sys.argv) > 1 else 'R9_2_1848'
    g = int(sys.argv[2]) if len(sys.argv) > 2 else 8
    R = C['tensors'][rid]
    assert R[g][g] == [1] + [0] * 8
    assert all(R[g][i] == R[i][g] for i in range(9))
    result = module.enumerate_anti(R, g, max_seconds=120)
    result['id'] = rid
    result['involution'] = g
    result['outcome'] = 'no_conclusion' if result.get('branches') or not result.get('complete') else 'module_action_obstructed'
    for T in result.get('branches', []):
        A = [np.array(x, dtype=np.int64) for x in T]
        assert all(np.array_equal(A[i] @ A[j], sum((R[j][i][k] * A[k] for k in range(9)),
                   np.zeros_like(A[0]))) for i in range(9) for j in range(9))
    (P / f'noncomm_anti_{rid}.json').write_text(json.dumps(result, indent=2) + '\n')
    print(rid, result['outcome'], 'complete', result.get('complete'), 'branches', len(result.get('branches', [])), flush=True)


if __name__ == '__main__':
    main()
