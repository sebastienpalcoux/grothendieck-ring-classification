"""Independent all-coefficient source identification and positive-ledger receipt."""
import hashlib
import itertools
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MODELS = ROOT / 'phase2/results/models.json'
CORPUS = ROOT / 'work/verification_corpus.json'

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    models = json.loads(MODELS.read_text())
    corpus = json.loads(CORPUS.read_text())['tensors']
    seen = set()
    receipts = []
    for record in models:
        name = record['id']
        assert name not in seen
        seen.add(name)
        source, model = corpus[name], record['tensor']
        p = record['basis_map_source_to_model']
        assert sorted(p) == list(range(9)) and p[0] == 0
        for a, b, c in itertools.product(range(9), repeat=3):
            assert source[a][b][c] == model[p[a]][p[b]][p[c]]
        receipts.append({'id': name, 'model': record['model'],
                         'source_coefficients_checked': 729,
                         'source_to_model': p,
                         'categorical_existence_review': 'PASS',
                         'categorical_scope': 'existence_of_unitary_realization'})
    out = {'model_count': len(receipts), 'models_sha256': digest(MODELS),
           'corpus_sha256': digest(CORPUS),
           'categorical_review': 'phase3/audit_models/CATEGORICAL_AUDIT.md',
           'note': 'Existence is justified in the categorical report; coefficient checks alone do not prove existence.',
           'models': receipts}
    (Path(__file__).parent / 'audit_manifest.json').write_text(json.dumps(out, indent=2) + '\n')
    print(f'PASS: {len(receipts)} models, {729*len(receipts)} source coefficients')

if __name__ == '__main__':
    main()
