"""Independent cochain and tensor replay for R9_2_92.

No imports from the construction code.  The group is rebuilt as permutations,
and the tensor is recomputed from the audited bimodule character formulas.
"""
from pathlib import Path
from itertools import permutations, product
import json

ROOT = Path(__file__).resolve().parents[2]
P = ROOT / 'phase3/group_models'
raw = json.loads((P/'s5_schur_data.json').read_text().replace('\\\n',''))
record = json.loads((P/'s5_relative_twist.json').read_text())
perms = list(permutations(range(5)))
idx = {p:i for i,p in enumerate(perms)}
M = [[idx[tuple(q[p[k]] for k in range(5))] for q in perms] for p in perms]
assert M == raw['table']
sign = [sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))%2 for p in perms]
assert sign == raw['sign']
H = [i for i,p in enumerate(perms) if set(p[:3])=={0,1,2}]
assert H == raw['H'] == record['H']
inv = [next(j for j in range(120) if M[i][j]==0) for i in range(120)]
def mul(*args):
    r=0
    for a in args:r=M[r][a]
    return r
def conjugate(a,b):return mul(inv[a],b,a)

alpha = record['alpha_F2']
assert len(alpha)==120 and all(len(row)==120 for row in alpha)
assert all(v in (0,1) for row in alpha for v in row)
assert all(alpha[0][g]==alpha[g][0]==0 for g in range(120))
assert all(alpha[b][c]^alpha[M[a][b]][c]^alpha[a][M[b][c]]^alpha[a][b]==0
           for a,b,c in product(range(120),repeat=3))
assert all(sign[M[a][b]]==sign[a]^sign[b] for a,b in product(range(120),repeat=2))
psi = {(a,b):2*e for a,b,e in record['psi_exponents_mod4']}
assert len(psi)==144 and all(psi[0,h]==psi[h,0]==0 for h in H)
def w(a,b,c):return 4*sign[a]*alpha[b][c]
assert all((psi[b,c]-psi[M[a][b],c]+psi[a,M[b][c]]-psi[a,b]+w(a,b,c))%8==0
           for a,b,c in product(H,repeat=3))

# Rebuild all double cosets and projective characters independently.
double=[];covered=set();hs=set(H)
for t in range(120):
    if t in covered:continue
    support={mul(h,t,k) for h in H for k in H};covered |= support
    K=[h for h in H if conjugate(t,h) in hs]
    representatives=[];used=set()
    for l in H:
        if l not in used:
            representatives.append(l);used |= {M[l][k] for k in K}
    decomposition={mul(l,t,k):(l,k) for l in representatives for k in H}
    assert len(decomposition)==len(support)
    def factor(a,b):
        aa,bb=conjugate(t,a),conjugate(t,b)
        return (psi[a,b]+w(a,t,bb)-w(a,b,t)-w(t,aa,bb)-psi[aa,bb])%8
    fac={(a,b):factor(a,b) for a,b in product(K,repeat=2)}
    assert all((fac[b,c]-fac[M[a][b],c]+fac[a,M[b][c]]-fac[a,b])%8==0
               for a,b,c in product(K,repeat=3))
    chars=[]
    if t==0:
        assert all(e==0 for e in fac.values())
        y={h:int(perms[h][3]==4) for h in H}
        x={h:sign[h]^y[h] for h in H}
        for a,b in product(range(2),repeat=2):
            chars.append({h:((-1)**(a*x[h]+b*y[h]),0) for h in H})
        for b in range(2):
            chars.append({h:((sum(perms[h][i]==i for i in range(3))-1)*(-1)**(b*y[h]),0) for h in H})
    elif len(K)==2:
        a=next(h for h in K if h)
        assert fac[a,a]%2==0
        chars=[{0:(1,0),a:(1,(fac[a,a]//2+4*b)%8)} for b in range(2)]
    else:
        assert len(K)==4 and all(M[h][h]==0 for h in K)
        assert [h for h in K if all(fac[h,k]==fac[k,h] for k in K)]==[0]
        chars=[{h:(2 if h==0 else 0,0) for h in K}]
    double.append((t,support,K,representatives,decomposition,chars))
objects=[(d,ch) for d in double for ch in d[5]]
assert len(objects)==9

def character_at(obj,v,g):
    (t,support,K,reps,decomp,chars),chi=obj
    l,k=decomp[v];u=mul(l,t);s=conjugate(l,g)
    assert s in K
    c=conjugate(t,s);b=conjugate(v,g)
    p=(psi[g,l]+w(l,s,t)-w(g,l,t)-psi[l,s]-w(l,t,c)
       +w(u,c,k)+psi[c,k]-w(g,u,k)-w(u,k,b)-psi[k,b])
    mag,phase=chi[s]
    return mag,(phase+p)%8

computed=[[[0]*9 for _ in range(9)] for _ in range(9)]
for i,j,k in product(range(9),repeat=3):
    left,right,target=objects[i],objects[j],objects[k]
    t,support,K,reps,decomp,chars=target[0]
    coeff=[0]*4
    for g in K:
        target_mag,target_phase=target[1][g]
        b=conjugate(t,g)
        for l in left[0][3]:
            u=mul(l,left[0][0]);v=mul(inv[u],t);h=conjugate(u,g)
            if h not in hs or v not in right[0][1]:continue
            m1,e1=character_at(left,u,g);m2,e2=character_at(right,v,h)
            e=(e1+e2-target_phase+w(u,h,v)-w(g,u,v)-w(u,v,b))%8
            coeff[e%4]+=(1 if e<4 else -1)*m1*m2*target_mag
    assert coeff[1:]==[0,0,0] and coeff[0]%len(K)==0
    computed[i][j][k]=coeff[0]//len(K)
assert computed==record['tensor']
source=json.loads((ROOT/'work/verification_corpus.json').read_text())['tensors']['R9_2_92']
mapping=[0,3,1,5,7,6,4,2,8]
assert all(source[i][j][k]==computed[mapping[i]][mapping[j]][mapping[k]] for i,j,k in product(range(9),repeat=3))
dimensions=[len(d[3])*chi[0][0] for d,chi in objects]
assert sum(x*x for x in dimensions)==120
assert all(computed[0][i][j]==computed[i][0][j]==int(i==j) for i,j in product(range(9),repeat=2))
assert all(sum(computed[i][j][s]*computed[s][k][l] for s in range(9))==sum(computed[j][k][s]*computed[i][s][l] for s in range(9)) for i,j,k,l in product(range(9),repeat=4))
out={'status':'PASS','id':'R9_2_92','categorical_scope':'unitary fusion category',
     'group':'S5 independently reconstructed from permutations',
     'cochain_checks':{'normalized_alpha':True,'alpha_cocycle_triples':120**3,'normalized_psi':True,'relative_algebra_triples':12**3},
     'independent_tensor_recomputed':True,'coefficients_matched':729,
     'basis_map_source_to_model':mapping,'dimensions':dimensions,
     'double_cosets':[(len(d[1]),len(d[2]),[chi[0][0] for chi in d[5]]) for d in double]}
(Path(__file__).parent/'s5_relative_twist_audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
