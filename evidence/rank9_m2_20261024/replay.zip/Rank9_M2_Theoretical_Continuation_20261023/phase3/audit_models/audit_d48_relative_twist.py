"""Independent exact reconstruction of the dimension-48 relative-twist model.

Imports no author constructor or common tensor-isomorphism routine. The group
and subgroup are reconstructed as permutations, cochain identities are checked
directly, projective characters are reconstructed, and the original compressed
census supplies the final 729-coefficient comparison.
"""
from pathlib import Path
from itertools import permutations, product
import gzip,json,hashlib,sys

ROOT=Path(__file__).resolve().parents[2]
EXOTIC='--exotic' in sys.argv
label=1246 if EXOTIC else 392
modulus=16 if EXOTIC else 8
half=modulus//2
filename='d48_exotic_relative_twists.json' if EXOTIC else 'd48_relative_twists.json'
payload=json.loads((ROOT/'phase3/integral_theory'/filename).read_text())
record=next(r for r in payload['distinct_tensor_records'] if (r['mask'],r['psi_parity'])==((20,0) if EXOTIC else (80,0)))
perms=list(permutations(range(4)));elements=list(product(perms,range(2)))
index={g:i for i,g in enumerate(elements)}
identity=(tuple(range(4)),0)
assert index[identity]==0
def multiply(a,b):
    p,e=elements[a];q,f=elements[b]
    return index[tuple(q[p[i]] for i in range(4)),e^f]
table=[[multiply(a,b) for b in range(48)] for a in range(48)]
assert table==payload['group_table']
inverse=[next(b for b in range(48) if table[a][b]==0) for a in range(48)]
def mul(*args):
    r=0
    for a in args:r=table[r][a]
    return r
def transported(v,g):return mul(inverse[v],g,v)

x=index[((1,0,2,3),1)];y=index[((0,1,3,2),0)]
H=sorted([0,x,y,mul(x,y)]);hs=set(H)
assert H==record['H']==payload['H']
hx={0:0,x:1,y:0,mul(x,y):1}
hy={0:0,x:0,y:1,mul(x,y):1}
external=[e for p,e in elements]
sign=[sum(p[i]>p[j] for i in range(4) for j in range(i+1,4))%2 for p,e in elements]
assert external==payload['external'] and sign==payload['sign']
alpha=payload['factors_F2'][0]
assert all(v in [0,1] for row in alpha for v in row)
assert all(alpha[0][g]==alpha[g][0]==0 for g in range(48))
assert all(alpha[b][c]^alpha[table[a][b]][c]^alpha[a][table[b][c]]^alpha[a][b]==0
           for a,b,c in product(range(48),repeat=3))
assert all(external[table[a][b]]==external[a]^external[b] for a,b in product(range(48),repeat=2))
provenance=None
if EXOTIC:
    prior_path=ROOT.parent/'research/prior/rank9_rank10_m1_20261023/work/resolve_small_models/s4_twisted_models.json'
    seed_path=ROOT/'phase3/integral_theory/s4_exotic_cocycle_seed.json'
    prior=json.loads(seed_path.read_text())
    source_sha256='a5718e5471648b5b3fcb6df425dbe3f547701584afa95558413d3102e2281a2c'
    assert prior['provenance']['source_sha256']==source_sha256
    compared_original=False
    if prior_path.exists():
        prior_bytes=prior_path.read_bytes()
        assert hashlib.sha256(prior_bytes).hexdigest()==source_sha256
        original=next(r for r in json.loads(prior_bytes) if r['id']=='R9_1_92')['models'][0]['parameters']
        assert all(prior[k]==original[k] for k in ['group_table','group_labels','s','omega_exponents','modulus'])
        compared_original=True
    A=prior['group_table'];W=prior['omega_exponents'];assert prior['modulus']==8
    f=payload['old_S4_to_permutation_map'];assert sorted(f)==list(range(24))
    B=[[table[2*a][2*b]//2 for b in range(24)] for a in range(24)]
    assert all(f[A[a][b]]==B[f[a]][f[b]] for a,b in product(range(24),repeat=2))
    V=payload['S4_omega_exponents_mod8']
    assert all(W[a][b][c]==V[f[a]][f[b]][f[c]] for a,b,c in product(range(24),repeat=3))
    assert all(V[0][a][b]==V[a][0][b]==V[a][b][0]==0 for a,b in product(range(24),repeat=2))
    assert all((V[b][c][d]-V[B[a][b]][c][d]+V[a][B[b][c]][d]-V[a][b][B[c][d]]+V[a][b][c])%8==0
               for a,b,c,d in product(range(24),repeat=4))
    def omega(a,b,c):
        return (2*V[a//2][b//2][c//2]+8*(external[a]*alpha[b][c]^sign[a]*external[b]*external[c]))%16
    psi_table={(a,b):2*q for a,b,q in record['psi_exponents_mod8']}
    def psi(a,b):return psi_table[a,b]
    assert all(psi(0,a)==psi(a,0)==0 for a in H)
    provenance={'source_path':str(prior_path),'source_sha256':source_sha256,'source_record':'R9_1_92','portable_seed':'phase3/integral_theory/s4_exotic_cocycle_seed.json','portable_seed_compared_to_original_in_this_run':compared_original,'source_modulus':8,'group_isomorphism_products_checked':24**2,'transported_cocycle_entries_checked':24**3,'independent_S4_cocycle_quadruples':24**4}
else:
    def omega(a,b,c):return 4*external[a]*(alpha[b][c]^external[b]*external[c])
    def psi(a,b):return 2*hx[a]*hy[b]
    assert [[a,b,psi(a,b)//2] for a,b in product(H,repeat=2)]==record['psi_exponents_mod4']
assert all((psi(b,c)-psi(table[a][b],c)+psi(a,table[b][c])-psi(a,b)+omega(a,b,c))%modulus==0
           for a,b,c in product(H,repeat=3))
assert all((omega(b,c,d)-omega(table[a][b],c,d)+omega(a,table[b][c],d)-omega(a,b,table[c][d])+omega(a,b,c))%modulus==0
           for a,b,c,d in product(range(48),repeat=4))

# Every projective character used below is explicit: four ordinary characters
# of H, one nondegenerate V4 character, trivial-group characters, and two C2
# characters. Character values are magnitude times a power of zeta_8.
cosets=[];covered=set()
for t in range(48):
    if t in covered:continue
    support={mul(a,t,b) for a,b in product(H,repeat=2)};covered|=support
    stabilizer=[a for a in H if transported(t,a) in hs]
    representatives=[];used=set()
    for a in H:
        if a not in used:
            representatives.append(a);used|={mul(a,b) for b in stabilizer}
    decomposition={mul(l,t,k):(l,k) for l in representatives for k in H}
    def beta(a,b):
        u,v=transported(t,a),transported(t,b)
        return (psi(a,b)+omega(a,t,v)-omega(a,b,t)-omega(t,u,v)-psi(u,v))%modulus
    beta_table={(a,b):beta(a,b) for a,b in product(stabilizer,repeat=2)}
    assert all((beta_table[b,c]-beta_table[table[a][b],c]+beta_table[a,table[b][c]]-beta_table[a,b])%modulus==0
               for a,b,c in product(stabilizer,repeat=3))
    if t==0:
        assert set(beta_table.values())=={0}
        characters=[{a:((-1)**(i*hx[a]+j*hy[a]),0) for a in H} for i,j in product(range(2),repeat=2)]
    elif len(stabilizer)==1:
        characters=[{0:(1,0)}]
    elif len(stabilizer)==2:
        g=stabilizer[1]
        assert beta_table[g,g]%2==0
        characters=[{0:(1,0),g:(1,(beta_table[g,g]//2+half*j)%modulus)} for j in range(2)]
    else:
        assert len(stabilizer)==4
        assert all(mul(g,g)==0 for g in stabilizer)
        radical=[a for a in stabilizer if all(beta_table[a,b]==beta_table[b,a] for b in stabilizer)]
        assert radical==[0]
        characters=[{a:(2 if a==0 else 0,0) for a in stabilizer}]
    cosets.append({'t':t,'support':support,'K':stabilizer,'reps':representatives,'dec':decomposition,'characters':characters})
objects=[(coset,character) for coset in cosets for character in coset['characters']]
assert len(objects)==9

def fiber_character(obj,degree,a):
    coset,character=obj;t=coset['t']
    l,k=coset['dec'][degree];u=mul(l,t);s=transported(l,a)
    c=transported(t,s);b=transported(degree,a)
    phase=(psi(a,l)+omega(l,s,t)-omega(a,l,t)-psi(l,s)-omega(l,t,c)
           +omega(u,c,k)+psi(c,k)-omega(a,u,k)-omega(u,k,b)-psi(k,b))
    magnitude,p=character[s]
    return magnitude,(p+phase)%modulus

# Compute the character of each product on each target stabilizer first; only
# then take all projective-character inner products. This is a separate replay.
tensor=[[[0]*9 for _ in range(9)] for _ in range(9)]
for i,j in product(range(9),repeat=2):
    left,right=objects[i],objects[j]
    for target in cosets:
        t=target['t'];product_character={}
        for a in target['K']:
            terms=[0]*modulus;b=transported(t,a)
            for l in left[0]['reps']:
                u=mul(l,left[0]['t']);v=mul(inverse[u],t);h=transported(u,a)
                if h not in hs or v not in right[0]['support']:continue
                m,p=fiber_character(left,u,a);n,q=fiber_character(right,v,h)
                terms[(p+q+omega(u,h,v)-omega(a,u,v)-omega(u,v,b))%modulus]+=m*n
            product_character[a]=terms
        for k,(outcoset,chi) in enumerate(objects):
            if outcoset is not target:continue
            terms=[0]*modulus
            for a in target['K']:
                magnitude,phase=chi[a]
                for p,value in enumerate(product_character[a]):terms[(p-phase)%modulus]+=magnitude*value
            reduced=[terms[p]-terms[p+half] for p in range(half)]
            assert reduced[1:]==[0]*(half-1) and reduced[0]%len(target['K'])==0
            tensor[i][j][k]=reduced[0]//len(target['K'])
            assert tensor[i][j][k]>=0
assert tensor==record['tensor']

counter=0
for physical_line,line in enumerate(gzip.open(ROOT/'inputs/rank9_M2_verified/FusionRingMultiplicationTables.txt.gz','rt'),1):
    source=json.loads(line.replace('{','[').replace('}',']'))
    if max(v for row in source for item in row for v in item)!=2:continue
    counter+=1
    if counter==label:break
else:raise AssertionError('Original source missing')
mapping=[0,8,7,5,6,3,1,2,4] if EXOTIC else [0,1,2,8,7,3,5,6,4]
assert all(source[i][j][k]==tensor[mapping[i]][mapping[j]][mapping[k]] for i,j,k in product(range(9),repeat=3))
dimensions=[len(c['reps'])*chi[0][0] for c,chi in objects]
assert sum(d*d for d in dimensions)==48
assert all(tensor[0][i][j]==tensor[i][0][j]==int(i==j) for i,j in product(range(9),repeat=2))
assert all(sum(tensor[i][j][s]*tensor[s][k][l] for s in range(9))==sum(tensor[j][k][s]*tensor[i][s][l] for s in range(9)) for i,j,k,l in product(range(9),repeat=4))
out={'status':'PASS','id':f'R9_2_{label}','scope':'unitary fusion category','group':'S4 x C2 reconstructed as permutations and binary coordinate',
     'group_order':48,'subgroup_order':4,'source_physical_line':physical_line,
     'alpha_cocycle_triples':48**3,'omega_cocycle_quadruples':48**4,'relative_algebra_triples':4**3,
     'tensor_recomputed_independently':True,'coefficients_matched_to_original_input':729,
     'basis_map_source_to_model':mapping,'dimensions':dimensions,
     'tensor_sha256':hashlib.sha256(json.dumps(tensor,separators=(',',':')).encode()).hexdigest(),
     'double_cosets':[{'size':len(c['support']),'stabilizer_order':len(c['K']),'projective_irrep_dimensions':[chi[0][0] for chi in c['characters']]} for c in cosets]}
if provenance:out['imported_associator_provenance']=provenance
audit_name='d48_exotic_relative_twist_audit.json' if EXOTIC else 'd48_relative_twist_audit.json'
(Path(__file__).parent/audit_name).write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
