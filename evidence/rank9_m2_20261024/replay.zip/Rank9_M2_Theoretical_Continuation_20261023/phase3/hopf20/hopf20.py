"""Exact fusion tensors and symmetric self-duality for Gelaki's 4p Hopf algebras.

Uses the explicit Andruskiewitsch--Natale construction, not a census tensor.
"""
from pathlib import Path
import itertools,json,sys
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'sources')]
from match_models import based_iso
from oriented_signed import validate_general

def even_tensor(p,t):
    # L(e,s): x=1, g=(-1)^s i^(t e), supported on idempotent delta_e.
    # V(e,j): x has eigenvalues zeta_p^(+-j), g interchanges eigenspaces.
    labs=[('L',e,s)for e in range(2)for s in range(2)]+[('V',e,j)for e in range(2)for j in range(1,(p+1)//2)]
    n=len(labs);T=[[[0]*n for _ in range(n)]for _ in range(n)]
    for a,A in enumerate(labs):
      for b,B in enumerate(labs):
        typ,e,j=A;typ2,f,k=B;h=e^f
        if typ==typ2=='L':out=[('L',h,j^k^(t*e*f))]
        elif typ==typ2=='V':
          out=[]
          for q in [(j+k)%p,(j-k)%p]:
            if q==0:out.extend([('L',h,0),('L',h,1)])
            else:out.append(('V',h,min(q,p-q)))
        else:out=[('V',h,j if typ=='V' else k)]
        for x in out:T[a][b][labs.index(x)]+=1
    validate_general(T)
    return labs,T

def extension_tensor(p,t):
    labs,E=even_tensor(p,t);n=len(E);T=[[[0]*(n+1)for _ in range(n+1)]for _ in range(n+1)]
    for a,b,c in itertools.product(range(n),repeat=3):T[a][b][c]=E[a][b][c]
    for a,(typ,e,j)in enumerate(labs):
      d=1 if typ=='L' else 2
      T[a][n][n]=T[n][a][n]=T[n][n][a]=d
    validate_general(T)
    return T

def structure_checks(p,t):
    # Basis b(a,e,b)=x^a delta_e g^b. Nonzero scalars are powers of zeta_(4p).
    B=list(itertools.product(range(p),range(2),range(2)))
    def mul(X,Y):
      a,e,b=X;c,f,d=Y
      return [] if e!=f else [(((a+(-1)**b*c)%p,e,b^d),(2*p*t*e*b*d)%(4*p))]
    def comul(X):
      a,e,b=X
      return [((a,s,b),(((-1)**s*a)%p,e^s,b))for s in range(2)]
    def pairing(X,Y):
      a,e,b=X;c,f,d=Y
      return None if e!=d or f!=b else (4*a*c+p*t*b*d)%(4*p)
    def one_product(u,v):return None if u is None or v is None else (u+v)%(4*p)
    def add_terms(vals):
      # In each tested pairing identity support forces at most one nonzero summand.
      vals=[x for x in vals if x is not None];assert len(vals)<=1
      return vals[0]if vals else None
    for X,Y in itertools.product(B,repeat=2):assert pairing(X,Y)==pairing(Y,X)
    for X,Y,Z in itertools.product(B,repeat=3):
      m=mul(X,Y);lhs=None if not m else one_product(pairing(m[0][0],Z),m[0][1])
      rhs=add_terms([one_product(pairing(X,U),pairing(Y,V))for U,V in comul(Z)])
      assert lhs==rhs,(t,X,Y,Z,lhs,rhs)
    def star(X):
      a,e,b=X
      return ((-(-1)**b*a)%p,e,b),(2*p*t*e*b)%(4*p)
    def antipode(X):
      a,e,b=X
      return ((-(-1)**(e+b)*a)%p,e,b),(2*p*t*e*b)%(4*p)
    for X,Y in itertools.product(B,repeat=2):
      XY=mul(X,Y)
      if XY:
        Z,c=XY[0];S,c2=star(Z);lhs=[(S,(c2-c)%(4*p))]
      else:lhs=[]
      SX,c=star(X);SY,d=star(Y);rhs=[(Z,(c+d+v)%(4*p))for Z,v in mul(SY,SX)]
      assert lhs==rhs
    for X in B:
      SX,c=star(X);lhs=sorted((U,V,c)for U,V in comul(SX));rhs=[]
      for U,V in comul(X):
        SU,a=star(U);SV,b=star(V);rhs.append((SU,SV,(a+b)%(4*p)))
      assert lhs==sorted(rhs)
    # Exact copairing unitarity in Q(zeta_(4p)). Coefficients have common
    # denominator p^2, so all arithmetic below is integral.
    import sympy as s
    z=s.Symbol('z');mod=s.Poly(s.cyclotomic_poly(4*p,z),z);deg=mod.degree()
    powers=[[int(s.rem(s.Poly(z**a,z),mod).nth(j))for j in range(deg)]for a in range(4*p)]
    def reduce_terms(terms):
      out={}
      for X,a,c in terms:
        v=out.setdefault(X,[0]*deg)
        for j,q in enumerate(powers[a%(4*p)]):v[j]+=c*q
      return {X:v for X,v in out.items()if any(v)}
    gamma=[(( (a,e,b),(c,b,e)),(-4*a*c-p*t*e*b)%(4*p),1)
           for a,c in itertools.product(range(p),repeat=2)for e,b in itertools.product(range(2),repeat=2)]
    expected={((0,e,0),(0,f,0)):[p*p]+[0]*(deg-1)for e,f in itertools.product(range(2),repeat=2)}
    gamma_dr=[]
    for (X,Y),a,c in gamma:
      SX,b=antipode(X);gamma_dr.append(((SX,Y),(a+b)%(4*p),c))
    for G in [gamma,gamma_dr]:
      assert reduce_terms(G)==reduce_terms([((Y,X),a,c)for (X,Y),a,c in G])
      Gstar=[]
      for (X,Y),a,c in G:
        SX,b=star(X);SY,d=star(Y);Gstar.append(((SX,SY),(b+d-a)%(4*p),c))
      product=[]
      for (X,Y),a,c in Gstar:
        for (U,V),b,d in G:
          for W,e in mul(X,U):
            for Z,f in mul(Y,V):product.append(((W,Z),a+b+e+f,c*d))
      assert reduce_terms(product)==expected
    # DR Corollary3.19 P-3/P-4, with common denominator p^2.
    lhs=[];rhs=[]
    for (X,Y),a,c in gamma:
      for U,V in comul(X):lhs.append(((U,V,Y),a,p*c))
    for (X,Y),a,c in gamma:
      for (U,V),b,d in gamma:
        for W,e in mul(Y,V):rhs.append(((X,U,W),a+b+e,c*d))
    assert reduce_terms(lhs)==reduce_terms(rhs) # (Delta tensor id)gamma=gamma13 gamma23
    lhs=[];rhs=[]
    for (X,Y),a,c in gamma:
      for U,V in comul(Y):lhs.append(((X,U,V),a,p*c))
    for (X,Y),a,c in gamma:
      for (U,V),b,d in gamma:
        for W,e in mul(X,U):rhs.append(((W,Y,V),a+b+e,c*d))
    assert reduce_terms(lhs)==reduce_terms(rhs) # (id tensor Delta)gamma=gamma12 gamma13
    # Check sqrt(p)*phi from the actual associator copairing gamma0.
    # DR equation2.28 inserts S^-1 after Gamma_DR=S Gamma0, so gamma0 is
    # the associator copairing; gamma_dr above is (id tensor Gamma_DR)coev.
    # The common denominator p cancels the two sqrt(p) normalization factors.
    for X in B:
      terms=[]
      for (U,V),a,c in gamma:
        for W,b in mul(V,X):
          if W[0]==0 and W[2]==0:
            SU,d=antipode(U);terms.append((SU,a+b+d,c))
      a,e,b=X
      formula=[((u,b,e),-4*((-1)**e)*u*a-p*t*e*b,1)for u in range(p)]
      assert reduce_terms(terms)==reduce_terms(formula)
    # Each pairing block is a Fourier matrix times a root of unity: rank 4p.
    # Normalized Haar h(b(a,e,b))=delta_a0 delta_b0 /2.
    # h is two-sided and lambda=sqrt(4p)*h; the inverse pairing has
    # coefficients (1/p) delta_e,d delta_f,b zeta_p^(-a*c) i^(-t*b*d).
    # (h tensor h)(gamma)=1/(4p); hence (lambda tensor lambda)(gamma)=1.
    return {'basis_size':4*p,'symmetric_pairing_entries_checked':(4*p)**2,
            'hopf_pairing_products_checked':(4*p)**3,
            'hopf_star_products_checked':(4*p)**2,
            'hopf_star_coproducts_checked':4*p,
            'copairing_unitary_exact':True,
            'DR_dual_convention':'Hvee=(Hstar)op,cop; Gamma=S Gamma0',
            'DR_coevaluation_symmetric_and_unitary_exact':True,
            'DR_associator_copairing':'gamma0 via inverse-antipode correction in DR equation2.28',
            'DR_P3_P4_copairing_identities_exact':True,
            'DR_odd_associator_Fourier_formula_checked':4*p,
            'pairing_nondegenerate':'four Fourier_p blocks times roots of unity',
            'cointegral_normalization_squared':4*p}

def main():
    C=json.load(open(ROOT/'work/verification_corpus.json'))['tensors'];out={}
    for t in [0,1]:
      T=extension_tensor(5,t);matches=[]
      for z in [21,965,1225,1673]:
        rid=f'R9_2_{z}';m=based_iso(C[rid],T)
        if m is not None:matches.append({'id':rid,'basis_map_source_to_model':m})
      out[str(t)]={'checks':structure_checks(5,t),'even_labels':even_tensor(5,t)[0],
                   'tensor':T,'matches':matches}
    (Path(__file__).parent/'hopf20_check.json').write_text(json.dumps(out,indent=2)+'\n')
    print({t:x['matches']for t,x in out.items()})
if __name__=='__main__':main()
