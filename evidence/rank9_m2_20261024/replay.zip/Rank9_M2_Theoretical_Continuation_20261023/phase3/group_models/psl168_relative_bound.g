G:=PSL(3,2);;
P:=SylowSubgroup(G,7);; p:=GeneratorsOfGroup(P)[1];;
exponents:=Set(List(Elements(Normalizer(G,P)),g->First([1..6],j->p^g=p^j)));;
Print("ORDER ",Size(G)," NORMALIZER7_ORDER ",Size(Normalizer(G,P))," EXPONENTS ",exponents," H4_MULTIPLIERS ",Set(List(exponents,x->x^2 mod 7)),"\n");
hs:=Filtered(List(ConjugacyClassesSubgroups(G),Representative),H->Size(H)=24);;
Print("S4_SUBGROUP_CLASSES ",Length(hs)," G_MULTIPLIER ",AbelianInvariantsMultiplier(G),"\n");
cover:=EpimorphismSchurCover(G);;
for H in hs do
 witness:=false;
 for a in Elements(H) do
  for b in Elements(H) do
   if a*b=b*a then
    aa:=PreImagesRepresentative(cover,a);;bb:=PreImagesRepresentative(cover,b);;
    if aa*bb<>bb*aa then witness:=true;fi;
   fi;
  od;
 od;
 Print("SUBGROUP ",StructureDescription(H)," MULTIPLIER ",AbelianInvariantsMultiplier(H)," RESTRICTED_SCHUR_COMMUTATOR_NONTRIVIAL ",witness,"\n");
od;
QUIT;
