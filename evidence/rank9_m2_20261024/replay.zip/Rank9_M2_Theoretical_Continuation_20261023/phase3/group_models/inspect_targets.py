from pathlib import Path
import itertools,json,sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work'))
from common import based_iso,digest
TENS=json.load(open(ROOT/'work/verification_corpus.json'))['tensors'];P={r['id']:r for r in json.load(open(ROOT/'results/unresolved.json'))}
registry=json.load(open(ROOT/'work/lower_positive_registry.json'))
print(type(registry).__name__)
if isinstance(registry,dict):print(registry.keys());registry=registry.get('models',registry.get('records',[]))
def close(T,gens):
 S=set(gens)|{0}
 while True:
  K=S|{k for a in S for b in S for k in range(9)if T[a][b][k]}
  if S==K:return sorted(S)
  S=K
out=[]
for rid in ['R9_2_1965','R9_2_12','R9_2_92','R9_2_959']:
 T=TENS[rid];d=[int(x[0])for x in P[rid]['dimension_coefficients']];du=[next(j for j in range(9)if T[i][j][0])for i in range(9)];inv=[i for i in range(9)if d[i]==1]
 subs=[]
 for mask in range(256):
  S=[0]+[i+1 for i in range(8)if mask>>i&1]
  if close(T,S)!=S or any(du[i]not in S for i in S):continue
  if len(S)==9:continue
  st=[[[T[i][j][k]for k in S]for j in S]for i in S]
  matches=[]
  for r in registry:
   tt=r.get('tensor',r.get('fusion_tensor'))
   if tt is not None and len(tt)==len(S):
    m=based_iso(st,tt)
    if m is not None:matches.append({'id':r.get('id'), 'model':r.get('model'),'map':m})
  subs.append({'basis':S,'dimension':sum(d[i]**2 for i in S),'dimensions':[d[i]for i in S],'dual':[S.index(du[i])for i in S],'known_matches':matches})
 row={'id':rid,'dimensions':d,'dual':du,'commutative':all(T[i][j]==T[j][i]for i,j in itertools.product(range(9),repeat=2)),'adjoint_basis':close(T,{k for i in range(9)for k in range(9)if T[i][du[i]][k]}),'invertibles':inv,'invertible_actions':[{'g':g,'left':[T[g][i].index(1)for i in range(9)],'right':[T[i][g].index(1)for i in range(9)]}for g in inv],'subrings':subs}
 out.append(row);print(json.dumps(row,indent=2))
(ROOT/'phase3/group_models/target_structure.json').write_text(json.dumps(out,indent=2)+'\n')
