"""Explicit sign-cup-Schur relative cocycle and exact GT fusion characters.
Categorical formulas and every coefficient independently audited in
phase3/audit_models/S5_RELATIVE_TWIST_AUDIT.md.
"""
from pathlib import Path
import json,itertools,sys
import numpy as np
P=Path(__file__).parent;ROOT=P.parents[1]
sys.path.insert(0,str(ROOT/'work'))
from common import based_iso,digest

def gf2_solve(mat,b):
 n=len(mat[0]);piv={}
 for aa,bb in zip(mat,b):
  row=sum((int(v)&1)<<i for i,v in enumerate(aa))|((int(bb)&1)<<n)
  while row&((1<<n)-1):
   p=(row&((1<<n)-1)).bit_length()-1
   if p in piv:row^=piv[p]
   else:piv[p]=row;break
  else:
   if row>>n:return None,None
 free=[j for j in range(n)if j not in piv]
 def solve(initial,inhom):
  v=initial
  for p,row in sorted(piv.items()):
   z=((row>>n)&inhom)^((row&v).bit_count()%2)
   if z:v|=1<<p
  return np.array([(v>>i)&1 for i in range(n)],dtype=int)
 return solve(0,1),[solve(1<<j,0)for j in free]

def canonical_primitive():
 pairs=[(a,b)for a in range(1,4)for b in range(1,4)];ix={p:i for i,p in enumerate(pairs)}
 mat=[];rhs=[]
 for a,b,c in itertools.product(range(4),repeat=3):
  row=[0]*len(pairs)
  for pair,coef in[((b,c),1),((a^b,c),-1),((a,b^c),1),((a,b),-1)]:
   if pair in ix:row[ix[pair]]+=coef
  mat.append(row);rhs.append(2*((a&1)^((a>>1)&1))*(b&1)*((c>>1)&1))
 M=np.array(mat);rhs=np.array(rhs);_,ker=gf2_solve(mat,[0]*len(mat))
 for bits in itertools.product([0,1],repeat=len(ker)):
  q0=np.zeros(9,dtype=int)
  for k,b in zip(ker,bits):
   if b:q0^=k
  delta=rhs-M@q0
  assert all(v%2==0 for v in delta)
  q1,_=gf2_solve(mat,delta//2)
  if q1 is not None:
   q=(q0+2*q1)%4;assert all((M@q-rhs)%4==0)
   out=[[0]*4 for _ in range(4)]
   for(a,b),i in ix.items():out[a][b]=int(q[i])
   return out
 raise AssertionError('no primitive')

def build_data():
 D=json.loads((P/'s5_schur_data.json').read_text().replace('\\\n',''))
 M=D['table'];n=len(M);H=D['H'];hs=set(H);eps=D['sign'];a=D['alpha'];inv=[next(j for j in range(n)if M[i][j]==0)for i in range(n)]
 order=[]
 for i in range(n):
  j=0
  for k in range(1,121):
   j=M[j][i]
   if j==0:order.append(k);break
 transp=next(h for h in H if eps[h]and order[h]==2)
 ext=a[transp][transp];a=[[a[i][j]^(ext*eps[i]*eps[j])for j in range(n)]for i in range(n)]
 assert all((a[j][k]^a[M[i][j]][k]^a[i][M[j][k]]^a[i][j])==0 for i,j,k in itertools.product(range(n),repeat=3))
 x={h:eps[h]^D['swap45'][h]for h in H};y={h:D['swap45'][h]for h in H}
 vars=H[1:];ix={g:i for i,g in enumerate(vars)};mat=[];rhs=[]
 for h,k in itertools.product(H,repeat=2):
  row=[0]*len(vars)
  for t in[h,k,M[h][k]]:
   if t:row[ix[t]]^=1
  mat.append(row);rhs.append(a[h][k]^(x[h]*y[k]))
 f,_=gf2_solve(mat,rhs);assert f is not None
 f={0:0,**{g:int(f[i])for g,i in ix.items()}}
 cp=canonical_primitive();ps={(h,k):(cp[x[h]+2*y[h]][x[k]+2*y[k]]+2*eps[h]*f[k])%4 for h,k in itertools.product(H,repeat=2)}
 def w(g,h,k):return 4*eps[g]*a[h][k]
 def psi(h,k):return 2*ps[h,k]
 assert all((psi(k,l)-psi(M[h][k],l)+psi(h,M[k][l])-psi(h,k)-w(h,k,l))%8==0 for h,k,l in itertools.product(H,repeat=3))
 return D,M,inv,H,hs,eps,x,y,a,w,psi,ps

def main():
 D,M,inv,H,hs,eps,x,y,a,w,psi,ps=build_data();n=len(M)
 def prod(*args):
  z=0
  for g in args:z=M[z][g]
  return z
 def conj(g,h):return prod(g,h,inv[g])
 cosets=[];seen=set()
 for t in range(n):
  if t in seen:continue
  supp={prod(h,t,k)for h in H for k in H};seen|=supp
  K=[h for h in H if prod(inv[t],h,t)in hs]
  L=[];used=set()
  for h in H:
   if h in used:continue
   L.append(h);used|={M[h][k]for k in K}
  dec={prod(l,t,k):(l,k)for l in L for k in H}
  assert len(dec)==len(supp)
  def alpha(s,z):
   b=prod(inv[t],s,t);c=prod(inv[t],z,t)
   return(psi(s,z)+w(s,t,c)-w(s,z,t)-w(t,b,c)-psi(b,c))%8
  al={(s,z):alpha(s,z)for s,z in itertools.product(K,repeat=2)}
  chars=[]
  if t==0:
   assert len(K)==12 and all(e==0 for e in al.values())
   for i,j in itertools.product(range(2),repeat=2):chars.append({h:((-1)**(i*x[h]+j*y[h]),0)for h in K})
   central=[h for h in H if all(M[h][k]==M[k][h]for k in H)]
   for j in range(2):chars.append({h:((2 if h in central else 0 if x[h] else -1)*(-1)**(j*y[h]),0)for h in K})
  elif len(K)==2:
   s=next(k for k in K if k);e=al[s,s];assert e%2==0
   for j in range(2):chars.append({0:(1,0),s:(1,(e//2+4*j)%8)})
  elif len(K)==4:
   assert all(M[s][s]==0 for s in K)
   radical=[s for s in K if all(al[s,z]==al[z,s]for z in K)]
   if radical==[0]:chars.append({s:(2 if s==0 else 0,0)for s in K})
   elif len(radical)==4:
    u,v=K[1:3];uv=M[u][v]
    for j,k in itertools.product(range(2),repeat=2):
     eu=(al[u,u]//2+4*j)%8;ev=(al[v,v]//2+4*k)%8
     chars.append({0:(1,0),u:(1,eu),v:(1,ev),uv:(1,(eu+ev-al[u,v])%8)})
   else:raise AssertionError(radical)
  else:raise AssertionError(('unexpected stabilizer',len(K)))
  cosets.append({'t':t,'K':K,'L':L,'support':supp,'dec':dec,'alpha':al,'chars':chars})
 print('skeleton',[(len(c['support']),len(c['K']),[chi[0][0]for chi in c['chars']])for c in cosets],flush=True)
 objs=[(c,ch)for c in cosets for ch in c['chars']];rank=len(objs)
 # Character on grade v of R_(v^-1 a v)^-1 L_a.
 def char_at(obj,v,g):
  c,chi=obj;t=c['t'];l,k=c['dec'][v];u=prod(l,t);s=prod(inv[l],g,l)
  if s not in chi:return(0,0)
  c0=prod(inv[t],s,t);b=prod(inv[v],g,v)
  exponent=psi(g,l)+w(l,s,t)-w(g,l,t)-psi(l,s)-w(l,t,c0)
  exponent+=w(u,c0,k)+psi(c0,k)-w(g,u,k)-w(u,k,b)-psi(k,b)
  mag,e=chi[s]
  return(mag,(e+exponent)%8)
 cache={}
 for oi,obj in enumerate(objs):
  c,chi=obj
  for v in c['support']:
   for g in H:
    if prod(inv[v],g,v)in hs:cache[oi,v,g]=char_at(obj,v,g)
 T=[[[0]*rank for _ in range(rank)]for _ in range(rank)]
 for i,j,k in itertools.product(range(rank),repeat=3):
  ci,_=objs[i];cj,_=objs[j];ck,chik=objs[k];t=ck['t'];total=[0]*8
  for g in ck['K']:
   mk,ek=chik[g];b=prod(inv[t],g,t)
   if not mk:continue
   for l in ci['L']:
    u=prod(l,ci['t']);v=prod(inv[u],t);h=prod(inv[u],g,u)
    if v not in cj['support']or h not in hs:continue
    mi,ei=cache[i,u,g];mj,ej=cache[j,v,h]
    e=(ei+ej-ek+w(u,h,v)-w(g,u,v)-w(u,v,b))%8
    total[e]+=mi*mj*mk
  coeff=[total[e]-total[e+4]for e in range(4)]
  assert coeff[1:]==[0,0,0]and coeff[0]%len(ck['K'])==0,(i,j,k,coeff)
  T[i][j][k]=coeff[0]//len(ck['K']);assert T[i][j][k]>=0,(i,j,k,T[i][j][k])
 assert all(T[0][i][j]==T[i][0][j]==int(i==j)for i,j in itertools.product(range(rank),repeat=2))
 assert all(sum(T[i][j][u]*T[u][k][l]for u in range(rank))==sum(T[j][k][u]*T[i][u][l]for u in range(rank))for i,j,k,l in itertools.product(range(rank),repeat=4))
 matches=[];C=json.load(open(ROOT/'work/verification_corpus.json'))['tensors']
 if rank==9:
  for rid in ['R9_2_12','R9_2_92','R9_2_959']:
   bm=based_iso(C[rid],T)
   if bm is not None:matches.append({'id':rid,'basis_map_source_to_model':bm})
 proof='phase3/group_models/S5_RELATIVE_TWIST.md'
 audit='phase3/audit_models/S5_RELATIVE_TWIST_AUDIT.md'
 audit_record=json.load(open(ROOT/'phase3/audit_models/s5_relative_twist_audit.json'))
 assert audit_record['status']=='PASS' and audit_record['id']=='R9_2_92'
 assert matches==[{'id':'R9_2_92','basis_map_source_to_model':audit_record['basis_map_source_to_model']}]
 out={'status':'audited_unitary_model','construction':'C(S5, sign cup Schur, S3 x C2, explicit trivialization)','proof':proof,'independent_audit':audit,'rank':rank,'dimensions':[len(c['L'])*chi[0][0]for c,chi in objs],'tensor':T,'tensor_sha256':digest(T),'matches':matches,'H':H,'alpha_F2':a,'psi_exponents_mod4':[[h,k,ps[h,k]]for h,k in itertools.product(H,repeat=2)],'cosets':[{'representative':c['t'],'size':len(c['support']),'stabilizer':c['K'],'projective_irrep_dimensions':[ch[0][0]for ch in c['chars']]}for c in cosets]}
 (P/'s5_relative_twist.json').write_text(json.dumps(out,indent=2)+'\n')
 models=[{'id':m['id'],'status':'unitarily_realized','model':out['construction'],'tensor':T,'tensor_sha256':digest(T),'basis_map_source_to_model':m['basis_map_source_to_model'],'proof':proof,'independent_audit':audit,'audit_record':'phase3/audit_models/s5_relative_twist_audit.json','constructor':'phase3/group_models/s5_relative_twist.py','cochain_data':'phase3/group_models/s5_relative_twist.json'}for m in matches]
 (P/'models.json').write_text(json.dumps(models,indent=2)+'\n')
 print('dimensions',out['dimensions'],'matches',matches,flush=True)
if __name__=='__main__':main()
