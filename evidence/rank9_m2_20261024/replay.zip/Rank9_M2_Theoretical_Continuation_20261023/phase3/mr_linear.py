"""Exact sparse elimination for the former mixed-MR Z/16 linear system.

Uses exactly the recorded tensor-functor, action, central transport and algebra
equivariance equations, then replays every equation on the resulting solution.
"""
from pathlib import Path
import sys,json,time,itertools,collections
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'sources'),str(ROOT/'phase2/weak_integral')]

def linear_solve(n,equations,mod):
    rows={};defs=[]
    for terms,b in equations:
      a={}
      for c,j in terms:a[j]=(a.get(j,0)+c)%mod
      a={j:c for j,c in a.items()if c};key=tuple(sorted(a.items()))
      if not a:
        if b%mod:return None
      elif key in rows and rows[key]!=b%mod:return None
      else:rows[key]=b%mod
    rows=[(dict(a),b)for a,b in rows.items()];M=mod
    while rows:
      candidates=[(len(a),r,next(j for j,c in a.items()if c%2))for r,(a,b)in enumerate(rows)if any(c%2 for c in a.values())]
      if not candidates:
        if any(b%2 for a,b in rows):return None
        M//=2;rows=[({j:c//2 for j,c in a.items()},b//2)for a,b in rows]
        if M==1:break
        continue
      _,r,j=min(candidates);a,b=rows.pop(r);u=pow(a[j],-1,M)
      a={k:c*u%M for k,c in a.items()};b=b*u%M
      defs.append((j,{k:c for k,c in a.items()if k!=j},b,M))
      new=[];seen={}
      for v,w in rows:
        q=v.get(j,0)
        if q:
          for k,c in a.items():
            z=(v.get(k,0)-q*c)%M
            if z:v[k]=z
            elif k in v:del v[k]
          w=(w-q*b)%M
        if not v:
          if w:return None
          continue
        key=tuple(sorted(v.items()))
        if key in seen:
          if seen[key]!=w:return None
        else:seen[key]=w;new.append((v,w))
      rows=new
    x=[0]*n
    for j,a,b,M in reversed(defs):x[j]=(b-sum(c*x[k]for k,c in a.items()))%M
    assert all((sum(c*x[j]for c,j in terms)-b)%mod==0 for terms,b in equations)
    return x

def equations(p,r,v,bits):
    # Load the prior equation generator without invoking its Z3 solver.
    src=(ROOT/'phase2/weak_integral/mr_mixed_action.py').read_text()
    src=src[:src.index("if __name__=='__main__'")]
    src=src.replace('import sys,json,itertools,time,z3','import sys,json,itertools,time')
    src=src.replace("jj={l:z3.BitVec('j%d_%d_%d'%l,bits)for l in labs};cc=[z3.BitVec(f'c{a}',bits)for a in range(N)]",'jj={l:i for i,l in enumerate(labs)};cc=list(range(len(labs),len(labs)+N))')
    src=src.replace("s=z3.SolverFor('QF_BV');s.set(timeout=90000);eqs=[]",'eqs=[]')
    src=src.replace('eqs.append((terms,rhs%mod));s.add(sum(co*(jj[k]if isinstance(k,tuple)else cc[k])for co,k in terms)==rhs)','eqs.append(([(co,jj[k]if isinstance(k,tuple)else cc[k])for co,k in terms],rhs%mod))')
    src=src[:src.index(' start=time.time();status=s.check()')]+" return {'eqs':eqs,'labs':labs,'B':B,'R':R,'sg':sg,'g':g,'j':j,'N':N,'mod':mod}\n"
    ns={'__file__':str(ROOT/'phase2/weak_integral/mr_mixed_action.py')};exec(src,ns)
    return ns['build'](p,r,v,bits)

if __name__=='__main__':
    p,r,v,bits=map(int,sys.argv[1:])if len(sys.argv)>1 else(2,15,1,4)
    t=time.time();d=equations(p,r,v,bits);L=len(d['labs']);x=linear_solve(L+d['N'],d['eqs'],d['mod'])
    out={'status':'unsatisfiable_linear_system'if x is None else'sat_exactly_verified','p':p,'r':r,'v':v,'bits':bits,'seconds':time.time()-t,'equations':len(d['eqs'])}
    if x is not None:out.update({'modulus':d['mod'],'labels':d['B'],'tensor':d['R'],'automorphism':d['sg'],'tensorator_labels':d['labs'],'tensorator_exponents':x[:L],'square_coherence_exponents':x[L:],'boson_index':d['g'],'boson_character':d['j']})
    (Path(__file__).parent/f'mr_linear_{p}_{r}_{v}_{bits}.json').write_text(json.dumps(out,indent=2)+'\n')
    print(out['status'],'seconds',out['seconds'],flush=True)
