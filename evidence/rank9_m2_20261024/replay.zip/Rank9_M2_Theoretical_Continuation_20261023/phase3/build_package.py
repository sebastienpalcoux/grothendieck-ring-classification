"""Package the corrected audit plus preserved historical research stages."""
from pathlib import Path
import hashlib
import io
import json
import os
import shutil
import zipfile

P = Path(__file__).resolve().parent
B = P.parent
W = B.parent
NAME = 'Rank9_M2_Theoretical_Continuation_20261023'
STAGE = W / 'rank9_phase3_package_stage'
BASE = W / 'Rank9_M2_Established_Methods_20261023'
SKIP = {'__pycache__', 'gap_root', 'gap_debs', '.library_helpers', 'previous_package', 'phase2_package'}
SUFFIX = {'.py', '.cpp', '.md', '.json', '.g', '.tex', '.bib', '.gz', '.log'}


def main():
    if STAGE.exists():
        shutil.rmtree(STAGE)
    shutil.copytree(BASE, STAGE)
    (STAGE / 'baseline_documents').mkdir()
    for name in ('README.md', 'HANDOFF.md'):
        shutil.move(STAGE / name, STAGE / 'baseline_documents' / name)
    for phase in ('phase2', 'phase3'):
        for directory, dirs, files in os.walk(B / phase):
            dirs[:] = [d for d in dirs if d not in SKIP and not d.startswith('.')]
            for name in files:
                if name == 'package_build.json':
                    continue
                source = Path(directory) / name
                if source.suffix not in SUFFIX:
                    continue
                target = STAGE / source.relative_to(B)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)
    summary = json.loads((P / 'results/summary.json').read_text())
    counts = f"{summary['excluded']:,} excluded, {summary['modelled']} unitary models, {summary['unresolved']} unresolved"
    (STAGE / 'README.md').write_text(f'''# Rank-nine multiplicity-two: corrected audit and continued research

Current verified partition: **{counts}**, out of 2,083 exact-M2 rings.

Read **[the corrected audit report](phase3/REPORT.md)** first. The current
classification is **`phase3/results/ledger.json`**, with exact residual
profiles in `phase3/results/unresolved.json`.

The earlier `results/` and `phase2/results/` ledgers are historical snapshots.
Their half-E6 subring exclusions are superseded: seven formerly excluded
rings now have unitary models; three others have valid replacement proofs.
All 26 invalid structural claims have been removed from the current ledger.

Install `requirements.txt` and provide `g++` for finite certificate replay.
Run `python3 phase3/verify_audit.py` for current partition, model maps and
explicit negative-subring checks. Add `--fresh` to rebuild the corrected
subring pass and restored model constructors, and independently replay
the new relative-cocycle models, Hopf construction, and center exclusions.
The earlier exclusion replays are available through
`python3 phase2/verify_continuation.py --fresh` and the original `verify.py`;
their printed historical totals are not the corrected classification.
Fresh original replays and independent categorical audits are documented
under `phase3/`. Candidate files are not accepted results; `phase3/accepted.json`
controls additions.

The original 142 multiplicity-one IDs and their explicit basis transports
are preserved. Research continues on the residual cases. No GitHub repository
or website has been changed. Publication remains deferred.
''')
    (STAGE / 'HANDOFF.md').write_text(f'''# Current research handoff

Verified partition: {counts}. Use phase3/results/, not the historical ledgers.
The full audit and correction are explained in phase3/REPORT.md.

Preserve the general-complex exclusion scope and unitary model existence
claims. Feasible necessary conditions, unfinished model leads, timed-out
solvers and signed existence gates alone are not classifications.

Continue the open cases from the saved artifacts. R9_2_941 exactly matches
the published dimension-504 open ring of Question 1.14 in arXiv:2507.07023v2.

Online publication is deferred. A later authorized revision should update
rank nine/multiplicity two in the usual ordered tables of both repositories
and the public GitHub Atlas. The former private Atlas is out of scope.
''')
    old = STAGE / 'manifests/SHA256SUMS.json'
    if old.exists():
        original = json.loads(old.read_text())
        mapped = {('baseline_documents/' + name if name in ('README.md', 'HANDOFF.md') else name): h
                  for name, h in original.items()}
        assert all(hashlib.sha256((STAGE / name).read_bytes()).hexdigest() == h for name, h in mapped.items())
        old.unlink()
        (STAGE / 'manifests/BASELINE_SHA256SUMS.json').write_text(json.dumps(mapped, indent=2) + '\n')
    snapshot = {str(f.relative_to(STAGE)): f.read_bytes()
                for f in sorted(STAGE.rglob('*')) if f.is_file()
                and f != STAGE / 'SHA256SUMS.json'}
    hashes = {name: hashlib.sha256(data).hexdigest() for name, data in snapshot.items()}
    snapshot['SHA256SUMS.json'] = (json.dumps(hashes, indent=2) + '\n').encode()
    (STAGE / 'SHA256SUMS.json').write_bytes(snapshot['SHA256SUMS.json'])
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, data in snapshot.items():
            z.writestr(str(Path(NAME) / name), data)
    payload = buffer.getvalue()
    with zipfile.ZipFile(io.BytesIO(payload)) as z:
        assert z.testzip() is None
        assert all(hashlib.sha256(z.read(str(Path(NAME) / name))).hexdigest() == h
                   for name, h in hashes.items())
    temporary = W / (NAME + '.building.zip')
    target = W / (NAME + '.zip')
    temporary.write_bytes(payload)
    os.replace(temporary, target)
    assert hashlib.sha256(target.read_bytes()).digest() == hashlib.sha256(payload).digest()
    assert all(hashlib.sha256((STAGE / name).read_bytes()).hexdigest() == h for name, h in hashes.items())
    print(json.dumps({'file': str(target), 'bytes': len(payload), 'files': len(hashes) + 1,
                      'sha256': hashlib.sha256(payload).hexdigest(), 'counts': summary}, indent=2))


if __name__ == '__main__':
    main()
