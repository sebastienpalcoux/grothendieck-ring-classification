from symmetry import *
R=qc.inputs('R9_2_1975');A,b,m=build(R,6);out=[]
for test in['absent','fermion_only','boson_only','boson_or_fermion']:
 forbidden=[]
 for col in m['singleton_g_variables']:
  vals=[tuple(map(Q,x))for x in col['trace_values']]
  plus=[(Q(1),Q(0))]*6;minus=[(Q((-1)**(j+1)),Q(0))for j in range(6)]
  if test=='absent'or(test=='fermion_only'and vals!=minus)or(test=='boson_only'and vals!=plus)or(test=='boson_or_fermion'and vals not in[plus,minus]):forbidden.append(col['index'])
 AA=A+[[int(j in forbidden)for j in range(len(A[0]))]];bb=b+[0]
 y,why=qc.exact_separator(AA,bb,timeout=60);row={'test':test,'ray':y,'solver_report':why,'outcome':'case_excluded'if y else'no_conclusion'}
 if y:assert qc.verify_ray(AA,bb,y);row['bTy']=sum(x*z for x,z in zip(bb,y))
 out.append(row);print(test,row['outcome'],row.get('bTy'),flush=True)
 Path(__file__).with_suffix('.json').write_text(json.dumps({'id':'R9_2_1975','attempts':out,'note':'No categorical exclusion unless every genuine central-structure case is eliminated'},indent=2)+'\n')
