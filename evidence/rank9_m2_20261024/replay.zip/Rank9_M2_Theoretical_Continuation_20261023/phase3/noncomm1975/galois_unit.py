"""Exact noncommutative extension of Galois-unit restriction integrality.
Uses a separate coefficient-solving implementation of polynomial interpolation.
"""
from center import *

def run(rid):
 R=qc.inputs(rid);a=chars(R);n=len(R);f,K,ds,D,pD,emb=a.fp();assert f.degree()==2
 factors=[]
 for p,m in a.cf:
  p=s.Poly(p,t,domain=s.QQ)
  if p not in factors:factors.append(p)
 assert all(p.degree()in(1,2)for p in factors)
 for p in factors:assert discover_roots(p,K)is not None
 W=s.Matrix.hstack(*s.Matrix.vstack(*(a.N[i]*a.N[j]-a.N[j]*a.N[i]for i in range(n)for j in range(i))).nullspace())
 assert W.cols==5 and n==9
 P=W*(W.T*W).inv()*W.T;Einv=(s.eye(n)+P)/2;T=Einv*a.C
 m=sum(p.degree()for p in factors);unknown=s.symbols('u:'+str(m));poly=sum(unknown[i]*t**i for i in range(m));equations=[]
 for p in factors:
  target=s.Poly(1 if p.degree()==1 else t*t/p.nth(0),t,domain=s.QQ).rem(p)
  rem=s.rem(poly,p.as_expr(),t)
  equations.extend(s.Poly(rem-target.as_expr(),t).all_coeffs())
 sol=s.solve(equations,unknown);assert len(sol)==m;coeff=[sol[x]for x in unknown]
 V=sum((coeff[i]*T**i for i in range(m)),s.zeros(n));v=list(V[0,:])
 assert V==sum((v[i]*a.N[i]for i in range(n)),s.zeros(n))
 good=all(x.is_Integer and x>=0 for x in v)and v[0]==1
 out={'id':rid,'outcome':'no_conclusion'if good else'candidate_exclusion','forced_restriction':list(map(str,v)),'polynomial_ascending':list(map(str,coeff)),'formal_factors':[list(map(str,p.all_coeffs()))for p in factors],'degree_operator':'2I-P_scalar','scalar_rank':5,'dimension':ec(sum((v[i]*ds[i]for i in range(n)),K.zero)),'expected_dimension':ec(D/(K(pD.nth(0))/D))}
 assert sum((v[i]*ds[i]for i in range(n)),K.zero)==D/(K(pD.nth(0))/D)
 Path(__file__).with_name('galois_'+rid+'.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2),flush=True)
 return out
if __name__=='__main__':
 for rid in['R9_2_1975','R9_2_1848']:run(rid)
