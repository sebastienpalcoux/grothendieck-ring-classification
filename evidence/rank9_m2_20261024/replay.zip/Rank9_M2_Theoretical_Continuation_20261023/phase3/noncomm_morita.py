"""Morita Gram conditions with the correct row orientation for noncommutative rings.

The categorical identity is derived in noncomm_morita.md. No baseline source
files are modified; only the local module-matrix verification orientation differs.
"""
from pathlib import Path
import sys,json,inspect,itertools,time,collections
P=Path(__file__).resolve().parent;ROOT=P.parent
sys.path[:0]=[str(ROOT/'sources'),str(ROOT/'work')]
import module_dual_gram as mdg
import full_morita_gram as fmg
from scalar_characters import chars
from higher_traces import farkas,check_farkas
ns=dict(mdg.__dict__)
src=inspect.getsource(mdg.module_matrices)
assert 'R[i][j][k]*Ms[k]'in src
src=src.replace('R[i][j][k]*Ms[k]','R[j][i][k]*Ms[k]')
exec(src,ns);module_matrices=ns['module_matrices']
mdg.module_matrices=module_matrices;fmg.module_matrices=module_matrices

def discover(rid):
 C=json.load(open(ROOT/'work/verification_corpus.json'));R=C['tensors'][rid]
 anti=json.load(open(P/f'noncomm_anti_{rid}.json'));g=anti['involution'];assert anti['complete']
 assert all(R[g][i]==R[i][g]for i in range(len(R)))
 a=chars(R).fp();results=[]
 for k,TT in enumerate(anti['branches']):
  T=[sum(m,[])for m in TT];labs,M=module_matrices(R,g,anti['fixed'],T)
  G=fmg.full_gram(M);nr=len(fmg.first_columns(M,g));rnk=G.rank();assert G==G.T
  if rnk>nr:results.append({'T':TT,'kind':'rank','rank':rnk,'dual_rank':nr});continue
  print(rid,'branch',k,'rank',rnk,'dual_rank',nr,flush=True);found=None
  for i in range(1,len(labs)):
   try:ab,meta=mdg.system(R,g,anti['fixed'],T,i,a)
   except TimeoutError:continue
   if ab is None:found={'kind':'partial','module_simple':i,'reason':meta};break
   A,b=ab
   if len(A[0]):y=farkas(A,b)
   elif any(b):y=[0]*len(b);j=next(j for j,v in enumerate(b)if v);y[j]=-1 if b[j]>0 else 1
   else:y=None
   if y is not None:check_farkas(A,b,y);found={'kind':'partial','module_simple':i,'meta':meta,'y':y};break
  if found is None:
   try:ab,meta=fmg.system(R,g,anti['fixed'],T)
   except TimeoutError:ab=None;meta={'reason':'timeout'}
   if ab is not None:
    A,b=ab
    if len(A[0]):y=farkas(A,b)
    elif any(b):y=[0]*len(b);j=next(j for j,v in enumerate(b)if v);y[j]=-1 if b[j]>0 else 1
    else:y=None
    if y is not None:check_farkas(A,b,y);found={'kind':'full','meta':meta,'y':y}
  results.append({'T':TT,'certificate':found})
  if found is None:return {'id':rid,'involution':g,'outcome':'no_conclusion','branches':results,'total_anti':len(anti['branches'])}
 return {'id':rid,'involution':g,'outcome':'excluded','branches':results,'total_anti':len(anti['branches']),'scope':'all_complex_categorifications'}

if __name__=='__main__':
 rid=sys.argv[1];t=time.time();out=discover(rid);out['seconds']=time.time()-t
 (P/f'noncomm_morita_{rid}.json').write_text(json.dumps(out,indent=2)+'\n');print(rid,out['outcome'],out['seconds'],flush=True)
