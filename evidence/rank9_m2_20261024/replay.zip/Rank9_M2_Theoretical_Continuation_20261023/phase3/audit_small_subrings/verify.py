"""Replay direct proofs for the 24 small-rank transfers lacking certificates.

The rank-five engine is an unchanged snapshot of the project's established
rank-five software. No positive-model registry is used in these proofs.
"""
import hashlib
import json
import sys
from pathlib import Path

P = Path(__file__).resolve().parent
B = P.parents[1]
sys.path.insert(0, str(P / 'engine/software'))
import unified
from induction import pseudo_certificate, check_pseudo
from rings import Characters


def digest(value):
    return hashlib.sha256(json.dumps(value, separators=(',', ':')).encode()).hexdigest()


def main():
    corpus = json.loads((B / 'work/verification_corpus.json').read_text())
    structural = {r['id']: r for r in json.loads((B / 'work/structural.json').read_text())}
    unique = json.loads((P / 'unique.json').read_text())
    output = []
    for j, row in enumerate(unique, 1):
        R = row['tensor']
        assert digest(R) == row['tensor_sha256']
        if j == 1:
            # This proof uses only the general low-induction checker; bypass
            # the old engine's rank-five native Gram accelerator at rank four.
            a = Characters(R)
            assert a.fp()[4].degree() == 1
            stored = json.loads((P / 'cert1.json').read_text())
            fresh = pseudo_certificate(R, gram_prune=False)
            assert fresh == stored['certificate']
            check_pseudo(R, fresh)
        else:
            stored = json.loads((P / f'cert{j}.jsonl').read_text())
            assert stored['status'] == 'excluded'
            unified.verify(R, stored['certificate'])
        for rid in row['uses']:
            c, = structural[rid]['certificates']
            T = corpus['tensors'][rid]
            J = c['subset']
            assert 0 in J and len(J) == len(R)
            assert all(T[i][k][h] == 0 for i in J for k in J for h in range(9) if h not in J)
            S = [[[T[i][k][h] for h in J] for k in J] for i in J]
            # Small ranks permit a complete permutation check, independently
            # of the main census matcher.
            import itertools
            maps = [(0,) + tail for tail in itertools.permutations(range(1, len(R)))]
            iso = next((p for p in maps if all(S[i][k][h] == R[p[i]][p[k]][p[h]]
                         for i, k, h in itertools.product(range(len(R)), repeat=3))), None)
            assert iso is not None
            output.append({'id': rid, 'subring_proof': row['name'],
                           'subset': J, 'source_to_proof_map': list(iso)})
    assert len(output) == 24 and len({r['id'] for r in output}) == 24
    receipt = {'status': 'PASS', 'unique_excluded_subrings': 3,
               'exact_transfers_verified': 24, 'transfers': output}
    (P / 'verification.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('PASS: three fresh small-rank proofs; all 24 transfers verified.')


if __name__ == '__main__':
    main()
