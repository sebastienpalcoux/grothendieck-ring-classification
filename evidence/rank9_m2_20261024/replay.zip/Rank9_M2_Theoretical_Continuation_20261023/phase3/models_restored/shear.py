"""Two C2 equivariantizations of the central-fermion shear on half-E6 x VecC2.

The action sign is parameterized here by the resulting odd duality, avoiding
an unnecessary gauge choice for the half-E6 fixed-object intertwiner.
"""
from products import *

def construct(odd_dual_pair):
    assert odd_dual_pair in (0,1)
    # Basis [1,f,epsilon,f epsilon,a+,a-,b+,b-,Y].
    T=[[[0]*9 for _ in range(9)] for _ in range(9)]
    def gact(g,k):
        if k<4:return g^k
        if k<6:return 4+((k-4)^((g>>1)&1))
        if k<8:return 6+((k-6)^((g&1)^((g>>1)&1)))
        return 8
    def fill(i,j,terms):
        for k,v in terms.items():T[i][j][k]=v;T[j][i][k]=v
    for g in range(4):
        for k in range(9):fill(g,k,{gact(g,k):1})
    for a,b in itertools.product(range(2),repeat=2):
        sign=a^b
        fill(4+a,4+b,{2*sign:1,1+2*sign:1,4+sign:2})
        g=2*(sign^odd_dual_pair)
        fill(6+a,6+b,{g:1,g^3:1,4:1,5:1})
        fill(4+a,6+b,{8:1,6:1,7:1})
    for a in range(2):
        fill(4+a,8,{6:1,7:1})
        fill(6+a,8,{4:1,5:1})
    fill(8,8,{g:1 for g in range(4)})
    validate_general(T,nonnegative=True)
    return T

def coherence_checks():
    out=[]
    for sign in (1,-1):
        # eta_h=i^(sign*h), F² tensorator=(-1)^(hk).
        for h,k in itertools.product(range(2),repeat=2):
            assert (sign*(h^k)+2*h*k-sign*h-sign*k)%4==0
            out.append({'sign':sign,'h':h,'k':k,'equation_mod_4':0})
    return out

def main():
    corpus=json.loads((ROOT/'work/verification_corpus.json').read_text())['tensors']
    base=product(ng2(2),cyclic(2))
    # Forgetful multiplicities in basis (1,0),(1,1),(f,0),(f,1),(x,0),(x,1).
    F=[[1,0,0,0,0,0],[0,0,1,0,0,0],[1,0,0,0,0,0],[0,0,1,0,0,0],
       [0,0,0,0,1,0],[0,0,0,0,1,0],[0,0,0,0,0,1],[0,0,0,0,0,1],
       [0,1,0,1,0,0]]
    out=[]
    checks=coherence_checks()
    for dual in (0,1):
        T=construct(dual)
        for i,j,k in itertools.product(range(9),range(9),range(6)):
            lhs=sum(T[i][j][l]*F[l][k] for l in range(9))
            rhs=sum(F[i][a]*F[j][b]*base[a][b][k] for a,b in itertools.product(range(6),repeat=2))
            assert lhs==rhs
        for rid,R in corpus.items():
            if coarse(T)!=coarse(R):continue
            p=based_iso(R,T)
            if p is None:continue
            assert all(R[i][j][k]==T[p[i]][p[j]][p[k]] for i,j,k in itertools.product(range(9),repeat=3))
            out.append({'id':rid,'status':'unitarily_realized',
                'model':'C2 equivariantization of the central-fermion shear on half-E6 x Vec(C2)',
                'tensor':T,'basis_map_source_to_model':p,
                'parameters':{'odd_lifts_form_dual_pair':bool(dual),'action':'F(X,h)=(f^h X,h)','square_coherence_choices':'eta_h=(+i)^h and eta_h=(-i)^h realize the two duality cases','coherence_checks':checks},
                'full_tensor_checks':729,'forgetful_tensor_checks':486,
                'reference':'shear.md; half-E6 central fermion from Aasen-Lake-Walker 1709.01941, Section 7.'})
    assert len(out)==2 and {r['id'] for r in out}=={'R9_2_96','R9_2_1266'}
    (HERE/'shear_models.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps([{k:r[k] for k in ['id','basis_map_source_to_model','parameters']} for r in out],indent=2))

if __name__=='__main__':main()
