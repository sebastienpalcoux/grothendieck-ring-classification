"""Exact rank-nine Deligne products with the half-E6 category."""
from pathlib import Path
import hashlib
import itertools
import json
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT/'sources'),str(ROOT/'work')]
from positive_models import product,ng2,cyclic,su2
from match_models import based_iso,coarse
from oriented_signed import validate_general

def construct():
    E=ng2(2)
    yield 'half-E6 x Ising',product(E,ng2(0))
    yield 'half-E6 x Rep(S3)',product(E,ng2(1))
    yield 'half-E6 x PSU(2)_5',product(E,su2(5,True))
    yield 'half-E6 x Vec(C3)',product(E,cyclic(3))

def main():
    corpus=json.loads((ROOT/'work/verification_corpus.json').read_text())['tensors']
    out=[]
    for name,T in construct():
        validate_general(T,nonnegative=True)
        for rid,R in corpus.items():
            if coarse(T)!=coarse(R):continue
            p=based_iso(R,T)
            if p is None:continue
            assert sorted(p)==list(range(9)) and p[0]==0
            assert all(R[i][j][k]==T[p[i]][p[j]][p[k]] for i,j,k in itertools.product(range(9),repeat=3))
            out.append({'id':rid,'model':name,'status':'unitarily_realized',
                'tensor':T,'basis_map_source_to_model':p,
                'source_tensor_sha256':hashlib.sha256(json.dumps(R,separators=(',',':')).encode()).hexdigest(),
                'full_tensor_checks':729,
                'reference':'Unitary half-E6 category (Aasen-Lake-Walker, arXiv:1709.01941, Section 7); standard unitary Ising, Rep(S3), PSU(2)_5, or Vec(C3); Deligne product.'})
    (HERE/'product_models.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps([{k:r[k] for k in ['id','model','basis_map_source_to_model']} for r in out],indent=2))

if __name__=='__main__':main()
