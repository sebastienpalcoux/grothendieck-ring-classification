"""Replay all seven categorical models restored after the half-E6 registry audit."""
from products import *
from products import construct as products
from ising_zest import construct as ising_zest
from shear import construct as shear,coherence_checks

def main():
    by_name=dict(products())
    tensors={
        'R9_2_71':by_name['half-E6 x Ising'],
        'R9_2_79':by_name['half-E6 x Rep(S3)'],
        'R9_2_499':by_name['half-E6 x PSU(2)_5'],
        'R9_2_2020':by_name['half-E6 x Vec(C3)'],
        'R9_2_1218':ising_zest()[0],
        'R9_2_96':shear(0),'R9_2_1266':shear(1),
    }
    coherence_checks()
    records=[]
    for filename in ['product_models.json','ising_zest_models.json','shear_models.json']:
        records.extend(json.loads((HERE/filename).read_text()))
    assert len(records)==7 and {r['id'] for r in records}==set(tensors)
    corpus=json.loads((ROOT/'work/verification_corpus.json').read_text())['tensors']
    results=[]
    for record in records:
        rid=record['id'];R=corpus[rid];T=tensors[rid];p=record['basis_map_source_to_model']
        assert T==record['tensor']
        validate_general(T,nonnegative=True)
        assert sorted(p)==list(range(9)) and p[0]==0
        for i,j,k in itertools.product(range(9),repeat=3):
            assert R[i][j][k]==T[p[i]][p[j]][p[k]],(rid,i,j,k)
        results.append({'id':rid,'status':'PASS','full_tensor_checks':729,
            'basis_map_source_to_model':p,
            'source_tensor_sha256':hashlib.sha256(json.dumps(R,separators=(',',':')).encode()).hexdigest()})
    result={'status':'PASS','model_count':7,'full_tensor_checks':7*729,'models':results}
    (HERE/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
