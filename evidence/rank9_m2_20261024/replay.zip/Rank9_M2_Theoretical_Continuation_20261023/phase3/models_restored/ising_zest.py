"""Fermionic C2 associative zest of half-E6 x Ising."""
from products import *

def construct():
    T=product(ng2(2),ng2(0))
    f=3  # (f,1)
    grades=[int(i%3==2) for i in range(9)]
    action=[T[f][i].index(1) for i in range(9)]
    out=[[[0]*9 for _ in range(9)] for _ in range(9)]
    for a,b,c in itertools.product(range(9),repeat=3):
        out[a][b][action[c] if grades[a]*grades[b] else c]+=T[a][b][c]
    # The normalized 2-cocycle is lambda(a,b)=f^(ab).
    # The central fermion braiding contributes (-1)^(abcd) to O4.
    # omega(a,b,c)=i^(abc) cancels it; exact arithmetic in Z/4.
    checks=[]
    for a,b,c,d in itertools.product(range(2),repeat=4):
        coboundary=b*c*d+a*(b^c)*d+a*b*c-(a^b)*c*d-a*b*(c^d)
        assert coboundary%4==2*a*b*c*d
        checks.append([a,b,c,d,coboundary%4])
    validate_general(out,nonnegative=True)
    return out,checks

def main():
    T,checks=construct()
    corpus=json.loads((ROOT/'work/verification_corpus.json').read_text())['tensors']
    out=[]
    for rid,R in corpus.items():
        if coarse(R)!=coarse(T):continue
        p=based_iso(R,T)
        if p is None:continue
        assert all(R[i][j][k]==T[p[i]][p[j]][p[k]] for i,j,k in itertools.product(range(9),repeat=3))
        out.append({'id':rid,'status':'unitarily_realized',
            'model':'Fermionic associative C2 zest of half-E6 x Ising',
            'tensor':T,'basis_map_source_to_model':p,
            'parameters':{'grading':'Ising parity','lambda_11':'half-E6 central fermion','omega_111':'i','cochain_checks':checks},
            'full_tensor_checks':729,
            'reference':'Half-E6 central fermion: Aasen-Lake-Walker 1709.01941, Section 7; associative zesting with lambda(a,b)=f^(ab) and omega(a,b,c)=i^(abc), explicitly verified obstruction coboundary.'})
    (HERE/'ising_zest_models.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps([{k:r[k] for k in ['id','model','basis_map_source_to_model']} for r in out],indent=2))

if __name__=='__main__':main()
