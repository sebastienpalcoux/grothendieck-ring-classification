"""Independent construction from shear relations; no model code is imported."""
from pathlib import Path
import sys,itertools,json
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'sources'))
from oriented_signed import validate_general
from match_models import based_iso

def construction(paired):
    # Different basis from the model constructor: 1,e,g,eg,a,ea,b,eb,Y.
    basis=[('G',i)for i in range(4)]+[('a',i)for i in range(2)]+[('b',i)for i in range(2)]+[('Y',0)]
    def translate(g,k):
        tag,bit=basis[k]
        if tag=='G':return basis.index((tag,bit^g))
        if tag=='a':return basis.index((tag,bit^(g&1)))
        if tag=='b':return basis.index((tag,bit^(g&1)^((g>>1)&1)))
        return k
    seeds={('a','a'):{0:1,2:1,4:2},('a','b'):{8:1,6:1,7:1},('a','Y'):{6:1,7:1},('b','Y'):{4:1,5:1},('Y','Y'):{i:1 for i in range(4)}}
    seeds['b','b']={1 if paired else 0:1,2 if paired else 3:1,4:1,5:1}
    T=[]
    for i,(a,aa)in enumerate(basis):
        row=[]
        for j,(b,bb)in enumerate(basis):
            value=[0]*9
            if a=='G':value[translate(aa,j)]=1
            elif b=='G':value[translate(bb,i)]=1
            else:
                key=(a,b)if(a,b)in seeds else(b,a)
                for k,n in seeds[key].items():value[translate(aa^bb,k)]+=n
            row.append(value)
        T.append(row)
    validate_general(T)
    return T

def main():
    checks=0
    # Restriction of the tensorator to the actual sVec x Vec(C2) pointed part.
    pts=list(itertools.product(range(2),repeat=2))
    add=lambda x,y:(x[0]^y[0],x[1]^y[1])
    F=lambda x:(x[0]^x[1],x[1])
    J=lambda x,y:x[0]*y[1]
    for x,y,z in itertools.product(pts,repeat=3):
        assert(J(x,y)+J(add(x,y),z)-J(y,z)-J(x,add(y,z)))%2==0;checks+=1
    for x,y in itertools.product(pts,repeat=2):
        assert(J(F(x),F(y))+J(x,y)-x[1]*y[1])%2==0;checks+=1
    for sign in(1,-1):
        for x,y in itertools.product(pts,repeat=2):
            assert(sign*(x[1]^y[1])+2*x[1]*y[1]-sign*x[1]-sign*y[1])%4==0;checks+=1
        for x in pts:assert sign*F(x)[1]==sign*x[1];checks+=1
    corpus=json.loads((ROOT/'work/verification_corpus.json').read_text())['tensors'];out=[]
    for paired,rid in[(False,'R9_2_96'),(True,'R9_2_1266')]:
        T=construction(paired);R=corpus[rid];p=based_iso(R,T);assert p is not None
        assert all(R[i][j][k]==T[p[i]][p[j]][p[k]]for i,j,k in itertools.product(range(9),repeat=3))
        out.append({'id':rid,'independent_729_match':'PASS','source_to_independent_basis':p,'odd_dual_pair':paired})
    result={'status':'accepted unitary models','categorical_audit':'SHEAR_AUDIT.md','models':out,'pointed_scalar_coherence_checks':checks,'phase3_model_constructor_imported':False}
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
