"""Independent phase-three checks of five categorical model constructions.

No phase-two constructor, stored model tensor, or prior PASS flag is imported.
The D4 alternant is computed as two determinants, rather than a signed-Weyl sum.
"""
from pathlib import Path
import hashlib,itertools,json,sys,time
import sympy as sp
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'sources'))
from exact import field,t
from oriented_signed import validate_general
from match_models import based_iso

CORPUS=json.loads((ROOT/'work/verification_corpus.json').read_text())['tensors']
def match(rid,R):
    validate_general(R);p=based_iso(CORPUS[rid],R);assert p is not None
    assert all(CORPUS[rid][i][j][k]==R[p[i]][p[j]][p[k]]for i,j,k in itertools.product(range(9),repeat=3))
    return {'id':rid,'tensor_match':'PASS','structure_constants_checked':729,'source_to_model':p,'tensor_sha256':hashlib.sha256(json.dumps(R,separators=(',',':')).encode()).hexdigest()}

def ising(i,j):
    if i==0:return {j:1}
    if j==0:return {i:1}
    if i==j==2:return {0:1,1:1}
    if i==j==1:return {0:1}
    return {2:1}

def free_quotient(R,g):
    n=len(R);act=[]
    for row in R[g]:assert sum(row)==1;act.append(row.index(1))
    assert all(act[act[i]]==i and act[i]!=i for i in range(n))
    orbits=[];seen=set()
    for i in range(n):
        if i not in seen:o=sorted([i,act[i]]);orbits.append(o);seen.update(o)
    return [[[sum(R[a[0]][b[0]][c]for c in out)for out in orbits]for b in orbits]for a in orbits]

def model515():
    labels=list(itertools.product(range(3),range(0,11,2)));n=len(labels)
    R=[[[0]*n for _ in range(n)]for _ in range(n)]
    for i,(a,x)in enumerate(labels):
        for j,(b,y)in enumerate(labels):
            for c,coef in ising(a,b).items():
                for z in range(abs(x-y),min(x+y,20-x-y)+1,2):R[i][j][labels.index((c,z))]+=coef
    return match('R9_2_515',free_quotient(R,labels.index((1,10))))

def model389():
    n=16;w=lambda a,b,c:2*a*((b+c)//n)%n
    mu=lambda a,b:-2*a*int(b!=0)%n
    for a,b,c,d in itertools.product(range(n),repeat=4):
        assert (w(b,c,d)-w((a+b)%n,c,d)+w(a,(b+c)%n,d)-w(a,b,(c+d)%n)+w(a,b,c))%n==0
    for a,b,c in itertools.product(range(n),repeat=3):
        assert (mu(a,b)+mu((a+b)%n,c)-mu(b,c)-mu(a,(b+c)%n)-w(-a%n,-b%n,-c%n)+w(a,b,c))%n==0
    for a,b in itertools.product(range(n),repeat=2):
        assert (mu(a,b)+mu(-a%n,-b%n))%n==0
        assert (w(8,a,b)+w(a,b,8)-w(a,8,b))%n==0
    for a in range(n):
        assert (14*a+w(8,8,a)-w(8,a,8)+w(a,8,8))%n==0
        assert (14*a-mu(8,-a%n)+mu(-a%n,8))%n==0
    assert mu(8,8)==0 and w(8,8,8)==0 and (8+7*8)%16==0
    labels=[(i,a)for i in range(3)for a in range(n)if a%2==int(i==2)]
    action=[labels.index((i,-a%n))for i,a in labels];orbits=[];seen=set()
    for i in range(len(labels)):
        if i not in seen:o=sorted({i,action[i]});orbits.append(o);seen.update(o)
    lifts=[(o,e)for o in orbits for e in ([1,-1]if len(o)==1 else [0])]
    def coeff(i,j,k):
        a,x=labels[i];b,y=labels[j];c,z=labels[k]
        return ising(a,b).get(c,0)*int((x+y)%16==z)
    R=[]
    for A,s in lifts:
        row=[]
        for B,u in lifts:
            out=[]
            for C,v in lifts:
                z=C[0];dim=sum(coeff(a,b,z)for a in A for b in B)
                if len(C)==2:out.append(dim);continue
                trace=sum(coeff(a,b,z)*s*u*v for a in A for b in B if action[a]==a and action[b]==b)
                assert (dim+trace)%2==0;out.append((dim+trace)//2)
            row.append(out)
        R.append(row)
    boson=next(i for i,(o,e)in enumerate(lifts)if o==[labels.index((1,8))]and e==1)
    out=match('R9_2_389',free_quotient(R,boson))
    out['coherence_checks']={'omega_pentagon':16**4,'inversion_tensorator':16**3,'square_and_central_slant':2*16**2,'central_square_and_transport':2*16}
    return out

def model1983():
    # Derive the balanced multiplication from left action = -right action.
    vals={(0,0):(0,1)}
    vals[0,1]=(1,1);vals[1,0]=(1,-1);vals[1,1]=(0,-1)
    for a,b in itertools.product(range(2),repeat=2):
        p,v=vals[a,b];p2,v2=vals[1-a,1-b];assert p==p2 and v2==-v
        p3,v3=vals[a,1-b];assert p3==p^1 and v3==v
        p4,v4=vals[1-a,b];p5,v5=vals[a,1-b];assert p4==p5 and v4==-v5
    R=[[[0]*9 for _ in range(9)]for _ in range(9)]
    for i,j in itertools.product(range(9),repeat=2):
        if i<4 and j<4:R[i][j][(i+j)%4]=1
        elif i<4 or j<4:
            a,b=(i,j)if i<4 else(j,i);R[i][j][4 if b==4 else 5+(b-5+a)%4]=1
        elif i==j==4:R[i][j]=[1,1,1,1,2,1,1,1,1]
        elif i==4 or j==4:R[i][j]=[0,0,0,0,1,1,1,1,1]
        else:
            a=i+j-10;R[i][j][(a+1)%4]=1;R[i][j][4]=1
            R[i][j][5+(a+2)%4]=R[i][j][5+(a+3)%4]=1
    return match('R9_2_1983',R)

def d4_seed():
    K=field(sp.Poly(t**16+1,t));z=K([1,0]);one=K.one;zero=K.zero
    powers=[one]
    for i in range(1,32):powers.append(powers[-1]*z)
    weights=[a for a in itertools.product(range(3),repeat=4)if a[0]+2*a[1]+a[2]+a[3]<=2]
    fw=[(2,0,0,0),(2,2,0,0),(1,1,1,-1),(1,1,1,1)]
    vectors=[tuple([6,4,2,0][j]+sum(a[i]*fw[i][j]for i in range(4))for j in range(4))for a in weights]
    permutations=[(p,(-1)**sum(p[i]>p[j]for i in range(4)for j in range(i+1,4)))for p in itertools.permutations(range(4))]
    def determinant(M):
        result=zero
        for p,sgn in permutations:
            term=K(sgn)
            for i in range(4):term*=M[i][p[i]]
            result+=term
        return result
    S=[]
    for u in vectors:
        row=[]
        for v in vectors:
            plus=[[powers[-u[i]*v[j]%32]+powers[u[i]*v[j]%32]for j in range(4)]for i in range(4)]
            minus=[[powers[-u[i]*v[j]%32]-powers[u[i]*v[j]%32]for j in range(4)]for i in range(4)]
            row.append((determinant(plus)+determinant(minus))/K(256))
        S.append(row)
    assert all(sum((S[i][j]*S[k][j]for j in range(11)),zero)==K(int(i==k))for i,k in itertools.product(range(11),repeat=2))
    R=[[[0]*11 for _ in range(11)]for _ in range(11)]
    for i,j,k in itertools.product(range(11),repeat=3):
        x=sum((S[i][a]*S[j][a]*S[k][a]/S[0][a]for a in range(11)),zero).to_list()
        assert not x or(len(x)==1 and x[0].denominator==1 and x[0]>=0)
        R[i][j][k]=int(x[0])if x else 0
    dims=[int((S[i][0]/S[0][0]).to_list()[0])for i in range(11)]
    sigma=[weights.index((a[3],a[1],a[0],a[2]))for a in weights]
    assert sorted(dims)==[1]*4+[2]*7
    fixed=[i for i in range(11)if sigma[i]==i];assert len(fixed)==2
    assert R[fixed[1]][fixed[1]]==[int(d==1)for d in dims]
    return R,weights,dims,sigma

def c3_equivariant(R,sigma):
    orbits=[];seen=set()
    for a in range(len(R)):
        if a not in seen:o=sorted({a,sigma[a],sigma[sigma[a]]});orbits.append(o);seen.update(o)
    lifts=[(o,e)for o in orbits for e in(range(3)if len(o)==1 else [0])]
    T=[]
    for A,a in lifts:
        row=[]
        for B,b in lifts:
            entries=[]
            for C,c in lifts:
                z=C[0];base=sum(R[x][y][z]for x in A for y in B)
                if len(C)==3:entries.append(base);continue
                trace=0
                if len(A)==len(B)==1:trace=R[A[0]][B[0]][z]*(2 if(a+b-c)%3==0 else -1)
                assert(base+trace)%3==0;entries.append((base+trace)//3)
            row.append(entries)
        T.append(row)
    return T

def triality_models():
    R,w,d,sigma=d4_seed();plain=match('R9_2_1857',c3_equivariant(R,sigma))
    # F4 multiplication uses direct reduction of binary polynomials.
    def mul(a,b):
        r=0
        for i in range(2):
            for j in range(2):
                if(a>>i&1)and(b>>j&1):r^=1<<(i+j)
        return r^7 if r&4 else r
    deg=[(a[0]%2)^2*(a[2]%2)^3*(a[3]%2)for a in w]
    currents=[w.index((0,0,0,0)),w.index((2,0,0,0)),w.index((0,0,2,0)),w.index((0,0,0,2))]
    lam=lambda a,b:mul(2,mul(mul(a,b),mul(a,b)))
    for a,b,c in itertools.product(range(4),repeat=3):assert lam(a,b)^lam(a^b,c)==lam(b,c)^lam(a,b^c)
    for a,b in itertools.product(range(4),repeat=2):assert lam(mul(2,a),mul(2,b))==mul(2,lam(a,b))
    assert all(deg[sigma[i]]==mul(2,deg[i])for i in range(11))
    T=[[[0]*11 for _ in range(11)]for _ in range(11)]
    for a,b,c in itertools.product(range(11),repeat=3):
        if R[a][b][c]:
            g=currents[lam(deg[a],deg[b])];out=R[g][c].index(1);T[a][b][out]+=R[a][b][c]
    zested=match('R9_2_2029',c3_equivariant(T,sigma))
    zested['cocycle_checks']=64;zested['equivariance_checks']=16
    plain['independent_seed_method']='Two 4x4 determinant D4 Weyl alternants and exact Verlinde formula in Q(zeta32)'
    return [plain,zested]

if __name__=='__main__':
    start=time.monotonic();out=[model389(),model515(),model1983()]+triality_models()
    result={'models':out,'seconds':time.monotonic()-start,'categorical_proof':'AUDIT.md','prior_PASS_flags_used':False,'phase2_constructors_imported':False}
    Path(__file__).with_name('replay.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
