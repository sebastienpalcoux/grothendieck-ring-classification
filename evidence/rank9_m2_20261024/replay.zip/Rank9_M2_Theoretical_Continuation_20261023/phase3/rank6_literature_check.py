"""Exact applicability of arXiv:2609.23559 to the nine strict-weak residuals."""
from pathlib import Path
import json,itertools,sympy as s
ROOT=Path(__file__).resolve().parents[1]
IDS=[585,746,1025,1209,1254,1303,1709,1759,1988]

def main():
    C=json.load(open(ROOT/'work/verification_corpus.json'))['tensors']
    U={x['id']:x for x in json.load(open(ROOT/'results/unresolved.json'))}
    out=[];z=s.Symbol('z')
    for k in IDS:
      rid=f'R9_2_{k}';R=C[rid];m=U[rid];f=s.Poly.from_list(list(map(s.Rational,m['defining_polynomial'])),z)
      ds=[s.Poly.from_list(list(map(s.Rational,c)),z)for c in m['dimension_coefficients']]
      subs=[]
      for tail in itertools.combinations(range(1,9),5):
        J=(0,)+tail;S=set(J)
        if any(R[a][b][c]for a,b in itertools.product(J,repeat=2)for c in range(9)if c not in S):continue
        assert all(m['dual'][a]in S for a in J)
        D=sum((ds[a]**2 for a in J),s.Poly(0,z)).rem(f)
        integral=all(ds[a].degree()==0 and ds[a].nth(0).q==1 for a in J)
        subs.append({'basis':J,'dimension_polynomial_coefficients':[str(v)for v in D.all_coeffs()],
                     'integral':integral,'simple_dimension_coefficients':[m['dimension_coefficients'][a]for a in J],
                     'strictly_weakly_integral':not integral and D.degree()==0 and D.nth(0).q==1})
      assert [list(x['basis'])for x in subs]==[J for J in m['proper_fusion_subrings']if len(J)==6]
      out.append({'id':rid,'rank6_subrings':subs,'direct_applicability':any(x['strictly_weakly_integral']for x in subs)})
    result={'source':'https://arxiv.org/pdf/2609.23559','version':'v1, 20 September 2026',
            'scope':'All complex strictly weakly integral fusion categories of rank6, claimed classification of eight rings.',
            'subset_tests':len(IDS)*56,'records':out,
            'applicable_strict_weak_rank6_subrings':sum(x['strictly_weakly_integral']for r in out for x in r['rank6_subrings'])}
    (ROOT/'phase3/rank6_literature_check.json').write_text(json.dumps(result,indent=2)+'\n')
    print([(x['id'],[(r['basis'],r['integral'],r['dimension_polynomial_coefficients'])for r in x['rank6_subrings']])for x in out])
if __name__=='__main__':main()
