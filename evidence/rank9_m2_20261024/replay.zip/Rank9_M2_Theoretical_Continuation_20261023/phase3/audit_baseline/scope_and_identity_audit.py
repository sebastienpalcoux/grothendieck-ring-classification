"""Audit exact direct subring witnesses, rank3 scope, M1 identity and weighted I1 conventions."""
from pathlib import Path
import sys,json,gzip,itertools,collections,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT/'sources'),str(ROOT/'work')]
from common import digest,based_iso,read
from arithmetic import near_group,verify_dnumber
from positive_models import ng2,cyclic
from match_models import su2,rep_dihedral
from scalar_characters import chars
from exact import discover_roots,t,ec
import sympy as s
P=Path(__file__).parent
C=json.load(open(ROOT/'work/verification_corpus.json'));cross=json.load(open(P/'structural_crosswalk.json'))
direct=[];rank3=[]
positive3=[('VecC3',cyclic(3)),('Ising',ng2(0)),('RepS3',ng2(1)),('halfE6',ng2(2)),('PSU2_5',su2(5,True))]
for u in cross['unique_subtensors']:
 R=u['tensor'];c=u['baseline_certificate'];w=c.get('direct_certificate')
 if w:
  if w['kind']=='casimir_dnumber':verify_dnumber(R,w)
  else:assert w['kind']=='near_group_small_m'and near_group(R)==w
  direct.append({'subtensor_sha256':u['subtensor_sha256'],'certificate_kind':w['kind'],'replayed':True})
 if len(R)==3:
  matched=[(name,based_iso(R,T))for name,T in positive3];matched=[(n,p)for n,p in matched if p is not None]
  if matched:
   assert len(matched)==1 and matched[0][0]=='halfE6';outcome='invalid_exclusion_of_categorizable_subring'
  else:outcome='excluded_by_general_rank3_classification'
  rank3.append({'subtensor_sha256':u['subtensor_sha256'],'outcome':outcome,'positive_matches':matched,'scope':'general_complex','source':'../grothendieck-ring-classification/manuscripts/rank3.tex','theorem':'Theorem1.1 and Corollary cor:list (five-ring unrestricted classification), with halfE6 explicitly included.'})

# All142 old M1 identities are checked coefficient by coefficient against the
# original separately supplied M1 archive, rather than against derived metadata.
prior=P/'prior_rank9_M1_tables.txt.gz'
old=[json.loads(line.replace('{','[').replace('}',']'))for line in gzip.open(prior,'rt')]
raw={r['physical_line']:r for r in read()};maps=json.load(open(ROOT/'work/multiplicity_one_crosswalk.json'));assert len(maps)==len(old)==142
checked=[]
for x in maps:
 r=raw[x['new_physical_line']];assert r['multiplicity']==1 and r['id']==x['new_band_id']==x['previous_id']
 j=int(x['previous_id'].rsplit('_',1)[1])-1;T=old[j];p=x['basis_map_new_to_previous'];assert sorted(p)==list(range(9))and p[0]==0
 assert all(r['tensor'][a][b][c]==T[p[a]][p[b]][p[c]]for a,b,c in itertools.product(range(9),repeat=3))
 checked.append({'id':r['id'],'physical_line':r['physical_line'],'tensor_sha256':digest(r['tensor']),'identity_basis':p==list(range(9))})

# Rebuild only the exact noncommutative spectral bookkeeping; the parent agent
# separately replays the complete exclusion solvers.
weighted=[]
for rid in ['R9_2_1375','R9_2_1376','R9_2_1798']:
 R=C['tensors'][rid];a=chars(R);f,K,ds,D,pD,e=a.fp();assert pD.degree()==1
 roots=discover_roots(a.scalar_codegree_polynomial,K);assert roots is not None
 sp=[(r,1)for r in roots];res,rem=a.C.charpoly(t).as_poly().div(a.scalar_codegree_polynomial);assert rem.is_zero
 for q,m in res.factor_list()[1]:
  assert m%4==0;qq=s.Poly(q.as_expr().subs(t,2*t)/2**q.degree(),t,domain=s.QQ);rr=discover_roots(qq,K);assert rr is not None
  sp.extend((r,2)for r in rr for j in range(m//4))
 assert sum(k*k for _,k in sp)==9
 assert sum((K(k)*D/r for r,k in sp),K.zero)==D
 B=s.Matrix(9,9,lambda j,i:sum(R[b][j][k]*R[k][a.du[b]][i]for b,k in itertools.product(range(9),repeat=2)))
 assert B==B.T and B[0,0]==9
 weighted.append({'id':rid,'gate':'weak_integrality','codegrees':[ec(r)for r,k in sp],'irrep_degrees':[k for r,k in sp],'central_simple_dimensions':[ec(D/r)for r,k in sp],'dimension_formula':'dim(A_E)=D/f_E','unit_restriction_coefficient':'[F(A_E):1]=dim(E)','induction_multiplicity':'[I(1):A_E]=dim(E)','weighted_identity_verified':True,'genuine_induction_gram_verified':True})
out={'direct_certificates':direct,'rank3_bindings':rank3,'multiplicity_one':{'count':142,'full_coefficient_equalities':142*9**3,'all_identity_basis':all(r['identity_basis']for r in checked),'records':checked},'weighted_induction':weighted}
(P/'scope_and_identity_audit.json').write_text(json.dumps(out,indent=2)+'\n')
print('direct_unique',len(direct),'rank3_unique',len(rank3),'M1',len(checked),'weighted',len(weighted))
