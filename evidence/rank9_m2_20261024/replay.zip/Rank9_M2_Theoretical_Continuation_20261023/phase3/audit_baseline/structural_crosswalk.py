"""Bind structural transfers to actual lower census decisions, never registry absence."""
from pathlib import Path
import sys,json,gzip,itertools,collections,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT/'sources'),str(ROOT/'work')]
from common import digest,based_iso,coarse
P=Path(__file__).parent;G=ROOT.parent/'grothendieck-ring-classification'
C=json.load(open(ROOT/'work/verification_corpus.json'))
L6={r['id']:r for r in json.load(open(P/'rank6_ledger.json'))}
lower=[]
for r in json.load(open(P/'rank6_census.json')):
 if r['m']<=2:lower.append({'id':r['id'],'tensor':r['N'],'decision':L6[r['id']],'decision_source':'phase3/audit_baseline/rank6_ledger.json'})
for r in json.load(open(P/'rank7_ledger.json')):
 if r['multiplicity']<=2:lower.append({'id':r['id'],'tensor':r['tensor'],'decision':{k:v for k,v in r.items()if k!='tensor'},'decision_source':'phase3/audit_baseline/rank7_ledger.json'})
L8={r['tensor_sha256']:r for r in json.load(open(G/'supplements/rank8/data/decisions.json'))};cnt=collections.Counter()
for line in gzip.open(ROOT.parent/'fusion-ring-census/results/rank8/tables.txt.gz','rt'):
 R=json.loads(line.replace('{','[').replace('}',']'));m=max(v for a in R for b in a for v in b);cnt[m]+=1
 if m>2:continue
 d=L8[digest(R)];rid=d['id'];lower.append({'id':rid,'tensor':R,'decision':d,'decision_source':'../grothendieck-ring-classification/supplements/rank8/data/decisions.json'})
index=collections.defaultdict(list)
for r in lower:index[(len(r['tensor']),coarse(r['tensor']))].append(r)
unique={};uses=[]
for s in json.load(open(ROOT/'work/structural.json')):
 if not s['certificates']:continue
 c=s['certificates'][0];rid=s['id'];R=C['tensors'][rid];J=c['subset'];S=[[[R[i][j][k]for k in J]for j in J]for i in J];h=digest(S)
 assert h==c['subtensor_sha256']
 u={'id':rid,'subset':J,'subtensor_sha256':h,'primary':C['ledger'][rid]['exclusion_certificates'][0]['certificate_kind']=='excluded_lower_subring'};uses.append(u)
 if h in unique:continue
 rec={'subtensor_sha256':h,'subrank':len(J),'tensor':S,'baseline_certificate':c}
 if len(J)>=6:
  matches=[(r,based_iso(S,r['tensor']))for r in index[len(J),coarse(S)]];matches=[(r,p)for r,p in matches if p is not None];assert len(matches)==1,(rid,[(r['id'],p)for r,p in matches])
  r,p=matches[0];assert all(S[i][j][k]==r['tensor'][p[i]][p[j]][p[k]]for i,j,k in itertools.product(range(len(J)),repeat=3))
  rec.update(lower_id=r['id'],basis_map_subring_to_lower=p,lower_tensor=r['tensor'],lower_decision=r['decision'],decision_source=r['decision_source'],audit_status='bound_to_'+r['decision']['status'])
 else:rec['audit_status']='small_rank_audit_pending'
 unique[h]=rec
(P/'structural_crosswalk.json').write_text(json.dumps({'unique_subtensors':list(unique.values()),'uses':uses},indent=2)+'\n')
small=[dict(u,subtensor=unique[u['subtensor_sha256']]['tensor'],baseline_certificate=unique[u['subtensor_sha256']]['baseline_certificate'])for u in uses if unique[u['subtensor_sha256']]['subrank']in[4,5]and 'direct_certificate'not in unique[u['subtensor_sha256']]['baseline_certificate']]
(P/'small_rank_nondirect_uses.json').write_text(json.dumps(small,indent=2)+'\n')
print('uses',len(uses),'unique',len(unique),'bound',collections.Counter(r['audit_status']for r in unique.values()),'small_nondirect',len(small))
print('bound_nonexcluded',[(r.get('lower_id'),r['audit_status'])for r in unique.values()if r['audit_status'].startswith('bound_to_')and r['audit_status']!='bound_to_excluded'])
