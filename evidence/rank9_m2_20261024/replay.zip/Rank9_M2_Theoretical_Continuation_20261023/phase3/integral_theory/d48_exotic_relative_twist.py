"""Combine the known twisted S4 associator with the new relative cup family."""
from d48_relative_twists import *
import z3

def existing_s4_cocycle(M):
 old=json.load(open(P/'s4_exotic_cocycle_seed.json'))
 A=old['group_table'];W=old['omega_exponents'];B=[[M[2*i][2*j]//2 for j in range(24)]for i in range(24)]
 def order(T,g):
  v=0
  for n in range(1,25):
   v=T[v][g]
   if v==0:return n
 def attempt(aa,bb,cc,dd):
  f={0:0};todo=[0]
  for v in todo:
   for u,t in [(aa,cc),(bb,dd)]:
    v1=A[v][u];w1=B[f[v]][t]
    if v1 in f:
     if f[v1]!=w1:return None
    else:f[v1]=w1;todo.append(v1)
  if len(f)!=24 or len(set(f.values()))!=24:return None
  if not all(f[A[i][j]]==B[f[i]][f[j]]for i,j in itertools.product(range(24),repeat=2)):return None
  return [f[i]for i in range(24)]
 found=None
 for a,c in itertools.product([i for i in range(24)if order(A,i)==4],[i for i in range(24)if order(B,i)==4]):
  found=attempt(a,old['s'],c,1)
  if found is not None:break
 assert found is not None
 back=[found.index(i)for i in range(24)]
 V=[[[W[back[i]][back[j]][back[k]]for k in range(24)]for j in range(24)]for i in range(24)]
 assert all((V[b][c][d]-V[B[a][b]][c][d]+V[a][B[b][c]][d]-V[a][b][B[c][d]]+V[a][b][c])%8==0 for a,b,c,d in itertools.product(range(24),repeat=4))
 return V,found

def primitive8(M,H,w):
 variables={(a,b):z3.Int(f'q{a}_{b}')for a,b in itertools.product(H[1:],repeat=2)}
 def q(a,b):return variables.get((a,b),z3.IntVal(0))
 solver=z3.Solver();solver.set(timeout=5000)
 solver.add(*[z3.And(v>=0,v<8)for v in variables.values()])
 for a,b,c in itertools.product(H,repeat=3):
  solver.add((q(b,c)-q(M[a][b],c)+q(a,M[b][c])-q(a,b)+w(a,b,c))%8==0)
 status=solver.check()
 if status==z3.unsat:return None
 if status!=z3.sat:raise TimeoutError('cochain primitive')
 model=solver.model()
 return {(a,b):(model[q(a,b)].as_long()if (a,b)in variables else 0)for a,b in itertools.product(H,repeat=2)}

def main():
 M,inv,H,hs,coords,s,e,factors=data();V,isomap=existing_s4_cocycle(M)
 C=json.load(open(ROOT/'work/verification_corpus.json'))['tensors'];out=[];count={};seen=set()
 for mask in [80]+[i for i in range(256)if i!=80]:
  def w8(a,b,c):
   cup=4*(sum((mask>>(4*j+k)&1)*u[a]*factors[k][b][c]for j,u in enumerate([s,e])for k in range(4))%2)
   return (V[a//2][b//2][c//2]+cup)%8
  ps=primitive8(M,H,w8)
  if ps is None:count['nontrivial_H_restriction']=count.get('nontrivial_H_restriction',0)+1;continue
  count['trivial_H_restriction']=count.get('trivial_H_restriction',0)+1
  for parity in [0,1]:
   def w(a,b,c):return 2*w8(a,b,c)
   def psi(a,b):return 2*((ps[a,b]+4*parity*(coords[a]&1)*((coords[b]>>1)&1))%8)
   assert all((psi(b,c)-psi(M[a][b],c)+psi(a,M[b][c])-psi(a,b)+w(a,b,c))%16==0 for a,b,c in itertools.product(H,repeat=3))
   T,meta=tensor(M,inv,H,hs,coords,w,psi,modulus=16)
   count['rank'+str(meta['rank'])]=count.get('rank'+str(meta['rank']),0)+1
   if T is None:continue
   hh=digest(T)
   if hh in seen:continue
   seen.add(hh)
   assert all(sum(T[i][j][u]*T[u][k][l]for u in range(9))==sum(T[j][k][u]*T[i][u][l]for u in range(9))for i,j,k,l in itertools.product(range(9),repeat=4))
   matches=[]
   for rid in ['R9_2_392','R9_2_1246']:
    bm=based_iso(C[rid],T)
    if bm is not None:matches.append({'id':rid,'basis_map_source_to_model':bm})
   r={'mask':mask,'psi_parity':parity,'H':H,'psi_exponents_mod8':[[a,b,psi(a,b)//2]for a,b in itertools.product(H,repeat=2)],'tensor':T,'tensor_sha256':hh,'matches':matches,**meta};out.append(r)
   print('exotic mask',mask,'parity',parity,'matches',matches,flush=True)
 (P/'d48_exotic_relative_twists.json').write_text(json.dumps({'status':'candidate_family_requires_categorical_audit','group_table':M,'H':H,'h_coordinates':coords,'sign':s,'external':e,'factors_F2':factors,'old_S4_to_permutation_map':isomap,'S4_omega_exponents_mod8':V,'counts':count,'distinct_tensor_records':out},indent=2)+'\n')
 print(count,'distinct tensors',len(out),flush=True)
if __name__=='__main__':main()
