"""Optimizer-free exact replay of the two relative dimension48 models."""
from d48_relative_twists import *

def verify(filename,rid):
 D=json.load(open(P/filename));M=D['group_table'];H=D['H'];hs=set(H)
 coords={int(k):v for k,v in D['h_coordinates'].items()}
 s=D['sign'];e=D['external'];factors=D['factors_F2'];alpha=factors[0]
 pp=list(itertools.permutations(range(4)));ix={p:i for i,p in enumerate(pp)}
 assert M==[[2*ix[tuple(pp[j//2][pp[i//2][k]]for k in range(4))]+((i%2)^(j%2))for j in range(48)]for i in range(48)]
 assert s==[sum(pp[i//2][a]>pp[i//2][b]for a in range(4)for b in range(a+1,4))%2 for i in range(48)]
 assert e==[i%2 for i in range(48)]
 assert all(alpha[0][g]==alpha[g][0]==0 for g in range(48))
 assert all(alpha[b][c]^alpha[M[a][b]][c]^alpha[a][M[b][c]]^alpha[a][b]==0 for a,b,c in itertools.product(range(48),repeat=3))
 assert factors[1]==[[s[a]*s[b]for b in range(48)]for a in range(48)]
 assert factors[2]==[[e[a]*e[b]for b in range(48)]for a in range(48)]
 assert factors[3]==[[s[a]*e[b]for b in range(48)]for a in range(48)]
 assert all(M[a][b]in hs for a,b in itertools.product(H,repeat=2))
 inv=[next(j for j in range(48)if M[i][j]==0)for i in range(48)]
 r=next(r for r in D['distinct_tensor_records']if any(m['id']==rid for m in r['matches']))
 mask=r['mask'];exotic='S4_omega_exponents_mod8'in D
 if exotic:
  V=D['S4_omega_exponents_mod8'];B=[[M[2*i][2*j]//2 for j in range(24)]for i in range(24)]
  assert all(V[0][a][b]==V[a][0][b]==V[a][b][0]==0 for a,b in itertools.product(range(24),repeat=2))
  assert all((V[b][c][d]-V[B[a][b]][c][d]+V[a][B[b][c]][d]-V[a][b][B[c][d]]+V[a][b][c])%8==0 for a,b,c,d in itertools.product(range(24),repeat=4))
  seed=json.load(open(P/'s4_exotic_cocycle_seed.json'));f=D['old_S4_to_permutation_map'];A=seed['group_table'];W=seed['omega_exponents']
  assert sorted(f)==list(range(24)) and all(f[A[a][b]]==B[f[a]][f[b]]for a,b in itertools.product(range(24),repeat=2))
  assert all(W[a][b][c]==V[f[a]][f[b]][f[c]]for a,b,c in itertools.product(range(24),repeat=3))
  q={(a,b):v for a,b,v in r['psi_exponents_mod8']}
 else:q={(a,b):2*v for a,b,v in r['psi_exponents_mod4']}
 def w8(a,b,c):
  cup=4*(sum((mask>>(4*j+k)&1)*u[a]*factors[k][b][c]for j,u in enumerate([s,e])for k in range(4))%2)
  return ((V[a//2][b//2][c//2]if exotic else 0)+cup)%8
 assert all(q[0,h]==q[h,0]==0 for h in H)
 assert all((q[b,c]-q[M[a][b],c]+q[a,M[b][c]]-q[a,b]+w8(a,b,c))%8==0 for a,b,c in itertools.product(H,repeat=3))
 T,meta=tensor(M,inv,H,hs,coords,lambda a,b,c:2*w8(a,b,c),lambda a,b:2*q[a,b],modulus=16)
 assert T==r['tensor'] and digest(T)==r['tensor_sha256']
 C=json.load(open(ROOT/'work/verification_corpus.json'))['tensors'][rid]
 bm=next(m['basis_map_source_to_model']for m in r['matches']if m['id']==rid)
 assert all(C[i][j][k]==T[bm[i]][bm[j]][bm[k]]for i,j,k in itertools.product(range(9),repeat=3))
 assert all(sum(T[i][j][u]*T[u][k][l]for u in range(9))==sum(T[j][k][u]*T[i][u][l]for u in range(9))for i,j,k,l in itertools.product(range(9),repeat=4))
 return {'id':rid,'status':'PASS','coefficients_matched':729,'coherence':'normalized actual cocycles and subgroup algebra checked','dimensions':meta['dimensions'],'basis_map_source_to_model':bm}

if __name__=='__main__':
 out=[verify('d48_relative_twists.json','R9_2_392'),verify('d48_exotic_relative_twists.json','R9_2_1246')]
 (P/'d48_model_verification.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(out,indent=2))
