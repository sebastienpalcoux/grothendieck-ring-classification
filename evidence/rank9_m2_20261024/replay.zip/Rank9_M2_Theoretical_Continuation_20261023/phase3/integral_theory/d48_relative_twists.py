"""Bounded explicit relative-cup-cocycle family on S4 x C2.

Explores the Vec(A4)^(V4) skeleton for the remaining dimension48 rings.
Construction data are actual cochains; positive records still require audit.
"""
from pathlib import Path
import sys,json,itertools,numpy as np
P=Path(__file__).parent;ROOT=P.parents[1]
sys.path[:0]=[str(ROOT/'work'),str(ROOT/'phase3/group_models')]
from common import based_iso,digest
from s5_relative_twist import gf2_solve

def data():
 raw=json.loads((ROOT/'phase3/group_models/s5_schur_data.json').read_text().replace('\\\n',''))
 pp=list(itertools.permutations(range(4)));ix={p:i for i,p in enumerate(pp)}
 pp5=list(itertools.permutations(range(5)));ix5={p:i for i,p in enumerate(pp5)}
 lift=[ix5[p+(4,)]for p in pp]
 M=[[2*ix[tuple(pp[j//2][pp[i//2][k]]for k in range(4))]+((i%2)^(j%2))for j in range(48)]for i in range(48)]
 inv=[next(j for j in range(48)if M[i][j]==0)for i in range(48)]
 s=[raw['sign'][lift[i//2]]for i in range(48)];e=[i%2 for i in range(48)]
 al=[[raw['alpha'][lift[i//2]][lift[j//2]]for j in range(48)]for i in range(48)]
 x=2*ix[(1,0,2,3)]+1;y=2*ix[(0,1,3,2)]
 H=sorted([0,x,y,M[x][y]])
 hs=set(H);coords={0:0,x:1,y:2,M[x][y]:3}
 factors=[al,[[s[i]*s[j]for j in range(48)]for i in range(48)],[[e[i]*e[j]for j in range(48)]for i in range(48)],[[s[i]*e[j]for j in range(48)]for i in range(48)]]
 for a in factors:
  assert all((a[j][k]^a[M[i][j]][k]^a[i][M[j][k]]^a[i][j])==0 for i,j,k in itertools.product(range(48),repeat=3))
 return M,inv,H,hs,coords,s,e,factors

def primitive(M,H,rhs):
 pairs=list(itertools.product(H[1:],repeat=2));ix={p:i for i,p in enumerate(pairs)}
 mat=[];bb=[]
 for a,b,c in itertools.product(H,repeat=3):
  row=[0]*len(pairs)
  for p,v in [((b,c),1),((M[a][b],c),-1),((a,M[b][c]),1),((a,b),-1)]:
   if p in ix:row[ix[p]]+=v
  mat.append(row);bb.append(rhs(a,b,c)%4)
 B=np.array(mat,dtype=int);r=np.array(bb,dtype=int)
 q0,ker=gf2_solve(mat,r%2)
 if q0 is None:return None
 for bits in itertools.product([0,1],repeat=len(ker)):
  q=q0.copy()
  for b,k in zip(bits,ker):
   if b:q^=k
  delta=r-B@q
  assert all(v%2==0 for v in delta)
  q1,_=gf2_solve(mat,delta//2)
  if q1 is not None:
   a=(q+2*q1)%4
   assert all((B@a-r)%4==0)
   return {(h,k):(0 if h==0 or k==0 else int(a[ix[h,k]]))for h,k in itertools.product(H,repeat=2)}
 return None

def tensor(M,inv,H,hs,coords,w,psi,modulus=8):
 half=modulus//2
 def prod(*args):
  z=0
  for a in args:z=M[z][a]
  return z
 cosets=[];seen=set()
 for t in range(48):
  if t in seen:continue
  support={prod(h,t,k)for h in H for k in H};seen|=support
  K=[h for h in H if prod(inv[t],h,t)in hs]
  reps=[];used=set()
  for h in H:
   if h not in used:reps.append(h);used|={M[h][k]for k in K}
  dec={prod(l,t,k):(l,k)for l in reps for k in H}
  assert len(dec)==len(support)
  def alpha(s,z):
   b=prod(inv[t],s,t);c=prod(inv[t],z,t)
   return(psi(s,z)+w(s,t,c)-w(s,z,t)-w(t,b,c)-psi(b,c))%modulus
  al={(s,z):alpha(s,z)for s,z in itertools.product(K,repeat=2)}
  chars=[]
  if t==0:
   assert all(v==0 for v in al.values())
   for a,b in itertools.product(range(2),repeat=2):
    chars.append({h:((-1)**(a*(coords[h]&1)+b*((coords[h]>>1)&1)),0)for h in K})
  elif len(K)==1:chars=[{0:(1,0)}]
  elif len(K)==2:
   s=K[1];assert al[s,s]%2==0
   chars=[{0:(1,0),s:(1,(al[s,s]//2+half*j)%modulus)}for j in range(2)]
  else:
   assert len(K)==4 and all(M[h][h]==0 for h in K)
   rad=[s for s in K if all(al[s,z]==al[z,s]for z in K)]
   if rad==[0]:chars=[{s:(2 if s==0 else 0,0)for s in K}]
   elif len(rad)==4:
    u,v=K[1:3];uv=M[u][v]
    for j,k in itertools.product(range(2),repeat=2):
     eu=(al[u,u]//2+half*j)%modulus;ev=(al[v,v]//2+half*k)%modulus
     chars.append({0:(1,0),u:(1,eu),v:(1,ev),uv:(1,(eu+ev-al[u,v])%modulus)})
   else:raise AssertionError(rad)
  cosets.append((t,support,K,reps,dec,chars))
 objs=[(c,chi)for c in cosets for chi in c[-1]]
 if len(objs)!=9:return None,{'rank':len(objs)}
 def char_at(obj,v,g):
  c,chi=obj;t=c[0];l,k=c[4][v];u=prod(l,t);s=prod(inv[l],g,l)
  assert s in chi
  c0=prod(inv[t],s,t);b=prod(inv[v],g,v)
  ee=psi(g,l)+w(l,s,t)-w(g,l,t)-psi(l,s)-w(l,t,c0)+w(u,c0,k)+psi(c0,k)-w(g,u,k)-w(u,k,b)-psi(k,b)
  mag,e=chi[s];return mag,(e+ee)%modulus
 T=[[[0]*9 for _ in range(9)]for _ in range(9)]
 for i,j,k in itertools.product(range(9),repeat=3):
  ci,_=objs[i];cj,_=objs[j];ck,chik=objs[k];t=ck[0];cc=[0]*half
  for g in ck[2]:
   mk,ek=chik[g];b=prod(inv[t],g,t)
   for l in ci[3]:
    u=prod(l,ci[0]);v=prod(inv[u],t);h=prod(inv[u],g,u)
    if h not in hs or v not in cj[1]:continue
    mi,ei=char_at(objs[i],u,g);mj,ej=char_at(objs[j],v,h)
    ex=(ei+ej-ek+w(u,h,v)-w(g,u,v)-w(u,v,b))%modulus
    cc[ex%half]+=(1 if ex<half else -1)*mi*mj*mk
  assert cc[1:]==[0]*(half-1)and cc[0]%len(ck[2])==0
  T[i][j][k]=cc[0]//len(ck[2]);assert T[i][j][k]>=0
 return T,{'rank':9,'dimensions':[len(c[3])*chi[0][0]for c,chi in objs],'cosets':[{'representative':c[0],'size':len(c[1]),'K':c[2],'projective_irrep_dimensions':[chi[0][0]for chi in c[-1]]}for c in cosets]}

def main():
 M,inv,H,hs,coords,s,e,factors=data();C=json.load(open(ROOT/'work/verification_corpus.json'))['tensors'];out=[];count={};seen=set()
 for mask in range(256):
  def w(a,b,c):return 4*(sum((mask>>(4*j+k)&1)*u[a]*factors[k][b][c]for j,u in enumerate([s,e])for k in range(4))%2)
  ps=primitive(M,H,lambda a,b,c:-w(a,b,c)//2)
  if ps is None:count['nontrivial_H_restriction']=count.get('nontrivial_H_restriction',0)+1;continue
  count['trivial_H_restriction']=count.get('trivial_H_restriction',0)+1
  for parity in [0,1]:
   def psi(a,b):return 2*((ps[a,b]+2*parity*(coords[a]&1)*((coords[b]>>1)&1))%4)
   assert all((psi(b,c)-psi(M[a][b],c)+psi(a,M[b][c])-psi(a,b)+w(a,b,c))%8==0 for a,b,c in itertools.product(H,repeat=3))
   T,meta=tensor(M,inv,H,hs,coords,w,psi)
   count['rank'+str(meta['rank'])]=count.get('rank'+str(meta['rank']),0)+1
   if T is None:continue
   hh=digest(T)
   if hh in seen:continue
   seen.add(hh)
   assert all(sum(T[i][j][u]*T[u][k][l]for u in range(9))==sum(T[j][k][u]*T[i][u][l]for u in range(9))for i,j,k,l in itertools.product(range(9),repeat=4))
   matches=[]
   for rid in ['R9_2_392','R9_2_1246']:
    bm=based_iso(C[rid],T)
    if bm is not None:matches.append({'id':rid,'basis_map_source_to_model':bm})
   r={'mask':mask,'psi_parity':parity,'H':H,'psi_exponents_mod4':[[a,b,psi(a,b)//2]for a,b in itertools.product(H,repeat=2)],'tensor':T,'tensor_sha256':hh,'matches':matches,**meta};out.append(r)
   print('mask',mask,'parity',parity,'matches',matches,flush=True)
 (P/'d48_relative_twists.json').write_text(json.dumps({'status':'candidate_family_requires_categorical_audit','group_table':M,'H':H,'h_coordinates':coords,'sign':s,'external':e,'factors_F2':factors,'counts':count,'distinct_tensor_records':out},indent=2)+'\n')
 print(count,'distinct tensors',len(out),flush=True)
if __name__=='__main__':main()
