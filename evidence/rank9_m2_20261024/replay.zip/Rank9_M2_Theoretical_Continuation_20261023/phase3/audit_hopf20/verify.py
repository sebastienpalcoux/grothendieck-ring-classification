"""Independent Hopf20 character and source-tensor audit, exact over Q(zeta20)."""
from pathlib import Path
import hashlib,itertools,json,sys
import sympy as s

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'sources'))
from oriented_signed import validate_general

t=s.Symbol('t')
K=s.QQ.alg_field_from_poly(s.Poly(s.cyclotomic_poly(20,t),t))
z=K([s.QQ.one,s.QQ.zero])
basis=list(itertools.product(range(5),range(2),range(2)))

def irreducible_characters(kappa):
    chars=[];labels=[]
    for j in range(2):
        for sign in (1,-1):
            chars.append([K.zero if r!=j else (K(sign)*z**(5*kappa*j))**ell
                          for i,r,ell in basis])
            labels.append(['one_dimensional',j,sign])
    for j in range(2):
        for a in (1,2):
            chars.append([z**(4*a*i)+z**(-4*a*i) if r==j and ell==0 else K.zero
                          for i,r,ell in basis])
            labels.append(['two_dimensional',j,a])
    return chars,labels

def coordinates(v):
    out=[]
    for x in v:
        co=list(x.to_list());out.extend([s.QQ.zero]*(8-len(co))+co)
    return s.Matrix(out)

def character_tensor(kappa):
    chars,labels=irreducible_characters(kappa)
    M=s.Matrix.hstack(*(coordinates(c) for c in chars))
    assert M.rank()==8
    L=(M.T*M).inv()*M.T
    tensor=[]
    for a,b in itertools.product(range(8),repeat=2):
        conv=[]
        reverse=[]
        for i,r,ell in basis:
            val=K.zero;rev=K.zero
            for u in range(2):
                v=(r-u)%2
                left=basis.index((i,u,ell));right=basis.index((((-1)**u*i)%5,v,ell))
                val+=chars[a][left]*chars[b][right]
                rev+=chars[b][left]*chars[a][right]
            conv.append(val);reverse.append(rev)
        assert conv==reverse
        vec=coordinates(conv);coeff=L*vec
        assert M*coeff==vec
        assert all(c.q==1 and c>=0 for c in coeff)
        tensor.append(list(map(int,coeff)))
    T=[tensor[8*i:8*i+8] for i in range(8)]
    validate_general(T,nonnegative=True)
    assert all(T[i][j]==T[j][i] for i,j in itertools.product(range(8),repeat=2))
    return T,labels

def main():
    hopf=[]
    for kappa in (0,1):
        T,labels=character_tensor(kappa)
        orders=[]
        for i in range(4):
            x=0
            for order in range(1,5):
                x=T[x][i].index(1)
                if x==0:orders.append(order);break
        assert sorted(orders)==([1,2,2,2] if kappa==0 else [1,2,4,4])
        hopf.append({'A':kappa,'character_labels':labels,'tensor':T,
            'character_convolution_commutes':True,'exact_basis_evaluations':64*20,
            'invertible_orders':orders})
    corpus=json.loads((ROOT/'work/verification_corpus.json').read_text())['tensors']
    checks=[]
    for rid in ('R9_2_1225','R9_2_1673'):
        R=corpus[rid];odd=5;neutral=[i for i in range(9) if i!=odd]
        ds={i:R[i][odd][odd] for i in neutral}
        assert sorted(ds.values())==[1]*4+[2]*4
        assert sum(d*d for d in ds.values())==20
        for i in neutral:
            assert R[i][odd]==R[odd][i]==[ds[i] if k==odd else 0 for k in range(9)]
            for j in neutral:assert R[i][j][odd]==0
        assert R[odd][odd]==[ds.get(i,0) for i in range(9)]
        assert all(next(j for j in range(9) if R[i][j][0]) in neutral for i in neutral)
        witness=next((i,j) for i,j in itertools.product(neutral,repeat=2) if R[i][j]!=R[j][i])
        checks.append({'id':rid,'status':'PASS','odd_simple':odd,'neutral_basis':neutral,
            'neutral_dimensions':[ds[i] for i in neutral],'neutral_FPdim':20,
            'noncommutative_pair':list(witness),'left_product':R[witness[0]][witness[1]],
            'right_product':R[witness[1]][witness[0]],
            'tensor_sha256':hashlib.sha256(json.dumps(R,separators=(',',':')).encode()).hexdigest()})
    result={'status':'PASS','conclusion':'Both neutral categories would need an impossible dimension20 Hopf algebra fiber functor','source_checks':checks,'hopf_characters':hopf}
    (HERE/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','ids':[r['id'] for r in checks],'character_convolution_checks':2560,'scope':'general complex fusion categories'}))

if __name__=='__main__':main()
