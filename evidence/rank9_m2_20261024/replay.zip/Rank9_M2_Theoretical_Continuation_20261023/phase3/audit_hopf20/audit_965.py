"""Independent copairing replay for the dimension40 Hopf extension."""
from verify import *

def check(kappa):
    def multiply(X,Y):
        a,e,b=X;c,f,d=Y
        if e!=f:return None
        return (((a+(-1)**b*c)%5,e,b^d),(-1)**(kappa*e*b*d))
    def delta(X):
        a,e,b=X
        return [((a,u,b),(((-1)**u*a)%5,e^u,b)) for u in range(2)]
    def antipode(X):
        a,e,b=X
        return (((-(-1)**(e+b)*a)%5,e,b),(-1)**(kappa*e*b))
    gamma=[((a,e,b),(c,b,e),z**(-4*a*c-5*kappa*e*b)/5)
           for a,c,e,b in itertools.product(range(5),range(5),range(2),range(2))]
    def add(D,key,v):D[key]=D.get(key,K.zero)+v
    def clean(D):return {k:v for k,v in D.items() if v}
    left1={};left2={};right1={};right2={}
    for X,Y,v in gamma:
        for A,B in delta(X):add(left1,(A,B,Y),v)
        for A,B in delta(Y):add(left2,(X,A,B),v)
    for X,Y,v in gamma:
        for U,V,w in gamma:
            q=multiply(Y,V)
            if q:add(right1,(X,U,q[0]),v*w*q[1])
            q=multiply(X,U)
            if q:add(right2,(q[0],Y,V),v*w*q[1])
    assert clean(left1)==clean(right1)
    assert clean(left2)==clean(right2)
    ordinary={(X,Y):v for X,Y,v in gamma}
    assert {(Y,X):v for X,Y,v in gamma}==ordinary
    sx={};sy={}
    for X,Y,v in gamma:
        A,c=antipode(X);add(sx,(A,Y),c*v)
        B,d=antipode(Y);add(sy,(X,B),d*v)
    assert clean(sx)==clean(sy)
    # h(x^a delta_e g^b)=delta(a,0)delta(b,0)/2.
    def haar(X):return K(s.Rational(1,2)) if X[0]==X[2]==0 else K.zero
    assert sum((v*haar(X)*haar(Y) for X,Y,v in gamma),K.zero)==K(s.Rational(1,20))
    assert sum((v*haar(X)*haar(Y) for (X,Y),v in sy.items()),K.zero)==K(s.Rational(1,20))
    # Source-free extension tensor built from the independently reconstructed characters.
    E,labels=character_tensor(kappa);n=len(E)
    T=[[[0]*9 for _ in range(9)] for _ in range(9)]
    for i,j,k in itertools.product(range(n),repeat=3):T[i][j][k]=E[i][j][k]
    for i in range(n):
        d=1 if i<4 else 2
        T[i][8][8]=T[8][i][8]=T[8][8][i]=d
    validate_general(T,nonnegative=True)
    rid='R9_2_21' if kappa==0 else 'R9_2_965'
    perm=[0,2,3,6,7,5,4,1,8] if kappa==0 else [0,2,3,6,7,8,5,4,1]
    R=json.loads((ROOT/'work/verification_corpus.json').read_text())['tensors'][rid]
    assert all(R[i][j][k]==T[perm[i]][perm[j]][perm[k]] for i,j,k in itertools.product(range(9),repeat=3))
    return {'id':rid,'status':'PASS','P3':'(Delta tensor id) gamma = gamma13 gamma23',
        'P4':'(id tensor Delta) gamma = gamma12 gamma13','symmetric':True,
        'antipode_balance':True,'normalized_cointegral':True,'full_tensor_checks':729,
        'basis_map_source_to_model':perm}

if __name__=='__main__':
    result={'status':'PASS','checks':[check(0),check(1)],
        'convention':'DR Gamma=S composed with ordinary inverse pairing; DR Eq2.28 cancels this S, so associator copairing is the ordinary inverse pairing'}
    (HERE/'audit_965.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
