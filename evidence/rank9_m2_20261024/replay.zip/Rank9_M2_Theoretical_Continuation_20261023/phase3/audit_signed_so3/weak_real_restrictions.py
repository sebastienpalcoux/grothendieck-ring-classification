"""Bounded exact sweep of dual-invariant scalar characters in weak-integral residuals."""
from pathlib import Path
import itertools,json,math,sys,time
import sympy as s

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT/'sources'),str(ROOT/'work')]
from scalar_characters import chars

def induction_gram(R,du):
    n=len(R)
    B=[[sum(R[y][j][a]*R[a][du[y]][i] for y,a in itertools.product(range(n),repeat=2)) for j in range(n)] for i in range(n)]
    assert B==list(map(list,zip(*B)))
    return B

def integral_dimensions(profile):
    # In these weakly integral residuals the only nonrational dimensions are
    # positive multiples of one square root. They cannot contribute to a
    # rational restriction dimension with nonnegative coefficients.
    p=list(map(s.Rational,profile['defining_polynomial']))
    ds=[]
    for coeff in profile['dimension_coefficients']:
        co=list(map(s.Rational,coeff))
        if len(co)==1:
            assert co[0].q==1 and co[0]>0;ds.append(int(co[0]));continue
        assert len(p)==3 and len(co)==2
        A,B=co
        assert B-A*p[1]/(2*p[0])==0
        ds.append(None)
    return ds

def restriction(R,du,ds,target,B):
    if target.q!=1:return None
    target=int(target);n=len(R);seen={0};orbits=[]
    for i in range(1,n):
        if i in seen:continue
        o=sorted({i,du[i]});seen.update(o)
        if any(ds[j] is None for j in o):continue
        cap=min(min(B[0][j],math.isqrt(B[j][j])) for j in o)
        orbits.append((o,sum(ds[j] for j in o),cap))
    v=[1]+[0]*(n-1)
    def recurse(at,remaining):
        if remaining<0:return None
        if at==len(orbits):return v.copy() if remaining==0 else None
        orbit,weight,cap=orbits[at]
        for val in range(min(cap,remaining//weight)+1):
            for i in orbit:v[i]=val
            if all(v[i]*v[j]<=B[i][j] for i,j in itertools.product(range(n),repeat=2)):
                ans=recurse(at+1,remaining-val*weight)
                if ans is not None:return ans
        for i in orbit:v[i]=0
        return None
    return recurse(0,target-1)

def main():
    profiles=json.loads((ROOT/'phase3/results/unresolved.json').read_text())
    corpus=json.loads((ROOT/'work/verification_corpus.json').read_text())['tensors']
    out=[]
    for profile in profiles:
        if profile['general_to_PU_gate']!='weak_integrality':continue
        start=time.monotonic();rid=profile['id'];R=corpus[rid];a=chars(R);du=a.du
        ds=integral_dimensions(profile);B=induction_gram(R,du)
        D=-s.Rational(profile['global_dimension_minimal_polynomial'][-1]);cases=[];skipped=[]
        for f,m in a.components:
            K,vals,cg,pcg=a.component(f)
            if any(vals[i]!=vals[du[i]] for i in range(len(R))):continue
            if pcg.degree()!=1:
                skipped.append({'character_factor':list(map(str,f.all_coeffs())),'reason':'nonrational codegree outside this bounded sweep'});continue
            codegree=-pcg.TC()/pcg.LC();target=D/codegree
            witness=restriction(R,du,ds,target,B)
            cases.append({'character_factor':list(map(str,f.all_coeffs())),
                'number_of_scalar_characters':f.degree(),'codegree':str(codegree),
                'central_dimension':str(target),'selfdual_restriction_witness':witness})
        row={'id':rid,'commutative':all(R[i][j]==R[j][i] for i,j in itertools.product(range(9),repeat=2)),
            'outcome':'candidate_exclusion' if any(c['selfdual_restriction_witness'] is None for c in cases) else 'no_conclusion',
            'cases':cases,'skipped':skipped,'seconds':round(time.monotonic()-start,3)}
        out.append(row);print(rid,row['outcome'],len(cases),'cases',len(skipped),'skipped',flush=True)
    (HERE/'weak_real_restrictions.json').write_text(json.dumps(out,indent=2)+'\n')

if __name__=='__main__':main()
