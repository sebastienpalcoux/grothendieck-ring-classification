"""Independent labelled-system assembly and exact ray verification for R516.
Reuses the separately audited phase-two base relaxation, not the new builder.
"""
from pathlib import Path
import sys,json,itertools,math,hashlib,time
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'phase2/quadratic_theory'))
import quadratic_center as qc

def plus(x,y):return(x[0]+y[0],x[1]+y[1])
def times(x,y):return(x[0]*y[0]+3*x[1]*y[1],x[0]*y[1]+x[1]*y[0])
def scalar(a,x):return(a*x[0],a*x[1])
def quotient(x,y):return scalar(1/(y[0]*y[0]-3*y[1]*y[1]),times(x,(y[0],-y[1])))
def encode(M,b):return hashlib.sha256(json.dumps({'A':M,'b':b},separators=(',',':')).encode()).hexdigest()
def system():
 cert=json.loads((ROOT/'phase3/quadratic_s_symmetry/R9_2_516_h3.json').read_text());R=qc.inputs('R9_2_516');data=qc.base(R);assert data['q']==3
 chars=[];D=(F(72),F(36))
 for item in cert['metadata']['labelled_characters']:
  v=[tuple(map(F,z))for z in item['values']];assert v[0]==(1,0)
  for i,j in itertools.product(range(9),repeat=2):
   assert times(v[i],v[j])==tuple(sum(R[i][j][k]*v[k][c]for k in range(9))for c in range(2))
  f=(F(0),F(0))
  for i in range(9):f=plus(f,times(v[i],v[data['ch'].du[i]]))
  dim=quotient(D,f)
  assert f==tuple(map(F,item['codegree']))and dim==tuple(map(F,item['dimension']))
  chars.append((v,dim))
 # Nine distinct homomorphisms on a nine-dimensional commutative algebra are complete.
 assert len(chars)==len({tuple(x[0])for x in chars})==9
 assert len({d for v,d in chars})==9
 assert dict(data['counts'])=={d:1 for v,d in chars}
 previous=qc.base;qc.base=lambda _:data
 try:A,b,meta=qc.system(R,3)
 finally:qc.base=previous
 packets=meta['trace_types'];labels=[];j=0
 for v,d in data['cols']:
  if v[0]:
   h=next(h for h,(ch,z)in enumerate(chars)if z==d);labels.append((h,v));j+=1
  else:labels.extend([(None,None)]*packets);j+=packets
 labels.extend([(None,None)]*(len(A[0])-j))
 assert len(labels)==len(A[0])
 for h in range(9):A.append([int(k==h)for k,v in labels]);b.append(1)
 for h in range(9):
  for k in range(h):
   pairrows=[[],[]]
   for lab,v in labels:
    z=(F(0),F(0))
    if lab in(h,k):
     other=k if lab==h else h
     value=tuple(sum(v[i]*chars[other][0][i][c]for i in range(9))for c in range(2))
     z=times(chars[other][1],value)
     if lab==h:z=scalar(-1,z)
    for c in range(2):pairrows[c].append(z[c])
   for row in pairrows:
    if any(row):
     l=math.lcm(*(x.denominator for x in row));r=[int(x*l)for x in row];g=math.gcd(*r);A.append([x//g for x in r]);b.append(0)
 assert encode(A,b)==cert['system_sha256']
 return A,b,cert,meta

def main():
 start=time.monotonic();A,b,cert,meta=system();y=cert['ray'];assert len(y)==len(b)
 bt=sum(a*z for a,z in zip(b,y));aty=[sum(row[j]*yi for row,yi in zip(A,y))for j in range(len(A[0]))]
 assert bt<0 and min(aty)>=0
 gate=json.loads((ROOT/'phase2/signed/gate_R9_2_516.json').read_text())
 result={'id':'R9_2_516','status':'exact ray independently replayed','rows':len(b),'variables':len(A[0]),'bTy':bt,'minimum_ATy':min(aty),'system_sha256':encode(A,b),'complete_exact_characters':9,'new_builder_imported':False,'general_scope_gate':'phase2/signed/gate_R9_2_516.json','seconds':time.monotonic()-start}
 Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
