"""Independent Galois-unit restriction reconstruction by rational linear solve.
No developing-agent code and no center enumeration is imported.
"""
from pathlib import Path
import sys,json,hashlib,itertools
import sympy as s
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'sources'))
from rings import Characters,codegree_poly
from induction import discover_roots
from exact import t,ec

def run(rid,R):
 a=Characters(R);n=len(R);f,K,d,D,pD,embedding=a.fp();assert f.degree()==pD.degree()==2
 factors=[s.Poly(p,t,domain=s.QQ)for p,m in a.cf]
 assert all(p.degree()in(1,2)for p in factors)
 for p in factors:
  roots=discover_roots(p,K);assert roots is not None
  for r in roots:assert sum((K(c)*r**i for i,c in enumerate(reversed(p.all_coeffs()))),K.zero)==K.zero
 degree=sum(p.degree()for p in factors)
 # Coefficient columns are remainders of 1,t,... modulo the distinct factors.
 rows=[];rhs=[]
 for p in factors:
  target=s.rem(1 if p.degree()==1 else t*t/p.nth(0),p.as_expr(),t)
  rem=[s.Poly(s.rem(t**j,p.as_expr(),t),t)for j in range(degree)]
  for k in range(p.degree()):
   rows.append([q.nth(k)for q in rem]);rhs.append(s.Poly(target,t).nth(k))
 A=s.Matrix(rows);b=s.Matrix(rhs);assert A.det()!=0;co=list(A.inv()*b)
 V=sum((co[j]*a.C**j for j in range(degree)),s.zeros(n));v=list(V[0,:])
 assert V==sum((v[i]*a.N[i]for i in range(n)),s.zeros(n))
 # Check scalar eigenvalues of the reconstructed class directly in each character field.
 for factor,m in a.components:
  L,ch,fc,_=a.component(factor);evalv=sum((L(v[i])*ch[i]for i in range(n)),L.zero)
  target=sum((L(co[j])*fc**j for j in range(degree)),L.zero);assert evalv==target
 expected=D*D/K(pD.nth(0));actual=sum((K(v[i])*d[i]for i in range(n)),K.zero);assert actual==expected
 valid=all(z.is_Integer and z>=0 for z in v)and v[0]==1
 return {'id':rid,'status':'necessary_condition_passes'if valid else'accepted_exclusion_via_audited_gate','forced_restriction':list(map(str,v)),'polynomial_ascending':list(map(str,co)),'formal_codegree_factors':[list(map(str,p.all_coeffs()))for p in factors],'dimension_in_FP_field':ec(actual),'tensor_sha256':hashlib.sha256(json.dumps(R,separators=(',',':')).encode()).hexdigest()}

def main():
 corpus=json.loads((ROOT/'work/verification_corpus.json').read_text())['tensors'];out=[]
 bad={114,128,1487,1635,1636,1959}
 for number in[96,1266,1983,114,128,1487,1635,1636,1959,137,1607,1976]:
  rid='R9_2_'+str(number);row=run(rid,corpus[rid]);out.append(row)
  assert(row['status']=='accepted_exclusion_via_audited_gate')==(number in bad)
  print(rid,row['status'],row['forced_restriction'],flush=True)
 Path(__file__).with_suffix('.json').write_text(json.dumps({'independent_developing_agent_code':True,'method':'rational remainder coefficient linear solve, then full regular operator equality','checks':out},indent=2)+'\n')
if __name__=='__main__':main()
