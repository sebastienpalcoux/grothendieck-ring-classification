"""Independent arithmetic replay of the real-character/dual-dimension obstruction."""
from pathlib import Path
import itertools,json,hashlib,sys
ROOT=Path(__file__).resolve().parents[2]
def mul(x,y):return(x[0]*y[0]+3*x[1]*y[1],x[0]*y[1]+x[1]*y[0])
def main():
 number=int(sys.argv[1])if len(sys.argv)>1 else 1487
 assert number in(1487,1959)
 rid='R9_2_'+str(number)
 R=json.loads((ROOT/'work/verification_corpus.json').read_text())['tensors'][rid]
 dual=[next(j for j in range(9)if R[i][j][0])for i in range(9)]
 chi=[1,2,2,1,1,1,2,-2,-2]if number==1487 else[1,2,2,-2,-2,1,1,1,2]
 dims=[(1,0),(2,2),(2,2),(1,0),(1,0),(1,0),(2,0),(4,2),(4,2)]if number==1487 else[(1,0),(2,2),(2,2),(4,2),(4,2),(1,0),(1,0),(1,0),(2,0)]
 for i,j in itertools.product(range(9),repeat=2):
  assert chi[i]*chi[j]==sum(R[i][j][k]*chi[k]for k in range(9))
  assert mul(dims[i],dims[j])==tuple(sum(R[i][j][k]*dims[k][c]for k in range(9))for c in range(2))
 assert all(chi[i]==chi[dual[i]]for i in range(9))
 f=sum(chi[i]*chi[dual[i]]for i in range(9));assert f==24
 D=tuple(sum(mul(d,d)[c]for d in dims)for c in range(2));assert D==(96,48)
 assert tuple(a//f for a in D)==(4,2) and all(a%f==0 for a in D)
 # Finite bound solely from positive rational coefficients in exact dimensions.
 candidates=[]
 for rest in itertools.product(*(range(4//dims[i][0]+1)for i in range(1,9))):
  v=(1,)+rest
  if tuple(sum(v[i]*dims[i][c]for i in range(9))for c in range(2))==(4,2):candidates.append(v)
 big=(7,8)if number==1487 else(3,4)
 assert len(candidates)==6 and all(v[1]+v[2]==1 and not v[big[0]] and not v[big[1]]for v in candidates)
 assert not any(all(v[i]==v[dual[i]]for i in range(9))for v in candidates)
 result={'id':rid,'status':'accepted general exclusion via real-character duality','character':chi,'formal_codegree':f,'global_dimension':list(D),'distinguished_dimension':[4,2],'dual':dual,'all_dimension_compatible_v0_1_columns':candidates,'selfdual_candidates':0,'tensor_sha256':hashlib.sha256(json.dumps(R,separators=(',',':')).encode()).hexdigest(),'proof':'AUDIT'+str(number)+'.md','gate':'phase2/signed/gate_'+rid+'.json'}
 Path(__file__).with_name('replay'+str(number)+'.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
