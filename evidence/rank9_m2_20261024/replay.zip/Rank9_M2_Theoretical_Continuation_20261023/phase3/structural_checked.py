"""Subring transfers with explicit negative witnesses.

This supersedes the baseline structural pass. Missing a positive catalog entry
is never an exclusion. The original pass remains in work/ for audit history.
"""
from pathlib import Path
import collections
import copy
import json
import sys

P = Path(__file__).resolve().parent
B = P.parent
sys.path[:0] = [str(B / 'work'), str(B / 'sources')]
from common import based_iso, coarse, digest
from arithmetic import near_group, dnumber, verify_dnumber


def read(path):
    return json.loads((B / path).read_text())


def build_registry():
    corpus = read('work/verification_corpus.json')
    structural = {r['id']: r for r in read('work/structural.json')}
    audit = read('phase3/audit_baseline/all_structural_uses_audit.json')
    crosswalk = {r['subtensor_sha256']: r for r in
                 read('phase3/audit_baseline/structural_crosswalk.json')['unique_subtensors']}
    registry = {}
    for row in audit['uses']:
        if row['audit_status'] == 'invalid_half_E6_subring':
            continue
        c, = structural[row['id']]['certificates']
        R = corpus['tensors'][row['id']]
        J = c['subset']
        S = [[[R[i][j][k] for k in J] for j in J] for i in J]
        h = digest(S)
        assert h == row['subtensor_sha256'] == c['subtensor_sha256']
        proof = {'audit_status': row['audit_status'],
                 'audit_record': 'phase3/audit_baseline/all_structural_uses_audit.json',
                 'example_ambient_id': row['id'], 'scope': 'general_complex_fusion_category'}
        if c.get('direct_certificate'):
            direct = c['direct_certificate']
            if direct['kind'] == 'casimir_dnumber':
                verify_dnumber(S, direct)
            elif direct['kind'] == 'near_group_small_m':
                assert near_group(S) == direct
            else:
                raise AssertionError('unreviewed direct certificate kind')
            proof['direct_certificate'] = direct
        elif h in crosswalk and 'lower_decision' in crosswalk[h]:
            lower = crosswalk[h]
            assert lower['lower_decision']['status'] == 'excluded'
            p = lower['basis_map_subring_to_lower']
            T = lower['lower_tensor']
            assert sorted(p) == list(range(len(S))) and p[0] == 0
            assert all(S[i][j][k] == T[p[i]][p[j]][p[k]]
                       for i in range(len(S)) for j in range(len(S)) for k in range(len(S)))
            proof.update(lower_id=lower['lower_id'], basis_map_to_lower=p,
                         lower_decision=lower['lower_decision'],
                         crosswalk='phase3/audit_baseline/structural_crosswalk.json')
        elif row['audit_status'] in ('parent_small_rank_direct_audit',
                                    'valid_fresh_small_rank_direct_certificate'):
            assert read('phase3/audit_small_subrings/verification.json')['status'] == 'PASS'
            proof['exact_replay'] = 'phase3/audit_small_subrings/verify.py'
        else:
            assert row['audit_status'] == 'valid_general_rank3_theorem'
            proof['theorem_binding'] = 'phase3/audit_baseline/scope_and_identity_audit.json'
        registry[h] = {'tensor': S, 'tensor_sha256': h, 'negative_proof': proof}
    # The three restored exclusions use a different, valid subring.
    for row in read('phase3/restored_direct_exclusions.json'):
        S = row['subtensor']
        assert near_group(S) == row['certificate']
        h = digest(S)
        registry[h] = {'tensor': S, 'tensor_sha256': h,
                       'negative_proof': {'direct_certificate': row['certificate'],
                                          'scope': 'general_complex_fusion_category'}}
    half_e6 = read('phase3/audit_baseline/invalid_half_E6_subrings.json')['half_E6_tensor']
    assert not any(based_iso(half_e6, x['tensor']) is not None
                   for x in registry.values() if len(x['tensor']) == 3)
    return list(registry.values())


def scan(registry):
    corpus = read('work/verification_corpus.json')
    by_shape = collections.defaultdict(list)
    for item in registry:
        S = item['tensor']
        by_shape[(len(S), coarse(S))].append(item)
    cache = {}
    result = []
    for meta in read('work/input_audit.json'):
        if meta['multiplicity'] != 2:
            continue
        R = corpus['tensors'][meta['id']]
        proofs = []
        for J in meta['subrings']:
            if len(J) in (1, 9):
                continue
            S = [[[R[i][j][k] for k in J] for j in J] for i in J]
            h = digest(S)
            if h not in cache:
                cache[h] = None
                for item in by_shape[(len(S), coarse(S))]:
                    p = based_iso(S, item['tensor'])
                    if p is not None:
                        cache[h] = {'negative_subtensor_sha256': item['tensor_sha256'],
                                    'basis_map_subring_to_negative': p,
                                    'negative_proof': item['negative_proof']}
                        break
            if cache[h] is not None:
                proofs.append({'kind': 'explicit_negative_subring', 'subset': J,
                               'subtensor_sha256': h, 'scope': 'general_complex_fusion_category',
                               **copy.deepcopy(cache[h])})
                break
        result.append({'id': meta['id'], 'certificates': proofs})
    return result


def main():
    registry = build_registry()
    result = scan(registry)
    (P / 'verified_lower_negative_registry.json').write_text(json.dumps(registry, indent=2) + '\n')
    (P / 'structural_checked.json').write_text(json.dumps(result, indent=2) + '\n')
    by_id = {r['id']: r for r in result}
    for num in (71, 79, 96, 499, 1218, 1266, 2020):
        assert not by_id[f'R9_2_{num}']['certificates']
    for num in (97, 98, 1489):
        assert by_id[f'R9_2_{num}']['certificates']
    print('PASS: explicit negative subring registry;', len(result), 'rings scanned;',
          sum(bool(r['certificates']) for r in result), 'certified transfers.')


if __name__ == '__main__':
    main()
