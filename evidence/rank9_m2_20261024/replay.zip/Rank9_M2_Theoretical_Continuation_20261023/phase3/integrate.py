"""Create the corrected classification, retaining earlier ledgers as history."""
from pathlib import Path
import collections
import copy
import json

P = Path(__file__).resolve().parent
B = P.parent
O = P / 'results'


def read(path):
    return json.loads((B / path).read_text())


def main():
    before = read('phase2/results/ledger.json')
    ledger = copy.deepcopy(before)
    by_id = {r['id']: r for r in ledger}
    structural = {r['id']: r for r in read('phase3/structural_checked.json')}
    invalid = read('phase3/audit_baseline/invalid_half_E6_subrings.json')['affected']
    invalid_ids = {r['id'] for r in invalid}
    primary = {r['id'] for r in invalid if r['primary']}
    assert len(invalid_ids) == 26 and len(primary) == 10
    for row in ledger:
        old_claims = [c for c in row['exclusion_certificates']
                      if c['record_file'] == 'work/structural.json']
        row['exclusion_certificates'] = [c for c in row['exclusion_certificates']
                                         if c['record_file'] != 'work/structural.json']
        if row['id'] in invalid_ids:
            assert old_claims
            row['withdrawn_claims'] = [{'record_file': 'work/structural.json',
                'reason': 'The claimed excluded subring is the known unitary half-E6 ring.',
                'audit': 'phase3/audit_baseline/invalid_half_E6_subrings.json'}]
        if structural[row['id']]['certificates']:
            row['exclusion_certificates'].append({
                'record_file': 'phase3/structural_checked.json',
                'certificate_kind': 'explicit_negative_subring',
                'scope': 'general_complex_fusion_category'})
        if row['status'] == 'excluded' and not row['exclusion_certificates']:
            assert row['id'] in primary
            row['status'] = 'unresolved'
    accepted = read('phase3/accepted.json')
    new_models = []
    wanted = set(accepted['new_models'])
    for file in accepted['model_files']:
        for model in read(file):
            if model['id'] not in wanted:
                continue
            assert model['status'] == 'unitarily_realized'
            row = by_id[model['id']]
            assert row['status'] == 'unresolved' and not row['exclusion_certificates']
            row['status'] = 'unitarily_realized'
            row['models'].append({'record_file': file, 'model': model['model']})
            new_models.append({**copy.deepcopy(model), 'record_file': file})
    assert {r['id'] for r in new_models} == wanted
    assert len(new_models) == len(wanted)
    for proof in accepted['additional_exclusions']:
        row = by_id[proof['id']]
        assert row['status'] == 'unresolved' and (B / proof['record_file']).is_file()
        row['status'] = 'excluded'
        row['exclusion_certificates'].append(copy.deepcopy(proof))
    profiles = {r['id']: copy.deepcopy(r) for r in read('phase2/results/unresolved.json')}
    profiles.update({r['id']: copy.deepcopy(r) for r in read('phase3/restored_profiles.json')})
    for num in (96, 97, 98, 1266, 1489):
        rid = f'R9_2_{num}'
        gate = f'phase3/audit_center_morita/gate_{rid}.json'
        assert (B / gate).is_file()
        profiles[rid]['general_to_PU_gate'] = 'signed_sphericalization_global_dimension_Galois_orbit'
        profiles[rid]['phase3_gate_certificate'] = gate
    by_id['R9_2_941']['literature_identification'] = {
        'source': 'https://arxiv.org/html/2507.07023v2#S1.SS5',
        'statement': 'The published rank-nine dimension-504 ring of Question 1.14.',
        'exact_tensor_match': 'phase3/audit_models/published_504_tensor.json',
        'classification_effect': 'none; it remains unresolved'}
    unresolved = []
    for row in ledger:
        assert not (row['exclusion_certificates'] and row['models'])
        assert (row['status'] == 'excluded') == bool(row['exclusion_certificates'])
        assert (row['status'] == 'unitarily_realized') == bool(row['models'])
        if row['status'] != 'unresolved':
            row.pop('categorification_scopes', None)
            continue
        p = profiles[row['id']]
        p['status'] = 'unresolved'
        integral_ids = {f'R9_2_{n}' for n in (12, 941, 959, 1965)}
        weak_ids = {f'R9_2_{n}' for n in (585, 746, 1025, 1209, 1254, 1303, 1709, 1759, 1988)}
        if row['id'] in integral_ids:
            notes = ['phase3/integral_theory/continuation_attempts.json',
                     'phase3/group_models/search_summary.json',
                     'phase3/audit_signed_so3/weak_real_restrictions.json']
        elif row['id'] in weak_ids:
            notes = ['phase3/weak_integral_attempt_manifest.json',
                     'phase3/audit_signed_so3/weak_real_restrictions.json',
                     'phase3/rank6_literature_check.json']
        elif row['id'] == 'R9_2_1848':
            notes = ['phase3/noncomm_morita_R9_2_1848.json',
                     'phase3/noncomm1975/galois_R9_2_1848.json']
        elif row['id'] == 'R9_2_1975':
            notes = ['phase3/noncomm1975/galois_R9_2_1975.json',
                     'phase3/noncomm1975/README.md']
        else:
            notes = ['phase3/quadratic_s_symmetry/dual_summary.json',
                     'phase3/quadratic_s_symmetry/galois_unit_results.json',
                     'phase3/quadratic_s_symmetry/SUMMARY.md']
        assert all((B / f).is_file() for f in notes)
        p['phase3_attempt_records'] = notes
        p['phase3_attempt_outcome'] = 'No model or general exclusion established; search limitations are explicit in the cited records.'
        assert p.get('general_to_PU_gate')
        scopes = {'general_complex': 'unresolved', 'pivotal': 'unresolved',
                  'spherical': 'unresolved', 'pseudo_unitary': 'unresolved',
                  'unitary': 'unresolved',
                  'general_existence_equivalent_to_pseudo_unitary_existence': True,
                  'existence_reduction': p['general_to_PU_gate'],
                  'braided': 'unresolved' if row['commutative'] else 'excluded',
                  'note': 'A Galois existence reduction does not make every original categorification pseudo-unitary.'}
        row['categorification_scopes'] = scopes
        p['categorification_scopes'] = copy.deepcopy(scopes)
        if row.get('literature_identification'):
            p['literature_identification'] = copy.deepcopy(row['literature_identification'])
        unresolved.append(p)
    changes = [{'id': a['id'], 'previous_status': a['status'], 'corrected_status': b['status']}
               for a, b in zip(before, ledger) if a['status'] != b['status']]
    counts = collections.Counter(r['status'] for r in ledger)
    summary = {'rank': 9, 'exact_multiplicity': 2, 'total': len(ledger),
        'excluded': counts['excluded'], 'modelled': counts['unitarily_realized'],
        'unresolved': counts['unresolved'], 'invalid_subring_claims_removed': 26,
        'primary_claims_reassessed': 10, 'restored_excluded_by_other_subring': ['R9_2_97', 'R9_2_98', 'R9_2_1489'],
        'new_unitary_models': len(new_models), 'previous_multiplicity_one_unchanged': 142,
        'online_changes': False,
        'scope': 'General complex exclusions; every recorded positive model has a unitary construction.'}
    summary['false_exclusions_corrected'] = sum(c['previous_status'] == 'excluded' and c['corrected_status'] == 'unitarily_realized' for c in changes)
    summary['formerly_unresolved_newly_excluded'] = sum(c['previous_status'] == 'unresolved' and c['corrected_status'] == 'excluded' for c in changes)
    summary['formerly_unresolved_newly_modelled'] = sum(c['previous_status'] == 'unresolved' and c['corrected_status'] == 'unitarily_realized' for c in changes)
    assert len(ledger) == 2083 and sum(counts.values()) == 2083
    models = read('phase2/results/models.json') + new_models
    assert len(models) == summary['modelled']
    O.mkdir(exist_ok=True)
    for name, value in [('ledger', ledger), ('summary', summary), ('models', models),
                        ('new_models', new_models), ('unresolved', unresolved), ('classification_changes', changes)]:
        (O / (name + '.json')).write_text(json.dumps(value, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
