import json,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'phase2/signed'))
from galois_pu_gate import discover_gate,read
from verify_nonzero_products import check
rows={r['id']:r for r in read()}
for k in [96,97,98,1266,1489]:
    rid=f'R9_2_{k}';r=rows[rid]
    result=discover_gate(r['tensor'],120)
    result.update(id=rid,tensor_sha256=r['tensor_sha256'])
    Path(__file__).with_name('gate_'+rid+'.json').write_text(json.dumps(result,indent=2)+'\n')
    print(rid,result['outcome'],len(result['branches']),result.get('reason'),flush=True)
    if result['complete']:
        verified=check(r['tensor'],result,120000)
        Path(__file__).with_name('gate_'+rid+'_verification.json').write_text(json.dumps(verified,indent=2)+'\n')
        print(json.dumps(verified),flush=True)
