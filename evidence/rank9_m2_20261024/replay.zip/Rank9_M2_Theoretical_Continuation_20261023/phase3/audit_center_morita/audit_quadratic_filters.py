"""Independent quadratic arithmetic, modular and Galois candidate filters."""
import json,math,sys,time,subprocess
from pathlib import Path
from fractions import Fraction as Q
import sympy as s
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'phase2/quadratic_theory'),str(ROOT/'phase2/signed')]
import quadratic_center as qc
from audit_neutral import low_counts

out=[]
for k in [1569,1886]:
    start=time.monotonic();rid=f'R9_2_{k}';R=qc.inputs(rid);data=qc.base(R);n=len(R);q=data['q'];D=data['D'];B=data['ch'].C
    assert all(R[i][j]==R[j][i] for i in range(n) for j in range(n))
    assert low_counts(B,D,q)==data['counts']
    inv=B.inv();den=math.lcm(*(int(a.q) for a in inv));J=[int(a*den) for a in inv]
    vals=[n,1]+[1]*n+list(map(int,B))+J+[den]
    raw=subprocess.run([str(ROOT/'phase2/quadratic_theory/quadratic_vectors')],input=' '.join(map(str,vals)),text=True,capture_output=True,check=True).stdout
    cs=[];before_modular=0;root=s.sqrt(q);DD=s.Rational(D[0])+s.Rational(D[1])*root
    def algint(x):
        x=s.expand(x);return s.expand(x+x.xreplace({root:-root})).is_Integer and s.expand(x*x.xreplace({root:-root})).is_Integer
    ops=[inv*N for N in data['ch'].N]
    for line in raw.splitlines():
        v=tuple(map(int,line.split()))[:-1];z=tuple(sum(v[i]*data['dims'][i][c] for i in range(n)) for c in range(2));zz=s.Rational(z[0])+s.Rational(z[1])*root
        if v[0]:
            if z not in data['counts']:continue
        else:
            quotient=s.radsimp(DD/zz)
            if not algint(quotient):continue
            if not s.cancel(4*s.Rational(z[0])**2/(s.Rational(z[0])**2-q*s.Rational(z[1])**2)).is_Integer:continue
        before_modular+=1
        M=sum((v[i]*ops[i] for i in range(n)),s.zeros(n));coeff=M.charpoly().all_coeffs();ratio=s.radsimp(DD/zz)
        if not all(algint(s.expand(coeff[j]*ratio**j)) for j in range(1,n+1)):continue
        cs.append((v,z))
    assert before_modular==data['pre_modular_columns']
    available={z for v,z in cs};scale=s.radsimp(DD/(s.Rational(D[0])-s.Rational(D[1])*root))
    def partner(z):
        w=s.expand(scale*(s.Rational(z[0])-s.Rational(z[1])*root));a=Q(w.coeff(root,0));b=Q(w.coeff(root,1))
        if qc.sign((a,b),q)<0:a,b=-a,-b
        return a,b
    cs=[(v,z) for v,z in cs if partner(z) in available]
    assert set(cs)==set(data['cols'])
    out.append({'id':rid,'PASS':True,'independent_low_codegree_factorization':True,'independent_sympy_arithmetic_modular_filters':True,'pre_modular_columns':before_modular,'final_columns':len(cs),'seconds':time.monotonic()-start});print(json.dumps(out[-1]),flush=True)
Path(__file__).with_name('quadratic_filters_fresh.json').write_text(json.dumps(out,indent=2)+'\n')
