"""Independent characteristic-polynomial implementation and fresh exact control."""
import json,sys,time,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'phase2/integral_theory'),str(ROOT/'phase2/signed')]
import sympy as s
import center_lp as ic
from audit_neutral import control,verify
start=time.monotonic();rid='R9_2_366';R=ic.inputs(rid);ch=ic.Characters(R)
cert=json.loads((ROOT/'phase2/integral_theory'/f'{rid}_modular_center.json').read_text());m=cert['metadata'];D=m['D'];B=ch.C
counts={D//int(r) for r in B.eigenvals()};cs=[c for c in ic.columns(R,m['dimensions'],D,B) if c[0]==0 or c[-1] in counts]
native=set(ic.modular_integral_columns(cs,ch,D));inv=B.inv();ops=[inv*N for N in ch.N];independent=set()
for c in cs:
    M=sum((c[i]*ops[i] for i in range(len(R))),s.zeros(len(R)))*s.Rational(D,c[-1])
    # SymPy's exact characteristic-polynomial algorithm, independent of the
    # discovery FLINT implementation.
    if all(a.q==1 for a in M.charpoly().all_coeffs()):independent.add(c)
assert independent==native
out={'modular_filter_366':{'PASS':True,'columns_before':len(cs),'columns_after':len(native),'independent_sympy_matches_flint':True,'seconds':time.monotonic()-start},'neutral_arithmetic_audits':[verify('R9_2_500'),verify('R9_2_1235')],'known_model_515_exact_control':control()}
Path(__file__).with_name('controls_modular_fresh.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
