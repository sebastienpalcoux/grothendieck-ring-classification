"""Fresh exact center certificates, with independent Python integral domains."""
import hashlib,json,math,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'phase2/integral_theory'),str(ROOT/'phase2/quadratic_theory')]
import center_lp as ic
from verify_quadratic_center import verify as verify_quad
from verify_quadratic_neutral import verify as verify_neutral
HERE=Path(__file__).parent

def domain(R,meta):
    # Construct Gram directly from tensor, not the character helper.
    import sympy as s
    n=len(R);B=s.Matrix(n,n,lambda a,b:sum(R[i][a][k]*R[i][b][k] for i in range(n) for k in range(n)))
    inv=B.inv();den=math.lcm(*(int(x.q) for x in inv));J=[int(x*den) for x in inv]
    ds=meta['dimensions'];D=meta['D'];bounds=[math.isqrt(int(B[i,i])) for i in range(n)];bounds[0]=1
    found=[];v=[0]*n
    def walk(k,z):
        if k==n:
            if z and D%z==0 and sum(v[i]*J[i*n+j]*v[j] for i in range(n) for j in range(n))<=den:
                found.append(tuple(v)+(z,))
            return
        for x in range(bounds[k]+1):
            if z+ds[k]*x>D:break
            if any(v[j]*x>int(B[j,k]) for j in range(k)):continue
            v[k]=x;walk(k+1,z+ds[k]*x)
    walk(0,0)
    native=ic.columns(R,ds,D,B)
    assert len(found)==len(set(found)) and set(found)==set(native)
    return {'independent_python_raw_columns':len(found),'native_exact_match':True,'box_bound':math.prod(x+1 for x in bounds)}

out=[]
for k in [301,352,385,725,727,1028,1134,1238,1448,1465,1501,1712,1778,1989,366]:
    rid=f'R9_2_{k}';t=time.monotonic();path=ROOT/'phase2/integral_theory'/f'{rid}_{"modular_" if k==366 else ""}center.json'
    cert=json.loads(path.read_text());R=ic.inputs(rid)
    A,b,m=ic.data(R,cert['metadata']['height'],cert['metadata'].get('modular_integrality',False))
    assert ic.verify_ray(A,b,cert['ray'])
    for key in ['dimensions','D','candidate_columns','variables','trace_types','trace_order_bound','height']:
        assert m[key]==cert['metadata'][key],key
    check=domain(R,m)
    row={'id':rid,'PASS':True,'equations':len(b),'variables':len(A[0]),'bTy':sum(x*y for x,y in zip(b,cert['ray'])),'minimum_ATy':min(sum(row[j]*y for row,y in zip(A,cert['ray'])) for j in range(len(A[0]))),'raw_domain':check,'seconds':time.monotonic()-t}
    out.append(row);(HERE/'center_fresh.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(row),flush=True)
for k in [1569,1886]:
    row=verify_quad(f'R9_2_{k}');out.append(row);(HERE/'center_fresh.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(row),flush=True)
for k in [500,1235]:
    row=verify_neutral(f'R9_2_{k}');out.append(row);(HERE/'center_fresh.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(row),flush=True)
