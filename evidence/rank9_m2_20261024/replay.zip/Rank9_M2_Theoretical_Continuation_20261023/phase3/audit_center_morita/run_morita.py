"""Phase 3 fresh audit, preserving all phase 2 files."""
import json,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'phase2/integral_theory'),str(ROOT/'phase2/weak_integral')]
from audit_morita48_anti import run
from morita_replay import replay
out=[]
for rid,g in [('R9_2_396',1),('R9_2_1265',5)]:
    t=time.monotonic()
    result={'id':rid,'independent_anti':run(rid,g),'rebuilt_gram_certificates':replay(rid,g),'seconds':time.monotonic()-t}
    out.append(result)
    Path(__file__).with_name('morita_fresh.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(result),flush=True)
