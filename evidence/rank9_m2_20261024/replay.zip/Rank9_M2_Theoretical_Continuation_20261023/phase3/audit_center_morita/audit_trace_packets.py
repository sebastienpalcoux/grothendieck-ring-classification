"""Check relative trace formulas by direct automorphism averaging in cyclotomic fields."""
import json,math,sys
from collections import Counter
from fractions import Fraction as Q
from pathlib import Path
import sympy as s
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'sources'))
from higher_traces import trace_types
from tensor_rotation import rotation_types
x=s.Symbol('x')
def direct(q,m,H):
    F=(q if q%4==1 else 4*q) if q>1 else 1
    L=math.lcm(F,m);mod=s.Poly(s.cyclotomic_poly(L,x),x,domain=s.QQ)
    autos=[a for a in range(L) if math.gcd(a,L)==1 and (q==1 or int(s.kronecker_symbol(F,a))==1)]
    if q>1:
        root=s.rem(s.Poly(sum(int(s.kronecker_symbol(F,a))*x**(a*(L//F)) for a in range(F)),x,domain=s.QQ),mod).mul_ground(s.Rational(1,math.isqrt(F//q)))
        index=next(i for i in range(1,mod.degree()) if root.nth(i))
    ans=set();cache={}
    for u in range(m):
        if math.gcd(u,m)!=1:continue
        vals=[]
        for k in range(1,H+1):
            key=tuple(sorted(Counter((a*u*k*(L//m))%L for a in autos).items()))
            if key in cache:vals.append(cache[key]);continue
            p=s.rem(s.Poly.from_dict({(e,):v for e,v in key},x,domain=s.QQ),mod).mul_ground(s.Rational(1,len(autos)))
            if q==1:a=p.nth(0);b=s.Rational(0);assert p.degree()<=0
            else:
                b=p.nth(index)/root.nth(index);left=p-root.mul_ground(b);assert left.degree()<=0;a=left.nth(0)
            pair=(Q(a),Q(b));cache[key]=pair;vals.append(pair)
        ans.add(tuple(vals))
    return ans

out=[]
for q,primes,H in [(1,[2,3],4),(1,[2,3,7],4),(2,[2],3),(6,[2,3],3)]:
    expected,bound=trace_types(q,primes,H);got={((Q(0),Q(0)),)*H}
    for m in s.divisors(bound):got|=direct(q,int(m),H)
    assert got==set(expected),(q,got-set(expected),set(expected)-got)
    if H==3:
        rot=set().union(*(direct(q,int(m),1) for m in s.divisors(3)))
        assert rot==set(rotation_types(q,3,[1]))
    # Check the first prime-power layer beyond each cutoff directly as well.
    for p in primes:
        e=0;t=bound
        while t%p==0:e+=1;t//=p
        assert direct(q,p**(e+1),H)=={((Q(0),Q(0)),)*H}
    out.append({'q':q,'primes':primes,'height':H,'bound':bound,'joint_packets':len(got),'direct_cyclotomic_automorphism_average_matches':True,'third_rotation_packets_match':True if H==3 else None,'one_layer_beyond_bound_zero':True})
    print(json.dumps(out[-1]),flush=True)
Path(__file__).with_name('trace_packets_fresh.json').write_text(json.dumps(out,indent=2)+'\n')
