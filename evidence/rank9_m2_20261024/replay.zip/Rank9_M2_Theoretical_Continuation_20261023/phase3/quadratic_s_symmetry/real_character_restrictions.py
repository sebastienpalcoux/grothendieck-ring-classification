"""Standalone real-character/self-dual-induction restriction obstruction."""
import itertools,json,math,time
from quadratic_s_symmetry import qc,characters,HERE

def vectors(ch,dims,target):
    n=ch.n;seen={0};orbits=[]
    for i in range(1,n):
        if i in seen:continue
        orb=sorted({i,ch.du[i]});seen.update(orb);orbits.append(orb)
    weights=[tuple(sum(dims[i][c] for i in orb) for c in range(2)) for orb in orbits]
    assert all(a>=0 and b>=0 for a,b in weights)
    bounds=[min(math.isqrt(int(ch.C[i,i])),int(ch.C[0,i])) for orb in orbits for i in orb]
    bounds=[min(min(math.isqrt(int(ch.C[i,i])),int(ch.C[0,i])) for i in orb) for orb in orbits]
    v=[1]+[0]*(n-1);out=[]
    def recurse(k,remaining):
        if any(x<0 for x in remaining):return
        if k==len(orbits):
            if remaining==(0,0) and all(v[i]*v[j]<=ch.C[i,j] for i in range(n) for j in range(n)):out.append(tuple(v))
            return
        orb=orbits[k];w=weights[k]
        for x in range(bounds[k]+1):
            for i in orb:v[i]=x
            recurse(k+1,tuple(remaining[c]-x*w[c] for c in range(2)))
    recurse(0,(target[0]-1,target[1]));return out

out=[]
for k in [1983,114,128,137,516,1487,1607,1635,1636,1959,1976]:
    start=time.monotonic();rid=f'R9_2_{k}';R=qc.inputs(rid);data=qc.base(R);cs=characters(data['ch'],data['q'],data['D']);cases=[]
    for c in cs:
        vv=vectors(data['ch'],data['dims'],c['dimension'])
        cases.append({'character':[[str(a),str(b)] for a,b in c['values']],'codegree':list(map(str,c['codegree'])),'central_dimension':list(map(str,c['dimension'])),'selfdual_restriction_count':len(vv),'selfdual_restrictions':[list(v) for v in vv]})
    failed=[c for c in cases if not c['selfdual_restriction_count']]
    row={'id':rid,'outcome':'candidate_exclusion' if failed else 'no_conclusion','q':data['q'],'dimensions':[[str(a),str(b)] for a,b in data['dims']],'dual':data['ch'].du,'failed_characters':failed,'counts':[c['selfdual_restriction_count'] for c in cases],'seconds':time.monotonic()-start}
    out.append(row);(HERE/'real_character_results.json').write_text(json.dumps(out,indent=2)+'\n');print(rid,row['outcome'],len(failed),row['seconds'],flush=True)
