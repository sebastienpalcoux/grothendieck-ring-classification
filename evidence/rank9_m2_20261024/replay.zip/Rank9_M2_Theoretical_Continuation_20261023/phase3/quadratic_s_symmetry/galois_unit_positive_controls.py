import hashlib,json,math,time
import sympy as s
from quadratic_s_symmetry import qc,HERE,ROOT
ledger=json.loads((ROOT/'phase2/results/ledger.json').read_text())
ids={r['id'] for r in ledger if r['models']}
accepted=json.loads((ROOT/'phase3/accepted.json').read_text());ids.update(accepted['new_models'])
raw=json.loads((ROOT/'work/verification_corpus.json').read_text())['tensors'];out=[]
for rid in sorted(ids,key=lambda r:int(r.rsplit('_',1)[1])):
    R=raw[rid]
    if any(R[i][j]!=R[j][i] for i in range(9) for j in range(9)):
        out.append({'id':rid,'status':'outside_commutative_scope'});continue
    ch=qc.Characters(R);f,K,ds,D,pD,emb=ch.fp()
    if f.degree()!=2:
        out.append({'id':rid,'status':'outside_quadratic_FP_scope','FP_field_degree':f.degree()});continue
    co=list(map(int,f.all_coeffs()));disc=co[1]**2-4*co[2];q=math.prod(int(p) for p,e in s.factorint(disc).items() if e%2)
    factors=[g for g,m in ch.cf];t=f.gens[0]
    if any(g.degree()>2 or (g.degree()==2 and not s.sqrt(s.discriminant(g)/q).is_Rational) for g in factors):
        out.append({'id':rid,'status':'codegrees_outside_quadratic_field'});continue
    P=s.Poly(s.prod(g.as_expr() for g in factors),t,domain=s.QQ);p=s.Poly(0,t,domain=s.QQ)
    for g in factors:
        g=s.Poly(g,t,domain=s.QQ);M=P.exquo(g);r=s.Poly(1 if g.degree()==1 else t*t/g.nth(0),t,domain=s.QQ)
        p=(p+r*M*s.invert(M,g)).rem(P)
    V=sum((c*ch.C**i for i,c in enumerate(reversed(p.all_coeffs()))),s.zeros(9));v=list(V[0,:])
    assert all(x.is_Integer and x>=0 for x in v) and v[0]==1,(rid,v)
    assert V==sum((v[i]*ch.N[i] for i in range(9)),s.zeros(9))
    out.append({'id':rid,'status':'PASS','q':q,'forced_restriction':list(map(str,v))});print(out[-1],flush=True)
    (HERE/'galois_unit_positive_controls.json').write_text(json.dumps(out,indent=2)+'\n')
(HERE/'galois_unit_positive_controls.json').write_text(json.dumps(out,indent=2)+'\n')
