"""Determine the restriction of the Galois-conjugate-unit central simple."""
import hashlib,json,math,time
from fractions import Fraction as Q
import sympy as s
from quadratic_s_symmetry import qc,HERE
out=[]
for k in [1983,114,128,137,516,1487,1607,1635,1636,1959,1976]:
    start=time.monotonic();rid=f'R9_2_{k}';R=qc.inputs(rid);ch=qc.Characters(R);C=ch.C
    fp,K,ds,D,pD,emb=ch.fp();assert fp.degree()==2
    co=list(map(Q,fp.all_coeffs()));disc=co[1]**2-4*co[2];assert disc.denominator==1
    q=math.prod(int(p) for p,e in s.factorint(disc.numerator).items() if e%2);h=math.isqrt(disc.numerator//q)
    def coords(x):
        z=list(map(lambda a:Q(str(a)),qc.ec(x)));z=[Q(0)]*(2-len(z))+z
        return(z[1]-co[1]*z[0]/2,Q(h)*z[0]/2)
    DD=coords(D);dims=list(map(coords,ds))
    factors=[f for f,m in ch.cf];t=factors[0].gens[0]
    assert all(f.degree() in [1,2] for f in factors)
    assert all(f.degree()==1 or s.sqrt(s.discriminant(f)/q).is_Rational for f in factors)
    modulus=s.prod(f.as_expr() for f in factors);P=s.Poly(modulus,t,domain=s.QQ);p=s.Poly(0,t,domain=s.QQ)
    for f in factors:
        f=s.Poly(f,t,domain=s.QQ);M=P.exquo(f);residue=s.Poly(1 if f.degree()==1 else t*t/f.nth(0),t,domain=s.QQ)
        p=(p+residue*M*s.invert(M,f)).rem(P)
    V=sum((c*C**i for i,c in enumerate(reversed(p.all_coeffs()))),s.zeros(len(R)))
    v=list(V[0,:]);assert V==sum((v[i]*ch.N[i] for i in range(len(R))),s.zeros(len(R)))
    assert tuple(sum(Q(v[i])*dims[i][c] for i in range(len(R))) for c in range(2))==qc.div(DD,(DD[0],-DD[1]),q)
    okay=all(x.is_Integer and x>=0 for x in v) and v[0]==1
    row={'id':rid,'outcome':'no_conclusion' if okay else 'candidate_exclusion','q':q,'polynomial_coefficients':list(map(str,p.all_coeffs())),'forced_restriction':list(map(str,v)),'nonnegative_integral_with_unit_one':bool(okay),'tensor_sha256':hashlib.sha256(json.dumps(R,separators=(',',':')).encode()).hexdigest(),'seconds':time.monotonic()-start}
    out.append(row);(HERE/'galois_unit_results.json').write_text(json.dumps(out,indent=2)+'\n');print(rid,row['outcome'],row['forced_restriction'],flush=True)
