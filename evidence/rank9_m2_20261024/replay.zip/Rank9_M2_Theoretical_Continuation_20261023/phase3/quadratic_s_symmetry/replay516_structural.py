"""Exact finite input checks for the computation-free categorical R516 proof."""
import hashlib,itertools,json,sys
from pathlib import Path
import sympy as s
from quadratic_s_symmetry import qc,characters,HERE
R=qc.inputs('R9_2_516');base=qc.base(R);ch=base['ch'];q=base['q'];assert q==3
t=s.sqrt(3);d=1+t;e=2+t
dims=[s.Rational(a)+s.Rational(b)*t for a,b in base['dims']]
assert dims==[1,1,d,e,e,d,2,2*e,2*d]
assert base['D']==(72,36)
cs=characters(ch,q,base['D']);assert len(cs)==9
low=[s.Rational(c['dimension'][0])+s.Rational(c['dimension'][1])*t for c in cs]
assert low.count(s.Integer(1))==1 and low.count(s.Integer(2))==1
assert all(z in (1,2) or bool(z>4) for z in low)
h=next(c for c in cs if c['dimension']==(2,0));assert h['values'][1]==(1,0)
perm=[next(k for k in range(9) if R[1][i][k]) for i in range(9)]
assert perm==[1,0,5,4,3,2,6,7,8]
assert all(sum(R[1][i])==1 for i in range(9)) and R[1][1][0]==1
deeq=[];seen=set()
for i in range(9):
    if i in seen:continue
    j=perm[i];seen.update([i,j])
    deeq.extend([dims[i]/2,dims[i]/2] if i==j else [dims[i]])
assert all(sum(1 for a in deeq if s.expand(a-z)==0)==3 for z in [1,d,e])
component_solutions=[]
for a,b,c in itertools.product(range(4),repeat=3):
    if s.expand(a+b*d*d+c*e*e-(12+6*t))==0:component_solutions.append((a,b,c))
assert component_solutions==[(0,3,0),(1,1,1)]
# Distinct dimensions force self-duality. Dimension identities and reciprocity
# uniquely give this rank-three tensor for the neutral component.
T=[[[1,0,0],[0,1,0],[0,0,1]],[[0,1,0],[1,1,1],[0,1,2]],[[0,0,1],[0,1,2],[1,2,2]]]
from rings import validate
validate(T)
Ds=[1,d,e]
assert all(s.expand(Ds[i]*Ds[j]-sum(T[i][j][k]*Ds[k] for k in range(3)))==0 for i in range(3) for j in range(3))
G=sum((s.Matrix(M)*s.Matrix(M).T for M in T),s.zeros(3));x=s.Symbol('x')
assert s.Poly(G.charpoly(x).as_expr(),x)==s.Poly((x-3)*(x*x-24*x+36),x)
D=12+6*t;low_dims=[1,s.expand(D/3),s.radsimp(D/(12-6*t))]
low_columns=[]
for z in low_dims:
    candidates=[(1,a,b) for a,b in itertools.product(range(10),repeat=2) if s.expand(1+a*d+b*e-z)==0]
    assert len(candidates)==1;low_columns.append(candidates[0])
assert low_columns==[(1,0,0),(1,1,1),(1,2,2)]
mass=s.expand(sum(v[1]*z for v,z in zip(low_columns,low_dims)));total=s.expand(D*d)
assert mass==18+10*t and total==30+18*t and s.expand(2*mass-total)==6+2*t
out={'id':'R9_2_516','PASS':True,'scope':'general complex using independently verified Galois-PU gate','source_tensor_sha256':hashlib.sha256(json.dumps(R,separators=(',',':')).encode()).hexdigest(),'unique_low_dimensions_at_most_four':['1','2'],'involution':1,'involution_permutation':perm,'central_dim_two_character_g_value':'1','deequivariantized_dimensions':'1^3,(1+sqrt(3))^3,(2+sqrt(3))^3','component_dimension_solutions':component_solutions,'neutral_rank_three_tensor':T,'neutral_low_columns':low_columns,'neutral_twist_one_mass':'18+10sqrt(3)','neutral_induced_dimension':'30+18sqrt(3)','strict_excess':'6+2sqrt(3)','proof':'R516_STRUCTURAL.md'}
(HERE/'R9_2_516_structural_verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
