import json,time
from quadratic_s_symmetry import build,qc,HERE
R=qc.inputs('R9_2_516');A,b,m=build(R,3)
labels=m['rows']+m['extra_rows'];out=[]
tests=[('gram_low_S',{'gram','low','label_count','S_symmetry'}),('gram_low_S_galois',{'gram','low','label_count','S_symmetry','galois'}),('through_second',{'gram','low','label_count','S_symmetry','galois','moment1','moment2','indicator_bound'})]
for name,kinds in tests:
    ix=[i for i,row in enumerate(labels) if row[0] in kinds];aa=[A[i] for i in ix];bb=[b[i] for i in ix]
    columns=list(dict.fromkeys(zip(*aa)));aa=[list(row) for row in zip(*columns)]
    ray,why=qc.exact_separator(aa,bb,90)
    r={'name':name,'outcome':'candidate_exclusion' if ray else 'no_conclusion','rows':[labels[i] for i in ix],'original_rows':ix,'variables':len(columns),'ray':ray,'solver':why,'bTy':sum(x*y for x,y in zip(bb,ray)) if ray else None}
    out.append(r);(HERE/'R9_2_516_simplifications.json').write_text(json.dumps(out,indent=2)+'\n');print(name,r['outcome'],r['bTy'],flush=True)
