import json
from quadratic_s_symmetry import run,HERE
out=[]
for k in [1983,114,128,137,516,1487,1607,1635,1636,1959,1976]:
    r=run(f'R9_2_{k}',6,k==1983,True)
    out.append({key:r[key] for key in ['id','height','outcome','seconds','solver_report']})
    (HERE/'dual_summary.json').write_text(json.dumps(out,indent=2)+'\n')
