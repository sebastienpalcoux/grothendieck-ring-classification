"""Bounded necessary-condition screen, not a categorification decision."""
import json,sys,time
from quadratic_s_symmetry import qc,build,HERE
rid=sys.argv[1];t=time.monotonic();R=qc.inputs(rid);data=qc.base(R)
removed=[v for v,z in data['cols'] if not v[0] and z==(1,0)]
data['cols']=[(v,z) for v,z in data['cols'] if v not in removed]
original=qc.base;qc.base=lambda R:data
try:A,b,m=build(R,3,True)
finally:qc.base=original
ray,why=qc.exact_separator(A,b,timeout=25)
out={'id':rid,'height':3,'hypothesis':'no nontrivial underlying invertible admits a central invertible lift','removed_restrictions':[list(v) for v in removed],'outcome':'candidate_forced_central_invertible' if ray else 'no_certified_forcing','ray':ray,'solver_report':why,'seconds':time.monotonic()-t,'classification_change':False}
if ray:out['bTy']=sum(x*y for x,y in zip(b,ray));out['metadata']=m
(HERE/f'{rid}_forced_invertible_screen.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
