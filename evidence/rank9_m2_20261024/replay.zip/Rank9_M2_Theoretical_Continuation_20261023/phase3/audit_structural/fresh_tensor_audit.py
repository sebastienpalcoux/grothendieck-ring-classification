"""Independent audit from compressed original input, not saved PASS records."""
from pathlib import Path
import gzip,json,hashlib,itertools
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
DIMENSIONS={907:[1,1,2,6,6,6,6,6,6],1071:[1,1,1,'sqrt26',4,4,4,'sqrt26',1],1724:[1,1,1,'sqrt26','sqrt26',4,4,4,1],1356:[1,1,1,2,6,6,3,2,2],1933:[1,1,1,6,6,2,3,2,2]}
# Exact Q(sqrt26), represented by pairs of integers.
def add(a,b):return(a[0]+b[0],a[1]+b[1])
def mul(a,b):return(a[0]*b[0]+26*a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def scale(n,a):return(n*a[0],n*a[1])
def closure(T,S):
 S=set(S)|{0}
 while True:
  new=S|{k for a in S for b in S for k in range(9)if T[a][b][k]}
  if new==S:return sorted(S)
  S=new
counts={};records=[]
for lineno,line in enumerate(gzip.open(ROOT/'inputs/rank9_M2_verified/FusionRingMultiplicationTables.txt.gz','rt'),1):
 T=json.loads(line.replace('{','[').replace('}',']'));m=max(x for a in T for b in a for x in b);counts[m]=counts.get(m,0)+1
 if m!=2 or counts[m]not in DIMENSIONS:continue
 label=counts[m];d=[(0,1)if x=='sqrt26'else(x,0)for x in DIMENSIONS[label]]
 assert len(T)==9
 assert all(T[0][i][j]==T[i][0][j]==int(i==j) for i,j in itertools.product(range(9),repeat=2))
 for i,j in itertools.product(range(9),repeat=2):
  val=(0,0)
  for k in range(9):val=add(val,scale(T[i][j][k],d[k]))
  assert val==mul(d[i],d[j])
 assert all(sum(T[i][j][k]for j in range(9))==1 for i in range(9)for k in[0])
 dual=[next(j for j in range(9)if T[i][j][0])for i in range(9)]
 assert all(dual[dual[i]]==i for i in range(9))
 inv=[i for i in range(9)if d[i]==(1,0)]
 invmul=[[T[i][j].index(1)for j in inv]for i in inv]
 ad=closure(T,{k for i in range(9)for k in range(9)if T[i][dual[i]][k]})
 D=(0,0)
 for x in d:D=add(D,mul(x,x))
 out={'id':f'R9_2_{label}','raw_physical_line':lineno,'raw_tensor_sha256':hashlib.sha256(json.dumps(T,separators=(',',':')).encode()).hexdigest(),'dimensions':DIMENSIONS[label],'dimension_character_all_81_products':True,'global_dimension':D[0],'dual':dual,'invertibles':inv,'invertible_multiplication':invmul,'adjoint_basis':ad}
 if label==907:
  assert D==(222,0)and inv==[0,1]and ad==list(range(9))
  assert all(T[1][i]==T[i][1]==[int(i==k)for k in range(9)]for i in range(2,9))
  out['p']=37;out['h_fixes_all_nonunits']=True
 elif label in[1356,1933]:
  assert D==(96,0)and len(inv)==3 and ad==list(range(9))
  witnesses=[]
  for g in inv[1:]:
   a=next(i for i in range(9)if T[g][i]!=T[i][g]);witnesses.append({'g':g,'x':a,'gx':T[g][a],'xg':T[a][g]})
  out['noncentrality_witnesses_for_each_nontrivial_invertible']=witnesses
 else:
  even=[i for i in range(9)if d[i][1]==0];odd=[i for i in range(9)if d[i][1]!=0]
  assert len(even)==7 and len(odd)==2 and D==(104,0)
  assert all(int(k in odd)==(int(i in odd)+int(j in odd))%2 for i,j,k in itertools.product(range(9),repeat=3)if T[i][j][k])
  assert closure(T,{k for i in even for k in even if T[i][dual[i]][k]})==even
  assert all(T[g][x]==T[x][g]==[int(x==k)for k in range(9)]for g in inv for x in even if d[x]==(4,0))
  orders=[]
  for g in inv:
   y=0
   for o in range(1,5):
    y=T[y][g].index(1)
    if y==0:orders.append(o);break
  assert sorted(orders)==[1,2,4,4]
  out.update({'neutral_basis':even,'odd_basis':odd,'neutral_adjoint_basis':even,'neutral_global_dimension':52,'neutral_invertible_orders':orders,'all_invertibles_fix_all_dimension4_objects':True,'neutral_category_rank':7,'odd_module_rank':2})
 records.append(out)
assert len(records)==5
(OUT/'fresh_tensor_checks.json').write_text(json.dumps(records,indent=2)+'\n')
print({x['id']:'PASS'for x in records})
