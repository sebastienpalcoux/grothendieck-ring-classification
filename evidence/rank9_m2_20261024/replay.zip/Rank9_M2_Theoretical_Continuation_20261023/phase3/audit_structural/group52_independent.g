LoadPackage("smallgrp");;
t:=PermList(Concatenation([2..13],[1]));;
u:=PermList(List([0..12],x->(5*x mod 13)+1));;
G:=Group(t,u);;
Print("GROUP_ORDER ",Size(G)," GROUP_ID ",IdGroup(G),"\n");
for c in ConjugacyClassesSubgroups(G) do
 H:=Representative(c);
 Print("SUBGROUP order=",Size(H)," conjugates=",Size(c)," rank=",NrConjugacyClasses(H)," multiplier=",AbelianInvariantsMultiplier(H),"\n");
 if Size(H)=2 then
  dc:=DoubleCosets(G,H,H);
  Print("DUAL_DOUBLE_COSETS ",Collected(List(dc,Size)),"\n");
  Print("DUAL_RANK ",Sum(dc,d->NrConjugacyClasses(Intersection(H,H^Representative(d)))),"\n");
  Print("NORMALIZER_ORDER ",Size(Normalizer(G,H)),"\n");
 fi;
od;
QUIT;
