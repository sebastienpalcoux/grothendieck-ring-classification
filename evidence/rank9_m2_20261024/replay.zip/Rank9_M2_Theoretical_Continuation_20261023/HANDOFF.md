# Current research handoff

Verified partition: 2,033 excluded, 32 unitary models, 18 unresolved. Use phase3/results/, not the historical ledgers.
The full audit and correction are explained in phase3/REPORT.md.

Preserve the general-complex exclusion scope and unitary model existence
claims. Feasible necessary conditions, unfinished model leads, timed-out
solvers and signed existence gates alone are not classifications.

Continue the open cases from the saved artifacts. R9_2_941 exactly matches
the published dimension-504 open ring of Question 1.14 in arXiv:2507.07023v2.

Online publication is deferred. A later authorized revision should update
rank nine/multiplicity two in the usual ordered tables of both repositories
and the public GitHub Atlas. The former private Atlas is out of scope.
