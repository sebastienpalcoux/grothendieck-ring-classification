from pathlib import Path
import sys,json,sympy as s
P=Path(__file__).resolve().parent;ROOT=P.parents[1]
sys.path[:0]=[str(ROOT/'sources'),str(ROOT/'work')]
from scalar_characters import chars
from exact import t
out=[]
for rec in json.load(open(P/'1975_d8_dual_candidates.json'))['candidates']:
 R=rec['N'];n=len(R);N=list(map(s.Matrix,R));C=sum((N[i]*N[rec['dual'][i]]for i in range(n)),s.zeros(n))
 W=s.Matrix.hstack(*s.Matrix.vstack(*(N[i]*N[j]-N[j]*N[i]for i in range(n)for j in range(i))).nullspace());assert W.cols==8
 Proj=W*(W.T*W).inv()*W.T;T=(s.eye(n)+Proj)*C/2
 fac=[p for p,m in T.charpoly(t).as_poly().factor_list()[1]];coeff=s.symbols('a:'+str(sum(p.degree()for p in fac)));poly=sum(c*t**i for i,c in enumerate(coeff));eq=[]
 for p in fac:
  target=t*t/2304 if p==s.Poly(t*t-288*t+2304,t)else 1
  eq+=s.Poly(s.rem(poly-target,p.as_expr(),t),t).all_coeffs()
 sol=s.solve(eq,coeff);V=sum((sol[c]*T**i for i,c in enumerate(coeff)),s.zeros(n));v=list(V[0,:]);assert V==sum((v[i]*N[i]for i in range(n)),s.zeros(n))
 out.append({'alpha':rec['alpha'],'a':rec['a'],'formal_codegrees':[str(p.as_expr())for p in fac],'sigma':'sqrt2 changes sign, sqrt6 fixed where present','forced_restriction':list(map(str,v)),'passes':all(x.is_Integer and x>=0 for x in v)})
 print(rec['alpha'],rec['a'],out[-1]['passes'],v,flush=True)
(P/'1975_dual_galois.json').write_text(json.dumps(out,indent=2)+'\n')
