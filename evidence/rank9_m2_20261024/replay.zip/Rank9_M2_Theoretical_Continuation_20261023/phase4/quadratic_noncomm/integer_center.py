from pathlib import Path
import sys,json,time,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path[:0]=[str(R/'phase3/noncomm1975')]
import symmetry as sy
import z3
start=time.time();a,b,meta=sy.build(sy.qc.inputs('R9_2_1975'),6)
S=z3.Solver();S.set(timeout=120000);xs=[z3.Int('x'+str(i))for i in range(len(a[0]))]
for x in xs:S.add(x>=0)
for row,rhs in zip(a,b):S.add(z3.Sum([v*x for v,x in zip(row,xs)if v])==rhs)
print('BUILT',len(xs),len(b),'time',time.time()-start,flush=True)
ans=S.check();out={'id':'R9_2_1975','solver':str(ans),'system_hash':hashlib.sha256(json.dumps([a,b],separators=(',',':')).encode()).hexdigest(),'rows':len(b),'columns':len(xs),'seconds':time.time()-start,'outcome':'unresolved'}
if ans==z3.sat:
 vv=[S.model().eval(x).as_long()for x in xs]
 assert all(x>=0 for x in vv)
 assert all(sum(x*y for x,y in zip(row,vv))==rhs for row,rhs in zip(a,b))
 out['exact_integer_witness']=[[i,x]for i,x in enumerate(vv)if x]
else:out['reason_unknown']=S.reason_unknown()
(P/'1975_integer_center.json').write_text(json.dumps(out,indent=2)+'\n');print(out,flush=True)
