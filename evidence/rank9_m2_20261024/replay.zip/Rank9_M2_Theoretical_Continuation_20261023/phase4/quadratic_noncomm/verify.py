"""Exact verification of phase-four noncommutative Morita reductions.
This checks finite arithmetic and tensor identities. It is not a categorification.
"""
from pathlib import Path
import json,sys,itertools,hashlib
import sympy as s
P=Path(__file__).resolve().parent;ROOT=P.parents[1]
sys.path[:0]=[str(ROOT/'work'),str(ROOT/'sources')]
from common import based_iso
C=json.load(open(ROOT/'work/verification_corpus.json'))['tensors']
receipts=[]
for rid in ['R9_2_1848','R9_2_1975']:
 r=json.load(open(P/(rid+'_morita_candidates.json')));assert r['anti']['complete'] and len(r['branches'])==1
 b=r['branches'][0];R=C[rid];M=list(map(s.Matrix,b['M']));n=len(R);q=M[0].rows
 assert all(M[i]*M[j]==sum((R[j][i][k]*M[k]for k in range(n)),s.zeros(q))for i,j in itertools.product(range(n),repeat=2))
 G=s.Matrix(q*q,q*q,lambda p,z:sum(m[z//q,p//q]*m[z%q,p%q]for m in M));assert G==s.Matrix(b['G'])
 cs=b['candidates'];B=[s.Matrix(q,q,x)for x in cs]
 assert all(x*y==y*x for x in B for y in M)
 A=s.Matrix.hstack(*[s.Matrix(list(s.Matrix(v)*s.Matrix(v).T))for v in cs])
 weights,params=A.gauss_jordan_solve(s.Matrix(list(G)));assert not params.rows and all(x.is_Integer and x>=0 for x in weights)
 receipts.append({'id':rid,'module_rank':q,'dual_rank':sum(map(int,weights)),'unique_gram_weights':list(map(int,weights)),'candidate_actions':len(cs)})
 if rid=='R9_2_1848':
  assert list(weights)==[1]*9
  V=s.Matrix.hstack(*map(s.Matrix,cs));assert V.rank()==9
  S=[]
  for i in range(9):
   row=[]
   for j in range(9):
    c=V.gauss_jordan_solve(s.Matrix(list(B[j]*B[i])))[0];assert all(x.is_Integer and x>=0 for x in c);row.append(list(map(int,c)))
   S.append(row)
  p=json.load(open(P/'1848_morita_transport.json'))['raw_to_original'];assert sorted(p)==list(range(9))
  assert all(S[i][j][k]==R[p[i]][p[j]][p[k]]for i,j,k in itertools.product(range(9),repeat=3))
  receipts[-1]['same_ring_transport']=p;receipts[-1]['tensor_equalities']=729
 else:
  assert list(weights)==[1]*6+[2,2]+[1,1]
  inv=[i for i,w in enumerate(weights)if w==1];u=next(i for i,x in enumerate(B)if x==s.eye(q))
  T=[[next(k for k in inv if B[i]*B[j]==B[k])for j in inv]for i in inv]
  orders=[]
  for i in inv:
   x=s.eye(q)
   for o in range(1,9):
    x=x*B[i]
    if x==s.eye(q):orders.append(o);break
  assert sorted(orders)==[1,2,2,2,2,2,4,4]
  assert not all(B[i]*B[j]==B[j]*B[i]for i,j in itertools.product(inv,repeat=2))
  receipts[-1]['invertible_group']='D8 (order8)';receipts[-1]['element_orders']=orders
candidates=json.load(open(P/'1975_d8_dual_candidates.json'));assert len(candidates['candidates'])==10
for rec in candidates['candidates']:
 N=rec['N'];du=rec['dual'];B=[s.Matrix(6,6,v)for v in rec['module_actions']]
 for i,j,k,l in itertools.product(range(12),repeat=4):assert sum(N[i][j][u]*N[u][k][l]for u in range(12))==sum(N[i][u][l]*N[j][k][u]for u in range(12))
 assert all(N[i][j][k]==N[du[i]][k][j]for i,j,k in itertools.product(range(12),repeat=3))
 assert all(B[i]*B[j]==sum((N[i][j][k]*B[k]for k in range(12)),s.zeros(6))for i,j in itertools.product(range(12),repeat=2))
 t=s.symbols('t');Nmat=list(map(s.Matrix,N));cas=sum((Nmat[i]*Nmat[du[i]]for i in range(12)),s.zeros(12))
 if rec['a']in[1,3]:assert s.rem(cas.charpoly(t).as_expr(),t*t-96*t+768,t)==0
lower=json.load(open(P/'lower_tensors.json'));rows={r['id']:r for r in lower['rows']}
assert set(rows)=={'R6_4_1','R6_4_155'}
for r in rows.values():
 assert hashlib.sha256(json.dumps(r['N'],separators=(',',':')).encode()).hexdigest()==r['tensor_sha256']
 assert hashlib.sha256(json.dumps(r['decision'],separators=(',',':'),sort_keys=True).encode()).hexdigest()==r['decision_record_sha256']
assert rows['R6_4_1']['decision']['status']=='excluded'
assert rows['R6_4_155']['decision']['status']=='unresolved'
assert lower['categorical_proof_dependency']['decision_source_sha256']==lower['sources']['decisions']['sha256']
for rec in json.load(open(P/'1975_dual_subrings.json')):
 cand=next(c for c in candidates['candidates']if c['a']==rec['a']and c['alpha']==rec['alpha']);N=cand['N'];J=rec['subring'];m=rec['matches'][0];T=rows[m['id']]['N'];p=m['map']
 assert all(N[i][j][k]==0 for i in J for j in J for k in range(12)if k not in J)
 assert all(N[J[i]][J[j]][J[k]]==T[p[i]][p[j]][p[k]]for i,j,k in itertools.product(range(6),repeat=3))
result={'status':'PASS','classification_changes':[],'morita':receipts,'rank12_candidate_tensors':10,'rank6_full_tensor_transports':4,'notes':['Candidate dual tensors are necessary alternatives, not models.','R6_4_1 branch exclusion uses existing lower-rank proof; no fresh replay of that full proof in this script.','R6_4_155 remains open.','Integer center SMT search timed out; no exclusion inferred.']}
(P/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
