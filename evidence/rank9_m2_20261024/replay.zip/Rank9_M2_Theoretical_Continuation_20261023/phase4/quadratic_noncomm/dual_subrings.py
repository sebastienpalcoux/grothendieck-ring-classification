from pathlib import Path
import json,sys,itertools
P=Path(__file__).resolve().parent;ROOT=P.parents[1];sys.path.insert(0,str(ROOT/'work'))
from common import based_iso,coarse
lower=json.load(open(P/'lower_tensors.json'))
rows=lower['rows']
ledger={r['id']:r['decision'] for r in rows}
out=[]
for r in json.load(open(P/'1975_d8_dual_candidates.json'))['candidates']:
 if r['a']not in [0,4]:continue
 N=r['N'];J={0}
 for x in range(8,12):J.update(i for i,v in enumerate(N[x][r['dual'][x]])if v)
 while True:
  K=J|{k for i in J for j in J for k,v in enumerate(N[i][j])if v}
  if K==J:break
  J=K
 J=sorted(J);S=[[[N[i][j][k]for k in J]for j in J]for i in J]
 assert len(J)==6
 matches=[]
 for rr in rows:
  if rr['m']!=4 or coarse(S)!=coarse(rr['N']):continue
  iso=based_iso(S,rr['N'])
  if iso is not None:matches.append({'id':rr['id'],'map':iso,'decision':ledger[rr['id']]})
 assert len(matches)==1
 out.append({'alpha':r['alpha'],'a':r['a'],'subring':J,'matches':matches})
 print(r['alpha'],r['a'],matches[0]['id'],matches[0]['decision'].get('status'),flush=True)
(P/'1975_dual_subrings.json').write_text(json.dumps(out,indent=2)+'\n')
