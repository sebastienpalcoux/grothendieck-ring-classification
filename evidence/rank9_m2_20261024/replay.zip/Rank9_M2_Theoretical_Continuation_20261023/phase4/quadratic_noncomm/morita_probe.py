from pathlib import Path
import sys,json,types,itertools,time
P=Path(__file__).resolve().parent;ROOT=P.parents[1]
sys.path[:0]=[str(ROOT/'phase3'),str(ROOT/'work'),str(ROOT/'sources')]
import noncomm_anti_experiment as na
import noncomm_morita as nm
import full_morita_gram as fg
import sympy as s
C=json.load(open(ROOT/'work/verification_corpus.json'))
for rid,g in [('R9_2_1975',5),('R9_2_1848',8)]:
 R=C['tensors'][rid];anti=na.module.enumerate_anti(R,g,max_seconds=120)
 print(rid,'complete',anti['complete'],'branches',len(anti['branches']),flush=True)
 result={'id':rid,'g':g,'anti':anti,'branches':[]}
 for TT in anti['branches']:
  T=[sum(m,[])for m in TT];labs,M=nm.module_matrices(R,g,anti['fixed'],T)
  G=fg.full_gram(M);V=s.Matrix.hstack(*G.columnspace());cols=fg.first_columns(M,g);unique=sorted(set(cols));allcs=[]
  for c in unique:
   cs=set()
   for row in unique:cs.update(fg.image_candidates(G,V,c,row,node_limit=10000000))
   for x in sorted(cs):
    B=s.Matrix(len(labs),len(labs),x)
    if all(B*m==m*B for m in M):allcs.append(x)
  branch={'T':TT,'labels':labs,'M':[m.tolist()for m in M],'G':G.tolist(),'first_cols':cols,'candidates':allcs,'rank':G.rank()}
  result['branches'].append(branch)
  print('module rank',len(labs),'dualrank',len(cols),'Gramrank',G.rank(),'candidates',len(allcs),flush=True)
 (P/(rid+'_morita_candidates.json')).write_text(json.dumps(result,indent=2,default=int)+'\n')
