from pathlib import Path
import json,itertools,sympy as s
P=Path(__file__).resolve().parent
b=json.load(open(P/'R9_2_1975_morita_candidates.json'))['branches'][0]
M=[s.Matrix(6,6,x)for x in b['candidates']]
invs=[9,4,5,8,0,3,1,2] # unit first
G=[[invs.index(M.index(M[i]*M[j]))for j in invs]for i in invs]
H=[0,1]
cosets=sorted(set(tuple(sorted(G[g][h]for h in H))for g in range(8)))
qof=[next(i for i,c in enumerate(cosets)if g in c)for g in range(8)]
Q=[[qof[G[a[0]][b[0]]]for b in cosets]for a in cosets]
assert Q[0]==list(range(4))
outs=[]
for alpha,a0 in itertools.product([2,3],range(5)):
 N=[[[0]*12 for j in range(12)]for i in range(12)]
 for g in range(8):
  for h in range(8):N[g][h][G[g][h]]=1
  for a in range(4):N[g][8+a][8+Q[qof[g]][a]]=N[8+a][g][8+Q[qof[g]][a]]=1
 for a in range(4):
  for c in range(4):
   for g in cosets[Q[Q[a][c]][alpha]]:N[8+a][8+c][g]=1
   for d in range(4):
    k=Q[Q[a][c]][d];N[8+a][8+c][8+d]=a0 if k in [0,alpha]else 4-a0
 for i,j,k,l in itertools.product(range(12),repeat=4):
  assert sum(N[i][j][u]*N[u][k][l]for u in range(12))==sum(N[i][u][l]*N[j][k][u]for u in range(12))
 du=[next(j for j in range(12)if N[i][j][0])for i in range(12)]
 for i,j,k in itertools.product(range(12),repeat=3):assert N[i][j][k]==N[du[i]][k][j]
 BM=[M[i]for i in invs]+[M[6],M[6],M[7],M[7]]
 for i,j in itertools.product(range(12),repeat=2):assert BM[i]*BM[j]==sum((N[i][j][k]*BM[k]for k in range(12)),s.zeros(6))
 outs.append({'alpha':alpha,'a':a0,'group_coset':list(cosets[alpha]),'dual':du,'N':N,'module_actions':[list(m)for m in BM]})
(P/'1975_d8_dual_candidates.json').write_text(json.dumps({'G':G,'H':H,'Q':Q,'cosets':cosets,'candidates':outs},indent=2,default=int)+'\n')
print('ten rank12 D8 candidate tensors: all associativity, reciprocity,144 action equations passed')
