from pathlib import Path
import sys,time,json,collections,heapq
P=Path(__file__).resolve().parent;B=P.parents[1];sys.path.insert(0,str(B/'phase3'))
from mr_linear import equations
start=time.time();d=equations(2,15,1,4);n=len(d['labs'])+d['N'];rows={};adj=collections.defaultdict(set);q=[];seq=0

def combine(a,b,m):
 a=dict(a)
 for k,v in b.items():
  z=a.get(k,0)+m*v
  if z:a[k]=z
  elif k in a:del a[k]
 return a

def put(r,a,b,proof):
 global seq
 if not a:
  if b%16:
   coeff=collections.defaultdict(int);rhs=0
   for k,c in proof.items():
    t,w=d['eqs'][k];rhs+=c*w
    for e,j in t:coeff[j]+=c*e
   assert all(v==0 for v in coeff.values())and rhs%16==b%16
   out={'status':'arbitrary_nonzero_complex_tensorators_impossible_for_this_ansatz','parameters':{'p':2,'r':15,'v':1},'equation_count':len(d['eqs']),'variable_count':n,'RHS_denominator':16,'integer_relation':sorted(proof.items()),'RHS_integer_sum':rhs,'RHS_residue':rhs%16,'seconds':time.time()-start}
   (P/'mr_exact_relation.json').write_text(json.dumps(out,indent=2)+'\n');print('CONTRADICTION',len(proof),'terms',rhs%16,'time',time.time()-start,flush=True);sys.exit(0)
  return
 rows[r]=(a,b%16,proof)
 for j in a:adj[j].add(r)
 unit=[j for j,v in a.items()if abs(v)==1]
 if unit:
  seq+=1;heapq.heappush(q,(len(a),len(proof),seq,r,min(unit,key=lambda j:len(adj[j]))))
for r,(terms,b) in enumerate(d['eqs']):
 a={}
 for c,j in terms:a[j]=a.get(j,0)+c
 a={j:c for j,c in a.items()if c}
 put(r,a,b,{r:1})
pivots=0
while q:
 ln,lp,seq,r,j=heapq.heappop(q)
 if r not in rows:continue
 a,b,proof=rows[r]
 if len(a)!=ln or len(proof)!=lp or a.get(j)not in(1,-1):continue
 rows.pop(r)
 for k in a:adj[k].discard(r)
 affected=list(adj[j]);v=a[j];pivots+=1
 for rr in affected:
  c,e,pp=rows.pop(rr)
  for k in c:adj[k].discard(rr)
  f=-c[j]*v
  put(rr,combine(c,a,f),e+f*b,combine(pp,proof,f))
 if pivots%100==0:print('pivots',pivots,'rows',len(rows),'time',time.time()-start,flush=True)
print('remaining',len(rows),'pivots',pivots)
(P/'mr_exact_remainder.json').write_text(json.dumps({'rows':[[sorted(a.items()),b,sorted(p.items())]for a,b,p in rows.values()]})+'\n')
