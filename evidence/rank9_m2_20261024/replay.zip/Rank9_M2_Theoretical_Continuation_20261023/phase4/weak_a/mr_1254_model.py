"""Fusion tensor of the coherently descended mixed cyclic action."""
from pathlib import Path
import json,itertools,sys
P=Path(__file__).resolve().parent;B=P.parents[1];sys.path.insert(0,str(B/'sources'))
from match_models import based_iso
from cyclic_ty_models import check_ring
D=json.load(open(P/'mr_order4_descent_2_3_1_4.json'))
lab=D['labels'];J={tuple(l):j for l,j in zip(D['tensorator_labels'],D['tensorator_exponents'])};dd=D['square_to_K_exponents'];g=D['boson_index'];R0=D['tensor'];F0=D['automorphism']
# Correct the C2 coherence defect by the universal-grading character h=-2.
for a,(i,q) in enumerate(lab):
 ga=R0[g][a].index(1)
 defect=(2*dd[F0[a]]-2*dd[a]-int(i==2)*(J[g,g,0]-2*J[g,a,ga]))%32
 assert defect==16*int(i==2)
d=[(v-4*q)%16 for v,(i,q)in zip(dd,lab)]
for a,(i,q)in enumerate(lab):
 ga=R0[g][a].index(1)
 defect=(2*d[F0[a]]-2*d[a]-int(i==2)*(J[g,g,0]-2*J[g,a,ga]))%32
 assert defect==0
for a,b,c in D['tensorator_labels']:
 assert (J[a,b,c]+J[F0[a],F0[b],F0[c]]-d[a]-d[b]+d[c]-D['K_tensorator_exponents'][D['tensorator_labels'].index([a,b,c])])%16==0
assert d[g]==J[g,g,0]
# quotient representatives (1,charge2a) and (sigma,1+2r)
Qlab=[['u',a]for a in range(8)]+[['X',r]for r in range(4)]
R=[[[0]*12 for _ in range(12)]for _ in range(12)]
for a,b in itertools.product(range(8),repeat=2):R[a][b][(a+b)%8]=1
for a,r in itertools.product(range(8),range(4)):R[a][8+r][8+(a+r)%4]=R[8+r][a][8+(a+r)%4]=1
for r,s in itertools.product(range(4),repeat=2):
 for t in [1,5]:R[8+r][8+s][(r+s+t)%8]=1
check_ring(R)
F=[-a%8 for a in range(8)]+[8+(3*r+1)%4 for r in range(4)]
assert all(F[F[a]]==a for a in range(12))
seen=set();E=[]
for a in range(12):
 if a in seen:continue
 O=sorted({a,F[a]});seen.update(O)
 for sign in([1,-1]if len(O)==1 else[0]):E.append((O,sign))
assert len(E)==9
cover=[lab.index([0,2*a])for a in range(8)]+[lab.index([2,1+2*r])for r in range(4)]
T=[[[0]*9 for _ in range(9)]for _ in range(9)]
for i,(A,s) in enumerate(E):
 for j,(BB,t) in enumerate(E):
  for k,(CC,u) in enumerate(E):
   c=CC[0];dim=sum(R[a][b][c]for a in A for b in BB)
   if len(CC)==1:
    trace=0
    for a,b in itertools.product(A,BB):
     if F[a]!=a or F[b]!=b or not R[a][b][c]:continue
     aa,bb,cc=cover[a],cover[b],cover[c]
     exponent=(d[aa]+d[bb]-d[cc]-2*J[aa,bb,cc])%32
     assert exponent in(0,16)
     trace+=s*t*u*((-1)**(exponent//16))*R[a][b][c]
    assert (dim+trace)%2==0;T[i][j][k]=(dim+trace)//2
   else:T[i][j][k]=dim
check_ring(T)
source=json.load(open(B/'work/verification_corpus.json'))['tensors']['R9_2_1254'];iso=based_iso(source,T);assert iso is not None
out={'id':'R9_2_1254','status':'unitarily_realized','model':'Mixed order-four cyclic-cover functor descended to a coherent C2 action on generalized Moore-Read category, then equivariantized','source_to_model':iso,'tensor':T,'parameters':{'cover_action':'mr_order4_descent_2_3_1_4.json','corrected_square_to_K_exponents':d,'grading_character_adjustment_h':-2,'quotient_labels':Qlab,'quotient_tensor':R,'quotient_involution':F,'equivariant_labels':E},'proof':'MR_1254_MODEL.md','all_729_coefficients_match':True}
(P/'mr_1254_model.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS R9_2_1254 all729coefficients',iso)
