from hopf8_pairing import B,ix,M,D,n,conv,chars
import itertools,json,sympy as s
from pathlib import Path
P=Path(__file__).resolve().parent
pairings=json.load(open(P/'hopf8_pairings.json'))['pairings']
def mul(A,B):
 out=[0]*n
 for i,a in enumerate(A):
  for j,b in enumerate(B):
   for k,v in M[i][j].items():out[k]+=a*b*v
 return [s.expand(v) for v in out]
def unit(a,b,c):return [int(ix[a,b,c]==i)for i in range(n)]
U=s.symbols('v:4')
for sw in [0,1]:
 xx=unit(1-sw,sw,0);yy=unit(sw,1-sw,0);zz=[U[2*a+b] if c else 0 for a,b,c in B]
 rows=[]
 for a,b,c in B:
  x=unit(0,0,0)
  if a:x=mul(x,xx)
  if b:x=mul(x,yy)
  if c:x=mul(x,zz)
  rows.append(x)
 A=s.Matrix(rows)
 eq=set()
 for i,j,k in itertools.product(range(n),repeat=3):
  out=sum(A[i,h]*D[h].get((j,k),0)for h in range(n))-sum(v*A[a,j]*A[b,k]for(a,b),v in D[i].items())
  if out:eq.add(s.expand(out))
 for i,j in itertools.product(range(n),repeat=2):
  lhs=mul(rows[i],rows[j]);rhs=[sum(co*A[k,l]for k,co in M[i][j].items())for l in range(n)]
  eq.update(s.expand(a-b)for a,b in zip(lhs,rhs)if a!=b)
 eq.add(sum(zz)-1)
 sols=s.solve(list(eq),U,dict=True)
 for sub in sols:
  T=s.simplify(A.subs(sub))
  if T.det()==0:continue
  print('automorphism',sw,sub,'order2',T*T==s.eye(8))
  print('chars',[next(j for j,c in enumerate(chars)if T*s.Matrix(c)==s.Matrix(d))for d in chars])
  print('pairingfixed',[s.simplify(T*s.Matrix([[s.sympify(x)for x in r]for r in p['pairing']])*T.T-s.Matrix([[s.sympify(x)for x in r]for r in p['pairing']]))==s.zeros(8)for p in pairings])
