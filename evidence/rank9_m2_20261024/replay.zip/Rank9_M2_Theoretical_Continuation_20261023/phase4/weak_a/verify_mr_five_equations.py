"""Independent five-equation impossibility check, no source generator imported."""
from pathlib import Path
import json
P=Path(__file__).resolve().parent
# tuples (a,b,c,d,e,f), with simple object (Ising index, C16 charge).
triples=[[(1,6),(2,3),(1,6),(2,15),(2,9),(2,9)],
 [(2,3),(2,3),(2,3),(2,9),(1,6),(1,6)],
 [(2,9),(1,6),(2,9),(1,8),(2,15),(2,15)],
 [(2,15),(2,9),(2,15),(2,7),(1,8),(1,8)]]
# Necessary tensorator ratios are x*y, x, y*z, z*t; central transport gives t.
rows=[[1,1,0,0],[1,0,0,0],[0,1,1,0],[0,0,1,1],[0,0,0,1]]
coeff=[-1,1,1,-1,1]
assert all(sum(c*row[j]for c,row in zip(coeff,rows))==0 for j in range(4))
def ising(a,b,c,d,e,f):
 if a==b==c==2:return (e*f)%2
 if a!=2 and b==2 and c!=2:return a*c%2
 if a==2 and b!=2 and c==2:return b*d%2
 return 0
out=[]
for p in [2,6,10,14]:
 for r in [7,15]:
  def F(X):
   i,a=X;return((i^((a//2)%2))if i<2 else 2,r*a%16)
  def exponent(T):
   return (8*ising(*(X[0]for X in T))+p*T[0][1]*((T[1][1]+T[2][1])//16))%16
  rhs=[(exponent([F(X)for X in T])-exponent(T))%16 for T in triples]
  j=(-p//2)%8
  half=lambda X:(j*X[1]+[0,8,12][X[0]])%16
  rhs.append((half(F((2,15)))-half((2,15)))%16)
  total=sum(c*b for c,b in zip(coeff,rhs))%16
  assert total==8
  out.append({'p':p,'r':r,'rhs_exponents':rhs,'combined_exponent':total})
(P/'mr_five_equations_verified.json').write_text(json.dumps({'status':'PASS','four_tensor_functor_channels':triples,'relation_coefficients':coeff,'variants':out},indent=2)+'\n')
print('PASS: five necessary equations give 1=-1 in all8 mixed-lift ansatzes over C*')
