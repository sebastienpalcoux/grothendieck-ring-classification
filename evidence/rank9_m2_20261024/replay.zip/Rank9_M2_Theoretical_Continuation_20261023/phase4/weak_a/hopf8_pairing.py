from pathlib import Path
import itertools,json
import sympy as s
P=Path(__file__).resolve().parent
B=list(itertools.product(range(2),repeat=3)); ix={v:i for i,v in enumerate(B)};n=8
# x^a y^b z^c. Delta(z)=1/2(1+1 tensor x+y tensor1-y tensor x)(z tensor z).
def mulbasis(u,v):
 a,b,c=B[u];d,e,f=B[v]
 if c:d,e=e,d
 a^=d;b^=e
 if c*f:
  return {ix[a^h,b^k,0]:s.Rational(co,2) for h,k,co in [(0,0,1),(1,0,1),(0,1,1),(1,1,-1)]}
 return {ix[a,b,c^f]:s.Integer(1)}
M=[[mulbasis(u,v) for v in range(n)]for u in range(n)]
D=[]
for a,b,c in B:
 if not c:D.append({(ix[a,b,0],ix[a,b,0]):s.Integer(1)})
 else:D.append({(ix[a^h,b^k,1],ix[a^l,b^m,1]):s.Rational(co,2) for h,k,l,m,co in [(0,0,0,0,1),(0,0,1,0,1),(0,1,0,0,1),(0,1,1,0,-1)]})
eps=[1]*n
chars=[]
for v,z in [(1,1),(1,-1),(-1,s.I),(-1,-s.I)]: chars.append([v**(a+b)*z**c for a,b,c in B])
def conv(A,B):return [s.expand(sum(v*A[i]*B[j]for(i,j),v in dd.items()))for dd in D]
u=s.symbols('u:4'); sols=[]
for xx,yy in itertools.permutations([1,2,3],2):
 rx=chars[xx];ry=chars[yy];rxy=conv(rx,ry)
 rows=[None]*8
 rows[ix[0,0,0]]=eps;rows[ix[1,0,0]]=rx;rows[ix[0,1,0]]=ry;rows[ix[1,1,0]]=rxy
 rz=[rows[k][ix[0,0,1]] if not c else u[2*a+b] for k,(a,b,c) in enumerate(B)]
 rows[ix[0,0,1]]=rz;rows[ix[1,0,1]]=conv(rx,rz);rows[ix[0,1,1]]=conv(ry,rz);rows[ix[1,1,1]]=conv(rxy,rz)
 PP=s.Matrix(rows)
 eq=set(s.expand(x) for x in PP-PP.T if x)
 for a,b,c in itertools.product(range(8),repeat=3):
  z=s.expand(sum(v*PP[k,c]for k,v in M[a][b].items())-sum(v*PP[a,i]*PP[b,j]for(i,j),v in D[c].items()))
  if z: eq.add(z)
 so=s.solve(list(eq),u,dict=True)
 for sub in so:
  Q=PP.subs(sub)
  if Q.det()!=0:
   print('pair',xx,yy,sub,'det',s.simplify(Q.det()))
   sols.append({'characters':[xx,yy],'pairing':[[str(s.simplify(Q[i,j]))for j in range(8)]for i in range(8)]})
(P/'hopf8_pairings.json').write_text(json.dumps({'basis':B,'pairings':sols},indent=2))
