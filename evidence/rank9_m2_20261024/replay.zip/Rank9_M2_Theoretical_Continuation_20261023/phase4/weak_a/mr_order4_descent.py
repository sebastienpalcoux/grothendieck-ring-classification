"""Order-four cover functor whose square is the central-boson grading functor."""
from pathlib import Path
import sys,json,itertools,time
P=Path(__file__).resolve().parent;B=P.parents[1];sys.path[:0]=[str(B/'phase3'),str(B/'phase2/weak_integral'),str(B/'sources')]
from mr_linear import linear_solve
from ising_square_action import fs
# Extract the pure tensor-functor/central-lift generator without executing search.
src=(P/'mr_order4_lift.py').read_text().split('\nstart=time.time();d=equations')[0]
ns={'__file__':str(P/'mr_order4_lift.py')};exec(src,ns)

def build(p=2,r=3,v=1,bits=4):
 start=time.time();D=ns['equations'](p,r,v,bits);labels=D['B'];ix={a:i for i,a in enumerate(labels)};R=D['R'];N=len(labels);g=D['g'];L=D['labs'];jx={a:i for i,a in enumerate(L)};F=D['sg'];mod=2**bits;scale=mod//16
 fusion=lambda a,b:[k for k in range(N)if R[a][b][k]]
 gx=[fusion(g,a)[0]for a in range(N)];K=[gx[a]if labels[a][0]==2 else a for a in range(N)]
 assert [F[F[a]]for a in range(N)]==K
 w=lambda a,b,c,d,e,f:scale*(8*fs(*(labels[x][0]for x in[a,b,c,d,e,f]))+p*labels[a][1]*((labels[b][1]+labels[c][1])//16))%mod
 half=lambda a:scale*(D['j']*labels[a][1]+[0,8,12][labels[a][0]])%mod
 J={}
 for a,b,c in L:
  aa=labels[a][0]==2;bb=labels[b][0]==2
  if not aa and not bb:z=0
  elif aa and not bb:z=w(g,a,b,gx[c],gx[a],c)
  elif not aa and bb:z=-w(a,g,b,gx[c],gx[a],gx[b])-half(a)+w(g,a,b,gx[c],gx[a],c)
  else:z=w(g,a,gx[b],c,gx[a],gx[c])-w(a,g,b,gx[c],gx[a],gx[b])-half(a)+w(g,a,b,gx[c],gx[a],c)-w(g,g,c,c,0,gx[c])
  J[a,b,c]=z%mod
 # Verify K is an actual tensor functor against every nonzero associator entry.
 count=0
 for a,b,c in itertools.product(range(N),repeat=3):
  for e in fusion(a,b):
   for d in fusion(e,c):
    for f in fusion(b,c):
     if not R[a][f][d]:continue
     lhs=J[a,b,e]+J[e,c,d]-J[b,c,f]-J[a,f,d]
     rhs=w(K[a],K[b],K[c],K[d],K[e],K[f])-w(a,b,c,d,e,f)
     assert (lhs-rhs)%mod==0,('Kfunctor',a,b,c,d,e,f,lhs,rhs)
     count+=1
 eqs=list(D['eqs'])
 for a,b,c in L:
  eqs.append(([(1,jx[a,b,c]),(1,jx[F[a],F[b],F[c]]),(-1,len(L)+a),(-1,len(L)+b),(1,len(L)+c)],J[a,b,c]))
 eqs.append(([(1,len(L)+g),(-1,jx[g,g,0])],0))
 print('Ktensorator PASS',count,'jointvariables',len(L)+N,'eqs',len(eqs),flush=True)
 x=linear_solve(len(L)+N,eqs,mod)
 out={'status':'inconsistent'if x is None else'sat_exactly_verified','p':p,'r':r,'v':v,'bits':bits,'modulus':mod,'seconds':time.time()-start,'K_tensorator_checked_entries':count}
 if x is not None:out.update(labels=labels,tensor=R,automorphism=F,K_automorphism=K,tensorator_labels=L,tensorator_exponents=x[:len(L)],square_to_K_exponents=x[len(L):],K_tensorator_exponents=[J[l]for l in L],boson_index=g,boson_character=D['j'],equations=len(eqs))
 (P/f'mr_order4_descent_{p}_{r}_{v}_{bits}.json').write_text(json.dumps(out,indent=2)+'\n');print(out['status'],out['seconds'],flush=True)
 return out
if __name__=='__main__':build(*(map(int,sys.argv[1:])if len(sys.argv)>1 else(2,3,1,4)))
