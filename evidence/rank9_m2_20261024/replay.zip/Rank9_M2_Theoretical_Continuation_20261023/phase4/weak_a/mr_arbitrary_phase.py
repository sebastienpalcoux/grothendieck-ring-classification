from pathlib import Path
import sys,time,json
from flint import fmpz_mat
P=Path(__file__).resolve().parent;B=P.parents[1];sys.path.insert(0,str(B/'phase3'))
from mr_linear import equations
start=time.time();d=equations(2,15,1,4);n=len(d['labs'])+d['N'];unique=set()
for terms,b in d['eqs']:
 row=[0]*(n+1)
 for c,j in terms:row[j]+=c
 row[-1]=b
 if any(row):
  f=next(x for x in row if x)
  if f<0:row=[-x for x in row]
  unique.add(tuple(row))
print('matrix',len(unique),n+1,flush=True)
A=fmpz_mat(sorted(unique));print('built',time.time()-start,flush=True)
H=A.hnf(); print('hnf',time.time()-start,flush=True)
constraints=[];rank=0
for row in H.tolist():
 if any(row):rank+=1
 if not any(row[:-1])and row[-1]:constraints.append(int(row[-1]))
out={'status':'arbitrary_U1_phases_inconsistent'if any(x%16 for x in constraints)else'no_constraint_from_full_torus','rows':len(unique),'columns':n+1,'rank':rank,'pure_RHS_integer_lattice_constraints':constraints,'RHS_denominator':16,'seconds':time.time()-start}
(P/'mr_arbitrary_phase.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
