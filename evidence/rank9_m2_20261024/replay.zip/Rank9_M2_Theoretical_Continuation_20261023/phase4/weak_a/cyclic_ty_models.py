"""Explicit cyclic C9 generalized-TY condensation and inversion orbifolds.
Only exact modular arithmetic and integer tensor equations are used.
"""
from pathlib import Path
import itertools,json,sys,hashlib
P=Path(__file__).resolve().parent; B=P.parents[1]
sys.path.insert(0,str(B/'sources'))
from match_models import based_iso

def check_ring(T):
 n=len(T); dual=[]
 for i in range(n):
  candidates=[j for j in range(n) if T[i][j][0]]
  assert len(candidates)==1;dual.append(candidates[0])
 for i,j,k in itertools.product(range(n),repeat=3):
  assert T[0][i][j]==T[i][0][j]==int(i==j)
  assert T[i][j][0]==int(dual[i]==j)
  assert T[i][j][k]>=0
  assert T[i][j][k]==T[dual[i]][k][j]==T[k][dual[j]][i]
 for i,j,k,l in itertools.product(range(n),repeat=4):
  assert sum(T[i][j][x]*T[x][k][l] for x in range(n))==sum(T[j][k][x]*T[i][x][l] for x in range(n))
 return dual

def check_pointed():
 n=9
 w=lambda a,b,c:3*a*((b+c)//n)%n
 mu=lambda a,b:-3*a*int(b>0)%n
 for a,b,c,d in itertools.product(range(n),repeat=4):
  assert (w(b,c,d)-w((a+b)%n,c,d)+w(a,(b+c)%n,d)-w(a,b,(c+d)%n)+w(a,b,c))%n==0
 for a,b,c in itertools.product(range(n),repeat=3):
  assert (mu(a,b)+mu((a+b)%n,c)-mu(b,c)-mu(a,(b+c)%n)-w(-a%n,-b%n,-c%n)+w(a,b,c))%n==0
 for a,b in itertools.product(range(n),repeat=2):
  assert (mu(a,b)+mu(-a%n,-b%n))%n==0
 # Right half-braiding z tensor X -> X tensor z. For h=3, beta(x)=zeta9^(2x).
 hb=lambda h,j,x:j*x%n
 for x,y in itertools.product(range(n),repeat=2):
  assert (hb(3,2,(x+y)%n)-hb(3,2,x)-hb(3,2,y)+w(3,x,y)-w(x,3,y)+w(x,y,3))%n==0
 for x in range(n):
  # Tensor-square central object: h=6, beta(x)=zeta9^(4x).
  square=(2*hb(3,2,x)+w(3,3,x)-w(3,x,3)+w(x,3,3))%n
  assert square==hb(6,4,x)
  cube=(square+hb(3,2,x)+w(6,3,x)-w(6,x,3)+w(x,6,3))%n
  assert cube==0
  # Inversion transports the central generator to its inverse, exactly.
  transformed=(hb(3,2,-x%n)+mu(3,-x%n)-mu(-x%n,3))%n
  assert transformed==square
 for a,b,c in itertools.product(range(3),repeat=3):
  assert w(3*a,3*b,3*c)==0
 for a,b in itertools.product(range(3),repeat=2): assert mu(3*a,3*b)==0
 assert (3+hb(3,2,3))%n==0 # TY self-braiding zeta3 times pointed self-braiding.
 return {'omega_cocycle_equations':9**4,'inversion_tensorator_equations':9**3,'inversion_square_equations':9**2,'central_half_braiding_equations':9**2,'central_cube':True,'inversion_preserves_central_regular_algebra':True}

def generalized_ty():
 # Quotient of TY(C3) x Vec(C9,omega3) by diagonal (a,3).
 labels=[['g',a] for a in range(9)]+[['X',r] for r in range(3)]
 T=[[[0]*12 for _ in range(12)]for _ in range(12)]
 for a,b in itertools.product(range(9),repeat=2): T[a][b][(a+b)%9]=1
 for a,r in itertools.product(range(9),range(3)): T[a][9+r][9+(a+r)%3]=T[9+r][a][9+(a+r)%3]=1
 for r,s in itertools.product(range(3),repeat=2):
  for h in range(3):T[9+r][9+s][(r+s-3*h)%9]=1
 check_ring(T)
 return T,labels

def orbifold(parity):
 R,labels=generalized_ty();sigma=[-a%9 for a in range(9)]+[9+(-r%3)for r in range(3)]
 seen=set();labs=[]
 for a in range(12):
  if a in seen:continue
  O=sorted({a,sigma[a]});seen.update(O)
  for sg in ([1,-1]if len(O)==1 else[0]):labs.append((O,sg))
 n=len(labs);T=[[[0]*n for _ in range(n)]for _ in range(n)]
 for i,(A,s) in enumerate(labs):
  for j,(BB,t) in enumerate(labs):
   for k,(CC,u) in enumerate(labs):
    c=CC[0];dim=sum(R[a][b][c] for a in A for b in BB)
    if len(CC)==1:
     trace=0
     for a,b in itertools.product(A,BB):
      if sigma[a]!=a or sigma[b]!=b:continue
      sign=(-1)**parity if a==b==9 else 1
      trace+=s*t*u*sign*R[a][b][c]
     assert (dim+trace)%2==0
     T[i][j][k]=(dim+trace)//2
    else:T[i][j][k]=dim
 dual=check_ring(T)
 return T,{'GTY_labels':labels,'GTY_tensor':R,'inversion':sigma,'equivariant_labels':labs,'parity_coherence':parity,'dual':dual}

def main():
 arithmetic=check_pointed();src=json.load(open(B/'work/verification_corpus.json'))['tensors'];out=[]
 for parity,rid in [(0,'R9_2_746'),(1,'R9_2_1209')]:
  T,params=orbifold(parity);iso=based_iso(src[rid],T);assert iso is not None
  assert all(src[rid][i][j][k]==T[iso[i]][iso[j]][iso[k]] for i,j,k in itertools.product(range(9),repeat=3))
  out.append({'id':rid,'status':'unitarily_realized','model':'Inversion equivariantization of cyclic-C9 generalized Tambara-Yamagami category obtained by explicit central C3 condensation','tensor':T,'source_to_model':iso,'parameters':params,'proof':'CYCLIC_TY_MODELS.md','all_729_coefficients':True})
  print(rid,iso)
 (P/'cyclic_ty_models.json').write_text(json.dumps({'checks':arithmetic,'models':out},indent=2)+'\n')
 print('PASS: explicit central/action equations and both full fusion tensors')
if __name__=='__main__':main()
