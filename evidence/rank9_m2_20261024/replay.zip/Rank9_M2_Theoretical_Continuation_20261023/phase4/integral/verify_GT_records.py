"""Replay the exact stored group-theoretical narrowing records.

This standard-library-only replay verifies outputs and tensor bindings from
the research archive. No repository checkout, GAP installation, NumPy, or
SymPy is required. The separate GAP enumeration and transfer generators
are optional full fresh-replay commands documented in the proof.
"""
from pathlib import Path
import gzip,hashlib,itertools,json
P=Path(__file__).resolve().parent;ROOT=P.parents[1]
if not __debug__:
    raise SystemExit('Run this verifier without -O: its exact checks use assertions.')

def signature(T):
    n=len(T);dual=[next(j for j in range(n)if T[i][j][0])for i in range(n)]
    return [(i==0,dual[i]==i,tuple(sorted(map(sum,T[i]))),
             tuple(sorted(sum(T[j][i])for j in range(n))),
             tuple(sorted(T[i][dual[i]])),sum(T[i][j][j]for j in range(n)))
            for i in range(n)]

def based_iso(A,B):
    """Exhaustive identity-preserving based-ring isomorphism search."""
    n=len(A)
    if len(B)!=n:return None
    sa,sb=signature(A),signature(B)
    if sorted(sa)!=sorted(sb):return None
    candidates=[{j for j in range(n)if sa[i]==sb[j]}for i in range(n)]
    p={0:0};used={0}
    da=[next(j for j in range(n)if A[i][j][0])for i in range(n)]
    db=[next(j for j in range(n)if B[i][j][0])for i in range(n)]
    def compatible(i,j):
        if A[i][i][i]!=B[j][j][j]:return False
        if da[i] in p and p[da[i]]!=db[j]:return False
        for a,b in p.items():
            if (A[i][i][a],A[i][a][i],A[a][i][i])!=(B[j][j][b],B[j][b][j],B[b][j][j]):return False
            for c,d in p.items():
                if (A[i][a][c],A[a][i][c],A[a][c][i])!=(B[j][b][d],B[b][j][d],B[b][d][j]):return False
        return True
    def search():
        if len(p)==n:return [p[i]for i in range(n)]
        choices=None;chosen=None
        for i in range(n):
            if i in p:continue
            cs=[j for j in candidates[i]-used if compatible(i,j)]
            if not cs:return None
            if choices is None or len(cs)<len(choices):chosen,choices=i,cs
        for j in choices:
            p[chosen]=j;used.add(j);ans=search()
            if ans is not None:return ans
            del p[chosen];used.remove(j)
        return None
    ans=search()
    if ans is not None:
        assert all(A[i][j][k]==B[ans[i]][ans[j]][ans[k]]for i,j,k in itertools.product(range(n),repeat=3))
    return ans

R={};counts={}
input_path=ROOT/'inputs/rank9_M2_verified/FusionRingMultiplicationTables.txt.gz'
with gzip.open(input_path,'rt')as stream:
    for line in stream:
        T=json.loads(line.replace('{','[').replace('}',']'))
        multiplicity=max(c for a in T for b in a for c in b)
        counts[multiplicity]=counts.get(multiplicity,0)+1
        rid=f'R9_{multiplicity}_{counts[multiplicity]}'
        if rid in ['R9_2_12','R9_2_92','R9_2_959','R9_2_1557','R9_2_1965']:R[rid]=T
assert counts=={1:142,2:2083}
raw=(P/'all_twist_skeleton.jsonl').read_text();dec=json.JSONDecoder();recs=[]
while raw.strip():
    raw=raw.lstrip();a,n=dec.raw_decode(raw);recs.append(a);raw=raw[n:]
assert [(a['order'],a['groups'],a['subgroup_classes'],a['candidate_presentations'])for a in recs if a.get('complete')]==[(120,47,1431,2),(168,57,1751,2)]
assert [(a['order'],a['group_id'],a['subgroup_id'])for a in recs if 'group_id'in a]==[(120,34,[12,4]),(120,35,[12,4]),(168,42,[24,12]),(168,42,[24,12])]
summaries={}
for name,expected,accepted in [('s5',4,8),('a5c2',10,2)]:
    a=json.load(open(P/(name+'_transfer_search.json')))
    assert a['complete'] and len(a['results'])==16 and a['H3_metadata']['H3_F2_dimension']==expected
    good=[b for b in a['results']if b['relative_trivialization_found']]
    assert len(good)==accepted
    for b in good:
        assert b['tensor_subgroup_Schur_twist']==0
        assert b['psi_record_subgroup_Schur_twist']==int(name=='a5c2')
        assert b['base_psi_exponents_mod8']==b['all_subgroup_twists'][0]['psi_exponents_mod8']
        assert b['psi_exponents_mod8']==b['all_subgroup_twists'][-1]['psi_exponents_mod8']
        assert b['tensor']==b['all_subgroup_twists'][0]['tensor']
        for c in b['all_subgroup_twists']:
            T=c['tensor'];n=len(T)
            assert n==c['rank']
            assert all(T[0][i][j]==T[i][0][j]==int(i==j)for i in range(n)for j in range(n))
            d=c['dimensions'];assert sum(x*x for x in d)==120
            assert all(sum(T[i][j][k]*d[k]for k in range(n))==d[i]*d[j]for i in range(n)for j in range(n))
            if name=='a5c2':assert n==12
            elif n==9:
                assert [z['id']for z in c['matches']]==['R9_2_92']
                m=c['matches'][0]['basis_map_source_to_model']
                assert sorted(m)==list(range(9))
                assert all(R['R9_2_92'][i][j][k]==T[m[i]][m[j]][m[k]]for i,j,k in itertools.product(range(9),repeat=3))
                assert based_iso(R['R9_2_12'],T) is None
            else:assert n==12
    summaries[name]={'family_size':16,'relative_representatives':len(good),'rank9_representatives':sum(b['rank']==9 for b in good),'rank12_representatives':sum(b['rank']==12 for b in good),'cohomology_metadata':a['H3_metadata']}
inv=[i for i in range(9)if sum(R['R9_2_959'][i][j][0]for j in range(9)) and sum(R['R9_2_959'][i][next(j for j in range(9)if R['R9_2_959'][i][j][0])])==1]
assert inv==[0,1,2,8]
orders=[]
for g in inv:
    a=0
    for n in range(1,5):
        a=R['R9_2_959'][a][g].index(1)
        if a==0:orders.append(n);break
assert sorted(orders)==[1,2,4,4]
assert based_iso(R['R9_2_1965'],R['R9_2_1557']) is None
prior=json.load(open(ROOT/'phase2/group_models/matches.json'))
models=[a for a in prior if a['id']=='R9_2_1557'];assert len(models)==2
for a in models:assert based_iso(R['R9_2_1557'],a['tensor']) is not None
sources=['all_twist_skeleton.g','all_twist_skeleton.jsonl','s5_transfer_search.py','s5_transfer_search.json','a5c2_data.g','a5c2_data.json','a5c2_transfer_search.json','GROUP_THEORETICAL_OBSTRUCTIONS.md']
out={'status':'PASS_stored_record_replay','general_status_changes':[],'accepted_group_theoretical_exclusions':['R9_2_12','R9_2_959','R9_2_1965'],'independent_mathematical_audit':'phase4/audit_integral_gt/audit_verdict.json','preexisting_literature_WGT_obstruction':'R9_2_941','summaries':summaries,'relative_cochain_provenance_checked':True,'R959_invertible_orders':orders,'R1965_excluded_from_both_untwisted_PSL168_S4_models':True,'source_sha256':{f:hashlib.sha256((P/f).read_bytes()).hexdigest()for f in sources if(P/f).is_file()},'optional_sources_absent':[f for f in sources if not(P/f).is_file()],'runtime_dependencies':'Python standard library only; all data paths are relative to this research archive.','scope':'Group-theoretical only; no general exclusion.'}
(P/'GT_verification.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items()if k!='source_sha256'},indent=2))
