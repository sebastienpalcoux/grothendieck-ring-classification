"""Exact hypotheses for new braided-scope refinements; no general exclusion."""
from pathlib import Path
import itertools,json,sys
P=Path(__file__).resolve().parent
ROOT=P.parents[1]
sys.path.insert(0,str(ROOT/'work'))
from common import read,digest,based_iso

def closure(T,S):
    S=set(S)|{0}
    while True:
        V=S|{k for i in S for j in S for k,n in enumerate(T[i][j]) if n}
        if V==S:return sorted(S)
        S=V

rows={r['id']:r for r in read()}
profiles={r['id']:r for r in json.load(open(ROOT/'phase3/results/unresolved.json'))}
out=[]
for rid in ['R9_2_12','R9_2_959','R9_2_941','R9_2_1965']:
    T=rows[rid]['tensor']; r=profiles[rid]
    d=[int(a[0]) for a in r['dimension_coefficients']]
    assert all(sum(T[i][j][k]*d[k] for k in range(9))==d[i]*d[j] for i in range(9) for j in range(9))
    dual=[next(j for j in range(9) if T[i][j][0]) for i in range(9)]
    subs=[]
    for mask in range(256):
        S=[0]+[i+1 for i in range(8) if mask>>i&1]
        if closure(T,S)==S and all(dual[i] in S for i in S):subs.append(S)
    row={'id':rid,'tensor_sha256':digest(T),'dimensions':d,'FPdim':sum(a*a for a in d),'subrings':[{'basis':S,'dimension':sum(d[i]**2 for i in S)} for S in subs]}
    if rid in ['R9_2_12','R9_2_959']:
        assert sorted(d)==[1,1,1,1,2,2,6,6,6]
        triples=[S for S in subs if len(S)==3]
        assert len(triples)==1
        S=triples[0]; g=next(i for i in S if d[i]==1 and i!=0); x=next(i for i in S if d[i]==2)
        assert T[g][g][0]==T[g][x][x]==1 and all(T[x][x][i]==int(i in S) for i in range(9))
        nonpointed=[Q for Q in subs if any(d[i]>1 for i in Q)]
        assert all(set(S)<=set(Q) for Q in nonpointed)
        inv=[i for i in range(9) if d[i]==1]
        fixed={str(a):[i for i in range(9) if d[i]==6 and T[a][i][i]==1] for a in inv}
        assert all(fixed.values())
        row.update(S3_basis=S,all_nonpointed_subrings_contain_S3=True,invertibles=inv,dimension_six_fixed_points=fixed,braided_status='excluded',general_status='unresolved')
    elif rid=='R9_2_941':
        assert len(subs)==2
        published=json.load(open(ROOT/'phase3/audit_models/published_504_tensor.json'))
        iso=based_iso(T,published['tensor']); assert iso is not None
        assert sum(a*a for a in d)==504 and 504%49!=0
        row.update(simple=True,exact_published_tensor_map=iso,braided_status='excluded',weakly_group_theoretical_status='excluded',general_status='unresolved')
    else:
        witness=next((i,j) for i in range(9) for j in range(9) if T[i][j]!=T[j][i])
        row.update(noncommutative_witness=list(witness),braided_status='excluded_previously',general_status='unresolved')
    out.append(row)

# All orbit packets in an S3-equivariantization of an integral category,
# whose simple dimensions in the equivariantization belong to {1,2,6}.
packets=[]
for size,irreps in [(1,[1,1,2]),(2,[1,1,1]),(3,[1,1]),(6,[1])]:
    for d in range(1,7):
        equiv=[size*d*v for v in irreps]
        if all(v in [1,2,6] for v in equiv):
            packets.append({'orbit_size':size,'base_dimension':d,'equivariant_dimensions':equiv})
patterns=[]
for n in itertools.product(range(5),repeat=len(packets)):
    dims=sorted(sum((p['equivariant_dimensions']*m for p,m in zip(packets,n)),[]))
    if dims==[1,1,1,1,2,2,6,6,6]:
        base=sorted(sum(([p['base_dimension']]*p['orbit_size']*m for p,m in zip(packets,n)),[]))
        patterns.append({'packet_multiplicities':list(n),'base_dimensions':base,'base_FPdim':sum(a*a for a in base)})
assert sorted(p['base_dimensions'] for p in patterns)==sorted([[1]*20,[1]*8+[2]*3,[1]*2+[3]*2])
result={'status':'exact_hypotheses_verified','general_decision_changes':[],'scope_refinements':out,'S3_orbit_packets':packets,'S3_base_patterns':patterns,'categorical_argument':'BRAIDED_SCOPE_THEOREMS.md','limitations':'This script checks ring hypotheses and orbit bookkeeping, not categorical theorems.'}
(P/'scope_refinements.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'new_braided_exclusions':['R9_2_12','R9_2_959','R9_2_941'],'general_decision_changes':[],'S3_base_patterns':patterns},indent=2))
