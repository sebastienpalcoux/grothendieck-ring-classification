"""Explore the full sign-valued Sylow-transfer family over (S5,S3xC2).

Every returned candidate has explicit normalized cocycles and relative
trivialization. Exhaustiveness beyond this family is a separate theorem.
"""
from pathlib import Path
import itertools,json,sys,functools,time
import numpy as np
P=Path(__file__).resolve().parent;ROOT=P.parents[1]
sys.path.insert(0,str(ROOT/'phase3/group_models'))
import s5_relative_twist as old

def basis_add(B,r):
    while r:
        p=(r&-r).bit_length()-1
        if p in B:r^=B[p]
        else:B[p]=r;return r
    return 0

def nullspace(rows,n):
    B={}
    for r in rows:basis_add(B,r)
    ans=[]
    for f in range(n):
        if f in B:continue
        x=1<<f
        for p,r in sorted(B.items(),reverse=True):
            if (r&x).bit_count()%2:x^=1<<p
        assert all((r&x).bit_count()%2==0 for r in rows)
        ans.append(x)
    return ans

def cohom3(T):
    n=len(T);triples=list(itertools.product(range(1,n),repeat=3));ix={t:i for i,t in enumerate(triples)}
    rows=[]
    for a,b,c,d in itertools.product(range(1,n),repeat=4):
        row=0
        for t in [(b,c,d),(T[a][b],c,d),(a,T[b][c],d),(a,b,T[c][d]),(a,b,c)]:
            if 0 not in t:row^=1<<ix[t]
        rows.append(row)
    Z=nullspace(rows,len(triples));B={}
    for p in itertools.product(range(1,n),repeat=2):
        r=0
        for j,(a,b,c) in enumerate(triples):
            if sum(t==p for t in [(b,c),(T[a][b],c),(a,T[b][c]),(a,b)])%2:r^=1<<j
        basis_add(B,r)
    brank=len(B);H=[]
    for z in Z:
        r=basis_add(B,z)
        if r:H.append(r)
    return triples,H,{'variables':len(triples),'cocycle_dimension':len(Z),'boundary_dimension':brank,'H3_F2_dimension':len(H)}

def factor_binary(A):
    B={};bad=[]
    for j,row in enumerate(A):
        r=sum((int(v)&1)<<i for i,v in enumerate(row));e=1<<j
        while r:
            p=(r&-r).bit_length()-1
            if p in B:r^=B[p][0];e^=B[p][1]
            else:B[p]=(r,e);break
        if not r:bad.append(e)
    def solve(rhs):
        b=sum((int(v)&1)<<j for j,v in enumerate(rhs))
        if any((v&b).bit_count()%2 for v in bad):return None
        x=0
        for p,(r,e) in sorted(B.items(),reverse=True):
            if ((r&x).bit_count()+(e&b).bit_count())%2:x^=1<<p
        return np.array([(x>>i)&1 for i in range(A.shape[1])],dtype=np.int64)
    return solve

def main():
    mode='a5c2' if '--a5c2' in sys.argv else 's5'
    if mode=='s5':D,M,inv,H,hs,eps,x,y,alpha,oldw,oldpsi,ps=old.build_data()
    else:
        D=json.load(open(P/'a5c2_data.json'));M=D['table'];H=D['H'];hs=set(H)
        inv=[r.index(0)for r in M];x=dict(zip(H,D['x']));y=dict(zip(H,D['y']))
        eps=alpha=ps=None
    def close(gens):
        S={0}|set(gens)
        while True:
            T=S|{M[a][b]for a in S for b in S}
            if T==S:return sorted(S)
            S=T
    if mode=='s5':
        sylowH=next(S for a,b in itertools.product(H,repeat=2) if len(S:=close([a,b]))==4)
        sylow=next(S for a in range(120) if len(S:=close(sylowH+[a]))==8)
    else:sylow=D['sylow'];sylowH=sorted(set(sylow)&hs)
    ix={a:i for i,a in enumerate(sylow)};T=[[ix[M[a][b]]for b in sylow]for a in sylow]
    triples,h3,meta=cohom3(T);print('Sylow',sylow,'H3',meta,flush=True)
    if mode=='a5c2':
        trix={t:i for i,t in enumerate(triples)};B={}
        for pair in itertools.product(range(1,8),repeat=2):
            r=0
            for j,(a,b,c)in enumerate(triples):
                if sum(t==pair for t in [(b,c),(T[a][b],c),(a,T[b][c]),(a,b)])%2:r^=1<<j
            basis_add(B,r)
        n=D['normalizer3'];aut=[ix[M[M[inv[n]][a]][n]]for a in sylow]
        assert all(aut[aut[aut[a]]]==a for a in range(8))
        norms=[]
        for seed in h3:
            norm=0
            for j,t in enumerate(triples):
                u=tuple(aut[a]for a in t);v=tuple(aut[a]for a in u)
                if sum((seed>>trix[s])&1 for s in [t,u,v])%2:norm^=1<<j
            r=basis_add(B,norm)
            if r:norms.append(r)
        h3=norms;meta['normalizer_norm_basis_dimension']=len(h3)
        print('NORMALIZER-NORM DIMENSION',len(h3),flush=True)
    # Right coset transversal P\G, with t*g=h*t'.
    reps=[];decomp={}
    for t in range(120):
        if t in decomp:continue
        i=len(reps);reps.append(t)
        for h in sylow:decomp[M[h][t]]=(ix[h],i)
    steps=[[(decomp[M[t][g]])for g in range(120)]for t in reps]
    pairs=list(itertools.product(H[1:],repeat=2));pair_ix={t:i for i,t in enumerate(pairs)}
    htrip=list(itertools.product(H[1:],repeat=3));A=[]
    for a,b,c in htrip:
        row=np.zeros(len(pairs),dtype=np.int64)
        for t,sg in [((b,c),1),((M[a][b],c),-1),((a,M[b][c]),1),((a,b),-1)]:
            if t in pair_ix:row[pair_ix[t]]+=sg
        A.append(row)
    A=np.array(A);solve=factor_binary(A)
    cohom2=[np.array([x[a]*x[b]for a,b in pairs]),np.array([x[a]*y[b]for a,b in pairs]),np.array([y[a]*y[b]for a,b in pairs])]
    shifts=[sum((cohom2[j]*((m>>j)&1)for j in range(3)),np.zeros(len(pairs),dtype=np.int64))%2 for m in range(8)]
    def primitive(rhs):
        for q0 in shifts:
            r=rhs-A@q0
            if np.any(r%2):continue
            q10=solve(r//2)
            if q10 is None:continue
            for s in shifts:
                q1=(q10+s)%2;r2=r-2*(A@q1)
                assert not np.any(r2%4)
                q2=solve(r2//4)
                if q2 is not None:
                    q=(q0+2*q1+4*q2)%8
                    assert not np.any((A@q-rhs)%8)
                    return q
        return None
    source=(ROOT/'phase3/group_models/s5_relative_twist.py').read_text()
    start=source.index('def main():');cut=source.index(" proof='phase3/group_models/S5_RELATIVE_TWIST.md'",start)
    body=source[start:cut]+" return {'matches':matches,'rank':rank,'dimensions':[len(c['L'])*chi[0][0]for c,chi in objs],'tensor':T}\n"
    ns=dict(old.__dict__);exec(body,ns)
    results=[]
    for mask in range(1<<len(h3)):
        seed=0
        for j,h in enumerate(h3):
            if mask>>j&1:seed^=h
        values=np.zeros((8,8,8),dtype=np.int64)
        for j,t in enumerate(triples):values[t]=(seed>>j)&1
        @functools.lru_cache(None)
        def w(g,h,k):
            if not g or not h or not k:return 0
            z=0
            for ti in range(len(reps)):
                a,tj=steps[ti][g];b,tk=steps[tj][h];c,tl=steps[tk][k];z^=int(values[a,b,c])
            return 4*z
        rhs=np.array([w(a,b,c)for a,b,c in htrip],dtype=np.int64);q=primitive(rhs)
        row={'mask':mask,'relative_trivialization_found':q is not None}
        if q is None:results.append(row);print('mask',mask,'no primitive',flush=True);continue
        pd={p:int(v)for p,v in zip(pairs,q)}
        models=[]
        for twist in (range(2) if mode=='a5c2' else range(1)):
            def psi(a,b):return (pd.get((a,b),0)+4*twist*x[a]*y[b])%8
            ns['build_data']=lambda:(D,M,inv,H,hs,eps,x,y,alpha,w,psi,ps)
            model=ns['main']();models.append({'subgroup_Schur_twist':twist,'psi_exponents_mod8':[[a,b,psi(a,b)]for a,b in itertools.product(H,repeat=2)],**model})
        row.update(models[0]);row['all_subgroup_twists']=models
        row['seed_F2_values']=[int(values[t])for t in triples]
        row['tensor_subgroup_Schur_twist']=0
        row['base_psi_exponents_mod8']=[[a,b,pd.get((a,b),0)]for a,b in itertools.product(H,repeat=2)]
        row['psi_record_subgroup_Schur_twist']=models[-1]['subgroup_Schur_twist']
        row['psi_record_note']='Legacy psi field records the final subgroup twist; top-level tensor records twist0. Each model has its own explicit psi.'
        row['psi_exponents_mod8']=[[a,b,psi(a,b)]for a,b in itertools.product(H,repeat=2)]
        results.append(row)
        print('MASK',mask,'RANK',row['rank'],'MATCHES',row['matches'],flush=True)
        out={'status':'exploratory_complete_for_sign_valued_Sylow_transfer_family','sylow':sylow,'sylow_H':sylowH,'sylow_table':T,'right_coset_representatives':reps,'H3_metadata':meta,'cohomology_triples':triples,'results':results}
        (P/(mode+'_transfer_search.json')).write_text(json.dumps(out,indent=2)+'\n')
    out['complete']=True
    (P/(mode+'_transfer_search.json')).write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()
