"""Append phase-four research to the immutable version-three evidence archive.

Usage: python phase4/package.py /path/to/version3.zip /path/to/output.zip
Earlier evidence bytes are preserved; only the current entry points change.
"""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib, json, sys

P = Path(__file__).resolve().parent
baseline, output = map(Path, sys.argv[1:])
expected = '2baa9093cf3e72355f7aec9d40a795818c24f8fb3036ec7eaad16252b53446c4'
if hashlib.sha256(baseline.read_bytes()).hexdigest() != expected:
    raise ValueError('Expected the immutable version-three archive')
if baseline.resolve() == output.resolve():
    raise ValueError('Keep the version-three input separate from the output')
root = 'Rank9_M2_Theoretical_Continuation_20261023/'
with ZipFile(baseline) as z:
    files = {n[len(root):]: z.read(n) for n in z.namelist() if not n.endswith('/')}
original = dict(files)
for name in ('README.md', 'HANDOFF.md', 'SHA256SUMS.json'):
    files['phase4/baseline_documents/' + name] = files[name]
files['verify_phase1.py'] = files['verify.py']
files['README.md'] = b'''# Rank-nine multiplicity two: fourth research continuation

Current partition: **2,039 excluded, 35 unitary models, 9 unresolved**,
out of 2,083 exact-multiplicity-two rings. Nine of the previous eighteen
unresolved cases are settled: six exclusions and three models.

Read `phase4/REPORT.md` and the manuscript in `phase4/manuscript/`.
The current classification authority is `phase4/results/ledger.json`;
the accepted changes are listed in `phase4/accepted.json`.

The R8_3_436 exclusion has an independent replacement proof in
`phase4/r8_scope/REPAIR.md`. Its old unitary-table parameterization premise
is withdrawn, not silently restored. See the separate categorical audit.

All nine residual rings have no braided categorification. The four integral
residuals have no group-theoretical categorification; R9_2_941 additionally
has no weakly group-theoretical categorification. Their general existence
remains unresolved. Construction obstructions and feasible necessary
conditions are not general classification decisions.

Install `requirements.txt`, then run `python3 verify.py` for the current
finite replay and full model-transport check. It first checks archive hashes.
`python3 verify.py --baseline` also replays the phase-three baseline audit.
For optional fresh research generators, see each proof and audit report.
The new all-group scan requires GAP with SmallGrp. Building the PDF requires
Pandoc, XeLaTeX, and the stated DejaVu fonts. Neither is needed for the
default accepted-certificate replay.

All earlier research bytes are preserved. Earlier `results/`, `phase2/`,
and `phase3/` ledgers are historical snapshots, not the current status.
In particular, the first two phases' invalid half-E6 subring claims remain
superseded by the phase-three correction. The original first-pass verifier
is retained as `verify_phase1.py`; its historical totals are not current.

The 142 multiplicity-one records are unchanged. No repository or website
was changed in this research continuation. The publication handoff is
`HANDOFF.md`; public revision remains a later user-authorized step.
'''
files['HANDOFF.md'] = b'''# Current research and publication handoff

Research date: 24 October 2026. No online revision has been performed.

Use `phase4/results/` as the current classification authority:
2,039 excluded, 35 unitary models, 9 unresolved, out of 2,083 exact-M2 rings.
The prior 142 M1 rings are unchanged. Rank nine cumulatively through M2:
2,141 excluded, 75 modeled, 9 unresolved, out of 2,225. The project-wide
frontier is now 16, including seven earlier-rank cases.

New general-complex exclusions: R9_2_585, 1025, 1303, 1709, 1759, 1988.
New unitary models: R9_2_746, 1209, 1254.
Remaining: R9_2_12, 137, 941, 959, 1607, 1848, 1965, 1975, 1976.
All remaining rings are non-braided; this is not general nonexistence.
The integral residuals 12,941,959,1965 are not group-theoretical, and
941 is not weakly group-theoretical. Preserve these exact scopes.

R8_3_436 remains generally excluded by a NEW proof. Withdraw the previous
universal Galois-unitarization/table-parameterization proposition. Follow
`phase4/r8_scope/PUBLICATION_HANDOFF.md` for the exact affected proof files,
historical supersession notices, and manuscript-generator replacement.

For the later online revision, update BOTH repositories and BOTH parts
of the public GitHub Atlas, following the existing ordered/clean policy.
Integrate rank/multiplicity entries in the ordinary tables; do not create
a separate rank-nine feature section. Regenerate usual manuscripts and
update the classification code with the cyclic internal-end obstruction
and the other accepted new proofs/model records. Retain source tensor IDs,
explicit basis transports, scope fields, and independent audit links.
The former private Atlas is out of scope.

All eighteen former residual cases received new investigation. Nine remain
unresolved; no timeout, necessary-condition survivor, failed ansatz, or
Morita candidate is a categorical classification. See per-family reports
for exact future research boundaries.

Archive version-three research is preserved byte-for-byte except current
README/HANDOFF/hash/verification entry points; their prior versions are
retained under phase4/baseline_documents or verify_phase1.py.
'''
files['verify.py'] = b'''"""Verify the packaged current research without network access."""
from pathlib import Path
import hashlib,json,subprocess,sys
P=Path(__file__).resolve().parent
manifest=json.loads((P/'SHA256SUMS.json').read_text())
for rel,expected in manifest.items():
    if hashlib.sha256((P/rel).read_bytes()).hexdigest()!=expected:
        raise ValueError('Archive hash mismatch: '+rel)
print('PASS: '+str(len(manifest))+' packaged file hashes.',flush=True)
if '--baseline' in sys.argv:
    subprocess.run([sys.executable,str(P/'phase3/verify_audit.py')],check=True,cwd=P)
subprocess.run([sys.executable,str(P/'phase4/verify.py')],check=True,cwd=P)
'''
for path in sorted(P.rglob('*')):
    if not path.is_file():
        continue
    rel = path.relative_to(P)
    if '__pycache__' in rel.parts or 'render' in rel.parts:
        continue
    if path.suffix in {'.pyc', '.tmp', '.aux', '.toc', '.out'}:
        continue
    files['phase4/' + rel.as_posix()] = path.read_bytes()
changed = {'README.md', 'HANDOFF.md', 'verify.py', 'SHA256SUMS.json'}
if any(files[k] != v for k, v in original.items() if k not in changed):
    raise ValueError('Earlier research evidence was changed')
files.pop('SHA256SUMS.json')
manifest = {k: hashlib.sha256(v).hexdigest() for k, v in sorted(files.items())}
files['SHA256SUMS.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
output.parent.mkdir(parents=True, exist_ok=True)
with ZipFile(output, 'w', ZIP_DEFLATED, compresslevel=9) as z:
    for name, content in sorted(files.items()):
        z.writestr(root + name, content)
with ZipFile(output) as z:
    if z.testzip() is not None:
        raise ValueError('ZIP CRC failure')
print(json.dumps({'path':str(output),'files':len(files),
                  'bytes':output.stat().st_size,
                  'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
                  'preserved_earlier_research_files':len(original)-len(changed)},indent=2))
