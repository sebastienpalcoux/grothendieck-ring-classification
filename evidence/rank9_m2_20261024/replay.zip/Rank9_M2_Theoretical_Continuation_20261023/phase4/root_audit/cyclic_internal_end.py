"""Independent cyclic internal-end test: exact integer coefficients only.

The categorical theorem is proved in weak_b. This implementation deliberately
uses only multiplication and duals; it imports no prior sieve or new generator.
"""
from pathlib import Path
import json, hashlib
P=Path(__file__).resolve().parent
B=P.parent.parent

def witness(R,subrings):
 n=len(R)
 dual=[next(j for j in range(n) if R[i][j][0]) for i in range(n)]
 inv={i for i in range(n) if sum(R[i][dual[i]])==1}
 for D in subrings:
  for x in range(n):
   coeff={i:R[i][x][x] for i in D if R[i][x][x]}
   H=set(coeff)
   if not H.issubset(inv) or any(a!=1 for a in coeff.values()):continue
   gen=None
   for g in sorted(H):
    cyc=[0]; h=g
    while h not in cyc:
     cyc.append(h); h=R[g][h].index(1)
    if set(cyc)==H and h==0:gen=g;break
   if gen is None:continue
   for y in D:
    if max(R[y][x])<=1:continue
    stab=[g for g in sorted(H) if R[y][g][y]==1]
    assert sum(a*a for a in R[y][x])==len(stab)
    assert all(R[i][j][k]==0 for i in D for j in D for k in range(n) if k not in D)
    return {'subcategory':D,'object':x,'internal_end_support':sorted(H),
      'cyclic_generator':gen,'acting_object':y,'product':R[y][x],
      'right_stabilizer':stab,'endomorphism_dimension':len(stab),
      'noncommutative_matrix_blocks':[{'simple':k,'multiplicity':a}for k,a in enumerate(R[y][x])if a>1]}
 return None

def main():
 corpus=json.loads((B/'work/verification_corpus.json').read_text())['tensors']
 meta=json.loads((B/'work/input_audit.json').read_text())
 ledger={r['id']:r for r in json.loads((B/'phase3/results/ledger.json').read_text())}
 results=[]
 for row in meta:
  if row['multiplicity']!=2:continue
  w=witness(corpus[row['id']],row['subrings'])
  if w:
   assert ledger[row['id']]['status']!='unitarily_realized',row['id']
   results.append({'id':row['id'],'previous_status':ledger[row['id']]['status'],
       'tensor_sha256':row['tensor_sha256'],'witness':w})
 out={'criterion':'cyclic_relative_internal_end_multiplicity_freeness',
  'scope':'all_complex_fusion_categories','checked':2083,'model_controls':32,
  'total_witnesses':len(results),'new_exclusions':[r['id']for r in results if r['previous_status']=='unresolved'],
  'records':results}
 (P/'cyclic_internal_end.json').write_text(json.dumps(out,indent=2)+'\n')
 print({k:v for k,v in out.items()if k!='records'})
if __name__=='__main__':main()
