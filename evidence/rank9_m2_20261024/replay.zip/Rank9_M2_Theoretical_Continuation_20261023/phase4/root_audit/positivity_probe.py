"""Numerical discovery probe only. No classification consequences."""
from pathlib import Path
import json,numpy as np
P=Path(__file__).resolve().parent;B=P.parent.parent
c=json.loads((B/'work/verification_corpus.json').read_text())['tensors']; metas={r['id']:r for r in json.loads((B/'work/input_audit.json').read_text())}; out=[]
for p in json.loads((B/'phase3/results/unresolved.json').read_text()):
 rid=p['id'];R=np.array(c[rid],float); ds=np.array(metas[rid]['dimensions_approx']);
 if not metas[rid]['commutative']:continue
 vals,V=np.linalg.eig(np.einsum('i,ijk->jk',np.arange(1,10)+1j*np.arange(2,11)**2,R)); V/=np.linalg.norm(V,axis=0)[None,:]
 ch=np.array([np.diag(V.conj().T@a@V)for a in R]); err=max(np.linalg.norm(a@V-V*ch[i][None,:])for i,a in enumerate(R));
 T=np.einsum('ia,ib,ic,i->abc',ch,ch,ch,1/ds)
 out.append({'id':rid,'min_primary3_eigenvalue':float(T.real.min()),'max_imag':float(np.abs(T.imag).max()),'character_residual':err,'result':'numerical_only_no_classification'})
(P/'positivity_probe.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
