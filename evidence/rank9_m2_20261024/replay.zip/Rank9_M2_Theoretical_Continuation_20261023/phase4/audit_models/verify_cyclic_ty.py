#!/usr/bin/env python3
"""Independent parent-orbit construction and coherence checks for 746/1209."""
from pathlib import Path
from itertools import product
import json
HERE=Path(__file__).resolve().parent;BASE=HERE.parents[1]
def req(c,m):
    if not c:raise ValueError(m)
def omega(a,b,c):return (3*a*((b+c)//9))%9
def tensorator(a,b):return (-3*a*int(b!=0))%9

def main():
    count={}
    # Right half-braiding on TY: z_a has scalar omega3^(q[a]) on m.
    q=[0,1,1]
    for h,b,c in product(range(3),repeat=3):
        req((h*(b+c)-h*b-h*c)%3==0,'TY all-group hexagon')
        req((-b*h+q[h]+h*b-q[h])%3==0,'TY (b,m) hexagon')
        req((h*b+q[h]-h*b-q[h])%3==0,'TY (m,b) hexagon')
        req((2*q[h]+h*(h+b)-h*b)%3==0,'TY (m,m) output channel hexagon')
        req((q[(h+b)%3]-q[h]-q[b]+h*b)%3==0,'TY central tensor multiplication')
    count['TY_hexagons_and_central_multiplication']=True
    for a,b,c,d in product(range(9),repeat=4):
        req((omega(b,c,d)+omega(a,(b+c)%9,d)+omega(a,b,c)-omega((a+b)%9,c,d)-omega(a,b,(c+d)%9))%9==0,'3-cocycle')
    for a,b,c in product(range(9),repeat=3):
        lhs=(tensorator(a,b)+tensorator((a+b)%9,c)+omega(a,b,c))%9
        rhs=(omega(-a%9,-b%9,-c%9)+tensorator(b,c)+tensorator(a,(b+c)%9))%9
        req(lhs==rhs,'monoidal inversion')
    for a,b in product(range(9),repeat=2):req((tensorator(a,b)+tensorator(-a%9,-b%9))%9==0,'involution square')
    # Central powers of h=3: r=0,1,2 underlying3r, hb exponent2r*x.
    for r,x,y in product(range(3),range(9),range(9)):
        h=3*r
        rhs=(2*r*x+2*r*y-omega(h,x,y)+omega(x,h,y)-omega(x,y,h))%9
        req(2*r*((x+y)%9)%9==rhs,'pointed right hexagon')
    for r,s,x in product(range(3),range(3),range(9)):
        p=(r+s)%3
        rhs=(2*r*x+2*s*x+omega(3*r,3*s,x)-omega(3*r,x,3*s)+omega(x,3*r,3*s))%9
        req(rhs==(2*p*x)%9,'central pointed powers')
    for r,s in product(range(3),repeat=2):
        req((3*r*s+2*r*3*s)%9==0,'all diagonal g-power braidings')
        req(tensorator(3*r,3*s)==0,'algebra map tensorator')
    for r,s,t in product(range(3),repeat=3):req(omega(3*r,3*s,3*t)==0,'algebra associator')
    for r,x in product(range(3),range(9)):
        rhs=(2*r*(-x%9)+tensorator(3*r,-x%9)-tensorator(-x%9,3*r))%9
        req(rhs==(2*(-r%3)*x)%9,'inversion preserves full central powers')
    count['pointed_cocycle_equations']=6561
    count['pointed_monoidal_action_equations']=729
    count['all_central_powers_and_algebra_coherence']=True
    # Build the rank12 tensor from orbits of the actual rank36 parent product.
    parent=list(product(range(4),range(9)));quot=[];where={}
    for a,c in parent:
        if (a,c) in where:continue
        orb=sorted({((a+r)%3 if a<3 else 3,(c+3*r)%9)for r in range(3)})
        n=len(quot);quot.append(orb)
        for x in orb:where[x]=n
    req(len(quot)==12,'quotient rank')
    def mul(v,w):
        a,c=v;b,d=w
        aa=[(a+b)%3]if a<3 and b<3 else([3]if (a<3)!=(b<3)else[0,1,2])
        return [(h,(c+d)%9)for h in aa]
    R=[[[0]*12 for _ in range(12)]for _ in range(12)]
    for i,j in product(range(12),repeat=2):
        for z in mul(quot[i][0],quot[j][0]):R[i][j][where[z]]+=1
    inv=[]
    for orb in quot:
        a,c=orb[0];inv.append(where[(-a%3 if a<3 else 3,-c%9)])
    # Linear involution trace on free-module fusion spaces. Fixed parent reps
    # are exactly (0,0),(m,0), and each fixed fusion line is action-trivial.
    elabels=[];seen=set()
    for i in range(12):
        if i in seen:continue
        orb=sorted({i,inv[i]});seen.update(orb)
        for sign in ([1,-1]if len(orb)==1 else[0]):elabels.append((orb,sign))
    corpus=json.loads((HERE/'source_tensors.json').read_text())['tensors']
    models=json.loads((BASE/'phase4/weak_a/cyclic_ty_models.json').read_text())['models']
    report=[]
    for parity,rid in [(0,'R9_2_746'),(1,'R9_2_1209')]:
        T=[[[0]*9 for _ in range(9)]for _ in range(9)]
        for i,j,k in product(range(9),repeat=3):
            A,si=elabels[i];B,sj=elabels[j];C,sk=elabels[k];c=C[0]
            dim=sum(R[a][b][c]for a,b in product(A,B));tr=0
            if len(C)==1:
                for a,b in product(A,B):
                    if inv[a]==a and inv[b]==b:
                        odd_a=quot[a][0][0]==3;odd_b=quot[b][0][0]==3
                        tr+=si*sj*sk*(-1 if parity and odd_a and odd_b else 1)*R[a][b][c]
                req((dim+tr)%2==0,'integral equivariant multiplicity');T[i][j][k]=(dim+tr)//2
            else:T[i][j][k]=dim
        m=next(m for m in models if m['id']==rid);p=m['source_to_model']
        req(T==m['tensor'],'independent orbifold tensor differs')
        req(all(T[p[i]][p[j]][p[k]]==corpus[rid][i][j][k]for i,j,k in product(range(9),repeat=3)),'source tensor differs')
        report.append({'id':rid,'all_729_coefficients':True,'source_to_model':p})
    result={'checks':count,'models':report,'status':'categorical_coherence_and_tensor_audit_passed'}
    (HERE/'cyclic_ty_audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print('PASS: independent TY/pointed central coherence; all powers/algebra; parent-orbit quotient; both729 coefficient matches.')
if __name__=='__main__':main()
