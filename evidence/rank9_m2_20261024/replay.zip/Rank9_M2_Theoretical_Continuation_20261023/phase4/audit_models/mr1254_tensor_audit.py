#!/usr/bin/env python3
"""Independent quotient-ring and equivariant-ring reconstruction for1254."""
from pathlib import Path
from itertools import product,permutations
import json
P=Path(__file__).resolve().parent;BASE=P.parents[1]
def req(c,m):
 if not c:raise ValueError(m)
# D: eight invertiblesu^a, fouroddρ_r, quotientofIsingchargeparity.
N=[[[0]*12 for _ in range(12)]for _ in range(12)]
for a,b in product(range(8),repeat=2):N[a][b][(a+b)%8]=1
for a,r in product(range(8),range(4)):N[a][8+r][8+(a+r)%4]=N[8+r][a][8+(a+r)%4]=1
for r,s in product(range(4),repeat=2):
 for t in[0,4]:N[8+r][8+s][(r+s+1+t)%8]=1
F=[-a%8 for a in range(8)]+[8+(3*r+1)%4 for r in range(4)]
req(all(F[F[a]]==a for a in range(12)),'quotient involution')
req(all(N[a][b][c]==N[F[a]][F[b]][F[c]]for a,b,c in product(range(12),repeat=3)),'quotient action')
labels=[([0],1),([0],-1),([4],1),([4],-1),([1,7],0),([2,6],0),([3,5],0),([8,9],0),([10,11],0)]
T=[[[0]*9 for _ in range(9)]for _ in range(9)]
for i,j,k in product(range(9),repeat=3):
 A,si=labels[i];B,sj=labels[j];C,sk=labels[k];c=C[0]
 dim=sum(N[a][b][c]for a,b in product(A,B))
 if len(C)==1:
  tr=sum(si*sj*sk*N[a][b][c]for a,b in product(A,B)if F[a]==a and F[b]==b)
  req((dim+tr)%2==0,'integral invariant multiplicity');T[i][j][k]=(dim+tr)//2
 else:T[i][j][k]=dim
S=json.loads((P/'source_tensors.json').read_text())['tensors']['R9_2_1254']
# Verysmall exhaustive based-isomorphism search, independently verified afterward.
def invs(R):return[i for i in range(len(R))if all(sum(R[i][j])==1 for j in range(len(R)))]
S_inv=invs(S);T_inv=invs(T);req(len(S_inv)==len(T_inv)==4,'four invertibles')
S_non=[i for i in range(9)if i not in S_inv];T_non=[i for i in range(9)if i not in T_inv]
found=None
for p1 in permutations([i for i in T_inv if i]):
 for p2 in permutations(T_non):
  p={0:0,**dict(zip([i for i in S_inv if i],p1)),**dict(zip(S_non,p2))}
  if all(S[i][j][k]==T[p[i]][p[j]][p[k]]for i,j,k in product(range(9),repeat=3)):
   found=[p[i]for i in range(9)];break
 if found:break
req(found is not None,'target tensor match')
res={'id':'R9_2_1254','status':'all729_coefficients_match_independent_equivariantization','source_to_audit_model':found,'labels':labels,'quotient_tensor':N,'quotient_involution':F,'equivariant_tensor':T,'fixed_lift_square_reason':'eta_u4=J(u4,u4)=14 mod16, so both lifts square to identity','odd_duality':'the two moving odd orbits are mutually dual'}
(P/'mr1254_tensor_audit.json').write_text(json.dumps(res,indent=2)+'\n');print('PASS: independent1254tensor, source_to_audit_model',found)
