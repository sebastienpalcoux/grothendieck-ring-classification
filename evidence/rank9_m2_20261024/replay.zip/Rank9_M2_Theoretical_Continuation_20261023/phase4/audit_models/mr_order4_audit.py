#!/usr/bin/env python3
"""Independent exact audit of the order-four cover lift and descended C2 action."""
from pathlib import Path
from itertools import product
import json
P=Path(__file__).resolve().parent
D=json.loads((P.parent/'weak_a/mr_order4_descent_2_3_1_4.json').read_text())
def req(c,m):
 if not c:raise ValueError(m)
B=[(i,a)for i in range(3)for a in range(16)if a%2==int(i==2)];ix={z:i for i,z in enumerate(B)};n=len(B)
req(B==[tuple(x)for x in D['labels']],'source labels')
def isingprod(i,j):
 if i==0:return[j]
 if j==0:return[i]
 if i==j==1:return[0]
 if i==j==2:return[0,1]
 return[2]
prod={}
for a,b in product(range(n),repeat=2):
 i,x=B[a];j,y=B[b];prod[a,b]=[ix[k,(x+y)%16]for k in isingprod(i,j)]
u=ix[0,0];g=ix[1,8];odd=[i==2 for i,a in B]
def ga(a):return prod[g,a][0]
def K(a):return ga(a)if odd[a]else a
def F(a):
 i,x=B[a];return ix[(i^((x//2)%2))if i<2 else 2,3*x%16]
def assoc(a,b,c,d,e,f):
 i,j,k,l,p,q=[B[t][0]for t in[a,b,c,d,e,f]]
 sign=p*q%2 if i==j==k==2 else(i*k%2 if i!=2 and j==2 and k!=2 else(j*l%2 if i==2 and j!=2 and k==2 else 0))
 x,y,z=[B[t][1]for t in[a,b,c]]
 return(8*sign+2*x*((y+z)//16))%16
def beta(a):
 i,x=B[a];return(7*x+[0,8,12][i])%16
JF={tuple(k):v for k,v in zip(D['tensorator_labels'],D['tensorator_exponents'])};eta=D['square_to_K_exponents'];JK={}
for a,b in product(range(n),repeat=2):
 p,q=int(odd[a]),int(odd[b]);gp=g if p else u;gq=g if q else u
 for c in prod[a,b]:
  qa=ga(a)if q else a;qc=ga(c)if q else c;gg=prod[gp,gq][0]
  JK[a,b,c]=(assoc(gp,a,K(b),K(c),K(a),qc)-assoc(a,gq,b,qc,qa,K(b))-q*beta(a)+assoc(gq,a,b,qc,qa,c)-assoc(gp,gq,c,K(c),gg,qc))%16
# Check the actual central boson, not only transport of a proposed central structure.
for a,b in product(range(n),repeat=2):
 for c in prod[a,b]:
  hb=beta(a)+beta(b)-assoc(g,a,b,ga(c),ga(a),c)+assoc(a,g,b,ga(c),ga(a),ga(b))-assoc(a,b,g,ga(c),c,ga(b))
  req((beta(c)-hb)%16==0,'central boson half-braiding hexagon')
for a in range(n):
 sq=2*beta(a)+assoc(g,g,a,a,u,ga(a))-assoc(g,a,g,a,ga(a),ga(a))+assoc(a,g,g,a,ga(a),u)
 req(sq%16==0,'central boson order two')
req(beta(g)==0 and assoc(g,g,g,g,u,u)==0,'boson commutativity and algebra associativity')
req([K(a)for a in range(n)]==D['K_automorphism'],'K permutation')
req([F(a)for a in range(n)]==D['automorphism'],'F permutation')
req(all(F(F(a))==K(a)for a in range(n)),'F2=K on objects')
count=0
for a,b,c in product(range(n),repeat=3):
 for e in prod[a,b]:
  for d in prod[e,c]:
   for f in prod[b,c]:
    if d not in prod[a,f]:continue
    for fn,J in[(F,JF),(K,JK)]:
     lhs=J[a,b,e]+J[e,c,d]-J[b,c,f]-J[a,f,d]
     rhs=assoc(fn(a),fn(b),fn(c),fn(d),fn(e),fn(f))-assoc(a,b,c,d,e,f)
     req((lhs-rhs)%16==0,('functor pentagon',fn.__name__,a,b,c,d,e,f))
    count+=1
for a in range(n):
 req(JF[u,a,a]==JF[a,u,a]==JK[u,a,a]==JK[a,u,a]==0,'unit')
 req((JF[g,a,ga(a)]-JF[a,g,ga(a)]-beta(F(a))+beta(a))%16==0,'F central transport')
 req((JK[g,a,ga(a)]-JK[a,g,ga(a)]-beta(K(a))+beta(a))%16==0,'K central transport')
for a,b,c in JF:
 req((JF[a,b,c]+JF[F(a),F(b),F(c)]-eta[a]-eta[b]+eta[c]-JK[a,b,c])%16==0,'F2 to K monoidality')
req(eta[g]==JF[g,g,u],'F2 to K algebra compatibility')
# φ_g=ζ16: its squareζ16² equals JF(g,g;1).
req(JF[g,g,u]==2,'stated algebra phase')
cphi=1
old_defect=[(eta[F(a)]-eta[a]-int(odd[a])*(cphi-JF[g,a,ga(a)]))%16 for a in range(n)]
req(all(old_defect[a]==(8 if odd[a]else 0)for a in range(n)),'old defect is parity')
adjusted=[(eta[a]-4*B[a][1])%16 for a in range(n)]
for a,b,c in JF:
 req((JF[a,b,c]+JF[F(a),F(b),F(c)]-adjusted[a]-adjusted[b]+adjusted[c]-JK[a,b,c])%16==0,'adjusted monoidality')
for a in range(n):
 defect=(adjusted[F(a)]-adjusted[a]-int(odd[a])*(cphi-JF[g,a,ga(a)]))%16
 req(defect==0,'descended C2 coherence')
req(adjusted[g]==JF[g,g,u],'adjusted algebra compatibility')
# Independent finite group-cohomology identity; explicit adjustment above is stronger.
ker=[x for x in range(8)if(1+3)*x%8==0];im=sorted({(3-1)*x%8 for x in range(8)})
req(ker==im,'H3(C2,Z8_action3)')
result={'status':'all_categorical_coherence_phase_checks_pass','F_pentagon_entries':count,'K_pentagon_entries':count,'natural_transformation_equations':len(JF),'central_algebra_phase_exponent_mod16':cphi,'old_defect_exponents':old_defect,'adjusted_square_to_K_exponents':adjusted,'C2_coherence_objects_checked':n,'H3_kernel':ker,'H3_image':im}
(P/'mr_order4_audit.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS: independent F/K pentagons; central algebra; F²=>K; explicit adjusted C2 coherence on all24 objects.')
