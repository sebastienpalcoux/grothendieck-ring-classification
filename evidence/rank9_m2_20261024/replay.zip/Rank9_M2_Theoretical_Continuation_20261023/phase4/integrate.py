"""Build the phase-four ledger without changing any earlier evidence."""
from pathlib import Path
import copy,json,hashlib,collections
P=Path(__file__).resolve().parent;B=P.parent

def load(p):return json.loads((B/p).read_text())
def require(c,m):
 if not c:raise ValueError(m)
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def main():
 baseline=load('phase3/results/ledger.json');ledger=copy.deepcopy(baseline);rows={r['id']:r for r in ledger}
 excluded={**{n:'weak_b/CYCLIC_INTERNAL_END_OBSTRUCTION.md'for n in(1025,1709,1759,1988)},**{n:'weak_b/DIMENSION120_A5_OBSTRUCTION.md'for n in(585,1303)}}
 checks={n:('weak_b/cyclic_obstruction_certificate.json'if n in(1025,1709,1759,1988)else'weak_b/dimension120_obstruction_certificate.json')for n in excluded}
 for n,proof in excluded.items():
  r=rows[f'R9_2_{n}'];require(r['status']=='unresolved','not baseline unresolved')
  r['status']='excluded';r['exclusion_certificates'].append({'record_file':'phase4/'+checks[n],'proof':'phase4/'+proof,'scope':'general_complex_fusion_category','independent_audit':'phase4/root_audit/EXCLUSION_AUDIT.md'})
  r.pop('categorification_scopes',None)
 models=copy.deepcopy(load('phase3/results/models.json'))
 new=[]
 candidates=[(m,'weak_a/cyclic_ty_models.json','weak_a/CYCLIC_TY_MODELS.md','audit_models/CYCLIC_TY_AUDIT.md')for m in load('phase4/weak_a/cyclic_ty_models.json')['models']]
 candidates.append((load('phase4/weak_a/mr_1254_model.json'),'weak_a/mr_1254_model.json','weak_a/MR_1254_MODEL.md','audit_models/MR_1254_AUDIT.md'))
 for m,record,proof,audit in candidates:
  r=rows[m['id']];require(r['status']=='unresolved','not baseline unresolved')
  r['status']='unitarily_realized';r['models'].append({'record_file':'phase4/'+record,'model':m['model']});r.pop('categorification_scopes',None)
  a=copy.deepcopy(m);a['basis_map_source_to_model']=a.pop('source_to_model');a['proof']='phase4/'+proof;a['record_file']='phase4/'+record;a['independent_audit']='phase4/'+audit;models.append(a);new.append(a)
 profiles={p['id']:copy.deepcopy(p)for p in load('phase3/results/unresolved.json')}
 braided={**{n:'integral/BRAIDED_SCOPE_THEOREMS.md'for n in(12,959,941)},**{n:'quadratic_comm/BRAIDED_OBSTRUCTION.md'for n in(137,1607,1976)}}
 unresolved=[]
 for r in ledger:
  if r['status']!='unresolved':continue
  p=profiles[r['id']];n=int(r['id'].split('_')[-1]);sc=r['categorification_scopes']
  if n in braided:
   sc['braided']='excluded';sc['braided_exclusion_proof']='phase4/'+braided[n]
  if n==941:
   sc['weakly_group_theoretical']='excluded';sc['weakly_group_theoretical_exclusion_proof']='phase4/integral/BRAIDED_SCOPE_THEOREMS.md'
  if n in(12,941,959,1965):
   sc['group_theoretical']='excluded';sc['group_theoretical_exclusion_proof']='phase4/integral/GROUP_THEORETICAL_OBSTRUCTIONS.md';sc['group_theoretical_independent_audit']='phase4/audit_integral_gt/AUDIT.md'
  folder='integral'if n in(12,941,959,1965)else'weak_a'if n==1254 else'quadratic_noncomm'if n in(1848,1975)else'quadratic_comm'
  r['phase4_research_report']='phase4/'+folder+'/REPORT.md';p['phase4_research_report']=r['phase4_research_report'];p['categorification_scopes']=copy.deepcopy(sc);unresolved.append(p)
 changes=[{'id':a['id'],'previous_status':a['status'],'current_status':b['status']}for a,b in zip(baseline,ledger)if a['status']!=b['status']]
 counts=collections.Counter(r['status']for r in ledger)
 require(counts=={'excluded':2039,'unitarily_realized':35,'unresolved':9},str(counts))
 require(len(models)==35 and len(changes)==9,'partition')
 out=P/'results';out.mkdir(exist_ok=True)
 summary={'rank':9,'exact_multiplicity':2,'total':2083,'excluded':2039,'modelled':35,'unresolved':9,'new_general_exclusions':6,'new_unitary_models':3,'new_braided_only_exclusions_among_residuals':6,'residuals_without_braided_categorification':9,'all_18_previous_residuals_investigated':True,'rank9_multiplicity1_unchanged':142,'online_changes':False,'R8_3_436':{'status':'excluded','scope':'general_complex','change':'Old TPE-parameterization proof withdrawn; independent spherical-equivariantization formal-codegree proof replaces it.','proof':'phase4/r8_scope/REPAIR.md','audit':'phase4/root_audit/R8_REPAIR_AUDIT.md'},'all_ranks_remaining_after_this_research':16,'baseline_ledger_sha256':hashlib.sha256((B/'phase3/results/ledger.json').read_bytes()).hexdigest(),'warning':'Necessary-condition survivors and excluded construction families are not general classification decisions.'}
 summary['integral_residual_group_theoretical_exclusions']=['R9_2_12','R9_2_941','R9_2_959','R9_2_1965']
 for name,x in [('ledger',ledger),('summary',summary),('models',models),('new_models',new),('unresolved',unresolved),('classification_changes',changes)]:write(out/(name+'.json'),x)
 write(P/'accepted.json',{'new_exclusions':sorted(excluded),'new_models':[746,1209,1254],'new_braided_only_exclusions':sorted(braided),'new_group_theoretical_only_exclusions':[12,959,1965],'weakly_group_theoretical_exclusion':[941],'R8_3_436_replacement_accepted':True,'classification_authority':'phase4/results/ledger.json','all_other_general_statuses_unchanged':True})
 print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
