"""Independent finite hypotheses of the cyclic internal-end theorem."""
from pathlib import Path
import hashlib
import json
from itertools import product

P = Path(__file__).resolve().parent
CASES = {
    'R9_2_1025': (6, 4, 5),
    'R9_2_1709': (7, 5, 6),
    'R9_2_1759': (6, 3, 4),
    'R9_2_1988': (7, 5, 6),
}
EXPECTED_SHA256 = {
    'R9_2_1025':'f65a94c8ea2e7dbfbed149dd31b381b6c6bdeea9c6bdbe64febd14069fee446d',
    'R9_2_1709':'d541caa1b5a0bb178428b603a08f533c243748aa715ca82707020108f37b0377',
    'R9_2_1759':'e266d5c774608742f54350c79143dcd5a250e4fac7a6c50e4862d358bf669a0e',
    'R9_2_1988':'5cfc1d3ea4eb5c790f9dfa7d552c938f9cb011828ab34034c9ebe099b7419909',
}

def require(condition, detail):
    if not condition:
        raise ValueError(detail)

def unit(n, k, coefficient=1):
    return [coefficient if i == k else 0 for i in range(n)]

def check(rid, R, data):
    n = 9
    digest=hashlib.sha256(json.dumps(R,separators=(',',':')).encode()).hexdigest()
    require(digest == EXPECTED_SHA256[rid], 'unchanged phase-three tensor hash')
    require(len(R) == n and all(len(a) == n and all(len(b) == n for b in a) for a in R), 'shape')
    require(all(type(v) is int and 0 <= v <= 2 for a in R for b in a for v in b), 'coefficients')
    for i in range(n):
        require(R[0][i] == unit(n,i) == R[i][0], 'unit')
    dual = []
    for i in range(n):
        targets = [j for j in range(n) if R[i][j][0]]
        require(len(targets) == 1 and R[i][targets[0]][0] == 1, 'dual')
        dual.append(targets[0])
    for i,j,k,l in product(range(n),repeat=4):
        require(sum(R[i][j][s]*R[s][k][l] for s in range(n)) == sum(R[j][k][s]*R[i][s][l] for s in range(n)), 'associativity')
    for i,j,k in product(range(n),repeat=3):
        require(R[i][j][k] == R[dual[i]][k][j] == R[k][dual[j]][i], 'Frobenius reciprocity')
        require(R[i][j][k] == R[dual[j]][dual[i]][dual[k]], 'dual anti-automorphism')
    G = [0,1,2,8]
    powers = [0,1,8,2]
    for a,b in product(range(4),repeat=2):
        require(R[powers[a]][powers[b]] == unit(n,powers[(a+b)%4]), 'C4 multiplication')
    y,x,xp = data
    D = sorted(G+[y])
    M = [x,xp]
    require(all(dual[i] in D for i in D), 'dual closure')
    for i,j in product(D,repeat=2):
        require(all(k in D for k,v in enumerate(R[i][j]) if v), 'D closure')
    for g in G:
        require(R[g][y] == unit(n,y) == R[y][g], 'TY stabilizer')
        for a in M:
            require(R[g][a] == unit(n,a), 'pointwise stabilizer')
    require(R[y][y] == [int(i in G) for i in range(n)], 'TY square')
    require(R[y][x] == unit(n,xp,2) and R[y][xp] == unit(n,x,2), 'double swap')
    internal = {i:R[i][x][x] for i in D if R[i][x][x]}
    require(internal == {g:1 for g in G}, 'internal end')
    return {'id':rid,'tensor_sha256':digest,
            'fusion_axioms_checked':True,'subcategory':D,'cyclic_group':G,'generator':1,'generator_powers':powers,
            'module_simples':M,'noninvertible':y,'internal_end_multiplicities':internal,
            'noninvertible_action':[[0,2],[2,0]],'conclusion':'excluded_all_complex_categorifications',
            'proof':'CYCLIC_INTERNAL_END_OBSTRUCTION.md'}

if __name__ == '__main__':
    tensors=json.loads((P/'cyclic_tensors.json').read_text())
    results=[check(rid,tensors[rid],data) for rid,data in CASES.items()]
    (P/'cyclic_obstruction_certificate.json').write_text(json.dumps({'theorem':'cyclic internal-end multiplicity-free obstruction','cases':results},indent=2)+'\n')
    print('PASS: four exact tensors and all cyclic internal-end obstruction hypotheses')
