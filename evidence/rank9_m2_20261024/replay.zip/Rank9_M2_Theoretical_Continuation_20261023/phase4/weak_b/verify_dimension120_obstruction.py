"""Exact tensor hypotheses of DIMENSION120_A5_OBSTRUCTION.md."""
from pathlib import Path
import json
import hashlib
from itertools import product
from verify_cyclic_obstruction import require, unit

P=Path(__file__).resolve().parent
CASES={'R9_2_585':([0,1,7,8,3,4],[2,5,6]),'R9_2_1303':([0,4,5,6,7,8],[1,2,3])}
EXPECTED_SHA256={'R9_2_585':'d8d0dd2b9343e9341b4b23f7d5ca5ef0af0a3b2e4ca3c3aa1fb879f824de84e3',
                 'R9_2_1303':'d10b2d13eeecf2d023b30f0552e166834ff660006c80385ecd9e6555bb996232'}

def multiply(a,b):
    return (a[0]*b[0]+5*a[1]*b[1],a[0]*b[1]+a[1]*b[0])

def check(rid,R,neutral,odd):
    n=9
    digest=hashlib.sha256(json.dumps(R,separators=(',',':')).encode()).hexdigest()
    require(digest==EXPECTED_SHA256[rid],'unchanged phase-three tensor hash')
    require(len(R)==n and all(len(row)==n and all(len(v)==n for v in row) for row in R),'tensor shape')
    require(all(type(x) is int and 0<=x<=2 for row in R for col in row for x in col),'coefficients')
    for i in range(n):require(R[0][i]==unit(n,i)==R[i][0],'unit')
    dual=[]
    for i in range(n):
        support=[j for j in range(n) if R[i][j][0]]
        require(len(support)==1 and R[i][support[0]][0]==1,'dual')
        dual.append(support[0])
    for i,j,k,l in product(range(n),repeat=4):
        require(sum(R[i][j][a]*R[a][k][l] for a in range(n))==sum(R[j][k][a]*R[i][a][l] for a in range(n)),'associativity')
    for i,j,k in product(range(n),repeat=3):
        require(R[i][j][k]==R[dual[i]][k][j]==R[k][dual[j]][i],'Frobenius')
        require(R[i][j][k]==R[dual[j]][dual[i]][dual[k]],'dual anti-automorphism')
    dims=[None]*n
    for i,d in zip(neutral,[1,1,2,2,5,5]):dims[i]=(d,0)
    for i in odd:dims[i]=(0,2)
    for i,j in product(range(n),repeat=2):
        target=tuple(sum(R[i][j][k]*dims[k][a] for k in range(n)) for a in range(2))
        require(multiply(dims[i],dims[j])==target,'exact FP character')
    require(sum(multiply(d,d)[0] for d in dims)==120,'global dimension')
    degrees={i:0 for i in neutral}|{i:1 for i in odd}
    require(len(degrees)==n,'grading partition')
    for i,j,k in product(range(n),repeat=3):
        if R[i][j][k]:require(degrees[k]==(degrees[i]+degrees[j])%2,'C2 grading')
    require(all(dual[i] in neutral for i in neutral),'neutral dual closure')
    adj={k for i in neutral for k,v in enumerate(R[i][dual[i]]) if v}
    stages=[sorted(adj)]
    while True:
        new=adj|{k for i in adj for j in adj for k,v in enumerate(R[i][j]) if v}
        if new==adj:break
        adj=new;stages.append(sorted(adj))
    require(adj==set(neutral),'neutral adjoint closure')
    one,g,a,b,u,v=neutral
    for left,right in [(one,g),(g,one),(a,a),(b,b),(u,v),(v,u)]:require(R[g][left]==unit(n,right),'invertible action')
    return {'id':rid,'tensor_sha256':digest,
      'fusion_axioms_checked':True,'exact_FP_dimensions_Qsqrt5':dims,'global_dimension':120,
      'neutral_labels_1_g_a_b_u_v':neutral,'odd_labels':odd,'neutral_dimension':60,'neutral_adjoint_closure_steps':stages,
      'central_C2_hypothetical_condensation_dimensions':[1,1,1,1,1,5],
      'conclusion':'excluded_all_complex_categorifications','proof':'DIMENSION120_A5_OBSTRUCTION.md'}

if __name__=='__main__':
    tensors=json.loads((P/'d120_tensors.json').read_text())
    records=[check(rid,tensors[rid],*data) for rid,data in CASES.items()]
    (P/'dimension120_obstruction_certificate.json').write_text(json.dumps({'theorem':'dimension60 nonsolvable neutral obstruction','cases':records},indent=2)+'\n')
    print('PASS: two exact tensors, fusion axioms, dimensions, grading and neutral hypotheses')
