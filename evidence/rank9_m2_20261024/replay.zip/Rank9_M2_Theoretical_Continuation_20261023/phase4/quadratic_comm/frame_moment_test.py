"""Conditional exact center moment separators after complete low-frame enumeration.
Stop once a surviving necessary-condition branch is found. No classification inference.
"""
import sys,json,time,collections,hashlib
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csc_matrix
sys.path.insert(0,str(Path(__file__).parent));from complex_low_frames import qc,ROOT
rid=sys.argv[1];height=int(sys.argv[2]) if len(sys.argv)>2 else 3;start=time.monotonic();R=qc.inputs(rid);data=qc.base(R)
original=qc.base;qc.base=lambda R:data
try:A,b,meta=qc.system(R,height)
finally:qc.base=original
indices={};hi=[];j=0;nt=meta['trace_types']
for v,z in data['cols']:
 if v[0]:indices[v]=j;j+=1
 else:hi.extend(range(j,j+nt));j+=nt
hi.extend(range(j,len(A[0])))
AA=[[row[j]for j in hi]for row in A];aa=np.array(AA,dtype=float);scale=np.maximum(1,np.max(abs(aa),axis=1));mat=csc_matrix(aa/scale[:,None]);frames=json.load(open(Path(__file__).parent/f'{rid}_complex_low_frames.json'))['frames'];out=[]
for no,frame in enumerate(frames):
 bb=[bb-sum(row[indices[tuple(v)]]for v in frame)for row,bb in zip(A,b)]
 sol=linprog(np.zeros(aa.shape[1]),A_eq=mat,b_eq=np.array(bb)/scale,bounds=(0,None),method='highs',options={'time_limit':30})
 rec={'frame_index':no,'status':int(sol.status),'message':sol.message,'numerical_necessary_feasible':bool(sol.success)}
 if sol.success:
  rec['maximum_equality_residual']=float(max(abs(aa@sol.x-np.array(bb))));rec['classification_change']=False;out.append(rec);break
 if sol.status==2:
  ray,why=qc.exact_separator(AA,bb,timeout=30);rec['exact_ray']=ray;rec['ray_report']=why
 out.append(rec);print(rid,no,rec['status'],flush=True)
res={'id':rid,'height':height,'outcome':'no_conclusion','frame_total':len(frames),'tested':out,'seconds':time.monotonic()-start,'classification_change':False}
(Path(__file__).parent/f'{rid}_frame_moments_h{height}.json').write_text(json.dumps(res,indent=2)+'\n');print(res,flush=True)
