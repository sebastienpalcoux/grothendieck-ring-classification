"""Exact tensor witnesses for BRAIDED_OBSTRUCTION.md; no floating-point tests."""
import json,hashlib
from pathlib import Path
from fractions import Fraction as Q
ROOT=Path(__file__).resolve().parents[2]
RS=json.load(open(ROOT/'work/verification_corpus.json'))['tensors']
W={'R9_2_137':(7,3,[0,1,2,7],8,[3,4,5,6]),'R9_2_1607':(4,1,[0,4,5,6],3,[1,2,7,8]),'R9_2_1976':(6,1,[0,6,7,8],5,[1,2,3,4])}
def mul(x,y):return(x[0]*y[0]+2*x[1]*y[1],x[0]*y[1]+x[1]*y[0])
results=[]
for rid,(g,x,inv,y,irr)in W.items():
 R=RS[rid];n=len(R);assert n==9
 du=[next(j for j in range(n)if R[i][j][0])for i in range(n)]
 d=[(1,0)if i in inv else(2,0)if i==y else(4,3)for i in range(n)]
 for i in range(n):
  for j in range(n):assert mul(d[i],d[j])==tuple(sum(R[i][j][k]*d[k][s]for k in range(n))for s in range(2))
 assert R[g][g]==[int(k==0)for k in range(n)]
 assert R[g][x]==[int(k==x)for k in range(n)]
 ad={0}|{k for i in range(n)for k in range(n)if R[i][du[i]][k]}
 stages=[sorted(ad)]
 while True:
  nxt=ad|{k for i in ad for j in ad for k in range(n)if R[i][j][k]}
  if nxt==ad:break
  ad=nxt;stages.append(sorted(ad))
 assert ad==set(range(n))
 norm=Q(4,2)**2-2*Q(3,2)**2;assert norm==Q(-1,2)
 results.append({'id':rid,'tensor_sha256':hashlib.sha256(json.dumps(R,separators=(',',':')).encode()).hexdigest(),'g':g,'X':x,'dual':du,'FP_dimensions_Qsqrt2':[list(a)for a in d],'adjoint_closure_stages':stages,'half_dimension_norm':str(norm),'braided_status':'excluded','general_status':'unresolved'})
(Path(__file__).parent/'braided_obstruction_certificate.json').write_text(json.dumps({'scope':'all complex braided fusion categories','all_exact_checks_passed':True,'cases':results},indent=2)+'\n')
print('PASS: all 243 dimension identities, involution/fixed-point witnesses, adjoint closures and nonintegral norms.')
