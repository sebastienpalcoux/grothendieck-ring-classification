"""Exact labelled I(1) frames with all Q(zeta_8) characters.
Only a necessary condition; no surviving frame is a category.
"""
import sys,json,time,itertools,hashlib,math
from pathlib import Path
from fractions import Fraction as Q
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'phase2/quadratic_theory'))
import quadratic_center as qc
Z=(Q(0),)*4;ONE=(Q(1),Q(0),Q(0),Q(0))
def add(x,y):return tuple(a+b for a,b in zip(x,y))
def scale(x,t):return tuple(a*t for a in x)
def mul(x,y):
 r=[Q(0)]*4
 for i in range(4):
  for j in range(4):r[i^j]+=x[i]*y[j]*(2 if i&j&1 else 1)*(-1 if i&j&2 else 1)
 return tuple(r)
def chars(ch,D):
 out=[]
 for f,m in ch.components:
  K,ds,codegree,_=ch.component(f)
  co=list(map(Q,f.all_coeffs()))
  if f.degree()==1:roots=[(-co[1]/co[0],Q(0),Q(0),Q(0))]
  else:
   a,b,c=co;disc=b*b-4*a*c;z=abs(disc)/2;h=math.isqrt(z.numerator)
   assert z.denominator==1 and h*h==z
   roots=[]
   for eps in [-1,1]:
    u=[-b/(2*a),Q(0),Q(0),Q(0)];u[1 if disc>0 else 3]=eps*Q(h)/(2*a);roots.append(tuple(u))
  for root in roots:
   vv=[]
   for x in ds:
    cs=list(map(lambda z:Q(str(z)),qc.ec(x)));v=Z
    for a in cs:v=add(mul(v,root),(a,0,0,0))
    vv.append(v)
   assert vv[0]==ONE
   for i,j in itertools.product(range(9),repeat=2):assert mul(vv[i],vv[j])==tuple(sum(ch.R[i][j][k]*vv[k][c]for k in range(9))for c in range(4))
   ff=Z
   for i in range(9):ff=add(ff,mul(vv[i],vv[ch.du[i]]))
   assert ff[2:]==(0,0)
   dim=qc.div(D,ff[:2],2)+(Q(0),Q(0))
   out.append({'v':vv,'f':ff,'d':dim})
 assert len(out)==9
 return out

def run(rid,timeout=180):
 started=time.monotonic();R=qc.inputs(rid);base=qc.base(R);ch=base['ch'];cc=chars(ch,base['D']);du=ch.du
 domains=[]
 for h,c in enumerate(cc):
  dom=[v for v,z in base['cols'] if v[0] and z==c['d'][:2]]
  partner=next(k for k,c2 in enumerate(cc)if c2['v']==[c['v'][du[i]]for i in range(9)])
  c['partner']=partner
  if partner==h:dom=[v for v in dom if v==tuple(v[du[i]]for i in range(9))]
  if c['f'][:2]==(144,-96):dom=[v for v in dom if v==tuple(1 if i==0 or base['dims'][i]==(4,3)else 0 for i in range(9))]
  domains.append(dom)
 # Variables are duality orbits; a choice is a tuple of labelled columns.
 seen=set();variables=[]
 for h,c in enumerate(cc):
  if h in seen:continue
  k=c['partner'];seen|={h,k}
  opts=[]
  for v in domains[h]:
   w=tuple(v[du[i]]for i in range(9))
   if w not in domains[k]:continue
   opts.append(((h,v),)if h==k else ((h,v),(k,w)))
  variables.append(opts)
 def sym(h,v,k,w):
  a=mul(cc[k]['d'],tuple(sum(v[i]*cc[k]['v'][i][z]for i in range(9))for z in range(4)))
  b=mul(cc[h]['d'],tuple(sum(w[i]*cc[h]['v'][i][z]for i in range(9))for z in range(4)))
  return a==b
 variables=[[o for o in opts if all(sym(h,v,k,w)for h,v in o for k,w in o)]for opts in variables]
 # exact pairwise compatibility precomputed
 compatibility={}
 for a in range(len(variables)):
  for b in range(a):
   for i,o in enumerate(variables[a]):
    for j,p in enumerate(variables[b]):
     ok=all(sym(h,v,k,w)for h,v in o for k,w in p)
     compatibility[a,i,b,j]=ok;compatibility[b,j,a,i]=ok
 n=len(variables);C=ch.C;ij=list(itertools.combinations_with_replacement(range(9),2));target=tuple(int(C[i,j])for i,j in ij)
 gram=[[tuple(sum(v[i]*v[j]for h,v in o)for i,j in ij)for o in opts]for opts in variables]
 nodes=0;frames=[];complete=True
 def dfs(domains,chosen,used):
  nonlocal nodes,complete
  nodes+=1
  if time.monotonic()-started>timeout:complete=False;return
  if len(chosen)==n:
   if all(used[k]==target[k]for k,(i,j)in enumerate(ij)if i==0):
    frames.append(sorted([list(v)for a,b in chosen.items()for h,v in variables[a][b]]))
   return
  var=min((x for x in range(n)if x not in chosen),key=lambda x:len(domains[x]))
  for opt in domains[var]:
   nxt=tuple(x+y for x,y in zip(used,gram[var][opt]))
   if any(x>y for x,y in zip(nxt,target)):continue
   nd=[list(d) for d in domains];nd[var]=[opt];ok=True
   for other in range(n):
    if other==var or other in chosen:continue
    nd[other]=[j for j in nd[other]if compatibility[var,opt,other,j]]
    if not nd[other]:ok=False;break
   if ok:dfs(nd,chosen|{var:opt},nxt)
   if not complete:return
 dfs([list(range(len(v)))for v in variables],{},(0,)*len(ij))
 unique=sorted({tuple(tuple(v)for v in fr)for fr in frames})
 out={'id':rid,'outcome':'necessary_frames_survive'if unique else 'no_frames'if complete else'timeout','complete':complete,'nodes':nodes,'labelled_frame_count':len(frames),'unlabelled_frame_count':len(unique),'seconds':time.monotonic()-started,'characters':[{k:([[str(x)for x in y]for y in v]if k=='v'else[str(x)for x in v]if k in('f','d')else v)for k,v in c.items()}for c in cc], 'variable_domains':list(map(len,variables)),'frames':unique,'classification_change':False,'tensor_sha256':hashlib.sha256(json.dumps(R,separators=(',',':')).encode()).hexdigest()}
 path=Path(__file__).parent/f'{rid}_complex_low_frames.json';path.write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items()if k not in('frames','characters')},flush=True)
 return out
if __name__=='__main__':run(sys.argv[1],float(sys.argv[2])if len(sys.argv)>2 else 180)
