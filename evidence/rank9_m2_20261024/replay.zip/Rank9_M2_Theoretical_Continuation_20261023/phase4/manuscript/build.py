from pathlib import Path
import re,subprocess
P=Path(__file__).resolve().parent;F=P.parent
sections=[('Research status','REPORT.md'),('Cyclic internal-end obstruction','weak_b/CYCLIC_INTERNAL_END_OBSTRUCTION.md'),('Dimension-120 extension obstruction','weak_b/DIMENSION120_A5_OBSTRUCTION.md'),('Two unitary models and a uniform family','weak_a/CYCLIC_TY_MODELS.md'),('A unitary model for R9_2_1254','weak_a/MR_1254_MODEL.md'),('Independent repair for R8_3_436','r8_scope/REPAIR.md'),('Braided restrictions for the integral cases','integral/BRAIDED_SCOPE_THEOREMS.md'),('Group-theoretical restrictions for the integral cases','integral/GROUP_THEORETICAL_OBSTRUCTIONS.md'),('Braided restrictions for the quadratic cases','quadratic_comm/BRAIDED_OBSTRUCTION.md'),('Remaining noncommutative cases','quadratic_noncomm/REPORT.md'),('Remaining commutative quadratic cases','quadratic_comm/REPORT.md'),('An arbitrary-phase obstruction to a construction ansatz','weak_a/MR_ARBITRARY_PHASE_OBSTRUCTION.md')]
text='''---
title: "Rank-nine multiplicity-two fusion rings"
subtitle: "Six exclusions, three unitary models, and a repaired rank-eight proof"
date: "24 October 2026"
author: "Research continuation prepared with AI assistance"
fontsize: 10pt
geometry: margin=24mm
mainfont: DejaVu Serif
monofont: DejaVu Sans Mono
colorlinks: true
linkcolor: blue
urlcolor: blue
---

'''
for index,(title,rel) in enumerate(sections):
 s=(F/rel).read_text();s=re.sub(r'^# [^\n]*\n','',s,count=1)
 s=re.sub(r'^(#{2,6}) \d+\.\s*',r'\1 ',s,flags=re.M)
 s=re.sub(r'\b(dimension|rank|all|simples|mod|modulo|Theorem|Proposition|Section)(?=\d)',r'\1 ',s)
 text+= ('\n\\clearpage\n' if index==0 else '\n')+'\n# '+title+'\n\n'+s+'\n'
(P/'research.md').write_text(text)
(P/'header.tex').write_text(r'''\usepackage{fvextra}
\DefineVerbatimEnvironment{Highlighting}{Verbatim}{breaklines,commandchars=\\\{\}}
\usepackage{microtype}
\usepackage{xurl}
\setlength{\emergencystretch}{3em}
\AtBeginDocument{\hypersetup{breaklinks=true}}
''')
(P/'inline_code.lua').write_text(r'''
function Code(el)
  if not FORMAT:match('latex') then return el end
  local escape = { ['\\']='\\textbackslash{}', ['{']='\\{', ['}']='\\}',
    ['_']='\\_', ['%']='\\%', ['&']='\\&', ['#']='\\#', ['$']='\\$',
    ['^']='\\textasciicircum{}', ['~']='\\textasciitilde{}' }
  local out = {}
  local count = 0
  for _, c in utf8.codes(el.text) do
    local ch = utf8.char(c)
    table.insert(out, escape[ch] or ch)
    count = count + 1
    if ch:match('[/_.%-]') or count >= 6 then
      table.insert(out, '\\allowbreak{}')
      count = 0
    end
  end
  return pandoc.RawInline('latex', '\\texttt{' .. table.concat(out) .. '}')
end
''')
args=['pandoc',str(P/'research.md'),'--from=markdown+tex_math_single_backslash+autolink_bare_uris','--standalone','--toc','--number-sections','--lua-filter='+str(P/'inline_code.lua'),'--include-in-header='+str(P/'header.tex')]
subprocess.run(args+['-o',str(P/'Rank9_M2_Continuation_20261024.tex')],check=True)
subprocess.run(args+['--pdf-engine=xelatex','-o',str(P/'Rank9_M2_Continuation_20261024.pdf')],check=True)
print('Built manuscript Markdown, TeX, PDF')
