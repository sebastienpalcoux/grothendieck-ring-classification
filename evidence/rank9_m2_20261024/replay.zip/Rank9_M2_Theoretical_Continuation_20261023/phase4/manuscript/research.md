---
title: "Rank-nine multiplicity-two fusion rings"
subtitle: "Six exclusions, three unitary models, and a repaired rank-eight proof"
date: "24 October 2026"
author: "Research continuation prepared with AI assistance"
fontsize: 10pt
geometry: margin=24mm
mainfont: DejaVu Serif
monofont: DejaVu Sans Mono
colorlinks: true
linkcolor: blue
urlcolor: blue
---


\clearpage

# Research status


Research date: 24 October 2026. Online revision is deferred.

**Nine of the eighteen previous unresolved rank-nine rings are settled:
six general-complex exclusions and three explicit unitary models.** The new
exact-multiplicity-two partition is **2,039 excluded, 35 modeled, and
9 unresolved**, out of 2,083 rings. This is substantial progress, not a
complete categorification of all eighteen. All eighteen received new analysis.

| Outcome | IDs, with prefix R9_2_ | Main argument |
|---|---|---|
| General complex exclusion | 585, 1303 | A nonsolvable dimension-60 neutral category forces every extension to be group-theoretical, contrary to nonintegral dimensions |
| General complex exclusion | 1025, 1709, 1759, 1988 | A cyclic internal-end algebra forces multiplicity-free tensor products, contradicting multiplicity two |
| Explicit unitary model | 746, 1209 | Two coherent inversion equivariantizations of a cyclic generalized Tambara–Yamagami category |
| Explicit unitary model | 1254 | An order-four cover functor descends to a coherent involution of a generalized Moore–Read category |
| Still unresolved | 12, 137, 941, 959, 1607, 1848, 1965, 1975, 1976 | Scope restrictions, Morita reductions, and construction obstructions |

The prior 142 multiplicity-one rings are unchanged. Cumulatively, rank nine
through multiplicity two has 2,225 rings: 2,141 excluded, 75 modeled, and
9 unresolved. The overall project frontier decreases from 25 to 16 cases.

## R8_3_436: a corrected proof, not a restored premise

The criticism is correct. The earlier complete-table derivation assumes
unitarity; reconstruction of categories from scalar solutions does not
parameterize every original spherical category. The exact scalar checks do
not bridge this gap. The claimed universal Galois-unitarization proposition
is therefore explicitly withdrawn.

An independent replacement proves that **R8_3_436 still has no complex
categorification**. Its hypothetical neutral near-group category admits a
coherent inversion action after cancellation of a pointed associator anomaly.
The resulting spherical equivariantization has rank five and dimension
field Q(sqrt(21)). Every possible fusion-rule branch has a formal codegree
in Q(sqrt(5)) or Q(sqrt(13)), contradicting the spherical dimension-field
theorem. This proof allows either spherical dimension root and needs no
unitary parameterization. The full proof and independent audit are in
`r8_scope/REPAIR.md` and `root_audit/R8_REPAIR_AUDIT.md`.

The old stronger claim remains withdrawn even though the exclusion
conclusion is recovered. Historical proof files must be marked superseded,
and the manuscript generator must use the replacement; the exact publication
map is in `r8_scope/PUBLICATION_HANDOFF.md`.

## Precise status of every remaining case

All nine remain unresolved for arbitrary complex fusion categories. None
admits a braided categorification. The new restrictions are:

| Case | New progress |
|---|---|
| R9_2_12 | Central Rep(S3) obstruction; braided descent; all group-theoretical categorifications excluded |
| R9_2_137 | Fixed transparent involution obstruction; all-complex character frames; quantum-group Morita route ruled out |
| R9_2_941 | Exact published open dimension-504 ring; weakly group-theoretical categorifications excluded |
| R9_2_959 | Central Rep(S3)/braided obstruction; all group-theoretical categorifications excluded |
| R9_2_1607 | Same transparent-involution obstruction and refined center analysis |
| R9_2_1848 | Exact Morita dual returns the same ring; invertible group is C6 |
| R9_2_1965 | Noncommutativity; all group-theoretical categorifications excluded |
| R9_2_1975 | Rank-twelve Morita alternatives reduced; one branch contains the existing open R6_4_155 |
| R9_2_1976 | Same transparent-involution obstruction and refined center analysis |

A braided exclusion does not imply a fusion-category exclusion. Likewise,
excluding every group-theoretical construction does not exclude an
arbitrary complex category. R9_2_941 is precisely the exotic ring asked
about in Alekseyev–Bruns–Dong–Palcoux, arXiv:2507.07023v2, Question 1.14;
its published open status is not itself a nonexistence proof.

The group-theoretical exclusions cover every finite-group presentation,
including all associator and subgroup twists. The reduction uses an
exhaustive projective-character scan followed by cohomological transfer
and exact relative-trivialization tests. A separate audit repeated the
group scan and independently decided all primitive equations. This
settles that entire construction class for the integral residuals.

For R9_2_1254, the earlier mixed Moore–Read lift ansatz is impossible
even with arbitrary complex tensorators: five equations multiply to a
contradiction. The successful model uses a different lift whose square
becomes the identity only after central condensation. Its coherent action
is certified explicitly, including the correction of the initial parity
defect. See `weak_a/MR_1254_MODEL.md` and its independent audit.

For the five other quadratic cases, the earlier general-to-pseudo-unitary
reduction is at the level of existence and can require Galois conjugation.
It does not make every original categorification pseudo-unitary.

## Verification and limitations

The new general exclusions have explicit categorical proofs and separate
reviews of their premises. A second implementation of the cyclic criterion
scanned all 2,083 exact-M2 tensors: 289 witnesses, of which four were newly
unresolved; all 32 earlier models passed as controls. All three new constructions
received an independent audit of half-braidings, central-algebra descent,
action coherence, and the decisive equivariant fusion-line sign. Each matches
all 729 source coefficients. All 35 model transports were then replayed,
checking 25,515 coefficient equalities in total.

The R8 replacement was checked against every possible rank-five branch,
with independent exact formal-codegree and field-norm calculations. The six
new braided-only exclusions have exact tensor witnesses and scope proofs.
The frontier reports distinguish exhaustive finite enumerations from bounded
or numerical investigations. Surviving necessary conditions, a solver timeout,
and unsuccessful model searches are never classified as models or exclusions.

The current research ledger is `phase4/results/ledger.json`; phase3 and
all earlier ledgers are preserved as historical snapshots. Run
`python phase4/verify.py` from the package root for the accepted finite checks.
The full categorical proofs are mathematical arguments reviewed here; they
are not formal proof-assistant certificates. This AI-assisted research
requires independent human mathematical verification before reliance or
scholarly publication.

No GitHub repository, website, or online manuscript was changed in this
research continuation. The evidence is prepared for the later revision step.



# Cyclic internal-end obstruction


Date: 24 October 2026. Scope: arbitrary fusion categories over C. No
pivotal, spherical, pseudo-unitary, unitary, or braided hypothesis occurs.

## Theorem

Let D be a fusion category, M a finite semisimple indecomposable left
D-module category, and x a simple object of M. Suppose its internal end
algebra has underlying object

    A = [x,x]_D = direct_sum_{g in H} g,

where H is a finite cyclic group of invertible objects, each with
multiplicity one. Then y tensor x is multiplicity-free for every simple
object y of D.

### Proof

For each g in H, the nonzero morphism g tensor x -> x is an isomorphism.
Consequently every component g tensor h -> gh of the multiplication of A
is nonzero: it is induced by composition of these isomorphisms. This is
not an assumption about an arbitrarily chosen algebra structure.

The internal-Hom equivalence of Ostrik, Theorem 1, identifies M with the
category of right A-modules in D, sends x to A, and sends y tensor x to
the free module y tensor A. Therefore their endomorphism algebras agree.
By free-module adjunction,

    End_A(y tensor A) = Hom_D(y, y tensor A)
                      = direct_sum_{g in K} Hom_D(y,y tensor g),

as vector spaces, where K = {g in H : y tensor g is isomorphic to y}.
K is a subgroup of H, hence cyclic. Every displayed summand is
one-dimensional. Choose nonzero isomorphisms u_g:y -> y tensor g.
The associated free-module endomorphism is the composite

    y tensor A --u_g tensor id--> (y tensor g) tensor A
               --associator--> y tensor (g tensor A)
               --id tensor multiplication--> y tensor A.

Call this endomorphism e_g. The multiplication of A and the u_g are
isomorphisms on the relevant simple summands, so composition satisfies
e_g e_h = c(g,h) e_{gh} (or the reversed product according to convention),
with c(g,h) nonzero. In particular each e_g is invertible. If t generates
K of order n, the powers of e_t span all these homogeneous summands and
e_t^n = c id for c nonzero. Thus

    End_A(y tensor A) is isomorphic to C[T]/(T^n-c).

This algebra is commutative. In a semisimple C-linear category the
endomorphism algebra of direct_sum_i m_i z_i, for distinct simples z_i,
is the product of Mat_{m_i}(C); it is commutative precisely when every
m_i is at most one. This proves the theorem. The case K={1} is included.

The proof does not invoke H^2(H,C*)=0, a fiber functor on D, a
classification of Tambara-Yamagami categories, or a normalization of
their associators. The cyclic hypothesis is essential: for V4 a twisted
group algebra can be Mat_2(C).

## Four rank-nine applications

All labels are zero-based source-tensor labels. In every row, the
invertible group is G={0,1,2,8}, generated by label 1 with powers
(0,1,8,2). In particular it is C4, not V4.

| Ring | D simples | y | x | x' |
| --- | --- | --- | --- | --- |
| R9_2_1025 | 0,1,2,6,8 | 6 | 4 | 5 |
| R9_2_1709 | 0,1,2,7,8 | 7 | 5 | 6 |
| R9_2_1759 | 0,1,2,6,8 | 6 | 3 | 4 |
| R9_2_1988 | 0,1,2,7,8 | 7 | 5 | 6 |

For each tensor the listed D is a fusion subring with rules
g y = y g = y and y^2 = sum_{g in G} g. Its hypothetical categorical
realization is a fusion subcategory of any hypothetical categorification
of the full ring. The additive category M spanned by x,x' is a D-module
subcategory: each g fixes both objects and

    y tensor x = 2 x',     y tensor x' = 2 x.

It is indecomposable since y connects its two simples. The internal end
of x in D is exactly sum_G g: the four invertibles each fix x, and y
has no diagonal action on x. The theorem forces y tensor x to be
multiplicity-free, contrary to 2 x'. Equivalently its endomorphism
algebra would have to be both commutative and Mat_2(C).

**Conclusion:** all four rings have no categorification over C.

## Exact certificate and provenance

`cyclic_tensors.json` contains the four full 9-by-9-by-9 tensors copied
from the accepted phase-three corpus, without alteration.
`verify_cyclic_obstruction.py` checks their SHA-256 values, all fusion
ring axioms, C4 multiplication, dual closure and multiplication closure
of D, the complete action of D on M, the internal-end support, and the
off-diagonal multiplicity two. The output is
`cyclic_obstruction_certificate.json`. These finite checks verify the
hypotheses of the theorem; they do not replace the categorical proof.

## Primary source

V. Ostrik, *Module categories, weak Hopf algebras and modular invariants*,
Transform. Groups 8 (2003), 177–206, arXiv:math/0111139, Section 3.2,
Lemma 5 and Section 3.3, Theorem 1. The proof explicitly uses the internal
end of a chosen object and the free-module adjunction, and imposes no
unitarity assumption.

https://arxiv.org/pdf/math/0111139

The cyclic obstruction above is a direct algebraic consequence proved
here; no claim of priority or literature novelty is made.



# Dimension-120 extension obstruction


Date: 24 October 2026. General-complex scope, with no braiding or
unitarity assumptions on the hypothetical categorification.

## Theorem

Let D be a fusion category with simple FP dimensions 1,1,2,2,5,5.
Assume:

1. D equals its adjoint subcategory (its universal grading is trivial).
2. The nontrivial invertible g fixes the two dimension-two simples and
   exchanges the two dimension-five simples.

Then every faithful finite-group extension of D is group-theoretical,
and in particular is integral.

### Step 1: D cannot be solvable

Suppose D were solvable. By ENO Proposition 4.4 it admits a construction
from Vec by successive extensions and equivariantizations by cyclic
groups of prime order. The last step cannot be an extension, since D
has no nontrivial faithful grading. Thus D = E^{C_p} for a fusion
category E, and the canonical central Rep(C_p) embeds into D under
forgetting its central structure. D has exactly two invertibles, so
p=2, and the nontrivial character has underlying object g.

De-equivariantize by this central Rep(C2), or equivalently take modules
over its regular central algebra A=1+g. This is a fusion category of
dimension 30. Its simple dimensions can be determined without knowing
any associator of D. The free orbit {1,g} gives one invertible; the free
orbit consisting of the two dimension-five objects gives one simple
of dimension five. Each fixed dimension-two object gives two distinct
simple A-modules of dimension one. Indeed, the endomorphism algebra
of its free module has dimension two and is semisimple, hence is C+C;
the two simple summands each have underlying object equal to the
original dimension-two object. FP dimension after passage to A-modules
is the underlying FP dimension divided by FPdim(A)=2. These six objects
exhaust the simples since every simple A-module is a summand of a free
module. Therefore the de-equivariantization has dimensions 1^5,5.

Its invertibles form the cyclic group C5. Writing z for its unique
noninvertible simple, rigidity and dimensions force

    hz=z=zh,    z^2 = sum_{h in C5} h + 4z.

But Etingof–Gelaki–Ostrik, Corollary 7.4, applies to arbitrary complex
fusion categories with n cyclic invertibles and one noninvertible of
dimension n. It forces n+1 to be a prime power. Here n=5 and 6 is not
a prime power. This contradiction proves that D is not solvable.

### Step 2: D is Morita equivalent to Vec_{A5}^omega

ENO Theorem 9.16 says that every fusion category of dimension 60 is
weakly group-theoretical. Hence D is categorically Morita equivalent
to a nilpotent fusion category N of the same dimension. Choose a
tower of faithful group extensions constructing N from Vec. The
product of the orders of the grading groups is 60.

If all grading groups are solvable, their normal series refine this
tower into cyclic-prime extensions; N and hence D are solvable,
contrary to Step 1. Thus at least one grading group is nonsolvable.
Every proper divisor of 60 is the order of only solvable finite
groups; the unique nonsolvable group of order 60 is A5. These standard
finite-group facts can also be expressed using the smallest
nonabelian simple group A5, of order 60, and a composition series.
The nonsolvable grading group therefore has order 60, and every other
extension step is trivial. Consequently N is a pointed category
Vec_{A5}^omega for some 3-cocycle omega. No value or trivialization of
omega is assumed.

### Step 3: all extensions of Vec_{A5}^omega are pointed

Let P=Vec_{A5}^omega, and let B be an invertible P-bimodule category.
As a left P-module category it has pointed dual (indeed the right
action identifies its dual with P, up to the harmless opposite
convention). By the classification of pointed-dual module categories,
Naidu–Nikshych Example 2.2, such a module category is described by a
normal abelian subgroup H of A5 and compatible cochain data. Since A5
has no nontrivial normal abelian subgroup, H={1}. Therefore B is the
regular left P-module category and has 60 simple objects, transitively
permuted by the 60 invertibles of P.

Each homogeneous component of a faithful group extension of P is an
invertible P-bimodule category. Consequently each component has these
60 simple objects, all with the same FP dimension d, because the
invertibles of P permute them transitively. A faithful homogeneous
component has total FP dimension FPdim(P)=60. Hence 60*d^2=60 and d=1.
Every simple object of the extension is invertible: the extension is
pointed. This argument applies to every omega and every coherent
extension, not merely to untwisted or preselected models.

### Step 4: transport the extension through Morita equivalence

If C is any faithful finite-group extension of D, ENO Lemma 3.4
constructs an extension of P which is Morita equivalent to C. It does
this by replacing D with its category of bimodules over an
indecomposable algebra and applying the same construction to C;
the grading survives because the algebra lies in the neutral
component. Step 3 makes the resulting category pointed. Thus C is
group-theoretical. Group-theoretical fusion categories are integral:
the standard double-coset description of simples gives dimensions

    [H : H intersect tHt^{-1}] * dim(projective irreducible representation),

which are integers. This proves the theorem.

## Application to two remaining rank-nine rings

Both tensors have global FP dimension 120. Their integral objects
form a dimension-60 fusion subring D and the other three objects
each have dimension 2*sqrt(5). The tensor verifies a faithful C2
grading with D as neutral component. In the notation (1,g,a,b,u,v)
of dimensions (1,1,2,2,5,5), the neutral labels are:

| Ring | Neutral labels (1,g,a,b,u,v) | Odd labels |
| --- | --- | --- |
| R9_2_585 | (0,1,7,8,3,4) | 2,5,6 |
| R9_2_1303 | (0,4,5,6,7,8) | 1,2,3 |

The neutral rules satisfy the theorem's two conditions. In particular
the adjoint closure is all six labels, while g fixes a,b and exchanges
u,v. A hypothetical categorification would therefore be an integral
extension by the theorem. Its three dimensions 2*sqrt(5) contradict
integrality.

**Conclusion: R9_2_585 and R9_2_1303 have no complex categorification.**

This proof does not assume that a fusion-ring match to a known
dimension-60 model classifies its categorifications. Step 2 establishes
the necessary Morita form for every hypothetical categorification.

## Exact certificate

`d120_tensors.json` contains the two unchanged full source tensors.
`verify_dimension120_obstruction.py` checks all fusion-ring axioms,
all FP dimension equations exactly in Q(sqrt(5)), the neutral
subcategory, faithful grading, its adjoint closure, and the complete
permutation of simples by g. Its output is
`dimension 120_obstruction_certificate.json`.

## Primary references and theorem scopes

* P. Etingof, D. Nikshych and V. Ostrik, *Weakly group-theoretical and
  solvable fusion categories*, Adv. Math. 226 (2011), 176–205,
  arXiv:0809.3031v2. Definition 1.1; Proposition 4.4; Proposition 4.5;
  Theorem 9.16 (dimension 60); Lemma 3.4 (Morita transport of extensions).
  https://arxiv.org/pdf/0809.3031
* P. Etingof, S. Gelaki and V. Ostrik, *Classification of fusion
  categories of dimension pq*, IMRN 2004, no. 57, 3041–3056,
  arXiv:math/0304194v2, Corollary 7.4. The statement concerns all complex
  fusion categories and is not a unitary-only classification.
  https://arxiv.org/pdf/math/0304194
* D. Naidu and D. Nikshych, *Lagrangian subcategories and braided tensor
  equivalences of twisted quantum doubles of finite groups*, Commun.
  Math. Phys. 279 (2008), 845–872, arXiv:0705.0665v2, Example 2.2
  and Section 4.2. The normal-abelian-subgroup condition covers
  arbitrary 3-cocycles omega.
  https://arxiv.org/pdf/0705.0665

The theorem is proved here by combining the stated results. No claim
of priority or exhaustive literature novelty is made.



# Two unitary models and a uniform family


## Result

The rings R9_2_746 and R9_2_1209 have explicit unitary categorifications.
They are the two parity-coherence inversion equivariantizations of a
12-simple-object generalized Tambara–Yamagami category with invertible
group C9 and three simple objects of dimension sqrt(3). This category is
constructed below by an explicit central C3 condensation, rather than
inferred from vanishing of a group cohomology obstruction.

All half-braidings in this note use the orientation
`c_z(X): z tensor X -> X tensor z`. This is inverse to the orientation
used for central structures in GNN Section 2.2; keeping this convention
explicit avoids a sign reversal in the bicharacter.

## Starting unitary categories and central object

Let omega=exp(2 pi i/3), zeta=exp(2 pi i/9). Take the unitary category
T=TY(C3,chi,1/sqrt(3)), chi(a,b)=omega^(ab), with the skeletal associators
of GNN Section 4.1. Its objects are a in C3 and m, with m^2=sum_a a.
The central lift z of the invertible a=1 has right half-braiding

    c_z(b)=omega^b,   c_z(m)=omega.

The equations are c_z(m)^2=chi(1,1)^(-1) and
c_(z tensor z')(m)=c_z(m)c_z'(m)chi(a,a')^(-1).
Thus z has order3 as a central object, and c_z(z)=omega.
These formulas follow by substitution in the displayed TY associators;
they are also the inverse-half-braiding form of the central invertibles in
GNN Proposition 4.1. No braiding on T itself is asserted.

Let P=Vec(C9,Omega), with representatives0,...,8 and

    Omega(a,b,c)=zeta^(3a floor((b+c)/9)).

This is a normalized unitary 3-cocycle. The underlying invertible h=3
has right half-braiding beta(x)=zeta^(2x). Its central square has
underlying object6 and half-braiding zeta^(4x). Its central cube has
half-braiding

    zeta^(6x) Omega(x,6,3)=zeta^(9x)=1.

In the product category B=T boxtimes P, the central object

    g=(z,3)

has order3. Its self-braiding is omega*zeta^6=1. The associator on its
three powers is identically1, since Omega(3a,3b,3c)=1. Their braiding is
also identically1, because the self-braiding of a generator is1 and this
is a pointed category with trivial associator. They therefore give an
explicit central Tannakian Rep(C3). Set A=1+g+g^2, with the ordinary
group-algebra multiplication (all nonzero multiplication scalars1).
It is a commutative separable central algebra with the usual unitary
normalization. The right A-module category D=B_A is a unitary fusion
category of dimension (6*9)/3=18.

The action of g on every simple of B is free: its C9 charge shifts by3.
Hence every free simple A-module is simple, and these are indexed by the
12 orbits. Writing the nine invertibles as u^a, a in C9, and the three
other simples as X_r, r in C3, gives

    u^a u^b = u^(a+b),
    u^a X_r = X_r u^a = X_(r+a),
    X_r X_s = sum_(h=0,1,2) u^(r+s-3h).

For example, use orbit representatives (0,a) and (m,r); the relation
(1,3)=1 in the quotient identifies (h,r+s) with (0,r+s-3h).
The dimensions are1^9,(sqrt3)^3.

## A coherent involution preserving the algebra

On T use the canonical orthogonal inversion autoequivalence
F(a)=-a,F(m)=m. The tensorator is the canonical identity map, including
the permutation of summands of m^2. This is an actual involutive tensor
autoequivalence, as in GNN Proposition 4.8.

On P use F(x)=-x with tensorator

    J(a,b)=zeta^mu(a,b),  mu(a,b)=-3a*1_(b>0) modulo 9.

Writing w for the exponent of Omega, direct substitution gives

    mu(a,b)+mu(a+b,c)-mu(b,c)-mu(a,b+c)
      = w(-a,-b,-c)-w(a,b,c) modulo 9,
    mu(a,b)+mu(-a,-b)=0 modulo 9.

Consequently F^2=Id as a tensor functor with identity square coherence.
On T it sends the central z to z^2. On P the transported half-braiding
of h=3 at the new argument x is

    beta(-x) J(3,-x)/J(-x,3) = zeta^(4x),

the half-braiding of the inverse central object h^2. Thus F(g)=g^2 as
central objects. On powers of g the tensorator is identically1 because
mu(3a,3b)=0. The permutation g^i -> g^(-i) therefore defines an actual
algebra isomorphism F(A)->A whose square is identity, respecting both
multiplication and the central structure. Hence F descends to a coherent
unitary C2 action on D. It acts by

    u^a -> u^(-a),    X_r -> X_(-r).

There is a second coherent action with the same tensor functor: multiply
the square coherence by the parity natural automorphism, +1 on pointed
simples and -1 on X_r. Parity is monoidal, invariant under F, and trivial
on A; hence it obeys the C2 action coherence before and after descent.
Both actions consist entirely of unitary structure maps.

## Exact equivariant fusion tensors

Let E_0 and E_1 be the equivariantizations for the identity and negative
odd square coherence, respectively. They are unitary categories of
dimension 36. Inversion fixes the unit and X_0, and has four two-element
pointed orbits and one two-element nonpointed orbit. Thus each E has
simple dimensions1^2,2^4,(sqrt3)^2,2sqrt3 and rank 9.

The two fixed objects give two equivariant lifts each. Every free orbit
gives one simple. The fusion multiplicity for a fixed output is
(dim+trace)/2; for a free output orbit it is the multiplicity at either
representative. Only fixed input objects contribute to the trace.
The only nontrivial fixed-input fusion line is X_0 X_0 ->1. This line is
inherited from (m,0)(m,0)->(0,0), where the tensorator acts identically.
In E_0 its trace is the product of the equivariant signs. In E_1 each
fixed odd equivariant structure squares to-1, so their product contributes
the extra factor-1. This determines every tensor coefficient without
choosing unknown F-symbols on D.

The standalone generator `cyclic_ty_models.py` constructs both tensors
from these orbit/trace formulas, verifies the unit, duality, Frobenius
reciprocity and all associativity equations, and matches every one of
the729 original census coefficients. The source-to-model permutations are

| Source | Coherence | Basis permutation |
|---|---|---|
| R9_2_746 | identity | [0,1,6,7,2,5,3,8,4] |
| R9_2_1209 | negative odd square | [0,6,7,2,5,3,8,1,4] |

`cyclic_ty_models.json` contains both full tensors, the orbit labels, the
intermediate rank 12 tensor, and the complete exact parameter checks.
The finite checks corroborate explicit categorical data; associativity of
the fusion tensor alone is not used as an existence argument.

## References

- D. Tambara and S. Yamagami, Tensor categories with fusion rules of
  self-duality for finite abelian groups, J. Algebra209(1998),692–707.
- S. Gelaki, D. Naidu and D. Nikshych, Centers of graded fusion categories,
  Algebra & Number Theory3(2009),959–990; arXiv:0905.3117.
  Sections2.4–2.5 give equivariantization/de-equivariantization;
  Section 4.1 gives the explicit TY associators; Proposition 4.1 describes
  central invertibles and Proposition 4.8 gives the orthogonal action.
  Primary source checked: https://arxiv.org/pdf/0905.3117.

This settles existence only; no classification or novelty claim about
all tensor-equivalence classes with these fusion rings is made.

## Uniform family

The same construction works with3 replaced by any odd n>1. Put
zeta=exp(2 pi i/n^2), chi(a,b)=zeta^(n ab) on Cn, choose
`c_z(m)=chi(1,1)^((n-1)/2)` (whose square is chi(1,1)^(-1)), and use

    Omega(a,b,c)=zeta^(n a floor((b+c)/n^2)),
    h=n, beta(x)=zeta^((n-1)x),
    J(a,b)=zeta^(-n a 1_(b>0)).

The n-th central power of h has half-braiding
`beta(x)^n zeta^(n x)=1`. The diagonal generator's self-braiding is1.
Both the associator and inversion tensorator restrict trivially to its
powers. Inversion sends its central lift to its inverse because
`-(2n-1)=(n-1)^2 modulo n^2`. This gives a unitary category of dimension
2n^2 with invertibles C_(n^2), n simples of dimension sqrt(n), and the
same cyclic generalized-TY formulas. The two equivariantizations have
dimension 4n^2 and rank(n^2+n+6)/2. The two rank-nine models above are the
n=3 members. This uniform construction does not classify all generalized
Tambara–Yamagami categories or their actions.



# A unitary model for R9_2_1254


## Result and outline

The ring R9_2_1254 is realized by a coherent C2 equivariantization of a
unitary generalized Moore–Read category of dimension 16. The new action
comes from a mixed order-four tensor functor on the dimension 32 covering
category. Its square becomes tensor-isomorphic to the identity only after
central boson condensation. Requiring the cover functor to have square
identity would incorrectly discard this construction.

The certificate is `mr_order4_descent_2_3_1_4.json`: it gives every
root-of-unity tensorator scalar and every component of the square
isomorphism. `mr_order4_descent.py` checks all required equations. The
categorical argument below explains why those equations suffice.

## The existing unitary cover and its central algebra

Use a unitary Ising category I with simples 1,psi,sigma, and P=Vec(C16,Omega),

    Omega(a,b,c)=zeta^(2a floor((b+c)/16)), zeta=exp(2 pi i/16).

Let B be the parity subcategory of I boxtimes P: its simples are(i,a),
with i=0,1,2 for1,psi,sigma, and a even for i=0,1 and odd for i=2.
There are24 simples and FPdim(B)=32. The invertible

    g=(psi,8)

has right half-braiding g tensor(i,a)->(i,a)tensor g of scalar

    beta(i,a)=zeta^(7a+e_i),  (e_0,e_1,e_2)=(0,8,12).

It has order2 in Z(B), self-braiding1, and trivial associator on its powers.
Indeed the pointed square correction is zeta^(2a), giving
beta_pointed(a)^2*zeta^(2a)=1; the Ising central fermion squares to1.
The regular algebra A=1+g is commutative, separable and central. Its
multiplication g tensor g->1 is the identity in the chosen skeletal basis.
Thus D=B_A is a unitary fusion category of dimension 16.

These are precisely the explicitly verified cover and central algebra in
`phase2/weak_integral/mr_orbifold.md`, with the right-half-braiding
orientation made explicit.

## The order-four mixed tensor functor

On simple objects define

    F(i,a)=(i xor (a/2 mod 2),3a mod 16),   i=0,1;
    F(2,a)=(2,3a mod 16).

This preserves every fusion coefficient and the unit. The file lists the
scalar J_F(a,b;c) in mu_16 on every multiplicity-one fusion channel,
with tensorator orientation F(a)tensor F(b)->F(a tensor b).
F is linear on each chosen elementary morphism and permutes channel
labels in the obvious way. Its tensor-functor equations are verified
entry by entry against the cover's actual F-symbols, not only the fusion
rules. All nonzero Ising F-symbol magnitudes are preserved: the only
nontrivial magnitude1/sqrt2 occurs for three sigma inputs, and F fixes
the Ising type of those inputs. Consequently checking the phase of every
nonzero entry checks the entire tensor-functor diagram.

The actual F-symbol exponent is the standard Ising sign times8, plus
`2 a floor((b+c)/16)` from the charge factor. The script checks all 18432
nonzero associator entries and the unit constraints. Since J is unitary
and the object map is a permutation, F is a unitary tensor autoequivalence.

F(g)=g. The certificate additionally verifies every central transport
identity

    J_F(g,a;ga)/J_F(a,g;ga)=beta(Fa)/beta(a).

Choose an algebra isomorphism phi:F(A)->A which is identity on1 and has
scalar c=zeta32^2 on g (equivalently c=zeta16). Here the saved value is
J_F(g,g;1)=zeta16^2, so c^2=J_F(g,g;1). This is exactly the algebra
multiplication compatibility. The central transport equations make phi
an isomorphism of central algebras. Therefore F descends to a unitary
tensor autoequivalence f of D.

## Squaring before and after condensation

On B, F^2 is not the identity object map. It is

    K(a)=g^p(a) tensor a,

where p(a)=0 for an even Ising object and1 for a sigma object. Equip K
with its canonical tensorator: move the central g factors to the left
using the right half-braiding, and multiply g^2=1. More explicitly,
reassociate

    (g^p a)(g^q b) -> g^p(a(g^q b))
      -> g^p((a g^q)b) -> g^p((g^q a)b)
      -> g^p(g^q(ab)) -> (g^p g^q)(ab) -> g^(p+q)(ab).

The middle interchange contributes beta(a)^(-q). All other contributions
are specified cover associators. The script independently verifies the
resulting J_K against all 18432 tensor-functor equations.

The certificate supplies a natural isomorphism d:F^2->K on the common
underlying simple objects. Its phases satisfy for every channel a b->c

    d(a)d(b)/d(c)
      =J_F(a,b;c) J_F(Fa,Fb;Fc)/J_K(a,b;c).

This is exactly monoidality of d. It also satisfies

    d(g)=J_F(g,g;1)=c^2.

Thus d intertwines the algebra map phi F(phi):F^2(A)->A with the
identity algebra map K(A)->A. It descends to the module categories.

On D, K is canonically tensor-isomorphic to the identity. On a free
module q(a), use q(g)^p tensor q(a)->q(a), where q(g)->1_D is supplied by
the regular algebra multiplication. The tensorator of K was defined
by precisely the central movements appearing in this map. Its
monoidality uses beta(g)=1 and the group-algebra relation g^2=1. Hence
f^2 is tensor-isomorphic to Id_D.

## Coherent C2 action, with no unresolved obstruction

For completeness there are two ways to finish coherence.

First, the canonical universal grading of D is C8: writing its simples
as u^a(a in C8) and X_r(r in C4), their degrees are2a and2r+1 modulo 8.
Its adjoint subcategory has basis1,u^4, as follows from
X_r X_r^*=1+u^4. Therefore Aut_tensor(Id_D)=Hom(C8,C*)=C8. The functor f
acts on this group by multiplication3. The obstruction to upgrading an
order-two tensor-equivalence class to a C2 action lies in

    H^3(C2,C8_3)=ker(1+3)/(3-1)C8=2C8/2C8=0.

Thus the action coherence can always be corrected. This is the standard
monoidal-action obstruction (a direct cyclic coherence calculation), not
an assertion that H4 alone supplies an extension.

Second, for the displayed certificate the correction is explicit. If
phases are written as exponents mod 16, replace d(a) by

    d_new(i,a)=d(i,a)-4a modulo 16.

This multiplies d by the universal-grading character with parameter-2.
Before correction the C2 coherence defect is the parity character;
after correction it is identically1. In the saved bases the defect,
written as an exponent mod 32, is

    2d(Fa)-2d(a)-p(a)(J_F(g,g;1)-2J_F(g,a;ga)).

The script `mr_1254_model.py` checks that it is16 on odd objects and0 on
even objects before correction, and0 everywhere afterwards; the final
phases still satisfy all monoidality and algebra compatibility equations.
Every correction is unitary. This produces an actual coherent unitary
C2 action on D.

## Fusion tensor and census identification

In D use representatives(1,2a) for u^a, and(sigma,1+2r) for X_r. Then

    u^a u^b=u^(a+b),     u^a X_r=X_r u^a=X_(r+a),
    X_r X_s=u^(r+s+1)+u^(r+s+5).

The descended involution acts by

    u^a ->u^(-a),    X_r ->X_(3r+1).

It fixes1,u^4; it has three two-element pointed orbits, and two
two-element odd orbits. The equivariantization E=D^C2 therefore has
rank 9 and dimensions1^4,2^3,(2sqrt2)^2. The odd orbits are exchanged by
duality, giving the feature missing from the earlier model389.

For the fixed object u^4, the certificate has d_new(u^4)=14 and
J_F(u^4,u^4;1)=14 modulo 16. Thus its equivariant lifts have square1,
and the invertible group is V4. A later action-coherence correction by a
universal-grading character cannot change this, because deg(u^4)=0.

The full tensor is computed by the invariant-subspace formula. For a
fixed output the multiplicity is(dim+trace)/2; only fixed input objects
contribute to the trace. These inputs are1 andu^4, whose representatives
are literally fixed in the cover, so the relevant phases are exactly the
saved J_F and d_new entries. For a free output orbit use the dimension at
one representative. This determines every fusion coefficient.

`mr_1254_model.py` verifies all ring axioms and matches all 729 coefficients
of R9_2_1254 with source-to-model basis permutation

    [0,8,7,5,6,1,2,4,3].

`mr_1254_model.json` includes the full rank 9 tensor, rank 12 quotient
tensor, action, corrected coherence phases and equivariant orbit labels.
The model is unitary by construction from unitary categories, a central
unitary separable algebra, and a coherent unitary finite-group action.

## Scope and references

The proof establishes categorical existence for this fusion ring. It
does not classify all its categorifications or assert tensor-equivalence
novelty of the resulting category.

- S.Gelaki,D.Naidu,D.Nikshych, Centers of graded fusion categories,
  arXiv:0905.3117, Sections2.4–2.5, for actions and central condensation.
- J.Dong,S.Natale,H.Sun, A class of prime fusion categories of dimension 2^N,
  New York J.Math.27(2021),141–163,
  https://nyjm.albany.edu/j/2021/27-5p.pdf, for the generalized Moore–Read
  setting. Existence and the required action here are specified directly.
- P.Etingof,D.Nikshych,V.Ostrik, Fusion categories and homotopy theory,
  arXiv:0909.3140, for the obstruction-theoretic formulation of tensor
  actions; the relevant cyclic H3 calculation is supplied above.



# Independent repair for R8_3_436


Research correction, 24 October 2026. Online publication is deferred.

## What was wrong

The earlier proof `evidence/rank 8_frontier_20261021/structural_models/R436_GENERAL_TPE.md`
claimed that every complex near-group category of type `(C3,3)` is Galois
conjugate to a unitary category. Its crucial normalization assertion is not
established by the cited source. In He–Liu–Lu–Palcoux–Ren,
arXiv:2610.11652v1, Corollary 4.7 uses unitary representations and an
orthonormal basis, and the normalization following it uses unitary duality.
The separate algebraic reconstruction theorem constructs a category from
specified scalar data. It does not identify an arbitrary original spherical
category with that constructed category. The old exact scalar computation
establishes neither the missing parameterization nor the needed equivalence.

**Withdraw that general-unitarization proposition and its use in the old
proof.** The present argument uses no near-group associator classification,
unitarization theorem, or TPE parameterization. It replaces the invalid proof;
it does not validate the invalid premise retrospectively.

## Theorem

No complex fusion category has fusion tensor `R8_3_436`.

### Source structure

The tensor SHA256 is
`0f6d68de67a7287db7dd32a786237f7af9f35ec7c26b3ada2ba50012ff5455c7`.
It has a faithful `C2` grading whose neutral basis is `[0,1,2,5]` and whose
odd basis is `[3,4,6,7]`. In the neutral component write `g=1`, `X=5`:

\[
g^3=1,\quad gX=Xg=X,\quad X^2=1+g+g^2+3X.
\]

The odd invertible `t=3` obeys `t²=1`, `tgt^{-1}=g^{-1}`, and
`tXt^{-1}=X`. These claims are exact statements about all relevant source
coefficients; the accompanying verifier checks them directly.

Suppose a fusion category `C` realizes the tensor, and let `D=C_e`.

### Removing a possible associator anomaly

Do not assume that the pointed category generated by `t` is untwisted.
Choose skeletal identifications `t⊗t ≅ 1`; their associativity discrepancy
is a normalized scalar 3-cocycle `ω` on `C2`. Twist the associator of the
whole graded category `C` by the inflated cocycle `ω^{-1}`:

\[
\alpha'_{U,V,W}=\omega(|U|,|V|,|W|)^{-1}\alpha_{U,V,W}
\]

for homogeneous objects. The cocycle identity is precisely the additional
pentagon condition. This gives a fusion category with the same fusion ring,
with unchanged neutral category `D`, and with a monoidal section of `C2`
provided by `1,t`: its pointed associator is now trivial.

Conjugation by that monoidal section gives a **coherent categorical action**
of `C2` on `D`. In a strict realization of the section, its functors are
`F_h(U)=t_h⊗U⊗t_h^{-1}`; the tensor structures cancel adjacent
`t_h^{-1}⊗t_h`, and the action composition maps use
`t_h⊗t_k ≅ t_{hk}`. Their coherence is the associativity of the section.
The nontrivial functor interchanges `g,g²` and fixes `X`.
This cocycle cancellation avoids making any claim that an arbitrary bare
order-two autoequivalence automatically admits an action structure.

### Spherical equivariantization

By Thornton, *On braided near-group categories*, Theorem 1.3,
`D` has a spherical structure. That theorem does not assume braiding.
Its spherical dimensions are `dim(g)=1` and

\[
d=\dim(X),\qquad d^2=3+3d,
\]

so its dimension field is `Q(√21)`; either root is allowed.

The pivotal structure of `D` is unique. Indeed, a tensor automorphism of
its identity functor acts by nonzero scalars `λ_g,λ_X` on simple objects.
The summand relation `gX=X` gives `λ_g=1`. The occurrence of `X` in `X²`
gives `λ_X²=λ_X`, hence `λ_X=1`. Any two pivotal structures differ by
such an automorphism. Consequently every tensor autoequivalence preserves
the spherical pivotal structure. The above coherent action therefore
preserves sphericality, and its equivariantization `E=D^{C2}` is spherical.
The pivotal maps of equivariant objects are those of their underlying
objects; equivariance follows from preservation of the pivotal structure.
The forgetful functor is thus spherical and preserves dimensions.

There are exactly five simples of `E`, which we denote
`1, ε, Y, A, B`. They arise from the two fixed neutral simples `1,X`
and the free orbit `{g,g²}`. A fixed simple gives two equivariant lifts,
since a projective representation of `C2` over `C` can be linearized:
rescale its generator to make its square 1. Thus

\[
F(1)=F(\varepsilon)=1,\quad F(Y)=g\oplus g^2,
\quad F(A)=F(B)=X,
\]
\[
\dim(1,\varepsilon,Y,A,B)=(1,1,2,d,d).
\]

The sign representation `ε` is central, satisfies `ε²=1`, fixes `Y`,
and exchanges `A,B`.

### All possible equivariantized fusion rules

The fusion rules are forced up to nonnegative integers `a,b` with `a+b=3`.
First `Y` is self-dual, and forgetful images plus Frobenius reciprocity give

\[
Y^2=1+\varepsilon+Y.
\]

Both `YA` and `AY` have underlying object `2X`. Since `εY=Y` and `ε`
is central, they are invariant under interchanging `A,B`. Hence

\[
YA=AY=A+B,
\]

and the same holds with `B`. Moreover `B=εA`, so `A,B` commute with one
another. These relations prove that the entire based ring is commutative;
commutativity is not inferred merely from commutativity of `K_0(D)`.

The duality must either fix both `A,B` or interchange them. In the latter
case Frobenius reciprocity and the forgetful images force

\[
A^2=\varepsilon+Y+aA+bB,\qquad B^2=A^2.
\]

Dualizing this equality forces `a=b`, contradicting `a+b=3`. Thus both
`A` and `B` are self-dual, and the remaining products are

\[
A^2=B^2=1+Y+aA+bB,
\qquad AB=\varepsilon+Y+bA+aB,
\qquad a+b=3.
\]

All four ordered pairs `(a,b)` are retained. Interchanging `A,B` groups
them into two isomorphism classes, but that identification is unnecessary.

### Formal codegrees contradict the dimension field

Set `s=a-b`; then `s∈{-3,-1,1,3}`. The preceding fusion rules have the
one-dimensional character

\[
\chi(1)=1,\quad\chi(\varepsilon)=-1,\quad\chi(Y)=0,
\quad\chi(A)=x,\quad\chi(B)=-x,
\quad x^2=1+s x.
\]

As all basis elements are self-dual, its formal codegree is

\[
f=\sum_Z\chi(Z)^2=2+2x^2
 =s^2+4\;\pm\;s\sqrt{s^2+4}.
\]

It lies in `Q(√5)\Q` if `|s|=1`, and in `Q(√13)\Q` if `|s|=3`.
Neither field equals `Q(√21)`.

Ostrik, *Pivotal fusion categories of rank 3*, Corollary 2.15, says that
all formal codegrees of a spherical fusion category lie in its dimension
field. For completeness, Theorem 2.13 supplies a central simple of dimension
`dim(E)/f`; forgetting to `E` expresses this as an integral combination of
simple dimensions. Hence both `dim(E)/f` and `dim(E)` lie in the dimension
field, as does `f`.

Our spherical category `E` has dimension field exactly `Q(√21)` by
Section 3. This contradiction proves the theorem. No sign of `d`,
pseudo-unitarity, unitarity, or associator parameterization was assumed.

An independent arithmetic check is also available. The global dimension
`dim(E)=6+2d²=21±3√21` has quadratic norm 252. The two possible formal
codegree norms are 20 and 52. Thus the norm of `dim(E)/f` in the relevant
biquadratic field is respectively `3969/25` or `3969/169`, not an integer.
Such a number cannot be the dimension of a central simple.

## General reusable criterion

The same argument applies to a coherent inversion action on any complex
near-group category `NG(C3,m)` with odd `m>0`. There must exist an odd
integer `s` with `|s|≤m` such that

\[
\mathbb Q\bigl(\sqrt{s^2+4}\bigr)
\subseteq\mathbb Q\bigl(\sqrt{m^2+12}\bigr).
\]

It is a necessary condition, not an existence assertion. At `m=3` it fails
for all possible `s`. The parity assumption is essential: for even `m`,
`s=0` and non-self-dual branches can occur, and the present contradiction
does not apply. In particular it does not exclude the known `C3+6`
equivariantization.

## Scope and publication instructions

* Withdraw the old claimed theorem that every complex `NG(C3,3)` category
  is Galois-unitary. No replacement proof of that stronger assertion is given.
* Replace the old general exclusion with the theorem above after independent
  review. The *conclusion* remains general noncategorifiability, now with a
  different proof and explicit treatment of the pointed associator anomaly.
* The previous unitary inversion proof remains valid independently. Braided
  existence is also impossible from noncommutativity of the source ring.
* The source tensor has coefficient 3. It cannot occur as a fusion subring
  of a tensor of maximum coefficient 1 or 2. Thus this proof correction has
  no negative-subring transfer consequences for the rank 9 M2 classification.
* No online files were changed by this research task.

## Primary sources

1. J. Thornton, *On braided near-group categories*, arXiv:1102.4640v1,
   Theorem 1.3: https://arxiv.org/pdf/1102.4640 .
2. V. Ostrik, *Pivotal fusion categories of rank 3*, arXiv:1309.4822v1,
   Theorem 2.13 and Corollary 2.15: https://arxiv.org/pdf/1309.4822 .
3. C. Galindo, *Crossed product tensor categories*, arXiv:0911.0881v3,
   background for coherent crossed actions: https://arxiv.org/pdf/0911.0881 .
4. H. He, Z. Liu, F. Lu, S. Palcoux, Y. Ren,
   *Triangular prism equations for near-group categories: algebraic solutions
   and a unitary conjecture*, arXiv:2610.11652v1, Sections 4–5:
   https://arxiv.org/html/2610.11652v1 . This source is audited above and is
   **not a premise of the replacement proof**.

## Replay

`python rank 9_m2_research/phase4/r8_scope/verify_equivariantization.py`
checks the source, all four candidate fusion tensors, duality exhaustion,
formal codegrees and exact norm contradictions. Its assertions are explicit
exceptions and remain active under `python -O`. Default replay is read-only; `--write` regenerates only its local
certificate. It does not claim to verify the categorical theorems by code.



# Braided restrictions for the integral cases


These arguments exclude **braided** categorifications of `R9_2_12`,
`R9_2_959`, and `R9_2_941`. They do not exclude arbitrary fusion
categorifications and do not change the 2,033/32/18 general partition.
The noncommutative ring `R9_2_1965` was already excluded from braided
categorification.

## A general obstruction to a central Rep(S3)

**Proposition.** A complex fusion category of FP-dimension type
`(1^4,2^2,6^3)` admits no fully faithful central Tannakian embedding
`Rep(S3) -> Z(C)` whose composite with the forgetful functor is fully
faithful.

**Proof.** Such an embedding gives an actual equivariantization
`C = D^{S3}`, with `FPdim(D)=20` (EGNO Theorem 8.23.3).
The dimension formula for simples in an equivariantization is

`FPdim(X_{Y,pi}) = [S3:S_Y] dim(pi) FPdim(Y)`.

Every simple of D occurs below some equivariant simple. Thus its dimension
is a rational algebraic integer, hence a positive integer. All subgroups
of S3 have trivial Schur multiplier over C, so the projective character
degrees of a stabilizer equal its ordinary character degrees. This is
clear for cyclic subgroups; for S3 it is the standard vanishing
`H^2(S3,C^*)=0`.

Each S3-fixed invertible of D contributes simples of dimensions `(1,1,2)`
to C. Conversely, an invertible of C lies over an S3-fixed invertible of D.
Therefore D has exactly two S3-fixed invertibles, already accounting for
all four dimension-one and both dimension-two objects of C. The remaining
objects of C, of dimension six, can arise only in these packets:

| Stabilizer | Orbit size | Dimension in D | Dimensions contributed to C |
|---|---:|---:|---|
| trivial | 6 | 1 | 6 |
| C2 | 3 | 2 | 6,6 |
| C3 | 2 | 3 | 6,6,6 |

No additional fixed orbit is possible, since it contributes `d,d,2d`.
Partitioning the three six-dimensional objects gives exactly three
possible types for D:

1. `(1^20)`, with two fixed elements and three free S3-orbits of size six;
2. `(1^8,2^3)`;
3. `(1^2,3^2)`.

The second is impossible because a pointed subcategory of dimension eight
would lie in a category of dimension twenty. The FP-dimension of a fusion
subcategory divides that of the ambient category in the ring of algebraic
integers, whereas `20/8` is not an integer.

The third is impossible because fusion categories of dimension `2^2*5`
are solvable (ENO Theorem 1.6), hence have the strong Frobenius property
(ENO Theorem 1.5), whereas `20/3` is not an integer.

In the first case D is `Vec_K^omega` for a group K of order twenty. The
S3 action induces an action by group automorphisms on K. Its unique
Sylow-five subgroup P is characteristic. The subgroup C3 of S3 acts
trivially on P because `Aut(C5)=C4`. Consequently C3 fixes at least five
elements of K. But the stipulated S3-orbit pattern has exactly two
C3-fixed elements: every free six-element orbit restricts to two free
three-element C3-orbits. This is a contradiction. QED.

No assumption that C itself is braided, unitary, group-theoretical, or
solvable occurs in this proposition. The central Rep(S3) premise is
essential and is not inferred merely from the presence of its based ring.

## A braided criterion applying to R9_2_12 and R9_2_959

**Theorem.** Suppose an integral fusion ring R of type `(1^4,2^2,6^3)`
has the following two properties:

* every nonpointed fusion subring contains a subring with the ordinary
  representation ring of S3;
* every invertible fixes at least one of the three dimension-six basis
  elements.

Then R has no braided complex fusion categorification.

**Proof.** A hypothetical categorification C is pseudo-unitary by weak
integrality. Equip it with the canonical positive spherical structure and
the resulting ribbon structure. Write E for its Müger center.

If E is nonpointed, the first hypothesis gives a rank-three symmetric
subcategory with fusion rules `Rep(S3)`. By Deligne's classification of
symmetric fusion categories, it is `Rep(H,z)` for a finite group H and a
central involution z. Its dimension is six and it is nonpointed, so H is
S3. Since the center of S3 is trivial, z=1, and this subcategory is
Tannakian. Its embedding in the Müger center gives the prohibited central
Rep(S3) of the proposition.

Suppose E is pointed. For each simple g of E, choose a dimension-six
simple X fixed by g. Since g is transparent, the balancing equation gives
`theta_{gX}=theta_g theta_X`; hence `theta_g=1`. All twists in E are
therefore trivial, so E is Tannakian: `E=Rep(H)` for an abelian group H
of order `e` dividing four. (This includes `e=1`.)

De-equivariantization by the full Müger center gives a nondegenerate
braided fusion category B, with `FPdim(B)=120/e`, and `C=B^H`.
It is integral by the same rational-dimension argument as above. If a
dimension-six simple of C lies over Y in B, then

`6 = [H:H_Y] dim(pi) FPdim(Y)`.

Here H has order at most four. All subgroup indices and all projective
irreducible degrees are powers of two (for these groups the degrees are
one or two). Thus `FPdim(Y)` is an integer divisible by three.
But B is integral and nondegenerate, hence modular with its positive
spherical structure. Modular square-divisibility says
`FPdim(Y)^2 | FPdim(B)` in the integers. The left side is divisible by
nine, whereas `120/e` has 3-adic valuation one. Contradiction. QED.

This proof handles the potentially super-Tannakian center explicitly;
it does not assume that every symmetric subcategory is Tannakian.

**Exact application.** With zero-based source labels, the S3 subring is
`[0,6,7]` for R9_2_12 and `[0,7,8]` for R9_2_959. Every nonpointed fusion
subring contains this subring, including the whole ring. Each of the four
invertibles fixes a dimension-six object. The verifier regenerates every
fusion subring from the original compressed source tensor, checks all
dimension equations and fixed points, and exhaustively checks the small
S3-orbit bookkeeping. No floating-point arithmetic is used.

## R9_2_941: simple, nonbraided, and not weakly group-theoretical

The exact original tensor has no proper nontrivial fusion subring, has
dimensions `(1,7,8,7,7,7,9,9,9)`, and global dimension 504. Its full tensor
is isomorphic to the exotic dimension-504 ring in Alekseyev--Bruns--Dong--
Palcoux, arXiv:2507.07023v2, Sections 1.5 and 7.5. The exact based
isomorphism is rechecked by the verifier using the copied published tensor.
The source states that it is exotic, i.e. it is not the representation
ring of a finite group. It explicitly leaves categorification open.

A hypothetical braided categorification is simple. Its Müger center is
therefore either Vec or the entire category. In the first case it is
modular, impossible because a dimension-seven simple would require
`49 | 504`. In the second case it is symmetric; Deligne's classification
makes its underlying fusion ring a finite-group representation ring,
contradicting the exotic property. Thus it cannot be braided.

ENO Proposition 9.11 also says that a nonpointed simple weakly
group-theoretical category is equivalent to Rep(G) for a nonabelian
finite simple group. Consequently R9_2_941 admits no weakly
group-theoretical categorification. General and unitary existence remain
open. This obstruction must not be represented as a general exclusion.

## Primary references and proof dependencies

* Etingof--Gelaki--Nikshych--Ostrik, *Tensor Categories*, author's final
  version: <https://math.mit.edu/~etingof/egnobookfinal.pdf>.
  Proposition 4.15.9 (equivariant simple dimensions); Theorem 8.23.3
  (central embedding and actual equivariantization); Proposition 8.23.8
  (braided descent); Proposition 8.14.6 (modular square-divisibility);
  Sections 9.9 and 9.11 (symmetric/Tannakian categories), and Section 8.20
  (Müger center and nondegeneracy).
* Etingof--Nikshych--Ostrik, *Weakly group-theoretical and solvable fusion
  categories*, <https://arxiv.org/pdf/0809.3031>, Theorems 1.5 and 1.6,
  Proposition 9.11.
* Liu--Palcoux--Ren, *Interpolated family of non group-like simple
  integral fusion rings of Lie type*, <https://arxiv.org/pdf/2102.01663>,
  Section 5, especially the symmetric/modular dichotomy for simple
  weakly integral braided categories.
* Alekseyev--Bruns--Dong--Palcoux, *Classifying integral Grothendieck
  rings up to rank 5 and beyond*, <https://arxiv.org/pdf/2507.07023v2>,
  Sections 1.5 and 7.5, Question 1.14 (the exact open ring).

`verify_scope_refinements.py` and `scope_refinements.json` record the
finite ring hypotheses. They do not computationally certify the cited
categorical theorems or turn the missing general hypotheses into facts.



# Group-theoretical restrictions for the integral cases


**Scope.** This argument excludes group-theoretical categorifications of
`R9_2_12`, `R9_2_959`, and `R9_2_1965`. Together with ENO Proposition 9.11
for the simple exotic ring `R9_2_941`, all four integral residual rings
are outside the group-theoretical class. This does **not** exclude arbitrary
fusion categorifications. In particular, no theorem identifying all
integral categories of dimensions 120 or 168 as group-theoretical is used.

The finite computations below are exact. A separate independent audit
passed: `phase4/audit_integral_gt/AUDIT.md` and `audit_verdict.json`.
The accepted conclusion has group-theoretical scope only.

## An exhaustive projective-character profile reduction

Every group-theoretical category of dimension D has a presentation
`C(G,omega,H,psi)` with `|G|=D`, `d psi=omega|H`. Its simples over a double
coset `HgH` are indexed by projective irreducible representations of
`K_g=H intersect gHg^{-1}`, of dimensions

`[H:K_g] dim(pi)`.

The identity double coset supplies the ordinary category `Rep(H)` as a
fusion subcategory. A projective irreducible degree is at most the square
root of the order of its group, so all simple dimensions are at most |H|.
In particular, |H|<6 cannot supply a dimension-six simple.

`all_twist_skeleton.g` enumerates every group of orders 120 and 168 and
every conjugacy class of subgroups. It first checks that the ordinary
character degrees of H are a submultiset of the target type. For every
remaining double-coset intersection K, it constructs a Schur cover and
partitions the irreducible characters of the cover by their central
character on the kernel. These are precisely all projective degree
profiles, for every class in `H^2(K,C^*)`. It independently chooses any
of these profiles at every double coset, retaining those whose union is
the target type. Independence is a relaxation of global compatibility;
it cannot omit any global three-cocycle or relative two-cochain.

The complete output is:

| D | Groups | Subgroup conjugacy classes | Surviving pairs |
|---:|---:|---:|---|
| 120 | 47 | 1431 | `(S5,S3xC2)` and `(A5xC2,S3xC2)` |
| 168 | 57 | 1751 | the two conjugacy classes `(PSL(2,7),S4)` |

Both dimension-120 pairs have intersections of orders `12,2,4`, with
the order-four intersection V4. Their required projective degree packets
are `(1,1,1,1,2,2)`, `(6,6)`, and `(6)` respectively. Thus the V4
intersection must carry its nontrivial Schur class. Both dimension-168
pairs have intersections S4 and V4; the required packets are
`(1,1,2,3,3)` and `(6,6,6,6)`.

The scan uses GAP 4.12.1 with SmallGrp and the exact character/Schur-cover
algorithms. It is finite group classification plus finite exact arithmetic,
not a restricted three-cocycle ansatz. The saved `.json` normalizes the
GAP output; the original `.jsonl` contains line-wrapped JSON objects.

## Immediate consequence for R9_2_959

For both surviving dimension-120 pairs, H is `S3xC2`, whose representation
category has invertible group V4. It embeds as the identity double-coset
subcategory. But the invertible group of R9_2_959 is C4. A based inclusion
cannot embed V4 into C4. Thus no group-theoretical categorification of
R9_2_959 exists, independently of omega and psi.

## All relative three-cocycles for the S5 pair

Let `G=S5` and `H=S3xC2`. Every admissible class
`a in H^3(G,C^*)` restricts to zero on H. Restriction followed by
corestriction is multiplication by `[G:H]=10`, hence `10a=0`.

The five-primary part of `H^3(S5,C^*) = H^4(S5,Z)` is zero: restriction
to a Sylow C5 is injective on this part, and the image must be fixed by
the normalizer `C5:C4`. An order-four automorphism of C5 acts on H^4 by
the square of a primitive automorphism, namely -1 modulo five, whose
fixed space is zero. Therefore every admissible class has order at most
two.

Every two-torsion class in H^3(G,C^*) lifts to H^3(G,F2), by the long
exact sequence of `1 -> mu2 -> C^* --square--> C^* -> 1`.
Let P be a Sylow D8 of S5. Its index is fifteen, hence odd. If a is a
two-torsion global class and b is any F2 lift of its restriction to P,
then the image of `cor_P^G(b)` in H^3(G,C^*) is
`cor(res(a))=15a=a`. Consequently corestricting **every** F2 third
cohomology class of P exhausts all admissible global associator classes.

The normalized bar complex computes `dim H^3(D8,F2)=4`: 343 normalized
three-cochain variables, cocycle dimension 45, boundary dimension 41.
The program enumerates all sixteen classes. For right coset representatives
`t` of `P\G`, define `h(t,g)` and `t.g` by

`t g = h(t,g) (t.g)`.

The explicit corestricted sign cocycle is

`w(g1,g2,g3) = sum_t b(h(t,g1),h(t.g1,g2),h(t.g1g2,g3)) mod 2`.

This is the usual inhomogeneous cochain transfer, so it takes exact
cocycles to exact cocycles. The program solves `d psi=(-1)^w|H` exactly
in eighth roots of unity. Completeness of this finite primitive test is
explained below.

Eight of the sixteen representatives admit a relative trivialization.
Four yield rank twelve. The other four yield rank nine and match **all
729 coefficients of R9_2_92**, with explicit based isomorphisms; none
matches R9_2_12. Reusing the independently audited twisted bimodule
character formula is legitimate here: only its normalized cocycle and
relative cochain inputs change. Every returned tensor is separately
checked for the unit and every associativity equation: 6,561 at rank nine
and 20,736 at rank twelve.

There is no missing choice of psi. `H^2(H,C^*)=C2`, and the nontrivial
class extends from the Schur cocycle of S5: lifted disjoint transpositions
have nontrivial commutator. Multiplying psi by that class is induced by
an identity-on-objects tensor autoequivalence of `Vec_G^omega`, so it
does not change the based ring. This extension was independently checked
in phase three's `S5_RELATIVE_TWIST.md` and audit.

Thus the entire S5 pair, with all relative cocycles, gives no model for
R9_2_12.

### Exact primitive solver and its bound

Since `H^2(H,C^*)` has exponent two, a sign-valued three-cocycle on H
that is a C^*-coboundary has a fourth-root-valued primitive. Indeed, if
`d psi=w`, then `psi^2` is a two-cocycle. Hence `psi^4=d f` for a
one-cochain f. Choose a fourth root b of f, and replace psi by
`psi/(d b)`; its fourth power is one. Thus eighth roots are more than
sufficient.

The congruence solver lifts successively modulo two, four and eight.
At each lower stage it enumerates all possible H^2(H,F2) classes, whose
basis is `x^2,xy,y^2`, for the two abelianization characters of
`H=S3xC2`. This follows also from the normal odd-order C3 subgroup:
`H^*(H,F2)=H^*(C2xC2,F2)`. Two solutions differing by an F2 two-coboundary
have the same liftability, since that change can be lifted to an integral
one-coboundary adjustment. Exact Gaussian elimination handles the
inhomogeneous linear equations and tests every consistency row. The final
primitive is checked against every normalized triple of H. Thus a failed
test is an exact no-primitive conclusion, not an optimizer timeout.

## The A5xC2 pair, including the odd-primary part

Again the global restriction kernel is killed by ten, so an admissible
class is a sum of a two-torsion and a five-torsion class. We handle the
two-primary part by the same exhaustive transfer construction, using a
Sylow group P=C2^3 of index fifteen. The normalized bar complex has
cocycle dimension 49 and boundary dimension 39, giving ten F2 third
cohomology generators.

For efficiency, let n be an order-three element of the normalizer of P.
Corestriction is unchanged in cohomology by conjugating a seed by n.
Thus corestricting b is cohomologous to corestricting
`b+n*b+n^2*b`, since three is one modulo two. The span of these norm
classes has dimension four. Exact reduction modulo the bar boundaries
therefore gives sixteen representatives covering the image of **all
1,024** original F2 cohomology classes. No global class is discarded.

Only two of these sixteen representatives admit a primitive on H.
For each, both subgroup Schur choices `psi` and `psi*(-1)^{x cup y}`
are explicitly tested. In all four cases the V4 intersection multiplier
is trivial and the resulting category has rank twelve. Thus no
two-primary relative class gives the required rank-nine profile.

The five-primary part cannot change this conclusion. Relative pairs
`(omega,psi)` form relative cohomology, and the multiplier on a
double-coset intersection K is a homomorphism from that relative
cohomology group to `H^2(K,C^*)`. The five-primary part of the relative
group maps isomorphically to the five-primary global restriction kernel,
because `H^2(H,C^*)` has no five-torsion. Its image in the order-two
Schur multiplier of V4 is therefore zero. Equivalently, multiplying
the relative data by any order-five relative class does not change the
V4 projective degree profile. The necessary rank-nine profile requires
that multiplier to be nontrivial. Hence no admissible cocycles for
`(A5xC2,S3xC2)` realize R9_2_12.

Combining Sections 1, 3 and 4 proves the group-theoretical exclusion for
R9_2_12.

## The dimension-168 pair

The all-twist profile reduction leaves only `G=PSL(2,7)`, H=S4, for the
two subgroup conjugacy classes. The following completes the old bounded
argument by showing that these are now the *only* presentations that
need to be considered.

Restriction `H^3(G,C^*) -> H^3(H,C^*)` is injective. Its kernel is killed
by index seven. But G has no seven-primary H^4: restriction to its Sylow
C7 is injective on the seven-primary part, and the normalizer C7:C3
acts on H^4(C7,Z)=C7 by multiplication by 2 and 4, with zero fixed part.
Thus any admissible omega is globally trivializable.

After trivializing omega, `H^2(S4,C^*)=C2`, and both classes extend
from `H^2(PSL(2,7),C^*)=C2`. Nontriviality of restriction is witnessed
by a commuting pair in S4 whose lifts to the Schur double cover fail
to commute. The prior exact checker tests this for both subgroup classes:
`phase3/group_models/psl168_relative_bound.g` and its saved log.
Therefore psi can also be removed by a global two-cocycle autoequivalence.
Both presentations reduce to the untwisted category, whose full tensor
is R9_2_1557, not R9_2_1965. The based nonisomorphism is checked again.

## R9_2_941 and the precise remaining boundary

For the simple exotic dimension-504 ring R9_2_941, ENO Proposition 9.11
excludes the larger class of weakly group-theoretical categorifications;
see `BRAIDED_SCOPE_THEOREMS.md`.

None of these arguments supplies a general exclusion of any of the four
integral residual rings. A non-group-theoretical integral category could
still realize R9_2_12, R9_2_959 or R9_2_1965. A realization of R9_2_941
would additionally be non-weakly-group-theoretical. Models outside the
excluded classes and general categorical obstructions remain open.

## Replay and sources

* `all_twist_skeleton.g`, `.jsonl`, `.json`, `.log`:
  all finite groups/subgroups and all local projective degree profiles.
* `s5_transfer_search.py` (run once normally and once with `--a5c2`):
  exact normalized cohomology, transfer, relative primitives and tensors.
* `a5c2_data.g` and `.json`: explicit A5xC2 group and subgroup data.
* `s5_transfer_search.json` and `a5c2_transfer_search.json`: complete
  finite result records and explicit cocycle/relative-cochain inputs.
  Each model's `psi_exponents_mod8` is its own relative cochain.
  `base_psi_exponents_mod8` is the twist-zero cochain for the top-level
  tensor. The legacy top-level `psi_exponents_mod8` records the final
  subgroup twist, explicitly identified by `psi_record_subgroup_Schur_twist`
  (one for A5xC2, zero for S5); it is preserved for provenance.
* EGNO, *Tensor Categories*, Section 9.7, and ENO,
  <https://arxiv.org/pdf/0809.3031>, Section 2.5: group-theoretical
  presentations and projective double-coset dimensions.
* Kenneth S. Brown, *Cohomology of Groups*, Chapter III: normalized bar
  complex, restriction/corestriction and conjugation invariance. See also
  primary lecture notes on transfer:
  <https://courses.washington.edu/mnotes/groupcoho/notes.pdf>.
* Phase-three `S5_RELATIVE_TWIST.md` and independent model audit:
  exact twisted bimodule character formula, subgroup Schur extension.
* `phase4/audit_integral_gt/AUDIT.md`, `audit_verdict.json`, and independent
  replay certificates: all-group enumeration, all 32 relative classes,
  primitive completeness, stabilizer cocycles, projective characters,
  tensor identifications and categorical scope independently passed.

The new work does not infer nonexistence from an untwisted search failure.
The cohomological reductions above are the reason the tested finite
families cover all relative cocycles for these remaining presentations.



# Braided restrictions for the quadratic cases


**Result.** None of `R9_2_137`, `R9_2_1607`, `R9_2_1976` is the Grothendieck ring of a braided complex fusion category. This does **not** decide ordinary, spherical, pseudo-unitary, or unitary categorifiability. No pivotality or unitarity hypothesis is used in the proof.

## A general criterion

Let R be a fusion ring with trivial universal grading group. Suppose it has a basis element g of order two and a simple basis element X satisfying gX=X, such that FPdim(X)/2 is not an algebraic integer. Then R has no braided categorification.

**Proof.** Suppose C were a braided categorification. Monodromy with an invertible object gives a tensor automorphism of the identity functor (DGNO, Lemma 3.31(i)). Since the universal grading is trivial, every such tensor automorphism is the identity (DGNO, Proposition 2.3(iii)). Hence g belongs to the symmetric center C'. The symmetric rank-two subcategory generated by g is either Rep(C2) or sVec. The latter is impossible: a transparent fermion acts without fixed simple objects, by DGNO, Lemma 3.28, which is stated and proved without any pivotality hypothesis.

Thus <g> is Tannakian Rep(C2). De-equivariantization gives a fusion category E with a C2-action and an equivalence C=E^{C2}; see DGNO, Theorem 4.18 and Proposition 4.19. Under this equivalence g is the nontrivial character of C2.

For completeness, the relevant simple-object consequence can be seen directly. A simple equivariant object comes from a C2-orbit of simples in E and an irreducible projective representation of its stabilizer. If the orbit has size one, its stabilizer is C2 and its projective irreducible representations are one-dimensional (H^2(C2,C^*)=0). Tensoring by the nontrivial character exchanges its two equivariant structures, so it cannot fix the simple object. Therefore gX=X forces the underlying orbit to have size two, with trivial stabilizer. The underlying object of X is Y plus t(Y), with Y and t(Y) distinct simple objects of E of the same FP dimension. Tensor functors preserve FP dimensions, hence FPdim(X)=2 FPdim(Y). But FPdim(Y) is an algebraic integer, contrary to the hypothesis. QED.

## Exact witnesses

All three rings have FP dimensions

    1,1,1,1,2,d,d,d,d,   d=4+3 sqrt(2),

in the source-specific order recorded by `verify_braided_obstruction.py`.
The adjoint based subring equals the whole ring: starting with supports of all b_i b_i^*, its closure under multiplication contains all nine basis elements. This is a purely exact tensor check and is precisely the condition that the universal grading is trivial.

One can use the following source-basis witnesses (indices are zero-based):

| Ring | g | X |
|---|---:|---:|
| R9_2_137 | 7 | 3 |
| R9_2_1607 | 4 | 1 |
| R9_2_1976 | 6 | 1 |

Each satisfies g^2=1 and gX=X. The number d/2 has minimal polynomial

    x^2 - 4x - 1/2,

whose constant term is not integral. Equivalently, its field norm is -1/2. It is therefore not an algebraic integer, so the criterion applies.

## What this does and does not provide

This eliminates all braided constructions for the three rings at once. In particular, a future ordinary categorification, if one exists, must genuinely lack a braiding. It does not show that an invertible in an arbitrary nonbraided categorification has a half-braiding. Confusing centrality of a based-ring element with a central object would invalidate that stronger conclusion.

## Source

V. Drinfeld, S. Gelaki, D. Nikshych, V. Ostrik, *On braided fusion categories I*, arXiv:0906.0620v3: Proposition 2.3(iii), Lemmas 3.28 and 3.31(i), Theorem 4.18, Proposition 4.19 and Section 4.1. The cited categorical statements apply to arbitrary characteristic-zero fusion categories, without assuming a spherical structure.

https://arxiv.org/pdf/0906.0620



# Remaining noncommutative cases


## Status

Both **R9_2_1848 and R9_2_1975 remain unresolved as fusion rings**. Their
noncommutativity already excludes braided categorifications. No model,
associator, or general exclusion is claimed here. This continuation derives
new exact Morita reductions and checks additional necessary constraints.

The source tensors are taken, unchanged, from
`../../work/verification_corpus.json`. The existing general-to-pseudo-unitary
existence reductions are used only as existence reductions: no claim is made
that every original category is pseudo-unitary or unitary.

## R9_2_1848: a self-returning Morita reduction

Put `g=b1`, `h=b8=g^3`, and `X=b5`. The invertible group is **C6, not S3**:
`g,g^2,g^3,g^4,g^5 = b1,b4,b8,b3,b2`.
The noninvertibles form a single C6/C2 orbit, have dimension
`d=3+sqrt(11)`, and obey `d^2=2+6d`. The stabilizer is the central subgroup
`{1,h}`; the noncommutativity comes from the inversion action on C6/C2,
not from the group of invertibles. Thus the normal-stabilizer condition for
two-orbit fusion rings is satisfied.

Since `hX=X`, the pointed associator on `<h>` is trivializable: the action
on the simple object X gives a rank-one module category over that pointed
subcategory. Hence A=`1+h` is a connected separable algebra in every
hypothetical categorification. The split-module action has one exact branch,
with nine module simples. The full Morita Gram identity has exactly nine
admissible right-action matrices, with all multiplicities forced to one.
They are linearly independent. Their products therefore determine the
entire Grothendieck ring of the Morita dual.

All 729 coefficients identify that forced dual ring with R9_2_1848 again.
The map from the candidate-matrix order to the original tensor basis is
`[5,6,7,3,1,2,4,8,0]`. Therefore this algebra does not provide a reduction
to a smaller-rank category or a previously excluded ring.

Files: `R9_2_1848_morita_candidates.json`, `1848_dual_raw.json`,
`1848_morita_transport.json`; replay `morita_probe.py` and `verify.py`.
The exhaustive candidate-domain derivation is the existing full Morita Gram
argument in `../../phase3/noncomm_morita.md` and
`../../sources/full_morita_gram.py`, with reversed row-action multiplication
retained throughout.

A second possible direction is equivariantization by the inner order-three
symmetry cycling the noninvertibles, which would give near-group parameters
`(|G|,m)=(18,18)` if the coherent action is supplied. No classification of
all such near-group categories, and no contradiction from those parameters,
is established here. In particular, an odd central Tannakian subgroup is
not generally forbidden in near-group categories.

## R9_2_1975: a finite rank-twelve Morita reduction

Let `h=b5`. It is central as a based-ring element and fixes `b8`, of
dimension two. The same rank-one pointed-module argument provides A=`1+h`.
The exact split-module calculation has one branch and six module simples.
The full Morita Gram system has ten candidate action matrices. Their
multiplicities are uniquely

`[1,1,1,1,1,1,2,2,1,1]`.

Thus the dual has twelve simple objects. Eight have distinct permutation
actions and dimension one. Their multiplication is the dihedral group D8
of order eight: element orders `1,2,2,2,2,2,4,4`. The four remaining simples
have dimension `d=4+3sqrt(2)` and two repeated action matrices. Repeated
matrices must not be merged into two simple objects.

Here is a finite necessary completion of these repeated matrices. Let
`G=D8`, `H=Z(G)=C2`, and `Q=G/H=V4`. Because d is irrational and there are
only two FP dimensions in the dual, the invertible action is transitive on
the four noninvertibles (Schopieray, Lemma 2.6). Their stabilizer is a normal
subgroup of order two, necessarily H. Write them `X_q`, q in Q.

The two distinct module actions define a nonzero homomorphism
`pi:Q -> C2`. Left and right actions have the same pi. If `X=X_0`, its
square has invertible part the coset `alpha H`, where `pi(alpha)=1`.
The standard two-orbit automorphism `theta` of Q preserves pi, has order
at most two, and fixes alpha. An automorphism of V4 preserving pi is either
the identity or exchanges the two elements with pi=1. Hence theta is the
identity. Consequently G commutes with each X_q at the level of classes.

The duality is `X_q^*=X_(q alpha)`. Write

`X^2 = sum_(g in alpha H) g + sum_(q in Q) m_q X_q`.

Duality forces `m_q=m_(q alpha)`. Comparing the two repeated module actions
forces the sum of m_q in each pi-fiber to be four. Therefore, for some
integer a with `0<=a<=4`,

- `m_q=a` on `{0,alpha}`;
- `m_q=4-a` on the other two elements of Q.

There are two possible alpha cosets in the recorded labeling, and five
values of a, hence ten candidate based rings. Relabeling X exchanges a and
4-a, leaving six obvious isomorphism types before applying restrictions.
`build_d8_duals.py` constructs all ten and verifies associativity,
Frobenius reciprocity, and every product of their recorded module actions.
These are necessary alternatives, **not constructed fusion categories**.

### Eliminating four candidates by the FP field

For a=1 or 3, the degree-one characters have formal codegrees
`48+16sqrt(6)` and `48-16sqrt(6)`. Neither belongs to `Q(sqrt(2))`.
In any pseudo-unitary categorification, every formal codegree f satisfies
`dim(A_E)=FPdim(C)/f` for a distinguished central simple A_E. Since its
restriction is an integral combination of simples, this dimension belongs
to the FP-dimension field `Q(sqrt(2))`. Hence f belongs to that field too,
a contradiction. This excludes the four candidate dual rings with a=1,3.
The polynomial `t^2-96t+768` is checked as a factor of the regular Casimir
polynomial; it is from scalar blocks, so there is no missing degree factor.

### Extreme branches and the existing rank-six frontier

For a=0 or 4, the adjoint subring has rank six and multiplicity four.
Exact 216-coefficient transports give:

| alpha label | a | rank-six subring | Existing status |
|---|---:|---|---|
| 2 | 0,4 | R6_4_155 | unresolved |
| 3 | 0,4 | R6_4_1 | excluded |

The second row is ruled out by the project's existing general-complex
exclusion for R6_4_1. That entire lower-rank indicator proof is a dependency;
this continuation checks its tensor binding but does not claim a fresh full
replay of the lower-rank proof. The first row cannot be ruled out: R6_4_155
is one of the current open cases.

The two required lower-rank tensors and their source decision records are
bundled in `lower_tensors.json`, so both `verify.py` and `dual_subrings.py`
replay without a sibling GitHub checkout. Their source is classification
commit `111137a3e3ddf93be340b39c8a7c7b6ea94b844c`. The restored census has
SHA256 `9bb71564082688f1c130050bfe42034431c90dd4f48e0e2d31be8e3a224552ff`;
the decision ledger has SHA256
`abb36cb0e7f9196e0a231cb85a601c82a1c8fd398996f77a8961487a7ca692e5`.
Both hashes were checked against the
[commit-pinned payload manifest](https://github.com/sebastienpalcoux/grothendieck-ring-classification/blob/111137a3e3ddf93be340b39c8a7c7b6ea94b844c/data/large_files_manifest.json).
The local provenance file gives every immutable payload URL and its hash.
The dependent R6_4_1 categorical proof uses the two-FP-values Galois gate and
finite indicator traces; see the
[commit-pinned rank-six replay instructions](https://github.com/sebastienpalcoux/grothendieck-ring-classification/blob/111137a3e3ddf93be340b39c8a7c7b6ea94b844c/supplements/rank 6/README.md).
The copied decision includes its complete stored scalar certificate, but
this continuation does not re-establish its categorical premises.

Thus, up to the stated relabeling, three alternatives survive: the branch
containing R6_4_155, and the two uniform a=2 D8 quadratic rings. Establishing
or excluding coherent associators for these survivors remains necessary.
This is a useful finite structural reduction, not a resolution of 1975.

## Additional center test

The prior labelled-S, weighted-codegree, Galois-dimension and rotation
system for 1975 has 253 equations and 1291 variables. This continuation
required its variables to be nonnegative **integers**, rather than merely
nonnegative reals. Z3 returned `unknown` after 120 seconds. No feasible
integer witness and no unsatisfiability certificate was obtained. File
`1975_integer_center.json` records the exact system hash, time, and outcome;
`integer_center.py` reproduces the test. A timeout has no classification
consequence.

## Primary references checked

- Andrew Schopieray, *Categorification of integral group rings extended by
  one dimension*, JLMS 108 (2023), 1617–1641,
  <https://doi.org/10.1112/jlms.12789>. Lemma 2.6 and the two-orbit
  normal-stabilizer and quotient-automorphism results; the induction/formal
  codegree relation recalled in Section 3. This is not a classification of
  the candidate D8 categories.
- Jingcheng Dong and Hua Sun, *Structure, examples and classification for
  generalized near-group fusion categories*,
  <https://arxiv.org/abs/2004.08735>. The general structural statements apply;
  the classification conclusions requiring braidings do not exclude the
  present nonbraided cases.
- Pinhas Grossman and Masaki Izumi, *Infinite families of potential modular
  data related to quadratic categories*,
  <https://arxiv.org/abs/1906.07397>. Its potential modular data are not
  categorical existence or completeness theorems for these rings.

`verification.json` records the exact replay. No existing ledger or online
repository has been edited by this continuation.



# Remaining commutative quadratic cases


The ordinary complex categorifiability of `R9_2_137`, `R9_2_1607`, and `R9_2_1976` remains unresolved. This continuation proves a **new braided-only exclusion for all three** and strengthens the exact necessary-condition analysis of their centers. It produces no new ordinary categorification or general-complex exclusion.

## Accepted new scoped conclusion

`BRAIDED_OBSTRUCTION.md` proves a general criterion: a fusion ring with trivial universal grading, an involution g fixing a simple X, and nonintegral FPdim(X)/2 cannot have a braided categorification. It applies to all three rings with FPdim(X)=4+3√2. The proof works for arbitrary complex braided fusion categories, without pivotality, pseudo-unitarity, or unitarity assumptions. Its exact tensor witnesses and all 243 multiplicative dimension identities pass in `verify_braided_obstruction.py` and `braided_obstruction_certificate.json`.

| ID | General complex | Spherical | Pseudo-unitary | Unitary | Braided complex |
|---|---|---|---|---|---|
| R9_2_137 | unresolved | unresolved | unresolved | unresolved | excluded |
| R9_2_1607 | unresolved | unresolved | unresolved | unresolved | excluded |
| R9_2_1976 | unresolved | unresolved | unresolved | unresolved | excluded |

## Complete complex-character refinement

Earlier labelled S tests used only self-dual real characters in the quadratic FP field. The new `complex_low_frames.py` includes **all nine characters**, including the complex conjugate pairs of values in Q(√2,i) for 1607 and 1976. It checks every character multiplication identity exactly, and enumerates all possible restrictions of the nine distinct distinguished simples in I(1), subject to:

- the exhaustive previously audited restriction-column domain;
- exact formal-codegree dimensions;
- duality of character labels and restrictions;
- the previously proved Galois-unit restriction vector;
- every pairwise modular S-symmetry equation over Q(√2,i);
- entrywise induction-Gram bounds and the exact first Gram row.

The enumeration finishes, without a time limit being reached:

| Ring | Labelled frames | Distinct unlabelled frames |
|---|---:|---:|
| R9_2_137 | 172 | 43 |
| R9_2_1607 | 36 | 7 |
| R9_2_1976 | 108 | 19 |

A surviving frame is only a necessary-condition object. It is not a categorical model. The finite enumeration is a research refinement, not an exclusion certificate.

`frame_moment_test.py` then conditions the audited center moment system on individual low frames. For 1976 the first two frames admit exact integer separating rays, but frame 2 survives the numerical relaxation through height 6. Frame 0 of 137 and 1607 survives at height 3. In the latter statements “survives” means the numerical optimizer returned a feasible necessary-condition relaxation; no exact feasibility theorem or categorification follows. The records preserve the numerical equality residual and never promote this to classification authority.

## A tempting quantum-group model route ruled out theoretically

The common global dimension is D=144+96√2. This equals the global dimension of SU(3)_5: the usual Weyl-denominator formula gives

    3·8² / ((2 sin(π/8))⁴ (2 sin(2π/8))²)
    = 96 / (2-√2)² = 144+96√2.

This dimensional coincidence cannot give a model, even through a Morita equivalence. SU(3)_5 is modular and has the three distinct invertibles of highest weights (0,0),(5,0),(0,5). Its center is SU(3)_5 ⊠ SU(3)_5^rev and therefore has at least nine invertibles.

For any fusion category C, forgetting a central invertible gives a homomorphism Inv(Z(C))→Inv(C), whose kernel is the group of tensor automorphisms of id_C: a half-braiding on the unit is precisely such an automorphism. For these three rings U(C)=1, so this kernel is trivial. Thus Inv(Z(C)) injects into Inv(C)=V4 and cannot contain a subgroup of order nine. Morita equivalence preserves the braided center. Consequently none of the three rings is realized by a category Morita equivalent to SU(3)_5.

This is a rejection of a particular model family, not of categorifiability. It complements the braided obstruction: both the direct SU(3)_5 route and all its Morita variants fail for structural reasons.

## Limits and continuation targets

The three tensors share their dimension multiset and formal-codegree multiset but have different dualities. No based-ring isomorphism between them is asserted. Existing split-involution Morita computations lead back to each same ring on the forced branches; the other branch has repeated simple actions and does not determine a new dual ring.

A stronger argument would need, for example, a complete categorical construction with an exact tensor transport, an independently justified half-braiding/condensation theorem in the ordinary category, or an exhaustive obstruction to every surviving center branch. Based-ring commutativity, a feasible Gram frame, and a numerical relaxation do not supply those missing ingredients.

## Reproduction

Run from the research package root:

    python phase4/quadratic_comm/verify_braided_obstruction.py
    python phase4/quadratic_comm/complex_low_frames.py R9_2_137
    python phase4/quadratic_comm/complex_low_frames.py R9_2_1607
    python phase4/quadratic_comm/complex_low_frames.py R9_2_1976
    python phase4/quadratic_comm/frame_moment_test.py R9_2_137 3
    python phase4/quadratic_comm/frame_moment_test.py R9_2_1607 3
    python phase4/quadratic_comm/frame_moment_test.py R9_2_1976 6

Only new phase-four files were written. No previous evidence, ledger, manuscript, repository, or website was changed.

## Literature checked

- Drinfeld–Gelaki–Nikshych–Ostrik, *On braided fusion categories I*, arXiv:0906.0620v3. This supplies the arbitrary-category statements in the braided obstruction and the description of tensor automorphisms via universal grading. https://arxiv.org/pdf/0906.0620
- Gelaki–Nikshych, *Nilpotent fusion categories*, arXiv:math/0610726v2, Theorem 3.5, Corollary 3.7, Proposition 3.9. https://arxiv.org/pdf/math/0610726
- Coquereaux–Schieber, *Determination of quantum symmetries for higher ADE systems from the modular T matrix*, arXiv:hep-th/0203242. The SU(3) level-five exceptional quantum-symmetry route was examined; it does not overcome the center-invertible obstruction above. https://arxiv.org/pdf/hep-th/0203242
- Schopieray, *Categorification of integral group rings extended by one dimension*, arXiv:2208.07319. The two-dimension/near-group hypotheses do not apply directly: each of the present rings has three distinct FP dimensions 1,2,4+3√2. https://arxiv.org/abs/2208.07319

The former complex-exclusion count is unchanged by this branch. The only proposed ledger change is the braided scope of these three still-unresolved ordinary cases.



# An arbitrary-phase obstruction to a construction ansatz


The earlier phase3 tests ruled out16th- and32nd-root tensorators for the
mixed Moore–Read lift(p,r,v)=(2,15,1). That statement was intentionally
bounded. Here we remove the phase bound entirely, uniformly for
p=2,6,10,14 and r=7,15,v=1. This excludes these proposed tensor-functor
lifts preserving the given central condensation algebra; it does not
classify all actions on every generalized Moore–Read category and does
not by itself exclude R9_2_1254.

Use the notation of `phase2/weak_integral/mr_mixed_action.py`: objects of
the parity subcategory of Ising boxtimes Vec(C16,omega_p) are(i,a), with
i=0,1,2 for1,psi,sigma and charge a of the same parity as i==2.
The proposed functor is

    F(i,a)=(i+(a/2 mod 2) mod 2, r*a), if i<2;
    F(2,a)=(2,r*a).

The central boson is g=(psi,8), with right half-braiding phase
`zeta16^(j a + e_i)`, j=-p/2 modulo 8 and(e_0,e_1,e_2)=(0,8,12).
The tensorator J(a,b;c) is an arbitrary nonzero complex scalar on each
multiplicity-one channel a b ->c. It is not restricted to modulus one
or to roots of unity.

Define four ratios of tensorator scalars:

    x=J((psi,6),(sigma,3);(sigma,9)) /
      J((sigma,3),(psi,6);(sigma,9)),
    y=J((sigma,9),(psi,6);(sigma,15)) /
      J((psi,6),(sigma,9);(sigma,15)),
    z=J((sigma,15),(sigma,9);(psi,8)) /
      J((sigma,9),(sigma,15);(psi,8)),
    t=J((psi,8),(sigma,15);(sigma,7)) /
      J((sigma,15),(psi,8);(sigma,7)).

For p=2,r=15, four entries of the tensor-functor associator equation and
one central transport equation give, respectively,

    xy=zeta16^12,  x=zeta16^2,  yz=zeta16^6,
    zt=zeta16^2,   t=zeta16^14.

Multiplying the second, third and fifth and dividing by the first and
fourth gives1=zeta16^8=-1. This is a contradiction in C*.

The four associator channels(a,b,c;d;e,f) are listed verbatim in
`verify_mr_five_equations.py`. That independent verifier imports no
previous equation generator and computes their exponent ratios from the
standard Ising F-symbol signs and the explicit pointed3-cocycle. It checks
the same contradiction for all 8 choices of p,r. The exact5-equation
linear combination has coefficient vector(-1,1,1,-1,1); its variable
coefficients vanish over the integers, not merely modulo 16.

For reproducibility, `mr_exact_relation.py` discovers the relation from
all 19169 equations by integer sparse elimination. The discovered source
row indices and integer coefficients are in `mr_exact_relation.json`.
The small independent direct verification is authoritative for replay;
no solver or large matrix normal form is required.

A full-Hermite-normal-form exploratory run was not completed and is not
used in this proof. The short identity replaces it completely.

