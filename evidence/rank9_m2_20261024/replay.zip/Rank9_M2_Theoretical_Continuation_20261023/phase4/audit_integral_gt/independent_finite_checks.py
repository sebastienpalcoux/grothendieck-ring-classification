"""Independent high-pivot GF(2) audit of transfer and relative primitives.

Imports the search's deterministic basis generator only to reproduce its exact
class labels. All dimensions, independence, cocycle and primitive decisions
are checked with a distinct high-pivot elimination, and failed C* primitives
are decided directly modulo four (not the original modulo-eight solver).
"""
from pathlib import Path
import sys,itertools,json,functools
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'phase4/integral'))
import s5_transfer_search as search


def independent_basis(rows):
    B={}
    for original in rows:
        row=int(original)
        while row:
            p=row.bit_length()-1
            if p in B:row^=B[p]
            else:B[p]=row;break
    return B


def independent_solver(rows,n):
    B={};relations=[]
    for j,original in enumerate(rows):
        row=int(original);ops=1<<j
        while row:
            p=row.bit_length()-1
            if p in B:row^=B[p][0];ops^=B[p][1]
            else:B[p]=(row,ops);break
        if not row:relations.append(ops)
    def solve(rhs):
        rb=sum((int(v)&1)<<j for j,v in enumerate(rhs))
        if any((rb&r).bit_count()%2 for r in relations):return None
        v=0
        for p,(row,ops) in sorted(B.items()):
            if ((ops&rb).bit_count()+(row&v).bit_count())%2:v^=1<<p
        assert all((row&v).bit_count()%2==((rb>>j)&1) for j,row in enumerate(rows))
        return v
    return solve,len(B)


def complex_data(T):
    n=len(T);tri=list(itertools.product(range(1,n),repeat=3));ti={v:i for i,v in enumerate(tri)}
    delta3=[]
    for a,b,c,d in itertools.product(range(1,n),repeat=4):
        row=0
        for t in [(b,c,d),(T[a][b],c,d),(a,T[b][c],d),(a,b,T[c][d]),(a,b,c)]:
            if 0 not in t:row^=1<<ti[t]
        delta3.append(row)
    boundaries=[]
    for pair in itertools.product(range(1,n),repeat=2):
        row=0
        for j,(a,b,c) in enumerate(tri):
            if sum(t==pair for t in [(b,c),(T[a][b],c),(a,T[b][c]),(a,b)])%2:row^=1<<j
        boundaries.append(row)
    return tri,delta3,boundaries


def audit(mode):
    saved=json.load(open(R/f'phase4/integral/{mode}_transfer_search.json'))
    if mode=='s5':D,M,inv,H,hs,eps,x,y,alpha,oldw,oldpsi,ps=search.old.build_data()
    else:
        D=json.load(open(R/'phase4/integral/a5c2_data.json'));M=D['table'];H=D['H'];hs=set(H)
        inv=[row.index(0) for row in M];x=dict(zip(H,D['x']));y=dict(zip(H,D['y']))
    assert H[0]==0 and M[0]==list(range(120))
    sylow=saved['sylow'];ix={v:i for i,v in enumerate(sylow)}
    T=[[ix[M[a][b]] for b in sylow] for a in sylow]
    tri,d3,bd=complex_data(T)
    Zdim=len(tri)-len(independent_basis(d3));Bdim=len(independent_basis(bd))
    assert all((r&b).bit_count()%2==0 for r in d3 for b in bd)
    tri0,h3,meta=search.cohom3(T)
    assert tri==tri0 and Zdim==meta['cocycle_dimension'] and Bdim==meta['boundary_dimension']
    assert all((r&b).bit_count()%2==0 for r in d3 for b in h3)
    assert len(independent_basis(bd+h3))==Zdim
    seed_count_original=1<<len(h3)
    if mode=='a5c2':
        n=D['normalizer3'];aut=[ix[M[M[inv[n]][a]][n]] for a in sylow];tii={v:i for i,v in enumerate(tri)}
        assert all(T[aut[a]][aut[b]]==aut[T[a][b]] for a,b in itertools.product(range(8),repeat=2))
        assert all(aut[aut[aut[a]]]==a for a in range(8)) and aut!=list(range(8))
        norms=[]
        for seed in h3:
            z=0
            for j,t in enumerate(tri):
                u=tuple(aut[a] for a in t);v=tuple(aut[a] for a in u)
                if sum((seed>>tii[s])&1 for s in [t,u,v])%2:z^=1<<j
            norms.append(z)
        norm_rank=len(independent_basis(bd+norms))-Bdim
        assert norm_rank==4
        # Recover precisely the representative basis used by the certificate.
        ob={}
        for b in bd:search.basis_add(ob,b)
        hh=[]
        for b in norms:
            z=search.basis_add(ob,b)
            if z:hh.append(z)
        h3=hh
    else:norm_rank=None
    assert len(h3)==4
    reps=[];decomp={}
    for t in range(120):
        if t in decomp:continue
        i=len(reps);reps.append(t)
        for h in sylow:decomp[M[h][t]]=(ix[h],i)
    assert reps==saved['right_coset_representatives'] and len(reps)==15 and len(decomp)==120
    steps=[[(decomp[M[t][g]]) for g in range(120)] for t in reps]
    # Exact Schreier identity certifies the transfer cochain map construction.
    for i,g,h in itertools.product(range(15),range(120),range(120)):
        a,j=steps[i][g];b,k=steps[j][h];c,l=steps[i][M[g][h]]
        assert k==l and T[a][b]==c
    pairs=list(itertools.product(H[1:],repeat=2));pi={p:i for i,p in enumerate(pairs)}
    ht=list(itertools.product(H[1:],repeat=3));A=[]
    for a,b,c in ht:
        row={}
        for p,sg in [((b,c),1),((M[a][b],c),-1),((a,M[b][c]),1),((a,b),-1)]:
            if p in pi:row[pi[p]]=row.get(pi[p],0)+sg
        A.append(row)
    A2=[sum((coef&1)<<i for i,coef in row.items()) for row in A]
    solve,delta2rank=independent_solver(A2,len(pairs))
    shifts=[[((m&1)*x[a]*x[b]+((m>>1)&1)*x[a]*y[b]+((m>>2)&1)*y[a]*y[b])%2 for a,b in pairs] for m in range(8)]
    shifts_bits=[sum(v<<i for i,v in enumerate(q)) for q in shifts]
    boundaries2=[]
    for c in H[1:]:
        b=0
        for j,(a,z) in enumerate(pairs):
            if (int(z==c)-int(M[a][z]==c)+int(a==c))%2:b^=1<<j
        boundaries2.append(b)
    z2dim=len(pairs)-delta2rank;b2dim=len(independent_basis(boundaries2))
    assert z2dim==12 and b2dim==9
    assert all((r&q).bit_count()%2==0 for r in A2 for q in shifts_bits)
    assert len(independent_basis(boundaries2+shifts_bits))==z2dim
    def apply(q):return [sum(coef*q[i] for i,coef in row.items()) for row in A]
    decisions=[]
    for mask,row in enumerate(saved['results']):
        assert row['mask']==mask
        seed=0
        for j,b in enumerate(h3):
            if mask>>j&1:seed^=b
        values={t:(seed>>j)&1 for j,t in enumerate(tri)}
        @functools.lru_cache(None)
        def w(g,h,k):
            z=0
            if not g or not h or not k:return 0
            for ti in range(15):
                a,tj=steps[ti][g];b,tk=steps[tj][h];c,tl=steps[tk][k]
                z^=values.get((a,b,c),0)
            return z
        rhs=[2*w(a,b,c) for a,b,c in ht]
        primitive4=None
        for q0 in shifts:
            rr=[b-a for b,a in zip(rhs,apply(q0))]
            assert all(v%2==0 for v in rr)
            q1=solve([v//2 for v in rr])
            if q1 is not None:
                primitive4=[(a+2*((q1>>i)&1))%4 for i,a in enumerate(q0)]
                assert all((a-b)%4==0 for a,b in zip(apply(primitive4),rhs))
                break
        assert (primitive4 is not None)==row['relative_trivialization_found']
        decision={'mask':mask,'Cstar_primitive_exists':primitive4 is not None}
        if primitive4 is None:decisions.append(decision);continue
        assert row['seed_F2_values']==[values[t] for t in tri]
        recordpsi={(a,b):v for a,b,v in row['psi_exponents_mod8']}
        # A5 record stores the last (twist=1) cochain, whereas top-level tensor is twist=0.
        basepsi={(a,b):(v-(4*x[a]*y[b] if mode=='a5c2' else 0))%8 for (a,b),v in recordpsi.items()}
        for a,b,c in itertools.product(H,repeat=3):
            assert (basepsi[b,c]-basepsi[M[a][b],c]+basepsi[a,M[b][c]]-basepsi[a,b]-4*w(a,b,c))%8==0
        profiles=[]
        for twist in (range(2) if mode=='a5c2' else range(1)):
            def psi(a,b):return (basepsi[a,b]+4*twist*x[a]*y[b])%8
            def prod(*args):
                z=0
                for a in args:z=M[z][a]
                return z
            seen=set();packets=[]
            for t in range(120):
                if t in seen:continue
                supp={prod(h,t,k) for h in H for k in H};seen|=supp
                K=[h for h in H if prod(inv[t],h,t) in hs]
                def alph(s,z):
                    b=prod(inv[t],s,t);c=prod(inv[t],z,t)
                    return (psi(s,z)+4*w(s,t,c)-4*w(s,z,t)-4*w(t,b,c)-psi(b,c))%8
                al={(s,z):alph(s,z) for s,z in itertools.product(K,repeat=2)}
                assert all((al[b,c]-al[M[a][b],c]+al[a,M[b][c]]-al[a,b])%8==0 for a,b,c in itertools.product(K,repeat=3))
                if t==0:
                    assert len(K)==12 and all(v==0 for v in al.values());degrees=[1]*4+[2]*2
                elif len(K)==2:
                    s=next(k for k in K if k);assert al[s,s]%2==0;degrees=[1,1]
                else:
                    assert len(K)==4 and all(M[s][s]==0 for s in K)
                    radical=[s for s in K if all(al[s,z]==al[z,s] for z in K)]
                    if len(radical)==1:degrees=[2]
                    else:
                        assert len(radical)==4;u,v=K[1:3];uv=M[u][v]
                        assert al[u,u]%2==al[v,v]%2==0
                        for j,k in itertools.product(range(2),repeat=2):
                            eu=al[u,u]//2+4*j;ev=al[v,v]//2+4*k
                            chi={0:0,u:eu,v:ev,uv:eu+ev-al[u,v]}
                            assert all((chi[s]+chi[z]-chi[M[s][z]]-al[s,z])%8==0 for s,z in itertools.product(K,repeat=2))
                        degrees=[1]*4
                packets.append({'intersection_order':len(K),'projective_degrees':degrees})
            rank=sum(len(p['projective_degrees']) for p in packets)
            assert rank==row['all_subgroup_twists'][twist]['rank']
            profiles.append({'subgroup_Schur_twist':twist,'rank':rank,'packets':packets})
        decision['profile_checks']=profiles;decisions.append(decision)
    return {'mode':mode,'status':'PASS','H3_cocycle_dimension':Zdim,'H3_boundary_dimension':Bdim,'H3_dimension':Zdim-Bdim,'original_seed_count':seed_count_original,'normalizer_norm_image_dimension':norm_rank,'H2_H_F2_dimension':z2dim-b2dim,'Schreier_identity_checks':15*120*120,'decisions':decisions}

if __name__=='__main__':
    result={'status':'PASS','audits':[audit('s5'),audit('a5c2')]}
    (P/'independent_finite_checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({a['mode']:{'status':a['status'],'H3_dimension':a['H3_dimension'],'admissible':sum(d['Cstar_primitive_exists'] for d in a['decisions'])} for a in result['audits']}))
