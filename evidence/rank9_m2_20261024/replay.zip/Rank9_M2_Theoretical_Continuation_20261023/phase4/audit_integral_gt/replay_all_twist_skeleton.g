# Necessary projective-character profiles for EVERY 3-cocycle and subgroup
# cochain, over all groups of orders 120 and 168. Local multipliers are
# deliberately chosen independently: survivors need not be coherent.
LoadPackage("smallgrp");;
SetInfoLevel(InfoWarning,0);;
OUT:="rank9_m2_research/phase4/audit_integral_gt/replayed_all_twist_skeleton.jsonl";;
PrintTo(OUT,"");;
cache:=[];;
Profiles:=function(K)
 local id,c,f,Z,l,p;
 id:=IdGroup(K);
 for c in cache do if c.id=id then return c.profiles;fi;od;
 if Size(K)=1 then p:=[[1]];
 else
  f:=EpimorphismSchurCover(K);Z:=Kernel(f);p:=[];
  for l in Irr(Z) do
   Add(p,SortedList(List(Filtered(Irr(Source(f)),c->RestrictedClassFunction(c,Z)=c[1]*l),c->c[1])));
  od;
  p:=Set(p);
 fi;
 Add(cache,rec(id:=id,profiles:=p));return p;
end;;
ContainedMultiset:=function(a,b)
 return ForAll(Set(a),x->Number(a,y->y=x)<=Number(b,y->y=x));
end;;
for D in [120,168] do
 if D=120 then target:=[1,1,1,1,2,2,6,6,6];else target:=[1,1,2,3,3,6,6,6,6];fi;
 subgroups:=0;candidates:=0;
 for gid in [1..NumberSmallGroups(D)] do
  G:=SmallGroup(D,gid);
  for hc in ConjugacyClassesSubgroups(G) do
   H:=Representative(hc);subgroups:=subgroups+1;
   ds:=SortedList(List(Irr(H),c->c[1]));
   if not ContainedMultiset(ds,target) then continue;fi;
   if Size(H)<6 then continue;fi;
   packets:=[];ints:=[];dcs:=DoubleCosets(G,H,H);
   for dc in dcs do
    g:=Representative(dc);K:=Intersection(H,H^g);Add(ints,IdGroup(K));
    if g in H then opts:=[ds];
    else opts:=List(Profiles(K),p->p*Index(H,K));
    fi;
    opts:=Filtered(opts,p->ContainedMultiset(p,target));Add(packets,opts);
   od;
   poss:=[[]];
   for opts in packets do
    nxt:=[];
    for acc in poss do for p in opts do
     pp:=SortedList(Concatenation(acc,p));
     if ContainedMultiset(pp,target) then Add(nxt,pp);fi;
    od;od;
    poss:=Set(nxt);
   od;
   if target in poss then
    candidates:=candidates+1;
    AppendTo(OUT,"{\"order\":",D,",\"group_id\":",gid,",\"group\":\"",StructureDescription(G),"\",\"subgroup_id\":",IdGroup(H),",\"subgroup\":\"",StructureDescription(H),"\",\"intersection_ids\":",ints,",\"packets\":",packets,"}\n");
   fi;
  od;
 od;
 AppendTo(OUT,"{\"order\":",D,",\"complete\":true,\"groups\":",NumberSmallGroups(D),",\"subgroup_classes\":",subgroups,",\"candidate_presentations\":",candidates,"}\n");
 Print("COMPLETE ",D," candidates ",candidates,"\n");
od;
AppendTo(OUT,"{\"projective_profile_cache\":",List(cache,c->[c.id,c.profiles]),"}\n");
QUIT;
