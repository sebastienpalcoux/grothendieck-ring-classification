"""Replay accepted phase-four finite evidence and check the complete ledger.
Run normally (not with -O: some exploratory verifiers use assertions).
Categorical proofs and their separate audits accompany these finite checks.
"""
from pathlib import Path
import json,subprocess,sys,itertools,hashlib,collections,os
P=Path(__file__).resolve().parent;B=P.parent

def req(c,m):
 if not c:raise ValueError(m)
def read(p):return json.loads((B/p).read_text())
def main():
 req(__debug__,'Run without -O; selected inherited verifiers use assertions.')
 scripts=['weak_b/verify_cyclic_obstruction.py','weak_b/verify_dimension120_obstruction.py','r8_scope/verify_equivariantization.py','audit_models/verify_cyclic_ty.py','audit_models/mr_order4_audit.py','audit_models/mr1254_tensor_audit.py','integral/verify_scope_refinements.py','integral/verify_GT_records.py','quadratic_comm/verify_braided_obstruction.py','weak_a/verify_mr_five_equations.py']
 reports=[]
 for rel in scripts:
  r=subprocess.run([sys.executable,str(P/rel)],capture_output=True,text=True,cwd=B,timeout=120)
  req(r.returncode==0,rel+' failed: '+r.stdout+r.stderr)
  reports.append({'script':rel,'status':'PASS','stdout':r.stdout.strip()})
 old=read('phase3/results/ledger.json');new=read('phase4/results/ledger.json');summary=read('phase4/results/summary.json')
 req(len(old)==len(new)==2083,'input count')
 req(hashlib.sha256((B/'phase3/results/ledger.json').read_bytes()).hexdigest()==summary['baseline_ledger_sha256'],'baseline hash')
 E={f'R9_2_{i}'for i in(585,1025,1303,1709,1759,1988)};M={'R9_2_746','R9_2_1209','R9_2_1254'}
 for a,b in zip(old,new):
  req(a['id']==b['id'] and a['tensor_sha256']==b['tensor_sha256'],'identity changed')
  if a['id']in E:req(a['status']=='unresolved'and b['status']=='excluded'and len(b['exclusion_certificates'])==1,'new exclusion')
  elif a['id']in M:req(a['status']=='unresolved'and b['status']=='unitarily_realized'and len(b['models'])==1,'new model')
  else:req(a['status']==b['status']and a['exclusion_certificates']==b['exclusion_certificates']and a['models']==b['models'],'old decision changed')
 counts=collections.Counter(r['status']for r in new);req(counts=={'excluded':2039,'unitarily_realized':35,'unresolved':9},'partition')
 corpus=read('work/verification_corpus.json')['tensors'];models=read('phase4/results/models.json')
 req(len(models)==35 and len({m['id']for m in models})==35,'unique models')
 for m in models:
  p=m['basis_map_source_to_model'];R=corpus[m['id']];T=m['tensor']
  req(sorted(p)==list(range(9))and p[0]==0,'basis permutation')
  req(all(R[i][j][k]==T[p[i]][p[j]][p[k]]for i,j,k in itertools.product(range(9),repeat=3)),'model tensor '+m['id'])
  if m['id']in M:
   for k in('record_file','proof','independent_audit'):req((B/m[k]).is_file(),'missing '+m[k])
 unresolved=read('phase4/results/unresolved.json')
 req({x['id']for x in unresolved}=={f'R9_2_{i}'for i in(12,137,941,959,1607,1848,1965,1975,1976)},'remaining set')
 req(sum(r['categorification_scopes']['braided']=='excluded'for r in unresolved)==9,'braided scopes')
 req({r['id']for r in unresolved if r['categorification_scopes'].get('group_theoretical')=='excluded'}=={'R9_2_12','R9_2_941','R9_2_959','R9_2_1965'},'integral GT scopes')
 for r in new:
  for c in r['exclusion_certificates']:
   if c['record_file'].startswith('phase4/'):
    for k in('record_file','proof','independent_audit'):req((B/c[k]).is_file(),'missing '+c[k])
 result={'status':'PASS','total_input_decisions':2083,'partition':dict(counts),'all_35_model_tensor_coefficients':35*729,'new_model_coefficients':2187,'new_general_exclusions':6,'new_models':3,'remaining':9,'braided_excluded_remaining':9,'R8_3_436_general_replacement':'accepted_after_independent_categorical_audit_and_exact_replay','replays':reports,'limitations':'Finite replays verify hypotheses and certificates; categorical proofs are reviewed in separate text audits, not formalized in a proof assistant.'}
 (P/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items()if k!='replays'},indent=2))
if __name__=='__main__':main()
