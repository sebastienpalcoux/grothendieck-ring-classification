# Rank-nine multiplicity two: fifth research continuation

Current research partition: **2043 excluded, 36 unitary models, 4 unresolved**,
out of 2083 exact-multiplicity-two rings.

Five of the preceding nine residuals are settled: general exclusions of
R9_2_12,941,959,1965 and a unitary model of R9_2_1848. The remaining cases
are R9_2_137,1607,1975,1976; all four have no braided categorification.

Read phase5/REPORT.md and the manuscript in phase5/manuscript/.
The current classification authority is phase5/results/ledger.json;
accepted changes are in phase5/accepted.json. Every changed classification
has a separate categorical audit and exact arithmetic replay.

Install requirements.txt and run python3 verify.py. This checks packaged
hashes, all phase-five accepted finite evidence, every ledger identity,
and all 26244 coefficients of the 36 model transports. The proofs are
reviewed mathematical arguments, not proof-assistant formalizations.
Use python3 verify.py --baseline to additionally replay phase four.
Use python3 verify.py --frontier to also replay the auxiliary Morita and
orbifold evidence; it makes no further rank-nine classification changes.

All previous research evidence is preserved. Earlier ledgers are historical
snapshots, not current status. The phase-three correction of invalid early
half-E6 claims and phase-four independent R8_3_436 repair remain in force.
No universal unitary-table parameterization premise is reinstated.

Downloaded primary papers and their extracted text are not redistributed;
their source URLs and recorded hashes are retained. Local-cache paths in
research reports refer to the original research workspace. Exact arithmetic
replays do not require those downloaded papers or network access.

The four residuals have further necessary Morita-ring reductions and model
construction investigations. Necessary rings and failed ansatzes are not
categorical classifications. Read their reports for exact scope.

No GitHub repository or website was modified. Another agent is performing
an online audit/revision; before future publication reconcile these exact
tensor-bound changes with that agent's current decisions and heads.
The ordered/clean publication handoff is HANDOFF.md. The old private Atlas
is out of scope. The 142 prior multiplicity-one records are unchanged.
