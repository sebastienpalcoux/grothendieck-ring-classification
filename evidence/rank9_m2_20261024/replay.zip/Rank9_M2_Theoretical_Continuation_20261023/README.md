# Rank-nine multiplicity-two: corrected audit and continued research

Current verified partition: **2,033 excluded, 32 unitary models, 18 unresolved**, out of 2,083 exact-M2 rings.

Read **[the corrected audit report](phase3/REPORT.md)** first. The current
classification is **`phase3/results/ledger.json`**, with exact residual
profiles in `phase3/results/unresolved.json`.

The earlier `results/` and `phase2/results/` ledgers are historical snapshots.
Their half-E6 subring exclusions are superseded: seven formerly excluded
rings now have unitary models; three others have valid replacement proofs.
All 26 invalid structural claims have been removed from the current ledger.

Install `requirements.txt` and provide `g++` for finite certificate replay.
Run `python3 phase3/verify_audit.py` for current partition, model maps and
explicit negative-subring checks. Add `--fresh` to rebuild the corrected
subring pass and restored model constructors, and independently replay
the new relative-cocycle models, Hopf construction, and center exclusions.
The earlier exclusion replays are available through
`python3 phase2/verify_continuation.py --fresh` and the original `verify.py`;
their printed historical totals are not the corrected classification.
Fresh original replays and independent categorical audits are documented
under `phase3/`. Candidate files are not accepted results; `phase3/accepted.json`
controls additions.

The original 142 multiplicity-one IDs and their explicit basis transports
are preserved. Research continues on the residual cases. No GitHub repository
or website has been changed. Publication remains deferred.
