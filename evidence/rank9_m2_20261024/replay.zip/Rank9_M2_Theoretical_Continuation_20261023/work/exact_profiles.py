from common import *
from scalar_characters import chars
from exact import pc,ec
import collections,time
def main():
 raw={r['id']:r for r in read()};out=[];start=time.time()
 for m in load('remaining_profiles.json'):
  a=chars(raw[m['id']]['tensor']);f,K,ds,D,pD,e=a.fp()
  out.append({'id':m['id'],'tensor_sha256':raw[m['id']]['tensor_sha256'],'defining_polynomial':pc(f),'positive_root_interval':[str(e.lo),str(e.hi)],'dimension_coefficients':[ec(d)for d in ds],'global_dimension_coefficients':ec(D),'global_dimension_minimal_polynomial':pc(pD),'formal_codegree_factors':[{'polynomial':pc(p),'multiplicity':int(k)}for p,k in a.cf],'dimension_field_degree':f.degree(),'scalar_character_rank':getattr(a,'scalar_rank',9),'general_to_PU_gate':'weak_integrality'if pD.degree()==1 else 'two_FP_values'if len(set(ds))==2 else None,'invertibles':m['invertibles'],'dual':m['dual'],'proper_fusion_subrings':[J for J in m['subrings']if 1<len(J)<9]})
  save('exact_survivor_profiles.json',out)
  if len(out)%20==0:print(len(out),'exact profiles','seconds',round(time.time()-start,2),flush=True)
 print('FINAL',len(out),flush=True)
if __name__=='__main__':main()
