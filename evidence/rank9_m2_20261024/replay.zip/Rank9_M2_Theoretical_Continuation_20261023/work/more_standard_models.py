from common import *
from standard_model_scan import field,t,require
from cyclic_equivariant import cyclic_equivariant
from match_models import group
from group_theoretical import permutation_group,subgroup,fusion
from group_scan import rank_est
import group_theoretical as gt
import sympy as s,itertools,collections,time
def pgl27():
 q=7;c=24;K=field(s.Poly(s.cyclotomic_poly(c,t),t));z=K([1,0]);zero=K.zero
 split=list(range(1,(q-1)//2+1));non=list(range(1,(q+1)//2+1))
 sizes=[1,q*q-1]+[q*(q+1)//(2 if 2*k==q-1 else 1)for k in split]+[q*(q-1)//(2 if 2*k==q+1 else 1)for k in non];D=q*(q*q-1)
 eps=[K.one,K.one]+[K((-1)**k)for k in split]+[K((-1)**k)for k in non]
 st=[K(q),zero]+[K.one]*len(split)+[-K.one]*len(non)
 rows=[[K.one]*9,eps,st,[a*b for a,b in zip(eps,st)]]
 for a in range(1,(q-1)//2):rows.append([K(q+1),K.one]+[z**(int(c//(q-1))*a*b)+z**(-int(c//(q-1))*a*b)for b in split]+[zero]*len(non))
 for a in range(1,(q+1)//2):rows.append([K(q-1),-K.one]+[zero]*len(split)+[-z**(int(c//(q+1))*a*b)-z**(-int(c//(q+1))*a*b)for b in non])
 require(len(rows)==9 and sum(sizes)==D,'character/class inventory')
 for i,j in itertools.product(range(9),repeat=2):require(sum((K(w)*a*b for w,a,b in zip(sizes,rows[i],rows[j])),zero)==K(D*int(i==j)),'orthogonality')
 T=[[[0]*9 for _ in range(9)]for _ in range(9)]
 for i,j,k in itertools.product(range(9),repeat=3):
  v=sum((K(w)*a*b*d for w,a,b,d in zip(sizes,rows[i],rows[j],rows[k])),zero)/K(D);co=v.to_list();require(len(co)<=1 and(not co or co[0].denominator==1 and co[0]>=0),'character coefficient');T[i][j][k]=int(co[0])if co else 0
 return T
def gl3f2():
 els=[]
 for a in itertools.product(range(2),repeat=9):
  images=[sum((sum(a[3*i+j]*((x>>j)&1)for j in range(3))%2)<<i for i in range(3))for x in range(8)]
  if len(set(images))==8:els.append(a)
 ident=(1,0,0,0,1,0,0,0,1);els.remove(ident);els.insert(0,ident);ix={a:i for i,a in enumerate(els)}
 G=[[ix[tuple(sum(a[3*i+k]*b[3*k+j]for k in range(3))%2 for i in range(3)for j in range(3))]for b in els]for a in els]
 return els,G
oldchars=gt.real_characters
def chars24(G,H,K):
 if len(H)!=24:return oldchars(G,H,K)
 order={x:len(gt.powers(G,x))for x in H};cent={x:sum(G[x][a]==G[a][x]for a in H)for x in H};one=K.one
 assert collections.Counter((order[x],cent[x])for x in H)=={(1,24):1,(2,4):6,(2,8):3,(3,3):8,(4,4):6}
 vals={(1,24):(1,1,2,3,3),(2,4):(1,-1,0,1,-1),(2,8):(1,1,2,-1,-1),(3,3):(1,1,-1,0,0),(4,4):(1,-1,0,-1,1)}
 out=[{x:K(vals[order[x],cent[x]][j])for x in H}for j in range(5)]
 for i,a in enumerate(out):
  for j,b in enumerate(out):assert sum((a[x]*b[x]for x in H),K.zero)==K(24*int(i==j))
 return out
gt.real_characters=chars24
def models():
 yield 'Rep(PGL(2,7))',pgl27(),{'kind':'finite_group_representations','group':'PGL(2,7)'},'Standard torus character table of PGL(2,7), checked exactly'
 for N,m,u in [(19,3,7),(15,4,2)]:
  T,labs=cyclic_equivariant(group((N,)),[(u*a)%N for a in range(N)],m)
  yield f'Rep(C{N} semidirect C{m}, u={u})',T,{'kind':'pointed_cyclic_equivariantization','N':N,'order':m,'automorphism_multiplier':u,'labels':labs},'Strict cyclic automorphism action on Vec(C_N); ordinary semidirect-product representation category'
 # Existing subgroup-algebra construction for symmetric and linear groups.
 perms,G=permutation_group(5)
 cases=[('S3',[(1,0,2,3,4),(1,2,0,3,4)]),('S3diagonal',[(1,0,2,4,3),(1,2,0,3,4)])]
 for name,gens in cases:
  H=subgroup(G,[perms.index(a)for a in gens]);r=rank_est(G,H)
  if r==9:yield f'C(S5,1,{name},1)',fusion(G,H),{'kind':'untwisted_group_theoretical','group':'S5','permutation_degree':5,'generators':gens},'Standard subgroup-algebra bimodules in Vec(S5)'
  else:print('S5',name,'rank',r,flush=True)
 els,G=gl3f2();H=subgroup(G,[els.index((0,1,0,1,0,0,0,0,1)),els.index((0,1,0,0,0,1,1,0,0))]);r=rank_est(G,H)
 if r==9:yield 'C(GL(3,2),1,S3,1)',fusion(G,H),{'kind':'untwisted_group_theoretical','group':'GL(3,2)=PSL(2,7)','group_table':G,'subgroup':H},'Standard subgroup-algebra bimodules in Vec(PSL(2,7))'
 else:print('GL32','S3','rank',r,flush=True)
 # The stabilizer of a nonzero vector is S4 of order 24.
 H=[i for i,a in enumerate(els) if (a[0],a[3],a[6])==(1,0,0)];assert len(H)==24;r=rank_est(G,H)
 if r==9:yield 'C(GL(3,2),1,S4,1)',fusion(G,H),{'kind':'untwisted_group_theoretical','group':'GL(3,2)=PSL(2,7)','group_table':G,'subgroup':H},'Standard subgroup-algebra bimodules in Vec(PSL(2,7))'
 else:print('GL32','S4','rank',r,flush=True)
def main():
 by=collections.defaultdict(list)
 for r in read():
  if r['multiplicity']==2:by[coarse(r['tensor'])].append(r)
 matches=[];attempts=[];start=time.time()
 for name,T,params,ref in models():
  hits=[];n=len(T);mult=max(v for a in T for b in a for v in b)
  if n==9 and mult==2:
   for r in by[coarse(T)]:
    p=based_iso(r['tensor'],T)
    if p is not None:matches.append({'id':r['id'],'model':name,'tensor':T,'basis_map_source_to_model':p,'parameters':params,'reference':ref,'status':'unitarily_realized'});hits.append(r['id'])
  attempts.append({'name':name,'rank':n,'multiplicity':mult,'tensor':T,'matches':hits})
  print(name,'rank',n,'mult',mult,hits,'seconds',round(time.time()-start,2),flush=True);save('more_standard_models.json',matches);save('more_standard_model_attempts.json',attempts)
if __name__=='__main__':main()
