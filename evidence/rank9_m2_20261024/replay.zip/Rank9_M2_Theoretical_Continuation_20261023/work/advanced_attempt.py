from common import *
import argparse,time
def main():
 ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['morita','rotation','character','modular','integer_gram','spectral_module']);ap.add_argument('ring');a=ap.parse_args();R=next(r['tensor']for r in read()if r['id']==a.ring);start=time.time()
 if a.mode=='morita':
  import full_morita_gram as module
  c=module.certificate(R,node_limit=100000)
 elif a.mode=='rotation':
  import tensor_rotation as module
  c=module.certificate(R,height=6)
 elif a.mode=='character':
  import character_induction as module
  c=module.certificate(R,height=6)
 elif a.mode=='modular':
  import modular_character_induction as module
  c=module.certificate(R,height=6)
 elif a.mode=='spectral_module':
  import new_module_spectral as module
  c=module.certificate(R)
 else:
  import integer_gram as module
  c=module.certificate(R,height=6,seconds=3,limit_frames=1000)
 result={'id':a.ring,'mode':a.mode,'certificate':c,'outcome':'scoped_exclusion'if c else 'no_conclusion','seconds':time.time()-start}
 save(f'advanced_{a.mode}_{a.ring}.json',result);print(a.ring,a.mode,result['outcome'],round(result['seconds'],2),flush=True)
if __name__=='__main__':main()
