from common import *
import collections,csv,time
def build():
 raw={r['id']:r for r in read()};meta={r['id']:r for r in load('input_audit.json')};negative=collections.defaultdict(list);models=collections.defaultdict(list);attempts=collections.defaultdict(list)
 def neg(rid,path,c):negative[rid].append({'record_file':'work/'+path,'certificate_kind':c.get('kind','signed_sphericalization'),'scope':'general_complex_fusion_category'})
 for path in ['baseline.json','structural.json','zero_spectrum.json','one_spectrum.json','established_scan.json','remaining_arithmetic.json']:
  for r in load(path):
   cs=r.get('certificates',[r.get('certificate')]);cs=[c for c in cs if c]
   for c in cs:neg(r['id'],path,c)
 for path in ['signed_sieve.json','pb_scan.json']:
  if not(BASE/'work'/path).exists():continue
  for r in load(path):
   if r['report']['outcome']=='excluded':neg(r['id'],path,{'kind':'complete_oriented_sphericalization'})
   else:attempts[r['id']].append({'file':'work/'+path,'method':'oriented_sphericalization','outcome':'no_conclusion','reason':r['report'].get('reason')})
 for path in ['module_scan.json','induction_smt_scan.json','weighted_scan.json']:
  if not(BASE/'work'/path).exists():continue
  for r in load(path):
   outcome=r.get('outcome',r.get('report',{}).get('outcome'))
   if outcome=='excluded':neg(r['id'],path,{'kind':'involution_module_finite'if path=='module_scan.json'else 'weighted_low_induction'if path=='weighted_scan.json'else 'low_induction_gram_moments'})
   else:attempts[r['id']].append({'file':'work/'+path,'method':path.replace('.json',''),'outcome':outcome})
 for advanced_path in ['advanced_scan.json','advanced_native_retry.json']:
  if not(BASE/'work'/advanced_path).exists():continue
  for r in load(advanced_path):
   if r['outcome']=='scoped_exclusion':
    general=r['mode']in ['spectral_module','morita']
    if not general:
     from scalar_characters import chars
     a=chars(raw[r['id']]['tensor']);f,K,ds,D,pD,e=a.fp();general=pD.degree()==1 or len(set(ds))==2
    if general:neg(r['id'],advanced_path,r['certificate'])
   attempts[r['id']].append({'file':'work/'+advanced_path,'method':'advanced_criteria','outcome':r['outcome']})
 for path in ['final_arithmetic.json','advanced_retry.json']:
  if not(BASE/'work'/path).exists():continue
  for r in load(path):attempts[r['id']].append({'file':'work/'+path,'method':'field_automorphisms_and_final_arithmetic'if path=='final_arithmetic.json'else 'advanced_criteria_retry','outcome':r['report']['outcome']})
 for path in ['known_models.json','standard_models.json','more_standard_models.json','group_models.json','near_group_models.json','permutation_models.json','group48_models.json']:
  if(BASE/'work'/path).exists():
   for j,r in enumerate(load(path)):models[r['id']].append({'model':r['model'],'record_file':'work/'+path,'record_index':j,'reference':r['reference']})
 assert not set(negative)&set(models),sorted(set(negative)&set(models))
 out=[]
 for rid,r in raw.items():
  if r['multiplicity']!=2:continue
  m=meta[rid];status='excluded'if negative[rid]else 'unitarily_realized'if models[rid]else 'unresolved'
  out.append({'id':rid,'physical_line':r['physical_line'],'tensor_sha256':r['tensor_sha256'],'rank':9,'exact_multiplicity':2,'commutative':m['commutative'],'status':status,'exclusion_certificates':negative[rid],'models':models[rid],'attempts':attempts[rid]})
 counts=dict(collections.Counter(r['status']for r in out));assert sum(counts.values())==2083
 save('ledger.json',out);save('summary.json',{'rank':9,'exact_multiplicity':2,'total':2083,'excluded':counts.get('excluded',0),'modelled':counts.get('unitarily_realized',0),'unresolved':counts.get('unresolved',0),'input_records_including_previous_multiplicity_one':2225,'previous_multiplicity_one':142,'scope':'First established-criteria/models campaign. General-complex exclusions; all recorded models unitary. Search limits are no-conclusion outcomes.','online_changes':False})
 with open(BASE/'work/ledger.csv','w',newline='')as f:
  w=csv.writer(f);w.writerow(['id','physical_line','status','commutative','tensor_sha256','criterion_or_model'])
  for r in out:w.writerow([r['id'],r['physical_line'],r['status'],r['commutative'],r['tensor_sha256'],'; '.join([c['certificate_kind']for c in r['exclusion_certificates']]+[c['model']for c in r['models']])])
 print('COUNTS',counts,flush=True);return out
if __name__=='__main__':build()
