from common import *
from sphere import analyse,timed_out
from rings import Characters
import signal,time,collections
def main():
 raw={r['id']:r for r in read()};out=[];start=time.time();signal.signal(signal.SIGALRM,timed_out)
 for m in load('survivors_for_low.json'):
  R=raw[m['id']]['tensor']
  if not m['commutative']:
   out.append({'id':m['id'],'outcome':'not_applicable','reason':'commutative low-induction implementation'});continue
  signal.alarm(20)
  try:
   a=Characters(R);f,K,ds,D,pD,emb=a.fp();gate='weak_integrality' if pD.degree()==1 else 'two_FP_values' if len(set(ds))==2 else None
   report=analyse(R,low=True);rec={'id':m['id'],'general_gate':gate,'report':report,'outcome':'excluded' if gate and report.get('pseudo_obstruction') else 'spherical_excluded' if report['spherical_excluded'] else 'no_conclusion'}
  except TimeoutError:rec={'id':m['id'],'outcome':'no_conclusion','reason':'20 second discovery allowance'}
  finally:signal.alarm(0)
  out.append(rec);save('low_scan.json',out)
  print(m['id'],rec['outcome'],'TOTAL',len(out),dict(collections.Counter(x['outcome'] for x in out)),'seconds',round(time.time()-start,2),flush=True)
if __name__=='__main__':main()
