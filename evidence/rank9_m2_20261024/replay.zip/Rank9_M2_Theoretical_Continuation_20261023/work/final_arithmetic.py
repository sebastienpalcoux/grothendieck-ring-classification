from common import *
from exact import *
from arithmetic import casimir
from extra_arithmetic import automorphism_obstruction
import sympy as s,signal,time
def alarm(*_):raise TimeoutError('finite discovery allowance')
def main():
 signal.signal(signal.SIGALRM,alarm);raw={r['id']:r for r in read()};out=[]
 for row in load('ledger.json'):
  if row['status']!='unresolved':continue
  R=raw[row['id']]['tensor'];c=None;report={};signal.alarm(8)
  try:
   p=casimir(R).charpoly(t).as_poly();report['contains_2_3_7']=all(p.eval(x)==0 for x in [2,3,7])
   if row['commutative']:
    for i,A in enumerate(R):
     for f,m in s.Matrix(A).charpoly(t).as_poly().factor_list()[1]:
      q=automorphism_obstruction(tuple(pc(f)))
      if q:c=dict(q,object=i);break
     if c:break
   else:
    from scalar_characters import chars
    a=chars(R);f=a.fp()[0];q=automorphism_obstruction(tuple(pc(f)))
    if q:c=dict(q,scope='FP_dimension_field')
   report['outcome']='excluded'if c else 'no_conclusion'
  except TimeoutError:report['outcome']='no_conclusion';report['reason']='finite discovery allowance'
  finally:signal.alarm(0)
  out.append({'id':row['id'],'certificate':c,'report':report});save('final_arithmetic.json',out)
 print('FINAL',len(out),'exclusions',sum(bool(x['certificate'])for x in out),'237 instances',sum(x['report'].get('contains_2_3_7',False)for x in out),flush=True)
if __name__=='__main__':main()
