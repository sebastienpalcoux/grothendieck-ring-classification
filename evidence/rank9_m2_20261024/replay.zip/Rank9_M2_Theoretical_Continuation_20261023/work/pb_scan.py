from common import *
import subprocess,time
def main():
 targets=[r['id']for r in load('signed_sieve.json')if r['report']['outcome']!='excluded'];out=[]
 for rid in targets:
  path=BASE/'work'/f'pb_{rid}.json'
  if path.exists() and load(path.name).get('outcome')=='excluded':r=load(path.name)
  else:
   try:
    p=subprocess.run([sys.executable,str(BASE/'work/signed_pb.py'),'--ring',rid,'--seconds','60'],text=True,capture_output=True,timeout=75)
    if p.returncode:r={'outcome':'no_conclusion','reason':'implementation_error','stderr':p.stderr[-1500:]}
    else:r=load(path.name)
   except subprocess.TimeoutExpired:r={'outcome':'no_conclusion','reason':'75 second process allowance'}
  out.append({'id':rid,'report':r});save('pb_scan.json',out);print(rid,r['outcome'],len(r.get('branches',[])),flush=True)
if __name__=='__main__':main()
