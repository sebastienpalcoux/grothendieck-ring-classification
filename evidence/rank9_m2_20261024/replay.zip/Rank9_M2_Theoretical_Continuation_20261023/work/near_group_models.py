from common import *
from match_models import pointed_dihedral
from extra_models import dicyclic_table
import itertools
def extend(G):
 n=len(G);R=[[[0]*(n+1)for _ in range(n+1)]for _ in range(n+1)]
 for i,j in itertools.product(range(n),repeat=2):R[i][j][G[i][j]]=1
 for i in range(n):R[i][n][n]=R[n][i][n]=R[n][n][i]=1
 R[n][n][n]=2;return R
def main():
 rows=[r for r in read() if r['multiplicity']==2];out=[]
 for name,G in [('D8',[[row.index(1)for row in a]for a in pointed_dihedral(4)]),('Q8',dicyclic_table(2))]:
  R=extend(G);Z=[a for a in range(8) if all(G[a][b]==G[b][a]for b in range(8))];assert len(Z)==2
  assert all(G[G[a][b]][c]==G[a][G[b][c]]for a,b,c in itertools.product(range(8),repeat=3))
  for r in rows:
   p=based_iso(r['tensor'],R)
   if p is None:continue
   rec={'id':r['id'],'model':f'Izumi near-group ({name},2)','tensor':R,'basis_map_source_to_model':p,'parameters':{'kind':'extraspecial_near_group','group':name,'group_table':G,'multiplicity':2},'reference':'Izumi, A Cuntz algebra approach to the classification of near-group categories, Theorem 6.1, arXiv:1512.04288','status':'unitarily_realized'};out.append(rec);print(r['id'],rec['model'],flush=True)
 save('near_group_models.json',out)
if __name__=='__main__':main()
