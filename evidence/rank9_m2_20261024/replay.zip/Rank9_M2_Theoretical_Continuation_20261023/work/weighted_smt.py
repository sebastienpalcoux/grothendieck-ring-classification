"""Rank-nine adapter of existing multiplicity-weighted noncommutative induction."""
from common import *
from scalar_characters import chars
from induction_smt import interval
from exact import *
import z3,sympy as s,math,time,itertools,collections
def discover(R,timeout=10000):
 start=time.time();n=len(R);a=chars(R);f,K,ds,D,pD,emb=a.fp();assert getattr(a,'scalar_rank',9)in [1,5]
 spectral=[]
 roots=discover_roots(a.scalar_codegree_polynomial,K)
 if roots is None:return {'outcome':'no_conclusion','reason':'scalar codegrees outside FP field'}
 spectral += [(r,1)for r in roots]
 residual,rem=a.C.charpoly(t).as_poly().div(a.scalar_codegree_polynomial);assert rem.is_zero
 for p,m in residual.factor_list()[1]:
  assert m%4==0;q=s.Poly(p.as_expr().subs(t,2*t)/2**p.degree(),t,domain=s.QQ);roots=discover_roots(q,K)
  if roots is None:return {'outcome':'no_conclusion','reason':'matrix codegrees outside FP field'}
  spectral += [(r,2)for r in roots for _ in range(m//4)]
 assert sum(e*e for r,e in spectral)==9;spectral.remove((D,1));beta=[D/r for r,e in spectral];weights=[e for r,e in spectral];nb=len(beta)
 assert K.one+sum((K(e)*b for e,b in zip(weights,beta)),K.zero)==D,'weighted I(1) dimension identity'
 B=s.Matrix(n,n,lambda j,i:sum(R[b][j][k]*R[k][a.du[b]][i]for b,k in itertools.product(range(n),repeat=2)));assert B==B.T and B[0,0]==9
 solver=z3.SolverFor('QF_NIA');solver.set(timeout=timeout);v=[[z3.Int(f'w_{j}_{i}')for i in range(1,n)]for j in range(nb)];degree=f.degree();dv=[vector(d,degree)for d in ds[1:]]
 for j,row in enumerate(v):
  for i,x in enumerate(row,1):solver.add(x>=0,x<=min(int(B[0,i])//weights[j],math.isqrt(int(B[i,i]))))
  b=vector(beta[j]-K(weights[j]),degree)
  for q in range(degree):
   co=[d[q]for d in dv];den=s.ilcm(*[z.q for z in co+[b[q]]]);solver.add(sum(int(c*den)*x for c,x in zip(co,row))==int(b[q]*den))
 for i in range(1,n):solver.add(sum(e*row[i-1]for e,row in zip(weights,v))==int(B[0,i]))
 linear=solver.check();meta={'field':pc(f),'codegrees':[ec(r)for r,e in spectral],'irrep_degrees':weights,'induction_gram':B.tolist(),'column_dimensions':[ec(b)for b in beta]}
 meta['induction_gram']=[[int(x)for x in row]for row in meta['induction_gram']]
 gate='weak_integrality'if pD.degree()==1 else 'two_FP_values'if len(set(ds))==2 else None
 if linear==z3.unsat:return {'outcome':'excluded'if gate else 'scoped_exclusion','kind':'weighted_induction_smt','gate':gate,'stage':'dimension_and_row_sum','metadata':meta,'seconds':time.time()-start}
 if linear!=z3.sat:return {'outcome':'no_conclusion','reason':str(linear),'seconds':time.time()-start}
 LL=[[sum(row[i-1]*row[j-1]for row in v)for j in range(1,n)]for i in range(1,n)]
 for i in range(1,n):
  for j in range(i,n):solver.add(LL[i-1][j-1]<=int(B[i,j]))
 scale=10**6;rows=[]
 for i in range(1,n):
  factor=K(3)if a.du[i]!=i else K(3)*ds[i]+K.one;rhs=D*ds[i]if a.du[i]!=i else D*ds[i]*(ds[i]+K.one)
  co=[int(s.floor(scale*interval(factor*d,emb)[0]))for d in ds[1:]];upper=int(s.ceiling(scale*interval(rhs,emb)[1]));solver.add(sum(c*x for c,x in zip(co,LL[i-1]))<=upper);rows.append({'coefficients':co,'upper_bound':upper})
 meta['moment_rows']=rows;meta['root_interval']=[str(emb.lo),str(emb.hi)];r=solver.check()
 return {'outcome':('excluded'if gate else 'scoped_exclusion')if r==z3.unsat else 'no_conclusion','kind':'weighted_induction_smt','gate':gate,'stage':'gram_entries_and_twist_moments','solver_result':str(r),'metadata':meta,'seconds':time.time()-start}
def main():
 raw={r['id']:r for r in read()};out=[]
 for m in load('remaining_profiles.json'):
  if m['commutative']:continue
  r=discover(raw[m['id']]['tensor']);out.append({'id':m['id'],'report':r});save('weighted_scan.json',out);print(m['id'],r['outcome'],r.get('stage'),round(r.get('seconds',0),2),flush=True)
if __name__=='__main__':main()
