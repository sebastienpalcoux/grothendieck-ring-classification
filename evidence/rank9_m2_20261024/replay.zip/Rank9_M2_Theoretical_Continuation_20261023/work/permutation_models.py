from common import *
from extra_models import permutation_equivariant
from match_models import group,ty,su2,rep_dihedral
from zest_models import gradings,zest
import collections
def main():
 by=collections.defaultdict(list)
 for r in read():
  if r['multiplicity']==2:by[coarse(r['tensor'])].append(r)
 out=[];attempt=[]
 for name,R in [('Vec(C3)',group((3,))),('Ising',ty((2,))),('Rep(S3)',rep_dihedral(3)),('PSU(2)_5',su2(5,True))]:
  T=permutation_equivariant(R);variants=[(f'({name} x {name})^C2_swap',T,{'kind':'permutation_equivariantization','base_name':name,'base_tensor':R})]
  for g in gradings(T):
   for h in range(1,len(T)):
    if g[h] or T[h][h][0]!=1 or sum(T[h][h])!=1:continue
    U=zest(T,g,h);variants.append((f'C2-zest(({name} x {name})^C2_swap;h={h},grading={g})',U,{'kind':'associative_C2_zest','base_name':name,'base_tensor':T,'grading':g,'invertible':h}))
  for model,U,par in variants:
   hits=[];mult=max(v for a in U for b in a for v in b)
   if mult==2:
    for r in by[coarse(U)]:
     p=based_iso(r['tensor'],U)
     if p is not None:
      out.append({'id':r['id'],'model':model,'tensor':U,'basis_map_source_to_model':p,'parameters':par,'reference':'Canonical swap action on a Deligne square; equivariantization. Zested variants use the established associative C2-zesting theorem.','status':'unitarily_realized'});hits.append(r['id'])
   attempt.append({'name':model,'multiplicity':mult,'matches':hits,'tensor_sha256':digest(U)})
   print(model,'mult',mult,hits,flush=True)
 save('permutation_models.json',out);save('permutation_model_attempts.json',attempt)
 print('TOTAL',len({r['id']for r in out}),flush=True)
if __name__=='__main__':main()
