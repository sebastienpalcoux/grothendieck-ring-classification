from common import *
import sympy as s
import gng,compression,involution_module,fast_basis
from arithmetic import casimir,comm
from exact import t,pc,vector
from rings import Characters
import time,math,collections
involution_module.generated_basis=fast_basis.generated_basis
def subset_index(R,meta,a):
 f,K,ds,D,pD,emb=a.fp();u=K(s.Poly(t,t).rem(f).all_coeffs())
 for J in meta['subrings']:
  if len(J) in [1,len(R)]:continue
  q=D/sum((ds[i]*ds[a.du[i]] for i in J),K.zero)
  p=s.Matrix.hstack(*(vector(q*u**i,f.degree()) for i in range(f.degree()))).charpoly(t).as_poly()
  if any(x.q!=1 for x in p.all_coeffs()):return {'kind':'subring_index','subset':J,'polynomial':pc(p)}
def cyclic(R,meta,a):
 f,K,ds,D,pD,emb=a.fp();u=K(s.Poly(t,t).rem(f).all_coeffs());n=len(R)
 for g in meta['invertibles']:
  if g==0:continue
  x=g;order=1
  while x:
   x=R[x][g].index(1);order+=1
  X=[x for x in range(n) if R[g][x][x]];Y=[x for x in range(n) if R[x][g][x]]
  for z in set(X)&set(Y):
   for x in X:
    for y in Y:
     m=R[x][y][z]
     if not m:continue
     q=K(s.Rational(math.gcd(order,m),order))*ds[z]
     p=s.Matrix.hstack(*(vector(q*u**i,f.degree()) for i in range(f.degree()))).charpoly(t).as_poly()
     if any(v.q!=1 for v in p.all_coeffs()):return {'kind':'cyclic_isotypic_integrality','g':g,'order':order,'triple':[x,y,z],'multiplicity':m,'polynomial':pc(p)}
def primitive(R):
 p=casimir(R).charpoly(t).as_poly()
 if not comm(R):return None
 for q,e in p.factor_list()[1]:
  d=q.degree();norm=abs(int(q.TC()))
  if all(v<d for v in s.factorint(norm).values()) and (d!=len(R) or e!=1 or p!=q):return {'kind':'primitive_codegree','factor':pc(q),'norm':norm}
def main():
 raw={r['id']:r for r in read()};out=[];start=time.time();ct=collections.Counter()
 for m in load('survivors_initial.json'):
  R=raw[m['id']]['tensor'];c=gng.certificate(R) or primitive(R)
  if c is None:report,c=compression.discover(R)
  else:report=None
  if c is None and m['commutative']:c=involution_module.certificate(R)
  if c is None and m['commutative']:
   a=Characters(R);c=subset_index(R,m,a) or cyclic(R,m,a)
  rec={'id':m['id'],'certificate':c,'compression_profile':report};out.append(rec)
  if c:ct[c['kind']]+=1
  save('established_scan.json',out)
  if len(out)%10==0:print(len(out),dict(ct),'seconds',round(time.time()-start),flush=True)
 print('FINAL',len(out),dict(ct),flush=True)
if __name__=='__main__':main()
