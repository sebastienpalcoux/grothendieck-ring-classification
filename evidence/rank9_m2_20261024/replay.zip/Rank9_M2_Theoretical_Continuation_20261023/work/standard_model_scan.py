from common import *
from quantum_rank2 import principal
from exact import field,t,require
import sympy as s,itertools,collections,time
def d16():
 # Standard D16 even category: modularization of SU(2)_28,even by its boson.
 m=7;n=m+2;P=m;Q=m+1;T=[[[0]*n for _ in range(n)]for _ in range(n)]
 def a2(a,b,c):return int(abs(a-b)<=c<=min(a+b,8*m-a-b) and (a+b+c)%2==0)
 for i,j in itertools.product(range(m),repeat=2):
  for k in range(m):T[i][j][k]=a2(2*i,2*j,2*k)+a2(2*i,2*j,4*m-2*k)
  T[i][j][P]=T[i][j][Q]=a2(2*i,2*j,2*m)
 for i in range(m):
  for a in [P,Q]:
   for k in range(m):T[i][a][k]=T[a][i][k]=int(i+k>=m)
   out=a if i%2==0 else P+Q-a;T[i][a][out]=T[a][i][out]=1
 for a in [P,Q]:
  T[a][a][P+Q-a]=1
  for k in range(m):T[a][a][k]=int(k%2==1)
 for k in range(m):T[P][Q][k]=T[Q][P][k]=int(k%2==0)
 return T
def psl2even(q):
 # Standard PSL(2,q), q even, torus character table and exact character products.
 require(q==8,'this replay uses the field of order eight')
 c=s.ilcm(q-1,q+1);K=field(s.Poly(s.cyclotomic_poly(c,t),t));z=K([1,0]);zero=K.zero
 split=range(1,q//2);nonsplit=range(1,q//2+1)
 rows=[[K.one]*(q+1),[K(q),zero]+[K.one]*len(split)+[-K.one]*len(nonsplit)]
 for a in split:rows.append([K(q+1),K.one]+[z**(int(c//(q-1))*a*b)+z**(-int(c//(q-1))*a*b) for b in split]+[zero]*len(nonsplit))
 for a in nonsplit:rows.append([K(q-1),-K.one]+[zero]*len(split)+[-z**(int(c//(q+1))*a*b)-z**(-int(c//(q+1))*a*b) for b in nonsplit])
 sizes=[1,q*q-1]+[q*(q+1)]*len(split)+[q*(q-1)]*len(nonsplit);D=q*(q*q-1);require(sum(sizes)==D,'class sizes')
 n=len(rows)
 for i,j in itertools.product(range(n),repeat=2):require(sum((K(w)*a*b for w,a,b in zip(sizes,rows[i],rows[j])),zero)==K(D*int(i==j)),'character orthogonality')
 R=[[[0]*n for _ in range(n)]for _ in range(n)]
 for i,j,k in itertools.product(range(n),repeat=3):
  v=sum((K(w)*a*b*d for w,a,b,d in zip(sizes,rows[i],rows[j],rows[k])),zero)/K(D);co=v.to_list()
  require(len(co)<=1 and (not co or co[0].denominator==1 and co[0]>=0),'integral character product');R[i][j][k]=int(co[0]) if co else 0
 return R
def main():
 rows=[r for r in read() if r['multiplicity']==2];by=collections.defaultdict(list)
 for r in rows:by[coarse(r['tensor'])].append(r)
 matches=[];attempts=[];start=time.time()
 for name,fn,params,ref in [
  ('Rep(PSL(2,8))',lambda:psl2even(8),{'kind':'finite_group_representations','group':'PSL(2,8)'},'Standard character table of PSL(2,q) in even characteristic; Liu–Palcoux–Ren, arXiv:2102.01663'),
  ('D16 even category',d16,{'kind':'bosonic_modularization','base':'SU(2)_28,even','algebra':'1+V_28'},'Kirillov–Ostrik, On a q-analogue of the McKay correspondence and the ADE classification of sl2 conformal field theories'),
  ('G2 level 4',lambda:principal('G2',4)[0],{'kind':'WZW','type':'G2','level':4},'Standard unitary WZW category; exact Weyl-alternant reconstruction'),
  ('C2 level 4,adjoint',lambda:principal('C2',4,True)[0],{'kind':'WZW_adjoint','type':'C2','level':4},'Standard unitary C2 WZW category and its adjoint fusion subcategory; exact Weyl-alternant reconstruction')]:
  T=fn();n=len(T);mult=max(v for a in T for b in a for v in b);hits=[]
  if n==9 and mult==2:
   for r in by[coarse(T)]:
    p=based_iso(r['tensor'],T)
    if p is not None:matches.append({'id':r['id'],'model':name,'tensor':T,'basis_map_source_to_model':p,'parameters':params,'reference':ref,'status':'unitarily_realized'});hits.append(r['id'])
  attempts.append({'name':name,'rank':n,'multiplicity':mult,'tensor':T,'matches':hits})
  save('standard_models.json',matches);save('standard_model_attempts.json',attempts)
  print(name,'rank',n,'mult',mult,'MATCHES',hits,'seconds',round(time.time()-start,2),flush=True)
if __name__=='__main__':main()
