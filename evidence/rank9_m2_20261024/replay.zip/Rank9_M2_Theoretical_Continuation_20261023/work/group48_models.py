from common import *
from group_general import gl2f3,fusion
from group_scan import subgroups,rank_est
from group_theoretical import permutation_group
import collections,time
def main():
 by=collections.defaultdict(list)
 for r in read():
  if r['multiplicity']==2:by[coarse(r['tensor'])].append(r)
 _,G=permutation_group(4);groups=[('GL(2,3)',gl2f3()),('S4 x C2',[[2*G[a//2][b//2]+((a%2)^(b%2))for b in range(48)]for a in range(48)])];out=[];attempt=[]
 for name,G in groups:
  inv=[row.index(0)for row in G];seen=set();t=time.time()
  for HH in subgroups(G):
   H=sorted(HH)
   if tuple(H)in seen:continue
   seen|={tuple(sorted(G[G[a][h]][inv[a]]for h in H))for a in range(len(G))}
   if rank_est(G,H)!=9:continue
   try:T=fusion(G,H)
   except ValueError as e:attempt.append({'group':name,'subgroup':H,'outcome':'implementation_ineligible','reason':str(e)});continue
   mult=max(v for a in T for b in a for v in b);hits=[]
   if mult==2:
    for r in by[coarse(T)]:
     p=based_iso(r['tensor'],T)
     if p is not None:out.append({'id':r['id'],'model':f'C({name},1,H={H},1)','tensor':T,'basis_map_source_to_model':p,'parameters':{'kind':'untwisted_group_theoretical','group':name,'group_table':G,'subgroup':H},'reference':'Established subgroup-algebra bimodule construction; exact cyclotomic stabilizer-character convolution','status':'unitarily_realized'});hits.append(r['id'])
   attempt.append({'group':name,'subgroup':H,'multiplicity':mult,'matches':hits,'tensor':T});print(name,H,'mult',mult,hits,flush=True)
   save('group48_models.json',out);save('group48_model_attempts.json',attempt)
  print('Group complete',name,round(time.time()-t,2),flush=True)
if __name__=='__main__':main()
