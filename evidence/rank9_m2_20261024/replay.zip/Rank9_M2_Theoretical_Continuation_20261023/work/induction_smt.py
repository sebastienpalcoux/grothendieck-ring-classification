"""Finite solver adapter for the existing low-induction Gram/moment conditions.
Bounds, codegrees and every inequality come from induction.py. Rational interval
relaxation of positive algebraic coefficients only weakens necessary conditions.
"""
from common import *
from rings import Characters
from exact import *
import sympy as s,z3,math,time
def interval(a,emb):
 lo=hi=s.S.Zero
 for c in a.to_list():
  v=[lo*emb.lo,lo*emb.hi,hi*emb.lo,hi*emb.hi];lo=min(v)+s.Rational(c);hi=max(v)+s.Rational(c)
 return lo,hi
def discover(R,timeout_ms=6000):
 start=time.time();a=Characters(R);f,K,ds,D,pD,emb=a.fp();roots=discover_roots(a.C.charpoly(t).as_poly(),K)
 if roots is None:return {'outcome':'not_applicable','reason':'formal codegrees do not split in the FP field'}
 roots=list(roots);assert D in roots;roots.remove(D);beta=[D/r for r in roots];n=len(R);B=a.C
 solver=z3.SolverFor('QF_NIA');solver.set(timeout=timeout_ms)
 v=[[z3.Int(f'v_{j}_{i}') for i in range(1,n)]for j in range(n-1)]
 for row in v:
  for i,x in enumerate(row,1):solver.add(x>=0,x<=min(int(B[0,i]),math.isqrt(int(B[i,i]))))
 degree=f.degree();dv=[vector(d,degree)for d in ds[1:]]
 for j,row in enumerate(v):
  b=vector(beta[j]-K.one,degree)
  for q in range(degree):
   cs=[d[q]for d in dv];den=s.ilcm(*[x.q for x in cs+[b[q]]]);solver.add(sum(int(c*den)*x for c,x in zip(cs,row))==int(b[q]*den))
 for i in range(1,n):solver.add(sum(row[i-1]for row in v)==int(B[0,i]))
 linear=solver.check()
 meta={'field_polynomial':pc(f),'generator':a.k,'codegree_roots':[ec(r)for r in roots],'column_dimensions':[ec(b)for b in beta],'coordinate_bounds':[min(int(B[0,i]),math.isqrt(int(B[i,i])))for i in range(1,n)]}
 if linear==z3.unsat:return {'outcome':'excluded','kind':'low_induction_smt','stage':'dimension_and_row_sum','metadata':meta,'seconds':time.time()-start}
 if linear!=z3.sat:return {'outcome':'no_conclusion','reason':str(linear),'metadata':meta,'seconds':time.time()-start}
 LL=[[sum(row[i-1]*row[j-1]for row in v)for j in range(1,n)]for i in range(1,n)]
 for i in range(1,n):
  for j in range(i,n):solver.add(LL[i-1][j-1]<=int(B[i,j]))
 # Intervals are retained as exact rationals in the certificate.
 scale=10**6;moment=[]
 for i in range(1,n):
  factor=K(3) if a.du[i]!=i else K(3)*ds[i]+K.one
  rhs=D*ds[i] if a.du[i]!=i else D*ds[i]*(ds[i]+K.one)
  coeff=[int(s.floor(scale*interval(factor*d,emb)[0]))for d in ds[1:]]
  upper=int(s.ceiling(scale*interval(rhs,emb)[1]));solver.add(sum(c*x for c,x in zip(coeff,LL[i-1]))<=upper)
  moment.append({'object':i,'coefficients':coeff,'upper_bound':upper})
 meta['moment_rows']=moment;meta['root_interval']=[str(emb.lo),str(emb.hi)];meta['scale']=scale
 result=solver.check()
 if result==z3.unsat:return {'outcome':'excluded','kind':'low_induction_smt','stage':'gram_entries_and_twist_moments','metadata':meta,'seconds':time.time()-start}
 if result==z3.sat:
  mod=solver.model();frame=[[1]+[mod.eval(x).as_long()for x in row]for row in v]
  return {'outcome':'no_conclusion','frame':frame,'metadata':meta,'seconds':time.time()-start}
 return {'outcome':'no_conclusion','reason':str(result),'metadata':meta,'seconds':time.time()-start}
if __name__=='__main__':
 raw={r['id']:r for r in read()}
 for rid in ['R9_2_12','R9_2_92','R9_2_21','R9_2_301','R9_2_383']:
  r=discover(raw[rid]['tensor']);print(rid,r['outcome'],r.get('stage'),round(r.get('seconds',0),2),flush=True)
