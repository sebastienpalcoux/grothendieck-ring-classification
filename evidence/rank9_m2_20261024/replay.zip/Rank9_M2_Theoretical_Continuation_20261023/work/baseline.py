from common import *
from arithmetic import dnumber,near_group,cyclotomic,integral_drinfeld
import collections,time
from subrings import subrings

def main():
 start=time.time();rows=read();out=[];ct=collections.Counter()
 for r in rows:
  N=np.asarray(r['tensor'],dtype=np.int64);n=len(N);I=np.eye(n,dtype=np.int64)
  assert N.shape==(9,9,9) and np.all(N>=0) and int(N.max())<=2
  assert np.array_equal(N[0],I) and np.array_equal(N[:,0,:],I)
  assert np.all(N[:,:,0].sum(0)==1) and np.all(N[:,:,0].sum(1)==1)
  du=N[:,:,0].argmax(1)
  assert all(du[du[i]]==i for i in range(n))
  assert np.array_equal(np.einsum('ijx,xkl->ijkl',N,N),np.einsum('jkx,ixl->ijkl',N,N))
  assert all(N[i,j,k]==N[du[i],k,j]==N[k,du[j],i] and N[i,j,k]==N[du[j],du[i],du[k]] for i in range(n) for j in range(n) for k in range(n))
  A=N.sum(0);assert np.array_equal(A,A.T)
  w,V=np.linalg.eigh(A);d=V[:,-1]/V[0,-1];assert min(d)>0
  rec={k:v for k,v in r.items() if k!='tensor'}
  rec.update(dual=du.tolist(),commutative=bool(np.array_equal(N,N.swapaxes(0,1))),invertibles=[i for i in range(n) if N[i,du[i]].sum()==1],dimensions_approx=d.tolist(),global_dimension_approx=float(d@d),subrings=subrings(N,du))
  out.append(rec)
 save('input_audit.json',out)
 print('INPUT',len(out),collections.Counter(r['multiplicity'] for r in out),flush=True)
 out=[]
 for r in rows:
  if r['multiplicity']!=2:continue
  R=r['tensor'];cs=[]
  for fn in [near_group,dnumber,cyclotomic,integral_drinfeld]:
   c=fn(R)
   if c:cs.append(c);break
  out.append({'id':r['id'],'certificates':cs})
  if cs:ct[cs[0]['kind']]+=1
  if len(out)%100==0:
   save('baseline.json',out);print(len(out),dict(ct),'seconds',round(time.time()-start),flush=True)
 save('baseline.json',out);print('FINAL',len(out),dict(ct),flush=True)
if __name__=='__main__':main()
