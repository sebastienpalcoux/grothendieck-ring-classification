from common import *
from extra_models import auts,abelian_table,dihedral_table,dicyclic_table,a4_table,pointed_equivariant
from cyclic_equivariant import cyclic_equivariant
from match_models import ty
from zest_models import gradings,zest
import itertools,collections,time
def ty_involutions():
 # Reuse the project's orthogonal-TY action and parity-coherence constructors.
 for orders in [(8,),(4,2),(2,2,2),(11,)]:
  els=list(itertools.product(*(range(a) for a in orders)));G=abelian_table(orders);n=len(G);R=ty(orders)
  if orders==(8,):forms=[([[a*b%8 for b in range(8)]for a in range(8)],8)]
  elif orders==(11,):forms=[([[a*b%11 for b in range(11)]for a in range(11)],11)]
  elif orders==(4,2):
   forms=[]
   for a,b,c in itertools.product(range(4),range(2),range(2)):
    C=[[(a*x[0]*y[0]+2*b*(x[0]*y[1]+x[1]*y[0])+2*c*x[1]*y[1])%4 for y in els]for x in els]
    if all(any(C[i][j] for j in range(n)) for i in range(1,n)):forms.append((C,4))
  else:
   forms=[]
   for tail in itertools.product(range(2),repeat=6):
    a,b,c,d,e,f=tail;B=[[a,b,c],[b,d,e],[c,e,f]]
    C=[[sum(x[i]*B[i][j]*y[j] for i in range(3) for j in range(3))%2 for y in els]for x in els]
    if all(any(C[i][j] for j in range(n)) for i in range(1,n)):forms.append((C,2))
  for sigma in auts(G):
   if not all(sigma[sigma[i]]==i for i in range(n)):continue
   fixed=sum(sigma[i]==i for i in range(n))
   if (n+4+3*fixed)//2!=9 or (n+4+3*fixed)%2:continue
   form=next(((C,mod) for C,mod in forms if all(C[sigma[i]][sigma[j]]==C[i][j] for i in range(n) for j in range(n))),None)
   if form is None:continue
   for parity in [0,1]:
    pp=[0]*n+[parity];T,labs=cyclic_equivariant(R,sigma+[n],2,pp)
    yield f'TY({orders})^C2[sigma={sigma}, parity={parity}]',T,{'kind':'orthogonal_TY_equivariantization','orders':orders,'automorphism':sigma,'parity':pp,'bicharacter_exponents':form[0],'modulus':form[1],'labels':labs},'Established project orthogonal TY equivariantization with either parity coherence',orders in [(2,2,2)]
def pointed():
 for name,G in [('C12',abelian_table((12,))),('C6xC2',abelian_table((6,2))),('D12',dihedral_table(6)),('Dic3',dicyclic_table(3)),('A4',a4_table()),('C9',abelian_table((9,))),('C3xC3',abelian_table((3,3))),('C15',abelian_table((15,)))]:
  for sigma in auts(G):
   if not all(sigma[sigma[i]]==i for i in range(len(G))):continue
   if len(G)+3*sum(sigma[i]==i for i in range(len(G)))!=18:continue
   T=pointed_equivariant(G,sigma)
   yield f'Vec({name})^C2[{sigma}]',T,{'kind':'pointed_equivariantization','group':name,'group_table':G,'automorphism':sigma},'Strict action on Vec(G) by the explicit involutive group automorphism; unitary equivariantization',all(G[a][b]==G[b][a] for a in range(len(G)) for b in range(len(G)))
def main():
 rows=[r for r in read() if r['multiplicity']==2];by=collections.defaultdict(list)
 for r in rows:by[coarse(r['tensor'])].append(r)
 attempts=[];matches=[];seen=set();t=time.time()
 for name,T,pars,ref,braided in itertools.chain(ty_involutions(),pointed()):
  variants=[(name,T,pars,ref)]
  if braided:
   for g in gradings(T):
    for h in range(1,len(T)):
     if g[h] or T[h][h][0]!=1 or sum(T[h][h])!=1:continue
     U=zest(T,g,h);variants.append((f'C2-zest({name},h={h})',U,{'kind':'associative_C2_zest','base':pars,'base_tensor':T,'grading':g,'invertible':h},ref+'; established associative zesting theorem'))
  for name,U,pars,ref in variants:
   h=digest(U)
   if h in seen:continue
   seen.add(h);hits=[]
   if len(U)==9 and max(v for a in U for b in a for v in b)==2:
    for r in by[coarse(U)]:
     p=based_iso(r['tensor'],U)
     if p is not None:
      matches.append({'id':r['id'],'model':name,'tensor':U,'basis_map_source_to_model':p,'parameters':pars,'reference':ref,'status':'unitarily_realized'});hits.append(r['id']);print('MATCH',r['id'],name,flush=True)
   attempts.append({'name':name,'rank':len(U),'multiplicity':max(v for a in U for b in a for v in b),'tensor_sha256':h,'matches':hits})
  save('known_models.json',matches);save('model_attempts.json',attempts)
 print('Known models',len({x['id'] for x in matches}),'attempts',len(attempts),'seconds',time.time()-t,flush=True)
if __name__=='__main__':main()
