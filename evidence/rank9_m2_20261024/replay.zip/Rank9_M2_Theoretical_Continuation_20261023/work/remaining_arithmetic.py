from common import *
from scalar_characters import chars
from established_scan import cyclic,subset_index
from noncomm_integral import test
from arithmetic import comm
from exact import *
import sympy as s,collections
def main():
 raw={r['id']:r for r in read()};out=[]
 for m in load('survivors_current.json'):
  R=raw[m['id']]['tensor'];c=None
  if not m['commutative']:
   c=test(R)
   if c is None:
    a=chars(R);c=cyclic(R,m,a) or subset_index(R,m,a)
  out.append({'id':m['id'],'certificate':c})
  if c:print(m['id'],c['kind'],flush=True)
 save('remaining_arithmetic.json',out)
 print('FINAL',collections.Counter(x['certificate']['kind'] for x in out if x['certificate']),flush=True)
if __name__=='__main__':main()
