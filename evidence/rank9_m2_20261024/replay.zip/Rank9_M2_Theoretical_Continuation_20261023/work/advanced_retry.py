from common import *
from advanced_scan import attempt
from concurrent.futures import ThreadPoolExecutor,as_completed
import collections
def run(item):
 rid,mode=item;r=attempt(mode,rid);return {'id':rid,'mode':mode,'report':r}
def main():
 targets=load('advanced_dependency_retry_targets.json');out=[]
 with ThreadPoolExecutor(max_workers=3)as pool:
  for f in as_completed([pool.submit(run,x)for x in targets]):
   r=f.result();out.append(r);save('advanced_retry.json',out);print(r['id'],r['mode'],r['report']['outcome'],r['report'].get('reason',''),flush=True)
 print('FINAL',len(out),collections.Counter(x['report']['outcome']for x in out),flush=True)
if __name__=='__main__':main()
