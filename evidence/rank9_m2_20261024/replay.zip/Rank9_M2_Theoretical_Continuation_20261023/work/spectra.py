from common import *
from spectrum_verify import verify
import subprocess,time,collections
def main():
 rows=[r for r in read() if r['multiplicity']==2]
 data=[len(rows)]
 for r in rows:
  data.append(9);data.extend(v for a in r['tensor'] for b in a for v in b)
 for name,kind in [('zero_spectrum','zero_spectrum'),('one_spectrum_m3','one_spectrum')]:
  exe=BASE/'work'/name;subprocess.run(['g++','-O3','-std=c++17',str(BASE/'sources'/f'{name}.cpp'),'-o',str(exe)],check=True)
  t=time.time();p=subprocess.run([str(exe)],input=' '.join(map(str,data)),capture_output=True,text=True,check=True)
  out=[]
  for j,line in enumerate(p.stdout.splitlines()):
   nums=list(map(int,line.split()));assert nums[0]==j
   c={'kind':kind,'indices':nums[2:]} if nums[1] else None
   if c:verify(rows[j]['tensor'],c)
   out.append({'id':rows[j]['id'],'certificate':c})
  assert len(out)==len(rows);save(f'{kind}.json',out)
  print(kind,sum(bool(x['certificate']) for x in out),'seconds',round(time.time()-t,2),flush=True)
if __name__=='__main__':main()
