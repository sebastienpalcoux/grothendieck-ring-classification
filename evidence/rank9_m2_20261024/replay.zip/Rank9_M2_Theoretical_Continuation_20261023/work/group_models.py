from common import *
from group_theoretical import permutation_group,subgroup,fusion
import collections,time
def main():
 rows=[r for r in read() if r['multiplicity']==2];by=collections.defaultdict(list)
 for r in rows:by[coarse(r['tensor'])].append(r)
 G,M=permutation_group(4);cases=[('C2',[(1,0,2,3)]),('C2double',[(1,0,3,2)]),('V4nonnormal',[(1,0,2,3),(0,1,3,2)]),('V4normal',[(1,0,3,2),(2,3,0,1)]),('D8',[(1,2,3,0),(0,3,2,1)]),('S3',[(1,0,2,3),(1,2,0,3)])]
 matches=[];attempt=[];t=time.time()
 for name,gens in cases:
  H=subgroup(M,[G.index(g)for g in gens]);T=fusion(M,H);n=len(T);mult=max(v for a in T for b in a for v in b);hits=[]
  if n==9 and mult==2:
   for r in by[coarse(T)]:
    p=based_iso(r['tensor'],T)
    if p is not None:matches.append({'id':r['id'],'model':f'C(S4,1,{name},1)','tensor':T,'basis_map_source_to_model':p,'parameters':{'kind':'untwisted_group_theoretical','permutation_degree':4,'group':'S4','subgroup_generators':gens},'reference':'Established equivariant-bundle convolution construction of subgroup-algebra bimodules in Vec(S4); unitary','status':'unitarily_realized'});hits.append(r['id'])
  attempt.append({'model':f'C(S4,1,{name},1)','rank':n,'multiplicity':mult,'matches':hits,'tensor':T})
  print(name,'rank',n,'mult',mult,hits,'seconds',round(time.time()-t,2),flush=True);save('group_models.json',matches);save('group_model_attempts.json',attempt)
if __name__=='__main__':main()
