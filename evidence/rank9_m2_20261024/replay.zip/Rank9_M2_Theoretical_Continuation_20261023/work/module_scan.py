from common import *
from module_smt import discover
import time,collections
def main():
 raw={r['id']:r for r in read()};excluded=set()
 for name in ['baseline','structural','zero_spectrum','one_spectrum','established_scan','remaining_arithmetic']:
  for r in load(name+'.json'):
   if r.get('certificates',r.get('certificate')):excluded.add(r['id'])
 for r in load('signed_sieve.json'):
  if r['report']['outcome']=='excluded':excluded.add(r['id'])
 out=[];start=time.time()
 for m in load('input_audit.json'):
  if m['multiplicity']!=2 or not m['commutative'] or m['id']in excluded:continue
  R=raw[m['id']]['tensor'];reports=[]
  for g in m['invertibles']:
   if g and R[g][g]==[1]+[0]*8:
    z=discover(R,g);reports.append(z)
    if z['outcome']=='excluded':break
  out.append({'id':m['id'],'reports':reports,'outcome':'excluded'if any(z['outcome']=='excluded'for z in reports)else 'no_conclusion'});save('module_scan.json',out)
  if len(out)%10==0:print(len(out),collections.Counter(x['outcome']for x in out),'seconds',round(time.time()-start,2),flush=True)
 print('FINAL',len(out),collections.Counter(x['outcome']for x in out),flush=True)
if __name__=='__main__':main()
