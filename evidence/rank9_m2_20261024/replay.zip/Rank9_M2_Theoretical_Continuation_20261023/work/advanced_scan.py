from common import *
import subprocess,os,signal,time,collections
from concurrent.futures import ThreadPoolExecutor,as_completed
def attempt(mode,rid,seconds=12):
 env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
 start=time.time();p=subprocess.Popen([sys.executable,str(BASE/'work/advanced_attempt.py'),mode,rid],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env=env,start_new_session=True)
 try:stdout,stderr=p.communicate(timeout=seconds)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGKILL);stdout,stderr=p.communicate();return {'mode':mode,'outcome':'no_conclusion','reason':'finite discovery allowance','seconds':time.time()-start}
 if p.returncode:return {'mode':mode,'outcome':'no_conclusion','reason':'implementation_ineligible_or_error','returncode':p.returncode,'stderr':stderr[-1800:],'seconds':time.time()-start}
 return load(f'advanced_{mode}_{rid}.json')
def worker(m):
 rid=m['id'];reports=[]
 if not m['commutative']:return {'id':rid,'reports':[],'outcome':'no_conclusion','reason':'commutative advanced adapters'}
 for mode in ['spectral_module','morita','rotation','character','modular','integer_gram']:
  z=attempt(mode,rid);reports.append(z)
  if z.get('certificate'):return {'id':rid,'reports':reports,'outcome':'scoped_exclusion','mode':mode,'certificate':z['certificate']}
  if mode=='rotation' and z.get('reason')=='finite discovery allowance':
   reports.append({'modes':['character','modular','integer_gram'],'outcome':'no_conclusion','reason':'shared exhaustive low-column preprocessing exceeds the discovery allowance'});break
 return {'id':rid,'reports':reports,'outcome':'no_conclusion'}
def main():
 targets=load('remaining_profiles.json');out=[];start=time.time()
 with ThreadPoolExecutor(max_workers=3)as pool:
  fs={pool.submit(worker,m):m['id']for m in targets}
  for fut in as_completed(fs):
   try:r=fut.result()
   except Exception as e:r={'id':fs[fut],'outcome':'no_conclusion','reason':'adapter error '+str(e),'reports':[]}
   out.append(r);save('advanced_scan.json',out)
   print(r['id'],r['outcome'],r.get('mode',''),'TOTAL',len(out),'seconds',round(time.time()-start,2),flush=True)
 print('FINAL',len(out),collections.Counter(x['outcome']for x in out),flush=True)
if __name__=='__main__':main()
