from common import *
import collections,time,itertools
from match_models import group,ty,su2,rep_dihedral
from arithmetic import dnumber,cyclotomic,near_group
def positive_registry():
 p=REPO/'supplements';out=[]
 for name,R in [('Vec(C2)',group((2,))),('Fib',su2(3,True)),('Vec(C3)',group((3,))),('Ising',ty((2,))),('Rep(S3)',rep_dihedral(3)),('PSU(2)_5',su2(5,True))]:out.append({'name':name,'tensor':R,'reference':'Standard rank-two and rank-three complex classifications'})
 for f in ['rank8/data/lower_rank_positive_models.json','rank8/data/rank6_positive_models.json','rank7/data/model_catalog.json','rank8/data/model_catalog.json']:
  for x in json.loads((p/f).read_text()):
   if max(v for a in x['tensor'] for b in a for v in b)>2:continue
   out.append({'name':x.get('name',x.get('id')),'tensor':x['tensor'],'reference':x.get('reference',x.get('source_reference',f)),'source':f})
 return out
def main():
 rows={r['id']:r for r in read()};meta=load('input_audit.json');base={r['id']:r for r in load('baseline.json')}
 reg=positive_registry();by=collections.defaultdict(list)
 for x in reg:by[(len(x['tensor']),coarse(x['tensor']))].append(x)
 save('lower_positive_registry.json',reg)
 out=[];cache={};ct=collections.Counter()
 for m in meta:
  if m['multiplicity']!=2:continue
  R=rows[m['id']]['tensor'];cs=[]
  for J in m['subrings']:
   n=len(J)
   if n in [1,9]:continue
   S=[[[R[i][j][k] for k in J] for j in J]for i in J];h=digest(S)
   if h not in cache:cache[h]=any(based_iso(S,x['tensor']) is not None for x in by[(n,coarse(S))])
   if not cache[h]:
    c={'kind':'excluded_lower_subring','subset':J,'subrank':n,'submultiplicity':max(v for a in S for b in a for v in b),'subtensor_sha256':h,'scope':'general_complex_fusion_category','reference':f'Complete project rank-{n} classification through multiplicity two; full fusion subcategories inherit categorifications'}
    direct=near_group(S) or dnumber(S) or cyclotomic(S)
    if direct:c['direct_certificate']=direct
    cs.append(c);break
  out.append({'id':m['id'],'certificates':cs})
  if cs:ct[cs[0]['subrank']]+=1
 save('structural.json',out)
 print('Subring exclusions',sum(bool(x['certificates']) for x in out),dict(ct))
 excluded={i for i,r in base.items() if r['certificates']}|{x['id'] for x in out if x['certificates']}
 survivors=[m for m in meta if m['multiplicity']==2 and m['id'] not in excluded]
 save('survivors_initial.json',survivors)
 print('Union exclusions',len(excluded),'survivors',len(survivors),'commutative',sum(x['commutative'] for x in survivors))
 print('profiles',dict(collections.Counter(tuple(round(d,6) for d in sorted(x['dimensions_approx'])) for x in survivors)))
if __name__=='__main__':main()
