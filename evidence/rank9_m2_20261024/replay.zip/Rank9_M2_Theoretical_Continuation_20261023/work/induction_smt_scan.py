from common import *
from induction_smt import discover
from scalar_characters import chars
from sphere import analyse
from spherical_moments import positive_sign_embedding
from exact import pc
import collections,time
def main():
 raw={r['id']:r for r in read()};out=[];start=time.time()
 for m in load('survivors_for_low.json'):
  if not m['commutative']:continue
  R=raw[m['id']]['tensor'];a=chars(R);f,K,ds,D,pD,emb=a.fp();gate='weak_integrality' if pD.degree()==1 else 'two_FP_values' if len(set(ds))==2 else None
  c=discover(R);rec={'id':m['id'],'general_gate':gate,'report':c}
  if c['outcome']=='excluded':
   rec['outcome']='excluded' if gate else 'spherical_only'
   original=analyse(R);closed=True
   for b,(f,e) in zip(original['branches'],a.components):
    if b['obstruction'] is not None:continue
    K,ds,D,pD=a.component(f);pos=positive_sign_embedding(R,f,ds)
    if pos:b['obstruction']={'kind':'Galois_positive_dimension','gate':pos,'pseudo_obstruction':c}
    else:closed=False
   original['spherical_excluded']=closed;rec['spherical_report']=original
  else:rec['outcome']='no_conclusion'
  out.append(rec);save('induction_smt_scan.json',out)
  print(m['id'],rec['outcome'],dict(collections.Counter(x['outcome']for x in out)),round(time.time()-start,2),flush=True)
if __name__=='__main__':main()
