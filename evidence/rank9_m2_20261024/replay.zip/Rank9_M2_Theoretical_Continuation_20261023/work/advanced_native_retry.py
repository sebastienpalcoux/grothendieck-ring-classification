from common import *
from advanced_scan import attempt
from concurrent.futures import ThreadPoolExecutor,as_completed
import collections
def run(rid):
 reports=[]
 for mode in ['rotation','character','modular','integer_gram']:
  r=attempt(mode,rid);reports.append(r)
  if r.get('certificate'):return {'id':rid,'outcome':'scoped_exclusion','mode':mode,'certificate':r['certificate'],'reports':reports}
  if mode=='rotation'and r.get('reason')=='finite discovery allowance':break
 return {'id':rid,'outcome':'no_conclusion','reports':reports}
def main():
 out=[]
 with ThreadPoolExecutor(max_workers=3)as pool:
  for f in as_completed([pool.submit(run,rid)for rid in load('advanced_native_retry_targets.json')]):
   r=f.result();out.append(r);save('advanced_native_retry.json',out);print(r['id'],r['outcome'],r.get('mode',''),flush=True)
 print('FINAL',len(out),collections.Counter(x['outcome']for x in out),flush=True)
if __name__=='__main__':main()
