from extra_models import *
import group_theoretical as gt
def subgroups(G):
 n=len(G);found={frozenset([0])};queue=[frozenset([0])]
 for H in queue:
  for a in range(1,n):
   if a in H:continue
   J=frozenset(gt.subgroup(G,list(H)+[a]))
   if J not in found:found.add(J);queue.append(J)
 return sorted(found,key=lambda x:(len(x),sorted(x)))
def rank_est(G,H):
 # invariant estimate character count; supported groups stabilizers.
 inv=[row.index(0)for row in G];seen=set();r=0
 for z in range(len(G)):
  if z in seen:continue
  D={G[G[a][z]][b]for a in H for b in H};seen|=D
  K=[a for a in H if G[G[inv[z]][a]][z]in H]
  # number conjugacy classes in stabilizer
  seenK=set();k=0
  for x in K:
   if x not in seenK:seenK|={G[G[a][x]][inv[a]]for a in K};k+=1
  r+=k
 return r
