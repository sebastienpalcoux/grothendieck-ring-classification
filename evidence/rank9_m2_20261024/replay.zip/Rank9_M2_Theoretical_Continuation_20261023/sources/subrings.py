import numpy as np
def subrings(N,dual):
 n=len(N); supp=[[sum(1<<k for k in np.flatnonzero(N[i,j])) for j in range(n)] for i in range(n)]
 def closure(mask):
  while True:
   old=mask; a=[i for i in range(n) if mask>>i&1]
   for i in a:
    mask|=1<<int(dual[i])
    for j in a: mask|=supp[i][j]
   if mask==old:return mask
 seen={1}; todo=[1]
 while todo:
  S=todo.pop()
  for i in range(1,n):
   if not S>>i&1:
    T=closure(S|1<<i)
    if T not in seen:seen.add(T);todo.append(T)
 return [[i for i in range(n) if S>>i&1] for S in sorted(seen,key=lambda x:(x.bit_count(),x))]
