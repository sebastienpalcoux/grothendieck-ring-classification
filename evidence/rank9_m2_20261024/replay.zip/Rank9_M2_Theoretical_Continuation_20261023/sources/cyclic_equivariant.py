import itertools
def cyclic_equivariant(R,sigma,m,parity=None):
 # Exact cyclotomic Fourier projection, with no symbolic exponential heuristics.
 import sympy as sp
 n=len(R);parity=parity or [0]*n;seen=set();labs=[]
 for a in range(n):
  if a in seen:continue
  O=[];b=a
  while b not in O:O.append(b);b=sigma[b]
  if b!=a or m%len(O):raise ValueError('cyclic action')
  seen.update(O)
  for j in range(m//len(O)):labs.append((O,j))
 powers=[list(range(n))]
 for _ in range(1,m):powers.append([sigma[powers[-1][a]]for a in range(n)])
 x=sp.Symbol('x');phi=[int(v)for v in reversed(sp.Poly(sp.cyclotomic_poly(2*m,x),x).all_coeffs())];deg=len(phi)-1
 r=len(labs);T=[[[0]*r for _ in range(r)]for _ in range(r)]
 for i,(A,ja)in enumerate(labs):
  for j,(B,jb)in enumerate(labs):
   for k,(C,jc)in enumerate(labs):
    c=C[0];lc=len(C);co=[0]*(2*m)
    for h in range(0,m,lc):
     tr=sum(R[a][b][c]for a in A for b in B if powers[h][a]==a and powers[h][b]==b)
     co[((2*(ja+jb-jc)+parity[A[0]]+parity[B[0]]-parity[C[0]])*h)%(2*m)]+=tr
    for d in range(2*m-1,deg-1,-1):
     q=co[d]
     for t,v in enumerate(phi):co[d-deg+t]-=q*v
    divisor=m//lc
    if any(co[1:])or co[0]<0 or co[0]%divisor:raise ValueError('nonintegral Fourier projection')
    T[i][j][k]=co[0]//divisor
 return T,labs
