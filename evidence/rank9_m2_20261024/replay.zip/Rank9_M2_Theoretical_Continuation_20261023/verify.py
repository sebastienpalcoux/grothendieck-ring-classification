"""Replay the input audit and all accepted first-pass certificates, without network access."""
from pathlib import Path
import gzip,json,os,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory()as td:
 td=Path(td);tables=td/'tables.txt';tables.write_bytes(gzip.decompress((ROOT/'inputs/rank9_M2_verified/FusionRingMultiplicationTables.txt.gz').read_bytes()))
 exe=td/'verify_tables';subprocess.run(['g++','-O3','-std=c++17',str(ROOT/'sources/verify_tables.cpp'),'-o',str(exe)],check=True,capture_output=True)
 subprocess.run([str(exe),str(tables),str(td/'audit')],check=True)
 s=json.loads((td/'audit/summary.json').read_text());assert s['input_records']==s['distinct_rings']==2225 and s['duplicates']==0 and s['associativity_checked']
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
subprocess.run([sys.executable,str(ROOT/'work/verify_results.py'),'--fresh'],check=True,env=env)
r=json.loads((ROOT/'work/verification_results.json').read_text());assert len(r)==2083 and all(x['status']=='PASS'for x in r)
print('PASS: 2,225 distinct valid inputs; all 2,083 exact-multiplicity-two classification records replayed.')
