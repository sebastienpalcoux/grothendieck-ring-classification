# Classification software

These directories expose the exact exclusion engines and verification entry
points accompanying the rank-specific manuscripts. Restore the compressed
repository datasets with `python3 tools/restore_data.py` before running the
checks. Rank six includes the complete revised research release, including
its census data, model catalogs, accepted exclusion certificates and conformal constructions, exact proof sources and
verification records. Other rank directories describe any full source-release
inputs needed by their verifiers. Copying just `software/` and `verify.py`
does not create a self-contained verification run.

| Rank | Source | Required full input |
|---:|---|---|
| 4 | [`rank4/software/`](rank4/software/) and [`verify.py`](rank4/verify.py) | Rank-four source release, including 75.8 MB compressed classification ledger |
| 5 | [`rank5/software/`](rank5/software/) and [`verify.py`](rank5/verify.py) | Rank-five source release, including its decisions and exclusion certificates |
| 6 | [`rank6/software/`](rank6/software/) and [`verify.py`](rank6/verify.py) | Complete release; 25,362 excluded, 57 realized, 2 unresolved; complete through 3 and exact bands 1, 2, 3, 5, 6, 7, 9 |
| 7 | [`rank7/`](rank7/) | Complete census through 4; 4,164 generally excluded, 27 realized, 10 generally unresolved |
| 8 | [`rank8/`](rank8/) | Complete census through 2; 875 generally excluded, 72 realized, 26 generally unresolved |

The public [fusion-ring-census](https://github.com/sebastienpalcoux/fusion-ring-census)
continues to own the raw tensor census and enumeration code. See the
[verification guide](../docs/VERIFY.md) for the crosswalk and local checks.
Any copied licensed census code retains its license and notice in the
rank-specific software directory.


For the rank-six update, start with its [README](rank6/README.md),
[models](rank6/data/model_catalog.csv) and [current frontier](rank6/research/frontier/README.md).
The authoritative ledger is `rank6/data/decisions.json`. The archive is
`Rank6_Categorification_M9_Frontier_2026-10-01.zip`. Source-bound certificates retain their internal paths.

The [16 October theoretical update](../evidence/theoretical_20261016/README.md) adds 47 general exclusions, with no new realization. Together with the frozen October 2 stages, these updates resolve 104 rings: 91 general exclusions and 13 unitary models. Scope-specific obstructions remain separate from general categorification decisions. The earlier proofs and ledgers retain their historical replay. From the repository root, run `python3 tools/verify_theoretical_20261016.py` and its optimized-Python counterpart.
