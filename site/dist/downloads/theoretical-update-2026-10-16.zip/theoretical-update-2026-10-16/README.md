# Theoretical update — 16 October 2026

This bundle contains 47 new general exclusions, the full dated research
evidence, current rank-six through rank-eight manuscript sources and PDFs, and
the census data and ledgers used by the default verifier. General existence
remains unresolved for 2 rank-six, 10
rank-seven and 26 rank-eight rings. The precise scope of
additional pivotal and unitary results is retained in the proofs.

From this extracted directory, with Python 3.11+, SymPy 1.14.0 and NumPy 2.3.5
installed, run:

```sh
python3 tools/verify_theoretical_20261016.py
```

This default command is standalone: it checks the frozen proof-source manifest,
replays the exact verifiers, validates the new decisions and unresolved
inventory, and reconstructs the complete prior ledgers to check preservation of
every unchanged record. It prints a JSON receipt whose status must be PASS.
The mathematical proofs are in `evidence/theoretical_20261016/`.

The optional `--historical` and `--spectral` modes require the full repository
because their earlier-stage dependencies are intentionally outside this dated
bundle. Run those modes from a complete repository checkout.

`ARCHIVE_MANIFEST.json` records the byte size and SHA-256 of every bundled
source, manuscript and data file. `SHA256SUMS` additionally covers this README,
the requirements file and the manifest. The ZIP uses a fixed timestamp and
sorted paths; rebuilding identical frozen inputs gives identical ZIP bytes.

Manuscripts: `manuscripts/rank6/papers/manuscript.pdf`,
`manuscripts/rank6/papers/verification_guide.pdf`,
`manuscripts/rank7/papers/manuscript.pdf`, and
`manuscripts/rank8/paper/rank8.pdf`.

Repository: https://github.com/sebastienpalcoux/grothendieck-ring-classification
