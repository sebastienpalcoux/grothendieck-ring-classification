# Rank-7 Grothendieck rings through multiplicity 5

The 19 October rank-seven extension addresses all 5,805 exact-multiplicity-five rings: 5,789 general exclusions, 1 realization and 15 unresolved cases. The classification is complete through multiplicity 4. The new realization R7_5_5678 is Rep(AGL(1,7)). The unresolved records remain open for general complex categorification.

> **AI-generated research · independent verification pending.** Treat these
> results, proofs, code and data with caution. They have not yet been
> independently verified by human experts or formalized in Lean. Automated
> checks establish only their stated computational scope.

The authoritative decision ledger is [`output/rank7_ledger.json`](output/rank7_ledger.json). Classification is complete through multiplicity 4. Multiplicity 5 has unresolved classification records.

| Exact multiplicity | Rings | General exclusions | Unitary models | Open |
|---:|---:|---:|---:|---:|
| 1 | 43 | 30 | 13 | 0 |
| 2 | 319 | 309 | 10 | 0 |
| 3 | 1,059 | 1,057 | 2 | 0 |
| 4 | 2,780 | 2,776 | 4 | 0 |
| 5 | 5,805 | 5,789 | 1 | 15 |
| **Total** | **10,006** | **9,961** | **30** | **15** |

[Manuscript source](../../manuscripts/rank7/papers/manuscript.tex) · [PDF](../../manuscripts/rank7/papers/manuscript.pdf) · [Research status](../../docs/RESEARCH_STATUS.md)

From the repository root:

```bash
python3 tools/restore_data.py
python3 tools/verify_current_publication.py --historical
python3 -O tools/verify_current_publication.py --historical
```

The history option checks source-bound dependencies in isolated compatible
snapshots. These continuation checks do not replace the complete base-certificate
loops in the [full replay guide](../../evidence/prepublication_20261017/FULL_REPLAY.md).
Use normal Python for assertion-based checkers. Positive counts in an incomplete
band are lower bounds; a timeout or surviving necessary system proves no exclusion.
See [verification scope](../../docs/PREPUBLICATION_REVIEW.md).

## Multiplicity-five continuation

The current continuation is replayed with:

```bash
python3 supplements/rank7/software/verify_m5.py
python3 -O supplements/rank7/software/verify_m5.py
```

Use `--metadata-only` only for source and partition checks; it does not replay mathematical certificates.
The older top-level `analyze.py` and `verify.py` retain their M4 source commitments; run them in the preserved M4 archive, not against the extended source file.
The M5 release archive uses repository-relative directories and includes the frozen M4 archive.
