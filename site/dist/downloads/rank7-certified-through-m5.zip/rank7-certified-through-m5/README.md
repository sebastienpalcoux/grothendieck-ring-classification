# Rank-seven continuation through multiplicity five

AI-generated research; independent human verification and Lean formalization pending.

This archive preserves the earlier 4201 records and supplies all 5805 new records,
exact negative certificates, the Rep(AGL(1,7)) character model, and the open frontier.
The supplied census completeness claim is producer-reported; this continuation
checks source coverage and certificates, not a fresh full census enumeration.

From this directory, with Python3, SymPy, NumPy and a C++17 compiler:

```sh
python supplements/rank7/software/verify_m5.py --jobs 4
python -O supplements/rank7/software/verify_m5.py --jobs 4
```

Metadata-only checks use `--metadata-only` and do not replay proofs.
SciPy is optional for discovery routines and is not required for exact replay.
The immutable earlier full replay package is retained at
`supplements/rank7/release/rank7-certified-through-m4.zip`.
The current manuscript is `manuscripts/rank7/papers/manuscript.pdf`.
